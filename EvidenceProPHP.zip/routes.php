<?php

use App\Controller\AuthMobileController;
use App\Controller\UserController;
use App\Controller\VerifyController;
use App\Controller\DrugsController;
use App\Controller\MobileController;
use FastRoute\RouteCollector;

return function (RouteCollector $router) {

    $authMobileController = new AuthMobileController();
    $userController = new UserController();
    $verifyController = new VerifyController();
    $drugsController = new DrugsController();
    $mobileController = new MobileController();


    // Public routes
    $router->post("/auth/verify", [$verifyController, 'verify']);
    $router->post("/auth/verify-resend", [$verifyController, 'verifyResend']);
    $router->post("/auth/forgot-password", [$verifyController, 'forgotPassword']);
    $router->post("/auth/recover-password-check", [$verifyController, 'recoverPasswordCheck']);
    $router->post("/auth/recover-password", [$verifyController, 'recoverPassword']);
    $router->post("/auth/login", [$authMobileController, 'login']);
    $router->post("/auth/register", [$authMobileController, 'register']);
    $router->post("/is-close-app", [$mobileController, 'isCloseApp']);


    // Protected routes
    $router->addGroup('/api', function (RouteCollector $router) use ($userController, $mobileController, $authMobileController, $drugsController) {

        $router->post("/user/change-email", [$userController, 'changeEmail']);
        $router->post("/user/change-password", [$userController, 'changePassword']);
        $router->post("/user/delete-user", [$userController, 'deleteUser']);
        $router->post("/user/payment-status", [$userController, 'paymentStatus']);
        $router->post("/user/payment-expire", [$userController, 'paymentExpire']);
        $router->post("/user/favorites", [$userController, 'getUserFavorites']);
        $router->post("/user/favorites/calcs", [$userController, 'getUserCalcs']);
        $router->post("/user/favorites-delete", [$userController, 'deleteUserFavorite']);
        $router->post("/user/favorites-add", [$userController, 'addUserFavorite']);

        $router->post("/drug-disease-search", [$drugsController, 'drugDiseaseSearch']);
        $router->post("/drug-disease", [$drugsController, 'drugDisease']);
        $router->post("/drug-pregnancy-search", [$drugsController, 'drugPregnancySearch']);
        $router->post("/drug-pregnancy", [$drugsController, 'drugPregnancy']);
        $router->post("/drug-heptox-list", [$drugsController, 'drugHeptoxList']);
        $router->get("/drug-heptox/{hepdrug}", [$drugsController, 'drugHeptoxItem']);
        $router->post("/drug-pulmtox-list", [$drugsController, 'drugPulmtoxList']);
        $router->get("/drug-pulmtox/{pulmdrug}", [$drugsController, 'drugPulmtoxItem']);
        $router->get("/drug-pulmtox-subpattern/{subpattern}", [$drugsController, 'drugPulmtoxSubpattern']);
        $router->post("/drug-pulmtox-pattern", [$drugsController, 'drugPulmtoxPattern']);
        $router->post("/drug-nephtox-list", [$drugsController, 'drugNephtoxList']);
        $router->get("/drug-nephtox/{nephdrug}", [$drugsController, 'drugNephtoxItem']);
        $router->post("/drug-nephtox-disease", [$drugsController, 'drugNephtoxDisease']);
        $router->get("/drug-nephtox-disease/{nephdisease}", [$drugsController, 'drugNephtoxDiseaseItem']);
        $router->post("/drug-nephtox-morphology", [$drugsController, 'drugNephtoxMorphology']);
        $router->get("/drug-nephtox-morphology/{nephmorphology}", [$drugsController, 'drugNephtoxMorphologyItem']);
        $router->post("/drug-olders-search", [$drugsController, 'drugOldersSearch']);
        $router->post("/drug-olders", [$drugsController, 'drugOlders']);
        $router->post("/drug-qt-search", [$drugsController, 'drugQtSearch']);
        $router->get("/drug-qt/{qtdrug}", [$drugsController, 'drugQt']);
        $router->post("/drug-qt-factor", [$drugsController, 'drugQtFactor']);
        $router->post("/drug-qt-indication", [$drugsController, 'drugQtIndication']);
        $router->post("/drug-qt-search/calc", [$drugsController, 'drugQtSearchCalc']);
        $router->post("/drug-methem", [$drugsController, 'drugMethem']);
        $router->post("/drug-disl", [$drugsController, 'drugDisl']);

        //mobile
        $router->post("/user/notifications", [$mobileController, 'getUserNotifications']);
        $router->post("/user/notifications/change", [$mobileController, 'changeUserNotifications']);
        $router->post("/user/get-screenshots-quantity", [$mobileController, 'screenshotsQuantity']);
        $router->post("/user/get-device-block", [$mobileController, 'deviceBlock']);
        $router->post("/user", [$authMobileController, 'getCurrentUser']);
        $router->post("/auth/logout", [$authMobileController, 'logout']);
        $router->get("/auth/refresh-token", [$authMobileController, 'refreshToken']);
        $router->post("/auth/check-device/native", [$mobileController, 'checkDevice']);
    });
};