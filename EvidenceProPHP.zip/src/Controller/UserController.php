<?php

namespace App\Controller;

use App\Helpers\Auth;
use App\Helpers\SendEmail;
use App\Model\Model;



class UserController
{
   public Model $model;

   public function __construct()
   {
      $this->model = new Model();
   }

   public function changeEmail()
   {
      Auth::check();

      $data = file_get_contents("php://input");

      if (empty($data)) {
         http_response_code(400);
         echo json_encode([
            "status" => false,
            "message" => "error"
         ]);
         return;
      }

      $request = json_decode($data);
      $old_email = $request->oldemail;
      $password = $request->pass;
      $email = $request->email;

      $getUserWithNewEmail = $this->model->getUserWithEmail($email);

      if ($getUserWithNewEmail) {
         http_response_code(200);
         echo json_encode([
            "status" => true,
            "message" => ["already"]
         ]);
         exit();
      }

      $getUserWithEmail = $this->model->getUserWithEmail($old_email);
      if ($getUserWithEmail) {
         $email_change_quantity = $getUserWithEmail[0]['email_change_quantity'];

         if (!empty($email_change_quantity)) {
            http_response_code(200);
            echo json_encode([
               "status" => true,
               "message" => ["email_limit"]
            ]);
            exit();
         }

         $user_password = $getUserWithEmail[0]['password'];

         if (password_verify($password, $user_password)) {
            $username = $getUserWithEmail[0]['username'];
            $userverifycode = $getUserWithEmail[0]['verify_code'];

            if ($getUserWithEmail[0]['verify_code_time'] + 24 * 3600 > time()) {
               http_response_code(200);
               echo json_encode([
                  "status" => true,
                  "message" => ['limit']
               ]);
               exit();
            } else {
               $new_verify_code = md5($username . time());
               $verify_status = 0;
               $new_verify_code_time = time();
               $changeUserMail = $this->model->changeUserMail($email, $new_verify_code, $verify_status, $new_verify_code_time, 1, $old_email);
               if ($changeUserMail) {
                  // mail
                  // $subject = 'Ակտիվացման կոդ';
                  // $body = "<h4 style='color: rgb(23, 88, 131); line-height: 1.6; font-size: 23px;'>Ակտիվացման կոդ։</h4> <p style='margin: 5px 0; line-height: 1.6; font-size: 21px;'>Անձնական էջը ակտիվացնելու համար անցեք <a href='https://evidence.am/verify/$new_verify_code' target='_blank' style='color: rgb(24, 123, 169);'>հետևյալ հղումով</a>:</p> <p style='line-height: 1.6; font-size: 20px;'>Մի փոխանցեք ակտիվացման կոդը այլ անձանց։</p>";
                  // SendEmail::sendEmailStat($email, $subject, $body);

                  http_response_code(200);
                  echo json_encode([
                     "status" => true,
                     "message" => ['success']
                  ]);
                  exit();
               }
            }
         } else {
            http_response_code(200);
            echo json_encode([
               "status" => true,
               "message" => ["wrong password"]
            ]);
            exit();
         }
      }
   }

   public function changePassword()
   {
      Auth::check();

      $data = file_get_contents("php://input");

      if (empty($data)) {
         http_response_code(400);
         echo json_encode([
            "status" => false,
            "message" => "error"
         ]);
         return;
      }

      $request = json_decode($data);
      $email = $request->email;
      $old_password = $request->oldpass;
      $new_password = $request->newpass;

      $getUserWithEmail = $this->model->getUserWithEmail($email);
      $user_password = $getUserWithEmail[0]['password'];

      if (password_verify($old_password, $user_password)) {
         if ($getUserWithEmail[0]['pass_recovery_quantity'] < 2) {
            $pass_hash = password_hash($new_password, PASSWORD_DEFAULT);

            $pass_recovery_quantity = $getUserWithEmail[0]['pass_recovery_quantity'] + 1;
            $pass_recovery_time = time();

            $changeUserPassword = $this->model->changeUserPassword($pass_hash, $pass_recovery_quantity, $pass_recovery_time, $email);
            if ($changeUserPassword) {
               // mail
               // SendEmail::sendEmailStat($email);
               http_response_code(200);
               echo json_encode([
                  "status" => true,
                  "message" => ["success"]
               ]);
            }
         } else {
            http_response_code(200);
            echo json_encode([
               "status" => true,
               "message" => ["limit"]
            ]);
         }
      } else {
         http_response_code(200);
         echo json_encode([
            "status" => true,
            "message" => ["wrong password"]
         ]);
      }
   }

   public function deleteUser()
   {
      $user = Auth::check();

      $data = file_get_contents("php://input");

      if (empty($data)) {
         http_response_code(400);
         echo json_encode([
            "status" => false,
            "message" => "error"
         ]);
         return;
      }

      $uid = json_decode($data);

      if ($user->id !== +$uid) {
         http_response_code(403);
         echo json_encode([
            "status" => false,
            "message" => "Unauthorized access"
         ]);
         return;
      }

      $filePath = __DIR__ . '../../data/logs/user_delete.txt';
      $logEntry = "User ID: $user->id, Email: $user->email, Username: $user->username, Name: $user->name, Surname: $user->surname\n";
      file_put_contents($filePath, $logEntry, FILE_APPEND);

      $getUserAppWithUid = $this->model->getUserAppWithUid($uid);

      if ($getUserAppWithUid) {
         $this->model->deleteUserAppWithUniqueId($getUserAppWithUid[0]['unique_id']);
      }

      $this->model->deleteUserAppWithUid($uid);
      $this->model->deleteUserAcc($uid);
   }

   public function paymentStatus()
   {
      $user = Auth::check();

      $data = file_get_contents("php://input");

      if (empty($data)) {
         http_response_code(400);
         echo json_encode([
            "status" => false,
            "message" => "error"
         ]);
         return;
      }

      $request = json_decode($data);
      $uid = $request->uid;

      if ($user->id !== +$uid) {
         http_response_code(403);
         echo json_encode([
            "status" => false,
            "message" => "Unauthorized access"
         ]);
         return;
      }

      $platform = isset($request->platform) ? $request->platform : null;

      $platformPayment = [];

      if ($platform === 'ios') {

      } else if ($platform === 'android') {

      } else {
         $getUserPayment = $this->model->getUserPayment($uid);

         if ($getUserPayment)
            $platformPayment[] = $getUserPayment[0]['payment'];
      }

      http_response_code(200);
      echo json_encode([
         "status" => true,
         "data" => $platformPayment
      ]);
   }

   public function paymentExpire()
   {
      $user = Auth::check();

      $data = file_get_contents("php://input");

      if (empty($data)) {
         http_response_code(400);
         echo json_encode([
            "status" => false,
            "message" => "error"
         ]);
         return;
      }

      $request = json_decode($data);
      $uid = $request->uid;

      if ($user->id !== +$uid) {
         http_response_code(403);
         echo json_encode([
            "status" => false,
            "message" => "Unauthorized access"
         ]);
         return;
      }

      $platform = isset($request->platform) ? $request->platform : null;

      $platformPaymentExpire = [];

      if ($platform === 'ios') {
      } else if ($platform === 'android') {
      } else {
         $getUserPayment = $this->model->getUserPayment($uid);

         if ($getUserPayment)
            $platformPaymentExpire[] = $getUserPayment[0]['payment_expire'];
      }

      if (count($platformPaymentExpire) > 0) {
         $date = explode(' ', $platformPaymentExpire[0])[0];
         http_response_code(200);
         echo json_encode([
            "status" => true,
            "data" => [
               $date
            ]
         ]);
      }
   }

   public function getUserFavorites()
   {
      $user = Auth::check();
      Auth::checkPayment($this->model, $user->id, $user->platform);

      $getUserFavoritesWithUid = $this->model->getUserFavoritesWithUid($user->id);

      if ($getUserFavoritesWithUid) {
         $tempGrouped = [];

         foreach ($getUserFavoritesWithUid as $item) {
            $category = $item['category'];

            if (!isset($tempGrouped[$category])) {
               $tempGrouped[$category] = [];
            }

            $tempGrouped[$category][] = [
               'favorites_id' => $item['favorites_id'],
               'title' => $item['title'],
               'link' => $item['link'],
            ];
         }

         $grouped = [];
         foreach ($tempGrouped as $category => $items) {
            $grouped[] = [
               'title' => $category,
               'group' => $items,
            ];
         }

         http_response_code(200);
         echo json_encode([
            "status" => true,
            "data" => $grouped
         ]);
      } else {
         http_response_code(200);
         echo json_encode([
            "status" => true,
            "data" => []
         ]);
      }
   }

   public function getUserCalcs()
   {
      $user = Auth::check();
      Auth::checkPayment($this->model, $user->id, $user->platform);

      $getUserFavoritesWithUidAndCategory = $this->model->getUserFavoritesWithUidAndCategory($user->id, 'calc');

      $result = [];

      if ($getUserFavoritesWithUidAndCategory) {
         foreach ($getUserFavoritesWithUidAndCategory as $value) {
            $result[] = $value['favorites_id'];
         }

         http_response_code(200);
         echo json_encode([
            "status" => true,
            "data" => $result
         ]);
      } else {
         http_response_code(200);
         echo json_encode([
            "status" => true,
            "data" => []
         ]);
      }
   }

   public function deleteUserFavorite()
   {
      $user = Auth::check();
      Auth::checkPayment($this->model, $user->id, $user->platform);

      $data = file_get_contents("php://input");

      if (empty($data)) {
         http_response_code(400);
         echo json_encode([
            "status" => false,
            "message" => "error"
         ]);
         return;
      }

      $request = json_decode($data);

      $deleteUserFavorites = $this->model->deleteUserFavorites($user->id, $request);

      if ($deleteUserFavorites) {
         http_response_code(200);
         echo json_encode([
            "status" => true,
            "message" => "success"
         ]);
      } else {
         http_response_code(400);
         echo json_encode([
            "status" => false,
            "message" => "error"
         ]);
      }
   }

   public function addUserFavorite()
   {
      $user = Auth::check();
      Auth::checkPayment($this->model, $user->id, $user->platform);

      $data = file_get_contents("php://input");

      if (empty($data)) {
         http_response_code(400);
         echo json_encode([
            "status" => false,
            "message" => "error"
         ]);
         return;
      }

      $request = json_decode($data);

      $uid = $request->uid;

      if ($user->id !== +$uid) {
         http_response_code(403);
         echo json_encode([
            "status" => false,
            "message" => "Unauthorized access"
         ]);
         return;
      }

      $category = $request->category;
      $favorites_id = $request->favorites_id;
      $title = $request->title;
      $link = $request->link;

      $addUserFavorites = $this->model->addUserFavorites($uid, $category, $favorites_id, $title, $link);

      if ($addUserFavorites) {
         http_response_code(200);
         echo json_encode([
            "status" => true,
            "message" => "success"
         ]);
      } else {
         http_response_code(400);
         echo json_encode([
            "status" => false,
            "message" => "error"
         ]);
      }
   }
}