<?php

namespace App\Controller;

use App\Model\Model;
use App\Helpers\Auth;
use App\Helpers\Fuse;
use App\Helpers\Functions;


class DrugsController
{
   public Model $model;

   public function __construct()
   {
      $this->model = new Model();
   }

   public function drugDiseaseSearch()
   {
      $user = Auth::check();
      Auth::checkPayment($this->model, $user->id, $user->platform);

      $data = file_get_contents("php://input");

      if (empty($data)) {
         http_response_code(400);
         echo json_encode([
            "status" => false,
            "message" => "error"
         ]);
         return;
      }

      $request = json_decode($data);
      $type = $request->type;
      $value = $request->value;

      $result = [];
      $translit = Functions::textTranslit($value);

      if ($type === 'drug') {
         $searchDrugDiseaseByDrug = $this->model->searchDrugDiseaseByDrug($translit);

         if (count($searchDrugDiseaseByDrug) === 0) {
            $getDrugDiseaseDrug = $this->model->getDrugDiseaseDrug();
            $fuseResult = Fuse::fuseSearch($getDrugDiseaseDrug, $value);

            if ($fuseResult) {
               $result = $fuseResult;
            }
         } else {
            $result = $searchDrugDiseaseByDrug;
         }
      } else {
         $searchDrugDiseaseByDis = $this->model->searchDrugDiseaseByDis($translit);

         if ($searchDrugDiseaseByDis) {
            $drugsList = [];

            $full_data = file_get_contents(__DIR__ . '../../data/full-list.json');
            $full_data_decode = json_decode($full_data, true);

            foreach ($searchDrugDiseaseByDis as $str) {
               $exploded = explode(' ', $str['drug']);
               $disease = $str['disease'];
               foreach ($exploded as $value1) {
                  foreach ($full_data_decode as $value2) {
                     if ($value1 === $value2['id']) {
                        $value2['disease'] = $disease;
                        $drugsList[] = $value2;
                     }
                  }
               }
            }

            foreach ($drugsList as $item) {
               $result[$item['id']] = $item;
            }

            $result = array_values($result);

            usort($result, function ($a, $b) {
               return strcmp($a['id'], $b['id']);
            });
         }
      }

      http_response_code(200);
      echo json_encode([
         'status' => true,
         'data' => $result
      ]);
   }

   public function drugDisease()
   {
      $user = Auth::check();
      Auth::checkPayment($this->model, $user->id, $user->platform);

      $data = file_get_contents("php://input");

      if (empty($data)) {
         http_response_code(400);
         echo json_encode([
            "status" => false,
            "message" => "error"
         ]);
         exit();
      }

      $data = json_decode($data);

      $request = explode(':', $data);

      if (strpos($request[1], '--') != false) {
         $itemArr = explode('--', $request[1]);
         $resultArr = [];

         foreach ($itemArr as $value) {
            $label = Functions::searchFullData($value, 'label');

            $getDrugDisease = $this->model->getDrugDisease($value);

            if ($getDrugDisease) {
               foreach ($getDrugDisease as $val) {

                  $disRef = $val['refs'];

                  $disRefToArr = explode('+', $disRef);
                  $resultArr[] = array(
                     'disease' => $val['disease'],
                     'class' => $val['class'],
                     'text' => $val['text'],
                     'risk' => $val['risk'],
                     'refs' => $disRefToArr,
                     'label' => $label
                  );
               }
            }
         }

         if ($resultArr) {
            usort($resultArr, function ($item1, $item2) {
               if ($item1['risk'] == $item2['risk'])
                  return 0;
               return $item1['risk'] < $item2['risk'] ? -1 : 1;
            });

            http_response_code(200);
            echo json_encode([
               "status" => true,
               "data" => $resultArr
            ]);
         }

      } else {

         $getDrugDisease = $this->model->getDrugDisease($request[1]);

         if ($getDrugDisease) {
            $resultArr = [];
            $label = Functions::searchFullData($request[1], 'label');

            foreach ($getDrugDisease as $value) {
               $disRef = $value['refs'];

               $disRefToArr = explode('+', $disRef);
               $resultArr[] = array(
                  'disease' => $value['disease'],
                  'class' => $value['class'],
                  'text' => $value['text'],
                  'risk' => $value['risk'],
                  'refs' => $disRefToArr,
                  'label' => $label
               );
            }

            http_response_code(200);
            echo json_encode([
               "status" => true,
               "data" => $resultArr
            ]);
         }
      }
   }

   public function drugPregnancySearch()
   {
      $user = Auth::check();
      Auth::checkPayment($this->model, $user->id, $user->platform);

      $data = file_get_contents("php://input");

      if (empty($data)) {
         http_response_code(400);
         echo json_encode([
            "status" => false,
            "message" => "error"
         ]);
         exit();
      }

      $data = json_decode($data);
      $translit = Functions::textTranslit($data);

      $searchPregnancyDrug = $this->model->searchPregnancyDrug($translit, 1);

      if ($searchPregnancyDrug) {
         http_response_code(200);
         echo json_encode([
            "status" => true,
            "data" => $searchPregnancyDrug
         ]);
      } else {
         http_response_code(200);
         echo json_encode([
            "status" => true,
            "data" => []
         ]);
      }
   }

   public function drugPregnancy()
   {
      $user = Auth::check();
      Auth::checkPayment($this->model, $user->id, $user->platform);

      $data = file_get_contents("php://input");

      if (empty($data)) {
         http_response_code(400);
         echo json_encode([
            "status" => false,
            "message" => "error"
         ]);
         exit();
      }

      $data = json_decode($data);
      $request = explode(':', $data);

      $getPregnancyDrug = $this->model->getPregnancyDrug($request[1]);

      if ($getPregnancyDrug) {
         $response = [];

         foreach ($getPregnancyDrug as $key => $value) {
            $response[] = [
               'id' => $value['id'],
               'label' => $value['label'],
            ];

            if (!empty($value['pregnancy_fda']))
               $response[$key]['pregnancy_fda'] = $value['pregnancy_fda'];

            if (!empty($value['pregnancy_au']))
               $response[$key]['pregnancy_au'] = $value['pregnancy_au'];

            if (!empty($value['pregnancy_text']))
               $response[$key]['pregnancy_text'] = $value['pregnancy_text'];

            if (!empty($value['pregnancy_refs'])) {
               $response[$key]['pregnancy_refs'] = Functions::changeRefersToArr('+', $value['pregnancy_refs']);
            }
         }

         http_response_code(200);
         echo json_encode([
            "status" => true,
            "data" => $response
         ]);
      } else {
         http_response_code(404);
         echo json_encode([
            "status" => false,
            "message" => '404'
         ]);
      }
   }

   public function drugHeptoxList()
   {
      $user = Auth::check();
      Auth::checkPayment($this->model, $user->id, $user->platform);

      $getDrugHeptoxList = $this->model->getDrugHeptoxList(1);

      if ($getDrugHeptoxList) {
         http_response_code(200);
         echo json_encode([
            "status" => true,
            "data" => $getDrugHeptoxList
         ]);
      } else {
         http_response_code(400);
         echo json_encode([
            "status" => false,
            "message" => "error"
         ]);
      }
   }

   public function drugHeptoxItem($hepdrug)
   {
      $user = Auth::check();
      Auth::checkPayment($this->model, $user->id, $user->platform);

      $request = explode(':', $hepdrug);

      $getDrugHeptoxItem = $this->model->getDrugHeptoxItem($request[1]);

      $result = [];

      if ($getDrugHeptoxItem) {

         foreach ($getDrugHeptoxItem as $key => $value) {
            $result[] = [
               'id' => $value['id'],
               'label' => $value['label'],
            ];

            if (!empty($value['heptox_score']))
               $result[$key]['heptox_score'] = $value['heptox_score'];

            if (!empty($value['heptox_text']))
               $result[$key]['heptox_text'] = $value['heptox_text'];

            if (!empty($value['heptox_note']))
               $result[$key]['heptox_note'] = $value['heptox_note'];

            if (!empty($value['heptox_outcome']))
               $result[$key]['heptox_outcome'] = $value['heptox_outcome'];

            if (!empty($value['heptox_refs'])) {
               $result[$key]['heptox_refs'] = Functions::changeRefersToArr('+', $value['heptox_refs']);
            }
         }

         http_response_code(200);
         echo json_encode([
            "status" => true,
            "data" => $result
         ]);
      } else {
         http_response_code(404);
         echo json_encode([
            "status" => false,
            "message" => '404'
         ]);
      }
   }

   public function drugPulmtoxList()
   {
      $user = Auth::check();
      Auth::checkPayment($this->model, $user->id, $user->platform);

      $data = file_get_contents("php://input");

      if (empty($data)) {
         http_response_code(400);
         echo json_encode([
            "status" => false,
            "message" => "error"
         ]);
         exit();
      }

      $request = json_decode($data);

      if ($request === 'другие') {
         $getDrugPulmtoxOtherList = $this->model->getDrugPulmtoxOtherList($request, 1);

         if ($getDrugPulmtoxOtherList) {
            http_response_code(200);
            echo json_encode([
               "status" => true,
               "data" => $getDrugPulmtoxOtherList
            ]);
         } else {
            http_response_code(400);
            echo json_encode([
               "status" => false,
               "message" => "error"
            ]);
         }
      } else {
         $getDrugPulmtoxList = $this->model->getDrugPulmtoxList($request, 1);

         if ($getDrugPulmtoxList) {
            http_response_code(200);
            echo json_encode([
               "status" => true,
               "data" => $getDrugPulmtoxList
            ]);
         } else {
            http_response_code(400);
            echo json_encode([
               "status" => false,
               "message" => "error"
            ]);
         }
      }
   }

   public function drugPulmtoxItem($pulmdrug)
   {
      $user = Auth::check();
      Auth::checkPayment($this->model, $user->id, $user->platform);

      $request = explode(':', $pulmdrug);
      $itemArray = [];

      $getDrugPulmtoxItem = $this->model->getDrugPulmtoxItem($request[1]);

      if ($getDrugPulmtoxItem) {
         $itemArray = $getDrugPulmtoxItem;
      } else {
         $getDrugPulmtoxOtherItem = $this->model->getDrugPulmtoxOtherItem($request[1]);

         if ($getDrugPulmtoxOtherItem) {
            $itemArray = $getDrugPulmtoxOtherItem;
         } else {
            http_response_code(404);
            echo json_encode([
               "status" => false,
               "message" => '404'
            ]);
            exit();
         }
      }

      if (count($itemArray) > 0) {
         $result = [];

         $pulmtox_subpatterns_cases = explode('+', $itemArray[0]['pulmtox_subpatterns_cases']);
         $pulmtox_subpatterns = explode('+', $itemArray[0]['pulmtox_subpatterns']);
         $pulmtox_refs = json_decode($itemArray[0]['pulmtox_refs'], true);

         $pulmtox_subpatterns_arr = [];
         foreach ($pulmtox_subpatterns as $val) {
            $getDrugPulmtoxSubpatternById = $this->model->getDrugPulmtoxSubpatternById($val);
            $pulmtox_subpatterns_arr[] = $getDrugPulmtoxSubpatternById[0];
         }

         foreach ($pulmtox_subpatterns_arr as $item) {
            unset($item['subpattern_text']);
         }

         $result[] = [
            'id' => $itemArray[0]['id'],
            'label' => $itemArray[0]['label'],
            'pulmtox_cases' => $itemArray[0]['pulmtox_cases'],
            'pulmtox_subpatterns' => $pulmtox_subpatterns_arr,
            'pulmtox_subpatterns_cases' => $pulmtox_subpatterns_cases,
            'pulmtox_refs' => $pulmtox_refs,
         ];

         http_response_code(200);
         echo json_encode([
            "status" => true,
            "data" => $result
         ]);
      }
   }

   public function drugPulmtoxSubpattern($subpattern)
   {
      $user = Auth::check();
      Auth::checkPayment($this->model, $user->id, $user->platform);

      $getDrugPulmtoxSubpatternById = $this->model->getDrugPulmtoxSubpatternById($subpattern);

      if ($getDrugPulmtoxSubpatternById) {
         $getDrugPulmtoxWithSubpatternId = $this->model->getDrugPulmtoxWithSubpatternId($subpattern);

         $drugSubpattern = [];

         if ($getDrugPulmtoxWithSubpatternId) {

            foreach ($getDrugPulmtoxWithSubpatternId as $value) {
               $value['pulmtox_subpatterns'] = explode('+', $value['pulmtox_subpatterns']);
               $value['pulmtox_subpatterns_cases'] = explode('+', $value['pulmtox_subpatterns_cases']);
               foreach ($value['pulmtox_subpatterns'] as $key => $item) {
                  if ($item == $subpattern) {
                     $drugSubpattern[] = [
                        "id" => $value['id'],
                        "label" => $value['label'],
                        "link" => $value['link'],
                        "pulmtox_subpattern_cases" => $value['pulmtox_subpatterns_cases'][$key]
                     ];
                  }
               }
            }

            $getDrugPulmtoxSubpatternById[0]['drugs'] = $drugSubpattern;

         }

         http_response_code(200);
         echo json_encode([
            "status" => true,
            "data" => $getDrugPulmtoxSubpatternById
         ]);

      } else {
         http_response_code(404);
         echo json_encode([
            "status" => false,
            "message" => '404'
         ]);
      }
   }

   public function drugPulmtoxPattern()
   {
      $user = Auth::check();
      Auth::checkPayment($this->model, $user->id, $user->platform);

      $getDrugPulmtoxPattern = $this->model->getDrugPulmtoxPattern();

      if ($getDrugPulmtoxPattern) {
         $result = [];

         foreach ($getDrugPulmtoxPattern as $pattern) {
            $getDrugPulmtoxByPatternId = $this->model->getDrugPulmtoxByPatternId($pattern['pattern_id']);

            $result[] = [
               'pattern_id' => $pattern['pattern_id'],
               'pattern_number' => $pattern['pattern_number'],
               'pattern_title' => $pattern['pattern_title'],
               'subpattern' => $getDrugPulmtoxByPatternId
            ];
         }

         http_response_code(200);
         echo json_encode([
            "status" => true,
            "data" => $result
         ]);
      } else {
         http_response_code(400);
         echo json_encode([
            "status" => false,
            "message" => "error"
         ]);
      }
   }

   public function drugNephtoxList()
   {
      $user = Auth::check();
      Auth::checkPayment($this->model, $user->id, $user->platform);

      $getDrugNephtoxList = $this->model->getDrugNephtoxList(1);

      if ($getDrugNephtoxList) {

         http_response_code(200);
         echo json_encode([
            "status" => true,
            "data" => $getDrugNephtoxList
         ]);
      } else {
         http_response_code(400);
         echo json_encode([
            "status" => false,
            "message" => "error"
         ]);
      }
   }

   public function drugNephtoxItem($nephdrug)
   {
      $user = Auth::check();
      Auth::checkPayment($this->model, $user->id, $user->platform);

      $request = explode(':', $nephdrug);

      $result = [];
      $diseases = [];
      $morphologies = [];

      $getDrugNephtoxItem = $this->model->getDrugNephtoxItem($request[1]);

      if ($getDrugNephtoxItem) {
         if (!empty($getDrugNephtoxItem[0]['nephtox_diseases'])) {
            $diseaseToArr = explode('+', $getDrugNephtoxItem[0]['nephtox_diseases']);

            foreach ($diseaseToArr as $disease_number) {
               $getDrugNephtoxItemDisease = $this->model->getDrugNephtoxItemDisease($disease_number);
               if ($getDrugNephtoxItemDisease) {
                  $diseases[] = $getDrugNephtoxItemDisease[0];
               }
            }
         }

         if (!empty($getDrugNephtoxItem[0]['nephtox_morphologies'])) {
            $morphologyToArr = explode('+', $getDrugNephtoxItem[0]['nephtox_morphologies']);

            foreach ($morphologyToArr as $morphology_number) {
               $getDrugNephtoxItemMorphology = $this->model->getDrugNephtoxItemMorphology($morphology_number);
               if ($getDrugNephtoxItemMorphology) {
                  $morphologies[] = $getDrugNephtoxItemMorphology[0];
               }
            }
         }

         $result[] = [
            'id' => $getDrugNephtoxItem[0]['id'],
            'label' => $getDrugNephtoxItem[0]['label'],
            'link' => $getDrugNephtoxItem[0]['link'],
            'nephtox_diseases' => $diseases,
            'nephtox_morphologies' => $morphologies,
         ];

         if (!empty($getDrugNephtoxItem[0]['nephtox_refs'])) {
            $result[0]['nephtox_refs'] = $getDrugNephtoxItem[0]['nephtox_refs'];
         }

         http_response_code(200);
         echo json_encode([
            "status" => true,
            "data" => $result
         ]);
      } else {
         http_response_code(404);
         echo json_encode([
            "status" => false,
            "message" => '404'
         ]);
      }

   }

   public function drugNephtoxDisease()
   {
      $user = Auth::check();
      Auth::checkPayment($this->model, $user->id, $user->platform);

      $getDrugNephtoxDisease = $this->model->getDrugNephtoxDisease();

      if ($getDrugNephtoxDisease) {
         http_response_code(200);
         echo json_encode([
            "status" => true,
            "data" => $getDrugNephtoxDisease
         ]);
      } else {
         http_response_code(400);
         echo json_encode([
            "status" => true,
            "message" => 'error'
         ]);
      }
   }

   public function drugNephtoxDiseaseItem($nephdisease)
   {
      $user = Auth::check();
      Auth::checkPayment($this->model, $user->id, $user->platform);

      $getDrugNephtoxDiseaseItem = $this->model->getDrugNephtoxDiseaseItem(+$nephdisease);
      $result = [];

      if ($getDrugNephtoxDiseaseItem) {
         $result[] = $getDrugNephtoxDiseaseItem[0];

         $getDrugNephtoxWithDisease = $this->model->getDrugNephtoxWithDisease($nephdisease);

         if ($getDrugNephtoxWithDisease) {
            $result[0]['drugs'] = $getDrugNephtoxWithDisease;
         }

         http_response_code(200);
         echo json_encode([
            "status" => true,
            "data" => $result
         ]);
      } else {
         http_response_code(404);
         echo json_encode([
            "status" => false,
            "message" => '404'
         ]);
      }
   }

   public function drugNephtoxMorphology()
   {
      $user = Auth::check();
      Auth::checkPayment($this->model, $user->id, $user->platform);

      $getDrugNephtoxMorphology = $this->model->getDrugNephtoxMorphology();

      if ($getDrugNephtoxMorphology) {
         http_response_code(200);
         echo json_encode([
            "status" => true,
            "data" => $getDrugNephtoxMorphology
         ]);
      } else {
         http_response_code(400);
         echo json_encode([
            "status" => true,
            "message" => 'error'
         ]);
      }
   }

   public function drugNephtoxMorphologyItem($nephmorphology)
   {
      $user = Auth::check();
      Auth::checkPayment($this->model, $user->id, $user->platform);

      $getDrugNephtoxMorphologyItem = $this->model->getDrugNephtoxMorphologyItem(+$nephmorphology);

      if ($getDrugNephtoxMorphologyItem) {
         $result = [];

         $result[] = $getDrugNephtoxMorphologyItem[0];

         $getDrugNephtoxWithMorphology = $this->model->getDrugNephtoxWithMorphology($nephmorphology);

         if ($getDrugNephtoxWithMorphology) {
            $result[0]['drugs'] = $getDrugNephtoxWithMorphology;
         }

         http_response_code(200);
         echo json_encode([
            "status" => false,
            "data" => $result
         ]);
      } else {
         http_response_code(404);
         echo json_encode([
            "status" => false,
            "message" => '404'
         ]);
      }
   }

   public function drugOldersSearch()
   {
      $user = Auth::check();
      Auth::checkPayment($this->model, $user->id, $user->platform);

      $data = file_get_contents("php://input");

      if (empty($data)) {
         http_response_code(400);
         echo json_encode([
            "status" => false,
            "message" => "error"
         ]);
         exit();
      }

      $data = json_decode($data);
      $translit = Functions::textTranslit($data);

      $searchDrugOlders = $this->model->searchDrugOlders($translit, 1);

      if ($searchDrugOlders) {
         http_response_code(200);
         echo json_encode([
            "status" => true,
            "data" => $searchDrugOlders
         ]);
      } else {
         http_response_code(200);
         echo json_encode([
            "status" => false,
            "data" => []
         ]);
      }
   }

   public function drugOlders()
   {
      $user = Auth::check();
      Auth::checkPayment($this->model, $user->id, $user->platform);

      $data = file_get_contents("php://input");

      if (empty($data)) {
         http_response_code(400);
         echo json_encode([
            "status" => false,
            "message" => "error"
         ]);
         exit();
      }

      $data = json_decode($data);
      $request = explode(':', $data);

      $getDrugOlders = $this->model->getDrugOlders($request[1]);

      if ($getDrugOlders) {
         $result = [];

         $result[] = [
            'id' => $getDrugOlders[0]['id'],
            'label' => $getDrugOlders[0]['label'],
         ];

         foreach ($getDrugOlders as $item) {
            if (!empty($item['older_beers_1']))
               $result[0]['older_beers_1'] = json_decode($item['older_beers_1'], true);

            if (!empty($item['older_beers_2']))
               $result[0]['older_beers_2'] = json_decode($item['older_beers_2'], true);

            if (!empty($item['older_beers_3']))
               $result[0]['older_beers_3'] = json_decode($item['older_beers_3'], true);

            if (!empty($item['older_beers_4']))
               $result[0]['older_beers_4'] = json_decode($item['older_beers_4'], true);

            if (!empty($item['older_beers_5']))
               $result[0]['older_beers_5'] = json_decode($item['older_beers_5'], true);

            if (!empty($item['older_text']))
               $result[0]['older_text'] = $item['older_text'];
         }

         http_response_code(200);
         echo json_encode([
            "status" => true,
            "data" => $result
         ]);
      } else {
         http_response_code(404);
         echo json_encode([
            "status" => false,
            "message" => '404'
         ]);
      }
   }

   public function drugQtSearch()
   {
      $user = Auth::check();
      Auth::checkPayment($this->model, $user->id, $user->platform);

      $data = file_get_contents("php://input");

      if (empty($data)) {
         http_response_code(400);
         echo json_encode([
            "status" => false,
            "message" => "error"
         ]);
         exit();
      }

      $data = json_decode($data);
      $translit = Functions::textTranslit($data);

      $searchDrugQt = $this->model->searchDrugQt($translit, 1);

      if ($searchDrugQt) {
         http_response_code(200);
         echo json_encode([
            "status" => true,
            "data" => $searchDrugQt
         ]);
      } else {
         http_response_code(200);
         echo json_encode([
            "status" => false,
            "data" => []
         ]);
      }
   }

   public function drugQt($qtdrug)
   {
      $user = Auth::check();
      Auth::checkPayment($this->model, $user->id, $user->platform);

      $request = explode(':', $qtdrug);

      $getDrugQt = $this->model->getDrugQt($request[1]);

      if ($getDrugQt) {
         $result = [];

         foreach ($getDrugQt as $key => $value) {
            $result[$key] = [
               'id' => $value['id'],
               'label' => $value['label'],
               'qt_category' => $value['qt_category'],
            ];

            if (!empty($value['qt_prolongation']))
               $result[$key]['qt_prolongation'] = $value['qt_prolongation'];

            if (!empty($value['qt_tdp']))
               $result[$key]['qt_tdp'] = $value['qt_tdp'];

            if (!empty($value['qt_ecg']))
               $result[$key]['qt_ecg'] = $value['qt_ecg'];

            if (!empty($value['qt_lqts']))
               $result[$key]['qt_lqts'] = $value['qt_lqts'];

            if (!empty($value['qt_contraindication']))
               $result[$key]['qt_contraindication'] = $value['qt_contraindication'];
         }

         http_response_code(200);
         echo json_encode([
            "status" => false,
            "data" => $result
         ]);
      } else {
         http_response_code(400);
         echo json_encode([
            "status" => false,
            "message" => 'error'
         ]);
      }
   }

   public function drugQtSearchCalc()
   {
      $user = Auth::check();
      Auth::checkPayment($this->model, $user->id, $user->platform);

      $data = file_get_contents("php://input");

      if (empty($data)) {
         http_response_code(400);
         echo json_encode([
            "status" => false,
            "message" => "error"
         ]);
         exit();
      }

      $data = json_decode($data);
      $translit = Functions::textTranslit($data);

      $searchDrugQtCalc = $this->model->searchDrugQtCalc($translit, 1);

      if ($searchDrugQtCalc) {
         http_response_code(200);
         echo json_encode([
            "status" => true,
            "data" => $searchDrugQtCalc
         ]);
      } else {
         http_response_code(200);
         echo json_encode([
            "status" => false,
            "data" => []
         ]);
      }
   }

   public function drugQtFactor()
   {
      $user = Auth::check();
      Auth::checkPayment($this->model, $user->id, $user->platform);

      $getDrugQtFactor = $this->model->getDrugQtFactor();

      if ($getDrugQtFactor) {
         $result = [];

         foreach ($getDrugQtFactor as $value) {
            $result[] = [
               'id' => $value['id'],
               'title' => $value['title'],
               'factors' => json_decode($value['factors'], true)
            ];
         }

         http_response_code(200);
         echo json_encode([
            "status" => true,
            "data" => $result
         ]);
      } else {
         http_response_code(400);
         echo json_encode([
            "status" => false,
            "message" => 'error'
         ]);
      }
   }

   public function drugQtIndication()
   {
      $user = Auth::check();
      Auth::checkPayment($this->model, $user->id, $user->platform);

      $getDrugQtIndication = $this->model->getDrugQtIndication();

      if ($getDrugQtIndication) {
         http_response_code(200);
         echo json_encode([
            "status" => true,
            "data" => $getDrugQtIndication
         ]);
      } else {
         http_response_code(400);
         echo json_encode([
            "status" => false,
            "message" => 'error'
         ]);
      }
   }

   public function drugMethem()
   {
      $user = Auth::check();
      Auth::checkPayment($this->model, $user->id, $user->platform);

      $getDrugMethem = $this->model->getDrugMethem(1);

      if ($getDrugMethem) {
         $result = [];

         foreach ($getDrugMethem as $key => $value) {
            $result[$key] = [
               'id' => $value['id'],
               'label' => $value['label'],
            ];

            if (!empty($value['methem_text']))
               $result[$key]['methem_text'] = $value['methem_text'];

            if (!empty($value['methem_refs'])) {
               $refs = explode('+', $value['methem_refs']);
               $result[$key]['methem_refs'] = $refs;
            }
         }

         http_response_code(200);
         echo json_encode([
            "status" => true,
            "data" => $result
         ]);
      } else {
         http_response_code(400);
         echo json_encode([
            "status" => false,
            "message" => 'error'
         ]);
      }
   }

   public function drugDisl()
   {
      $user = Auth::check();
      Auth::checkPayment($this->model, $user->id, $user->platform);

      $getDrugDisl = $this->model->getDrugDisl(1);

      if ($getDrugDisl) {
         http_response_code(200);
         echo json_encode([
            "status" => true,
            "data" => $getDrugDisl
         ]);
      } else {
         http_response_code(400);
         echo json_encode([
            "status" => false,
            "message" => 'error'
         ]);
      }
   }
}