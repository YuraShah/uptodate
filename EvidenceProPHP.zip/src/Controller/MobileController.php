<?php

namespace App\Controller;

use App\Helpers\Auth;
use App\Model\Model;


class MobileController
{
   public Model $model;


   public function __construct()
   {
      $this->model = new Model();
   }

   public function getUserNotifications()
   {
      $data = file_get_contents("php://input");

      if (empty($data)) {
         http_response_code(400);
         echo json_encode([
            "status" => false,
            "message" => "error"
         ]);
         return;
      }

      $user = Auth::check();

      $uid = json_decode($data);

      if ($user->id !== +$uid) {
         http_response_code(403);
         echo json_encode([
            "status" => false,
            "message" => "Unauthorized access"
         ]);
         return;
      }

      $getUserNotification = $this->model->getUserNotification($uid);
      $result = [$getUserNotification[0]['notify']];

      http_response_code(200);
      echo json_encode([
         "status" => true,
         "data" => $result
      ]);
   }

   public function changeUserNotifications()
   {
      $data = file_get_contents("php://input");

      if (empty($data)) {
         http_response_code(400);
         echo json_encode([
            "status" => false,
            "message" => "error"
         ]);
         return;
      }

      $user = Auth::check();

      $request = json_decode($data);
      $uid = $request->uid;
      $notify_number = $request->notify_number;

      if ($user->id !== +$uid) {
         http_response_code(403);
         echo json_encode([
            "status" => false,
            "message" => "Unauthorized access"
         ]);
         return;
      }

      $this->model->updateUserNotifications($notify_number, $uid);
   }

   public function screenshotsQuantity()
   {
      date_default_timezone_set('Europe/Moscow');

      $data = file_get_contents("php://input");

      if (empty($data)) {
         http_response_code(400);
         echo json_encode([
            "status" => false,
            "message" => "error"
         ]);
         return;
      }

      $user = Auth::check();

      $uid = json_decode($data);

      if ($user->id !== +$uid) {
         http_response_code(403);
         echo json_encode([
            "status" => false,
            "message" => "Unauthorized access"
         ]);
         return;
      }

      $getScreenshotsQuantWithUid = $this->model->getScreenshotsQuantWithUid($uid);
      $currentDate = date("d.m.Y");
      $currentTime = date("H:i");

      if ($getScreenshotsQuantWithUid) {

         $notify = "$currentDate-$currentTime+" . $getScreenshotsQuantWithUid[0]['notify'];
         $this->model->changeScreenshotsQuant($notify, $uid);

         $getScreenshotsQuantWithUidNew = $this->model->getScreenshotsQuantWithUid($uid);

         if ($getScreenshotsQuantWithUidNew) {
            $notifies = $getScreenshotsQuantWithUidNew[0]['notify'];
            $notifiesArr = explode('+', $notifies);

            $notifyDates = [];
            $currentDate = date("d.m.Y");

            foreach ($notifiesArr as $value) {
               $slicedValue = substr($value, 0, 10);

               if ($currentDate === $slicedValue) {
                  $notifyDates[] = $slicedValue;
               }
            }

            if (count($notifyDates) > 5 && count($notifyDates) < 10) {
               http_response_code(200);
               echo json_encode([
                  "status" => true,
                  "message" => ['limit']
               ]);
            } else if (count($notifyDates) >= 10) {

               $this->model->changeTokenBlockWithUid(1, $uid);

               $getUserAppWithUid = $this->model->getUserAppWithUid($uid);
               if ($getUserAppWithUid && !empty($getUserAppWithUid[0]['unique_id'])) {
                  $getDeviceToken = $this->model->getDeviceToken($getUserAppWithUid[0]['unique_id']);

                  if ($getDeviceToken) {
                     $this->model->changeTokenBlockWithUniqueId(1, $getUserAppWithUid[0]['unique_id']);
                  }
               }

               http_response_code(200);
               echo json_encode([
                  "status" => true,
                  "message" => ['blocked']
               ]);
            }
         }
      } else {
         $notify = "$currentDate-$currentTime";
         $this->model->addScreenshotsQuant($uid, $notify);
      }
   }

   public function deviceBlock()
   {
      $data = file_get_contents("php://input");

      if (empty($data)) {
         http_response_code(400);
         echo json_encode([
            "status" => false,
            "message" => "error"
         ]);
         return;
      }

      $token = json_decode($data);

      $getDeviceTokenWithToken = $this->model->getDeviceTokenWithToken($token);

      if ($getDeviceTokenWithToken) {

         http_response_code(200);
         echo json_encode([
            "status" => true,
            "data" => [
               $getDeviceTokenWithToken[0]['block']
            ]
         ]);
      }
   }

   public function isCloseApp()
   {
      $data = file_get_contents("php://input");

      if (empty($data)) {
         http_response_code(400);
         echo json_encode([
            "status" => false,
            "message" => "error"
         ]);
         return;
      }

      $request = json_decode($data);

      $getIsAppClose = $this->model->getIsAppClose(1);

      if ($getIsAppClose) {
         $result = [];

         if ($request === 'ios') {
            $result[] = [
               "is_close_version" => $getIsAppClose[0]['ios_version'],
               "is_close_version_update" => $getIsAppClose[0]['ios_version_update'],
               "is_close" => $getIsAppClose[0]['ios_close'],
               "is_close_link" => $getIsAppClose[0]['ios_link'],
            ];
         } else {
            $result[] = [
               "is_close_version" => $getIsAppClose[0]['android_version'],
               "is_close_version_update" => $getIsAppClose[0]['android_version_update'],
               "is_close" => $getIsAppClose[0]['android_close'],
               "is_close_link" => $getIsAppClose[0]['android_link'],
            ];
         }


         http_response_code(200);
         echo json_encode([
            "status" => true,
            "data" => $result
         ]);
      }
   }

   public function checkDevice()
   {
      $data = file_get_contents("php://input");

      if (empty($data)) {
         http_response_code(400);
         echo json_encode([
            "status" => false,
            "message" => "error"
         ]);
         return;
      }

      $request = json_decode($data, true);

      if (
         (isset($request['device_token']) && empty($request['device_token']) ||
            (isset($request['uid']) && empty($request['uid'])))
      ) {
         exit();
      } else {
         $result = [];
         $getUserAppWithDeviceTokenAndUid = $this->model->getUserAppWithDeviceTokenAndUid($request['uid'], $request['device_token']);

         if (count($getUserAppWithDeviceTokenAndUid) > 0) {
            $result = ['ok'];
         } else {
            $getUserAppWithUid = $this->model->getUserAppWithUid($request['uid']);

            if (
               $getUserAppWithUid &&
               (
                  !isset($getUserAppWithUid[0]['token']) ||
                  (
                     isset($getUserAppWithUid[0]['token'])
                     && $request['device_token'] !== $getUserAppWithUid[0]['token']
                  )
               )
            ) {
               $this->model->deleteUserAppWithUid($request['uid']);
            }


            http_response_code(403);
            $result = ['error'];
         }

         http_response_code(200);
         echo json_encode([
            "status" => true,
            "message" => $result
         ]);
      }
   }
}