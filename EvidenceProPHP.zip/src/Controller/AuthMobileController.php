<?php

namespace App\Controller;

use App\Helpers\Auth;
use App\Helpers\Functions;
use App\Helpers\Logout;
use App\Helpers\Ip;
use App\Model\Model;
use Firebase\JWT\JWT;
use Exception;
use Firebase\JWT\Key;


class AuthMobileController
{
   public Model $model;

   // this should come from env preferably
   private string $secretKey;

   public function __construct()
   {
      $this->model = new Model();
      $this->secretKey = $_ENV['SECRET_KEY'];
   }

   public function login(): void
   {
      $clientType = $_SERVER['HTTP_X_CLIENT_TYPE'] ?? 'web';

      $postdata = file_get_contents("php://input");

      if (empty($postdata)) {
         http_response_code(400);
         echo json_encode([
            "status" => false,
            "message" => "Email and Password required"
         ]);
         exit();
      }

      $request = json_decode($postdata);

      if (!isset($request->email) || !isset($request->password)) {
         http_response_code(400);
         echo json_encode([
            "status" => false,
            "message" => "Email and Password are required fields"
         ]);
         exit();
      }

      $email = $request->email;
      $password = $request->password;
      $rememberMe = isset($request->remember_me) && !!$request->remember_me;
      $device_token = $request->device_token;
      $device_name = $request->device;
      $version = $request->version;
      $unique_id = !empty($request->uniqId) ? $request->uniqId : null;
      $platform = isset($request->platform) ? $request->platform : '';


      if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
         http_response_code(400);
         echo json_encode([
            "status" => false,
            "message" => "Invalid email format"
         ]);
         exit();
      }

      $getRowUserWithEmail = $this->model->getRowUserWithEmail($email);
      $ipAddress = Ip::get_client_ip();

      if ($getRowUserWithEmail) {
         $getUserWithEmail = $this->model->getUserWithEmail($email);

         foreach ($getUserWithEmail as $user) {

            if ($user['block'] === 1) {
               http_response_code(200);
               echo json_encode([
                  "status" => true,
                  "message" => ["Blocked"]
               ]);
               return;
            }

            $getDeviceTokenWithToken = $this->model->getDeviceTokenWithToken($device_token);

            $getUserAppWithUid = $this->model->getUserAppWithUid($user['id']);

            if ($getUserAppWithUid && isset($getUserAppWithUid[0]['token']) && $getUserAppWithUid[0]['token'] !== $device_token) {
               http_response_code(200);
               echo json_encode([
                  "status" => true,
                  "message" => ["The user is already signed in with another device"]
               ]);
               return;
            } else {
               if (count($getDeviceTokenWithToken) > 0 && !empty($getDeviceTokenWithToken[0]['user_id']) && $getDeviceTokenWithToken[0]['user_id'] !== $user['id']) {
                  http_response_code(200);
                  echo json_encode([
                     "status" => true,
                     "message" => ["The device is already attached to another user"]
                  ]);
                  return;
               }
            }

            $getUserAppWithUid = $this->model->getUserAppWithUid($user['id']);

            if ($getUserAppWithUid && isset($getUserAppWithUid[0]['token']) && $getUserAppWithUid[0]['token'] !== $device_token) {
               http_response_code(200);
               echo json_encode([
                  "status" => true,
                  "message" => ["The user is already signed in with another device"]
               ]);
               return;
            } else {
               $getDeviceTokenWithToken = $this->model->getDeviceTokenWithToken($device_token);

               if (count($getDeviceTokenWithToken) > 0 && !empty($getDeviceTokenWithToken[0]['user_id']) && $getDeviceTokenWithToken[0]['user_id'] !== $user['id']) {
                  http_response_code(200);
                  echo json_encode([
                     "status" => true,
                     "message" => ["The device is already attached to another user"]
                  ]);
                  return;
               } else {
                  if (password_verify($password, $user['password'])) {

                     if ($user['verify_status'] === 0) {
                        http_response_code(200);
                        echo json_encode([
                           "status" => true,
                           "message" => ["Verify email code"]
                        ]);
                        return;
                     } else {
                        if (count($getDeviceTokenWithToken) === 0) {
                           $this->model->addUserApp($user['id'], $device_token, $unique_id, $device_name, $version, $ipAddress);
                        } elseif (!empty($getDeviceTokenWithToken) && $getDeviceTokenWithToken[0]['user_id'] == null) {
                           $this->model->updateUserAppWithDeviceToken($user['id'], $unique_id, $device_name, $version, $ipAddress, $device_token);
                        }

                        $tokens = $this->generateTokens($user, $device_token, $platform, $rememberMe, $clientType);

                        $responseData = [
                           "status" => true,
                           "data" => [
                              "accessToken" => $tokens['accessToken'],
                              "user" => [
                                 "id" => $user['id'],
                                 "email" => $user['email'],
                                 "username" => $user['username'],
                                 "surname" => $user['surname'],
                                 "name" => $user['name'],
                                 "created_at" => $user['created_at'],
                                 "device" => $device_token,
                                 "platform" => $platform
                              ]
                           ]
                        ];

                        if ($clientType === 'mobile' && $tokens['refreshToken']) {
                           $responseData['data']['refreshToken'] = $tokens['refreshToken'];
                        }

                        echo json_encode($responseData);
                        return;
                     }
                  } else {

                     http_response_code(200);
                     echo json_encode([
                        "status" => true,
                        "message" => ["Not found"]
                     ]);
                     return;
                  }
               }
            }
         }
      } else {
         http_response_code(200);
         echo json_encode([
            "status" => true,
            "message" => ["Not found"]
         ]);
      }
   }

   public function logout(): void
   {
      $postdata = file_get_contents("php://input");

      if (empty($postdata)) {
         http_response_code(400);
         echo json_encode([
            "status" => false,
            "message" => "error"
         ]);
         exit();
      }

      $request = json_decode($postdata);
      $uid = $request->uid;
      $device_token = $request->device_token;

      $getUserWithId = $this->model->getUserWithId($uid);

      if ($getUserWithId) {
         $chars_em = $getUserWithId[0]['email'];
         $chars_fn = $getUserWithId[0]['name'];
         $chars_sn = $getUserWithId[0]['surname'];

         Logout::out($this->model, $uid, $device_token, $chars_em, $chars_fn, $chars_sn);

         http_response_code(200);
         echo json_encode([
            "status" => true,
            "message" => "Logged out successfully"
         ]);
      }
   }

   public function register(): void
   {
      $postdata = file_get_contents("php://input");

      if (empty($postdata)) {
         http_response_code(400);
         echo json_encode([
            "status" => false,
            "message" => "All fields are required"
         ]);
         exit();
      }

      $request = json_decode($postdata);

      // Validate required fields for registration
      if (!isset($request->email) || !isset($request->username) || !isset($request->password) || !isset($request->firstname) || !isset($request->surname)) {
         http_response_code(400);
         echo json_encode([
            "status" => false,
            "message" => "All fields are required"
         ]);
         exit();
      }

      $email = $request->email;
      $username = $request->username;
      $password = $request->password;
      $firstname = $request->firstname;
      $surname = $request->surname;

      if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
         http_response_code(400);
         echo json_encode([
            "status" => false,
            "message" => "Invalid email format"
         ]);
         exit();
      }

      if (
         strlen($username) < 5 ||
         strlen($username) > 30 ||
         !preg_match('/^[a-zA-Zа-яА-Я]+$/u', $firstname) ||
         strlen($firstname) < 2 ||
         strlen($firstname) > 30 ||
         !preg_match('/^[a-zA-Zа-яА-Я]+$/u', $surname) ||
         strlen($surname) < 4 ||
         strlen($surname) > 50 ||
         !preg_match('/^(?=.*[0-9])(?=.*[a-zа-яА-Я])(?=.*[A-Zа-яА-Я]).{8,32}$/u', $password)
      ) {
         http_response_code(400);
         echo json_encode([
            "status" => false,
            "message" => "Invalid format"
         ]);
         exit();
      }


      $checkRegisterUsername = $this->model->checkRegisterUsername($username);
      $checkRegisterEmail = $this->model->checkRegisterEmail($email);

      if ($checkRegisterEmail) {
         http_response_code(400);
         $response = [
            "status" => false,
            "message" => "Пользователь с таким адресом электронной почты уже зарегистрирован"
         ];
      } elseif ($checkRegisterUsername) {
         http_response_code(400);

         //user already exists
         $response = [
            "status" => false,
            "message" => "Пользователь с таким именем уже существует. Пожалуйста, измените имя пользователя"
         ];
      } else {
         $verify_code = md5($username . time());
         $verify_time = time();

         // Register user
         $registerUser = $this->model->registerUser($email, $username, $password, $firstname, $surname, $verify_code, $verify_time);
         if ($registerUser) {
            // $subject = 'Գրանցման հաստատում';
            // $body = "<h4 style='color: rgb(23, 88, 131); line-height: 1.6; font-size: 23px;'>Շնորհակալություն գրանցվելու համար։</h4> <p style='margin: 5px 0; line-height: 1.6; font-size: 21px;'>Անձնական էջը ակտիվացնելու համար անցեք <a href='https://evidence.am/verify/$verify_code' target='_blank' style='color: rgb(24, 123, 169);'>հետևյալ հղումով</a>:</p> <p style='line-height: 1.6; font-size: 20px;'>Եթե evidence.am կայքում գրանցում չեք կատարել և ստացել եք այս նամակը սխալմամբ, ապա թողեք այն առանց ուշադրության։</p>";
            // SendEmail::sendEmailStat($email, $subject, $body);
            http_response_code(200);
            $response = [
               "status" => true,
               "message" => ["Success"]
            ];
         } else {
            http_response_code(400);

            //connect error
            $response = [
               "status" => false,
               "message" => "Проблема с подключением. Попробуйте обновить страницу"
            ];
         }
      }

      $responseJson = json_encode($response);
      echo $responseJson;
   }

   public function refreshToken(): void
   {

      if (isset($_SERVER['HTTP_AUTHORIZATION'])) {

         $authorizationHeader = $_SERVER['HTTP_AUTHORIZATION'];
         $parts = explode(' ', $authorizationHeader);
         if (count($parts) !== 2 || strtolower($parts[0]) !== 'bearer') {
            http_response_code(401);
            echo json_encode([
               "status" => false,
               "message" => "Invalid Authorization header format"
            ]);
            exit();
         }
         $refreshToken = $parts[1];
      } else {
         http_response_code(401);
         echo json_encode([
            "status" => false,
            "message" => "Refresh token missing or expired"
         ]);
         exit();
      }

      try {
         $decoded = (array) JWT::decode($refreshToken, new Key($this->secretKey, 'HS256'));
         $user = (array) $decoded['data'];

         $storedToken = $this->model->checkMobileRefreshToken($user['id'], $user['device'], $refreshToken);

         if (empty($storedToken)) {
            Logout::out($this->model, $user['id'], $user['device']);
            throw new Exception('Invalid refresh token');
         }

         // Generate a new access token
         $tokens = $this->generateTokens($user, $user['device'], $user['platform']);

         // Set the new access token in the response
         echo json_encode([
            "status" => true,
            "accessToken" => $tokens['accessToken']
         ]);
      } catch (Exception) {
         http_response_code(401);
         echo json_encode([
            "status" => false,
            "message" => "Invalid refresh token"
         ]);
      }
   }

   private function generateTokens($user, $device_token, string $platform = '', bool $rememberMe = false, string $clientType = 'web'): array
   {
      $issuedAt = time();
      $accessTokenExpiration = $issuedAt + 900; // 900;  // 15 minutes
      $refreshTokenExpiration = ($rememberMe || $clientType === 'mobile') ? $issuedAt + (30 * 24 * 3600) : null;  // 30 days if remember me is checked (30 * 24 * 3600)

      $userData = [
         "id" => $user['id'],
         "email" => $user['email'],
         "username" => $user['username'],
         "surname" => $user['surname'],
         "name" => $user['name'],
         "created_at" => $user['created_at'],
         "device" => $device_token,
         "platform" => $platform
      ];

      // Access Token
      $accessTokenPayload = [
         'iss' => "localhost",
         'iat' => $issuedAt,
         'exp' => $accessTokenExpiration,
         'aud' => $clientType,
         'data' => $userData
      ];
      $accessToken = JWT::encode($accessTokenPayload, $this->secretKey, 'HS256');

      // Refresh Token (if needed)
      $refreshToken = null;
      if ($refreshTokenExpiration) {
         $refreshTokenPayload = [
            'iss' => "localhost",
            'iat' => $issuedAt,
            'exp' => $refreshTokenExpiration,
            'aud' => $clientType,
            'data' => $userData
         ];
         $refreshToken = JWT::encode($refreshTokenPayload, $this->secretKey, 'HS256');


         // Store the refresh token in the database
         $this->model->updateMobileRefreshToken($refreshToken, $device_token);
      }

      return [
         'accessToken' => $accessToken,
         'refreshToken' => $refreshToken,
         'accessTokenExpiration' => $accessTokenExpiration,
         'refreshTokenExpiration' => $refreshTokenExpiration,
      ];
   }

   public function getCurrentUser()
   {
      $data = file_get_contents("php://input");

      if (empty($data)) {
         http_response_code(400);
         echo json_encode([
            "status" => false,
            "message" => "error"
         ]);
         exit();
      }

      $request = json_decode($data);
      $device_token = $request->deviceToken;
      $platform = isset($request->platform) ? $request->platform : '';

      $user = Auth::check();

      $notAuthenticated = [
         "status" => false,
         "message" => "Not authenticated"
      ];

      if (!$user) {
         http_response_code(401);
         echo json_encode($notAuthenticated);
         return;
      }

      $getRowUserWithEmail = $this->model->getRowUserWithEmail($user->email);

      if (!$getRowUserWithEmail) {
         http_response_code(401);
         echo json_encode($notAuthenticated);
         return;
      }

      $currentUser = $this->model->getUserWithEmail($user->email);

      if (!$currentUser) {
         http_response_code(401);
         echo json_encode($notAuthenticated);
         return;
      }

      echo json_encode([
         "status" => true,
         "data" => [
            "user" => [
               "id" => $currentUser[0]['id'],
               "email" => $currentUser[0]['email'],
               "username" => $currentUser[0]['username'],
               "surname" => $currentUser[0]['surname'],
               "name" => $currentUser[0]['name'],
               "created_at" => $currentUser[0]['created_at'],
               "device" => $device_token,
               "platform" => $platform
            ]
         ]
      ]);
   }
}