<?php

namespace App\Controller;

use App\Helpers\SendEmail;
use App\Model\Model;

// require __DIR__ . '../../functions/mails/mail.php';
// require __DIR__ . '../../functions/mails/mail_pass_attention.php';

class VerifyController
{
   public Model $model;

   public function __construct()
   {
      $this->model = new Model();
   }


   public function verify()
   {
      $data = file_get_contents("php://input");

      if (empty($data)) {
         http_response_code(400);
         echo json_encode([
            "status" => false,
            "message" => "error"
         ]);
         return;
      }

      $request = json_decode($data);

      $getUserVerifCode = $this->model->getUserVerifCode($request);

      if ($getUserVerifCode) {
         $response = [];

         if ($getUserVerifCode[0]['verify_code_time'] + 24 * 3600 < time()) {
            $new_verify_code = md5($getUserVerifCode[0]['username'] . time());
            $new_verify_code_time = time();
            $updateUserVerifCode = $this->model->updateUserVerifCode($new_verify_code, $new_verify_code_time, $request);
            if ($updateUserVerifCode) {
               // email
               // $subject = 'Ակտիվացման կոդ';
               // $body = "<h4 style='color: rgb(23, 88, 131); line-height: 1.6; font-size: 23px;'>Ակտիվացման կոդ։</h4> <p style='margin: 5px 0; line-height: 1.6; font-size: 21px;'>Անձնական էջը ակտիվացնելու համար անցեք <a href='https://evidence.am/verify/$new_verify_code' target='_blank' style='color: rgb(24, 123, 169);'>հետևյալ հղումով</a>:</p> <p style='line-height: 1.6; font-size: 20px;'>Մի փոխանցեք ակտիվացման կոդը այլ անձանց։</p>";
               // SendEmail::sendEmailStat($getUserVerifCode[0]['email'], $subject, $body);
               $response = ['Activation code resent'];
            }
         } else {
            $new_verify_code = 'activated';
            $verify_status = 1;
            $new_verify_code_time = time();
            $updateUserVerifCodeFinally = $this->model->updateUserVerifCodeFinally($new_verify_code, $verify_status, $new_verify_code_time, $request);
            if ($updateUserVerifCodeFinally) {
               //mail
               //  $subject = 'Ակտիվացում';
               // $body = "<h4 style='color: rgb(23, 88, 131); line-height: 1.6; font-size: 23px;'>Անձնական էջի ակտիվացում։</h4> <p style='margin: 5px 0; line-height: 1.6; font-size: 21px;'>Անձնական էջը ակտիվացվեց:</p> <p style='line-height: 1.6; font-size: 20px;'>Եթե անձնական էջը դուք չեք ակտիվացրել, ապա կապվեք մեզ հետ։</p>";
               // SendEmail::sendEmailStat($getUserVerifCode[0]['email'], $subject, $body);
               $response = ['Activated'];
            }
         }

         http_response_code(200);
         echo json_encode([
            "status" => true,
            "message" => $response
         ]);
      } else {
         http_response_code(404);
         echo json_encode([
            "status" => false,
            "message" => "Invalid activation code"
         ]);
      }
   }

   public function verifyResend()
   {
      $data = file_get_contents("php://input");

      if (empty($data)) {
         http_response_code(400);
         echo json_encode([
            "status" => false,
            "message" => "error"
         ]);
         return;
      }

      $request = json_decode($data);

      $getUserWithEmail = $this->model->getUserWithEmail($request);
      $response = [];

      if ($getUserWithEmail) {
         if ($getUserWithEmail[0]['verify_code_time'] + 24 * 3600 < time()) {
            $old_verif_code = $getUserWithEmail[0]['verify_code'];
            $new_verify_code = md5($getUserWithEmail[0]['username'] . time());
            $new_verify_code_time = time();
            $updateUserVerifCode = $this->model->updateUserVerifCode($new_verify_code, $new_verify_code_time, $old_verif_code);
            if ($updateUserVerifCode) {
               // email
               // $subject = 'Ակտիվացման կոդ';
               // $body = "<h4 style='color: rgb(23, 88, 131); line-height: 1.6; font-size: 23px;'>Ակտիվացման կոդ։</h4> <p style='margin: 5px 0; line-height: 1.6; font-size: 21px;'>Անձնական էջը ակտիվացնելու համար անցեք <a href='https://evidence.am/verify/$new_verify_code' target='_blank' style='color: rgb(24, 123, 169);'>հետևյալ հղումով</a>:</p> <p style='line-height: 1.6; font-size: 20px;'>Մի փոխանցեք ակտիվացման կոդը այլ անձանց։</p>";
               // SendEmail::sendEmailStat($getUserVerifCode[0]['email'], $subject, $body);
               $response = ['Sent'];
            }
         } else {
            $response = ['Activate limit'];
         }
      } else {
         $response = ['Invalid email'];
      }

      http_response_code(200);
      echo json_encode([
         "status" => true,
         "message" => $response
      ]);
   }

   public function forgotPassword()
   {
      $data = file_get_contents("php://input");

      if (empty($data)) {
         http_response_code(400);
         echo json_encode([
            "status" => false,
            "message" => "error"
         ]);
         return;
      }

      $request = json_decode($data);

      $response = [];

      $getUserWithEmail = $this->model->getUserWithEmail($request);
      if ($getUserWithEmail) {
         if ($getUserWithEmail[0]['pass_recovery_quantity'] < 2) {
            if (isset($getUserWithEmail[0]['pass_recovery'])) {
               if ($getUserWithEmail[0]['pass_recovery_time'] + 24 * 3600 > time()) {
                  $response = ['The recovery code has already been sent'];
               } else {
                  $pass_recovery = md5($getUserWithEmail[0]['email'] . time());
                  $pass_recovery_time = time();
                  $addPassRecovery = $this->model->addPassRecovery($pass_recovery, $pass_recovery_time, $request);
                  if ($addPassRecovery) {
                     //mail
                     // $subject = 'Գաղտնաբառի վերականգնում';
                     // $body = "<h4 style='color: rgb(23, 88, 131); line-height: 1.6; font-size: 23px;'>Գաղտնաբառի վերականգնում</h4> <p style='margin: 5px 0; line-height: 1.6; font-size: 21px;'>Գաղտնաբառը փոխելու համար անցեք <a href='https://evidence.am/forgot-password/$pass_recovery' target='_blank' style='color: rgb(24, 123, 169);'>հետևյալ հղումով</a>:</p> <p style='line-height: 1.6; font-size: 20px;'>Եթե գաղտնաբառը դուք չեք փոխել, ապա կապվեք մեզ հետ։</p>";
                     // SendEmail::sendEmailStat($request, $subject, $body);
                     $response = ['The recovery code had expired'];
                  }
               }
            } else {
               $pass_recovery = md5($getUserWithEmail[0]['email'] . time());
               $pass_recovery_time = time();
               $addPassRecovery = $this->model->addPassRecovery($pass_recovery, $pass_recovery_time, $request);
               if ($addPassRecovery) {
                  //mail
                  // $subject = 'Գաղտնաբառի վերականգնում';
                  // $body = "<h4 style='color: rgb(23, 88, 131); line-height: 1.6; font-size: 23px;'>Գաղտնաբառի վերականգնում</h4> <p style='margin: 5px 0; line-height: 1.6; font-size: 21px;'>Գաղտնաբառը փոխելու համար անցեք <a href='https://evidence.am/forgot-password/$pass_recovery' target='_blank' style='color: rgb(24, 123, 169);'>հետևյալ հղումով</a>:</p> <p style='line-height: 1.6; font-size: 20px;'>Եթե գաղտնաբառը դուք չեք փոխել, ապա կապվեք մեզ հետ։</p>";
                  // SendEmail::sendEmailStat($request, $subject, $body);
                  $response = ['A password recovery code has been sent to the email address'];
               }
            }
         } else {
            $response = ['Exhausted'];
         }
      } else {
         $response = ['Invalid email'];
      }

      http_response_code(200);
      echo json_encode([
         "status" => true,
         "message" => $response
      ]);
   }

   public function recoverPasswordCheck()
   {
      $data = file_get_contents("php://input");

      if (empty($data)) {
         http_response_code(400);
         echo json_encode([
            "status" => false,
            "message" => "error"
         ]);
         return;
      }

      $request = json_decode($data);

      $getPassRecovery = $this->model->getPassRecovery($request);

      if ($getPassRecovery) {
         http_response_code(200);
         echo json_encode([
            "status" => true,
            "message" => ['Valid']
         ]);
      } else {
         http_response_code(404);
         echo json_encode([
            "status" => true,
            "message" => ['Not valid']
         ]);
      }
   }

   public function recoverPassword()
   {
      $data = file_get_contents("php://input");

      if (empty($data)) {
         http_response_code(400);
         echo json_encode([
            "status" => false,
            "message" => "error"
         ]);
         return;
      }

      $request = json_decode($data);
      $recov = $request->recov;
      $recov_pass = $request->recov_password;

      $getPassRecovery = $this->model->getPassRecovery($recov);
     
      if ($getPassRecovery) {
         $pass_recover_quantity = $getPassRecovery[0]['pass_recovery_quantity'] + 1;
         $recov_pass_hash = password_hash($recov_pass, PASSWORD_DEFAULT);
         $pass_recover_time = time();

         $changePassRecoveryandPass = $this->model->changePassRecoveryandPass($recov_pass_hash, $pass_recover_quantity, $pass_recover_time, $recov);

         if ($changePassRecoveryandPass) {
            // mail
            // SendEmail::sendEmailStat($email);
            http_response_code(200);
            echo json_encode([
               "status" => true,
               "message" => ['Succeeded']
            ]);
         }
      }
   }
}