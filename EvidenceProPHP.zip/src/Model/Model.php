<?php

namespace App\Model;

class Model
{
   private $conn;

   private array $config;


   public function __construct()
   {
      $this->config = require __DIR__ . '/../configs/database.php';
      $this->connect();
   }

   private function connect()
   {
      mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);
      try {
         $this->conn = new \mysqli(
            $this->config['host'],
            $this->config['user'],
            $this->config['pass'],
            $this->config['db'],
            $this->config['port']
         );

         if ($this->conn->connect_error) {
            throw new \mysqli_sql_exception('Connection failed: ' . $this->conn->connect_error);
         }

         $this->conn->set_charset($this->config['charset']);
         $this->conn->options(MYSQLI_OPT_INT_AND_FLOAT_NATIVE, 1);
      } catch (\mysqli_sql_exception | \Exception $e) {
         die("Database Error: " . $e->getMessage());
      }
   }

   public function __destruct()
   {
      if ($this->conn instanceof mysqli) {
         $this->conn->close();
      }
   }

   // Example methods for executing queries with parameter binding
   // upper S-string, I-integer params

   public function queryAll($sql)
   {
      $stmt = $this->conn->prepare($sql);
      $stmt->execute();
      $result = $stmt->get_result();
      $resultArray = [];
      while ($row = $result->fetch_assoc()) {
         $resultArray[] = $row;
      }
      return $resultArray;
   }

   public function queryOneParamOneBindS($sql, $data)
   {
      $stmt = $this->conn->prepare($sql);
      $stmt->bind_param('s', $data);
      $stmt->execute();
      $result = $stmt->get_result();
      $resultArray = [];
      while ($row = $result->fetch_assoc()) {
         $resultArray[] = $row;
      }
      return $resultArray;
   }

   public function queryOneParamOneBindI($sql, $data)
   {
      $stmt = $this->conn->prepare($sql);
      $stmt->bind_param('i', $data);
      $stmt->execute();
      $result = $stmt->get_result();
      $resultArray = [];
      while ($row = $result->fetch_assoc()) {
         $resultArray[] = $row;
      }
      return $resultArray;
   }

   public function queryOneParamOneBindLikeS($sql, $data)
   {
      $data = "%$data%";
      $stmt = $this->conn->prepare($sql);
      $stmt->bind_param('s', $data);
      $stmt->execute();
      $result = $stmt->get_result();
      $resultArray = [];
      while ($row = $result->fetch_assoc()) {
         $resultArray[] = $row;
      }
      return $resultArray;
   }

   public function queryOneParamOneBindLikeRegexS($sql, $data)
   {
      $data = "(^$data$)|(^$data\\+)|(\\+$data\\+)|(\\+$data$)";
      $stmt = $this->conn->prepare($sql);
      $stmt->bind_param('s', $data);
      $stmt->execute();
      $result = $stmt->get_result();
      $resultArray = [];
      while ($row = $result->fetch_assoc()) {
         $resultArray[] = $row;
      }
      return $resultArray;
   }

   public function queryOneParamOneBindDeleteS($sql, $data)
   {
      $stmt = $this->conn->prepare($sql);
      $stmt->bind_param('s', $data);
      $stmt->execute();
      return true;
   }

   public function queryOneParamOneBindDeleteI($sql, $data)
   {
      $stmt = $this->conn->prepare($sql);
      $stmt->bind_param('i', $data);
      $stmt->execute();
      return true;
   }

   public function queryOneParamOneBindRowS($sql, $data)
   {
      $stmt = $this->conn->prepare($sql);
      $stmt->bind_param('s', $data);
      $stmt->execute();
      $stmt->store_result();
      $result = $stmt->num_rows();
      return $result;
   }

   public function queryTwoParamsTwoBindsIS($sql, $first, $second)
   {
      $stmt = $this->conn->prepare($sql);
      $stmt->bind_param('is', $first, $second);
      $stmt->execute();
      $result = $stmt->get_result();
      $resultArray = [];
      while ($row = $result->fetch_assoc()) {
         $resultArray[] = $row;
      }
      return $resultArray;
   }

   public function queryTwoParamsTwoBindsSI($sql, $first, $second)
   {
      $stmt = $this->conn->prepare($sql);
      $stmt->bind_param('si', $first, $second);
      $stmt->execute();
      $result = $stmt->get_result();
      $resultArray = [];
      while ($row = $result->fetch_assoc()) {
         $resultArray[] = $row;
      }
      return $resultArray;
   }

   public function queryTwoParamsTwoBindsII($sql, $first, $second)
   {
      $stmt = $this->conn->prepare($sql);
      $stmt->bind_param('ii', $first, $second);
      $stmt->execute();
      $result = $stmt->get_result();
      $resultArray = [];
      while ($row = $result->fetch_assoc()) {
         $resultArray[] = $row;
      }
      return $resultArray;
   }

   public function queryTwoParamsTwoBindsLikeSI($sql, $first, $second)
   {
      $first = "%$first%";
      $stmt = $this->conn->prepare($sql);
      $stmt->bind_param('si', $first, $second);
      $stmt->execute();
      $result = $stmt->get_result();
      $resultArray = [];
      while ($row = $result->fetch_assoc()) {
         $resultArray[] = $row;
      }
      return $resultArray;
   }

   public function queryTwoParamsTwoBindsInsertIS($sql, $first, $second)
   {
      $stmt = $this->conn->prepare($sql);
      $stmt->bind_param('is', $first, $second);
      $stmt->execute();
      return $stmt->insert_id;
   }

   public function queryTwoParamsTwoBindsInsertSI($sql, $first, $second)
   {
      $stmt = $this->conn->prepare($sql);
      $stmt->bind_param('si', $first, $second);
      $stmt->execute();
      return $stmt->insert_id;
   }

   public function queryTwoParamsTwoBindsDeleteIS($sql, $first, $second)
   {
      $stmt = $this->conn->prepare($sql);
      $stmt->bind_param('is', $first, $second);
      $stmt->execute();
      return true;
   }

   public function queryTwoParamsTwoBindsDeleteSI($sql, $first, $second)
   {
      $stmt = $this->conn->prepare($sql);
      $stmt->bind_param('si', $first, $second);
      $stmt->execute();
      return true;
   }

   public function queryTwoParamsTwoBindsSetSS($sql, $first, $second)
   {
      $stmt = $this->conn->prepare($sql);
      $stmt->bind_param('ss', $first, $second);
      $stmt->execute();
      return true;
   }

   public function queryTwoParamsTwoBindsSetIS($sql, $first, $second)
   {
      $stmt = $this->conn->prepare($sql);
      $stmt->bind_param('is', $first, $second);
      $stmt->execute();
      return true;
   }

   public function queryTwoParamsTwoBindsSetSI($sql, $first, $second)
   {
      $stmt = $this->conn->prepare($sql);
      $stmt->bind_param('si', $first, $second);
      $stmt->execute();
      return true;
   }

   public function queryTwoParamsTwoBindsSetII($sql, $first, $second)
   {
      $stmt = $this->conn->prepare($sql);
      $stmt->bind_param('ii', $first, $second);
      $stmt->execute();
      return true;
   }

   public function queryThreeParamsThreeBindsISS($sql, $first, $second, $third)
   {
      $stmt = $this->conn->prepare($sql);
      $stmt->bind_param('iss', $first, $second, $third);
      $stmt->execute();
      $result = $stmt->get_result();
      $resultArray = [];
      while ($row = $result->fetch_assoc()) {
         $resultArray[] = $row;
      }
      return $resultArray;
   }

   public function queryThreeParamsThreeBindsSetSSS($sql, $first, $second, $third)
   {
      $stmt = $this->conn->prepare($sql);
      $stmt->bind_param('sss', $first, $second, $third);
      $stmt->execute();
      return true;
   }

   public function queryThreeParamsThreeBindsInsertSIS($sql, $first, $second, $third)
   {
      $stmt = $this->conn->prepare($sql);
      $stmt->bind_param('sis', $first, $second, $third);
      $stmt->execute();
      return $stmt->insert_id;
   }

   public function queryFourParamsFourBindsInsertIISS($sql, $first, $second, $third, $fourth)
   {
      $stmt = $this->conn->prepare($sql);
      $stmt->bind_param('iiss', $first, $second, $third, $fourth);
      $stmt->execute();
      return $stmt->insert_id;
   }

   public function queryFourParamsFourBindsSetSSSS($sql, $first, $second, $third, $fourth)
   {
      $stmt = $this->conn->prepare($sql);
      $stmt->bind_param('ssss', $first, $second, $third, $fourth);
      $stmt->execute();
      return true;
   }

   public function queryFourParamsFourBindsSetSISS($sql, $first, $second, $third, $fourth)
   {
      $stmt = $this->conn->prepare($sql);
      $stmt->bind_param('siss', $first, $second, $third, $fourth);
      $stmt->execute();
      return true;
   }

   public function queryFourParamsFourBindsSetSSIS($sql, $first, $second, $third, $fourth)
   {
      $stmt = $this->conn->prepare($sql);
      $stmt->bind_param('ssis', $first, $second, $third, $fourth);
      $stmt->execute();
      return true;
   }

   public function queryFourParamsFourBindsSetISSI($sql, $first, $second, $third, $fourth)
   {
      $stmt = $this->conn->prepare($sql);
      $stmt->bind_param('issi', $first, $second, $third, $fourth);
      $stmt->execute();
      return true;
   }

   public function queryFiveParamsFiveBindsInsertISSSS($sql, $first, $second, $third, $fourth, $times)
   {
      $stmt = $this->conn->prepare($sql);
      $stmt->bind_param('issss', $first, $second, $third, $fourth, $times);
      $stmt->execute();
      return $stmt->insert_id;
   }

   public function querySixParamsSixBindsSetSSISIS($sql, $first, $second, $third, $fourth, $fifth, $sixth)
   {
      $stmt = $this->conn->prepare($sql);
      $stmt->bind_param('ssisis', $first, $second, $third, $fourth, $fifth, $sixth);
      $stmt->execute();
      return true;
   }

   public function querySixParamsSixBindsSetISSSSS($sql, $first, $second, $third, $fourth, $fifth, $sixth)
   {
      $stmt = $this->conn->prepare($sql);
      $stmt->bind_param('isssss', $first, $second, $third, $fourth, $fifth, $sixth);
      $stmt->execute();
      return true;
   }

   public function querySixParamsSixBindsSetISSIIS($sql, $first, $second, $third, $fourth, $fifth, $sixth)
   {
      $stmt = $this->conn->prepare($sql);
      $stmt->bind_param('issiis', $first, $second, $third, $fourth, $fifth, $sixth);
      $stmt->execute();
      return true;
   }

   public function querySixParamsSixBindsSetSISSII($sql, $first, $second, $third, $fourth, $fifth, $sixth)
   {
      $stmt = $this->conn->prepare($sql);
      $stmt->bind_param('sissii', $first, $second, $third, $fourth, $fifth, $sixth);
      $stmt->execute();
      return true;
   }

   public function querySixParamsSixBindsInsertISSSSS($sql, $first, $second, $third, $fourth, $fifth, $sixth)
   {
      $stmt = $this->conn->prepare($sql);
      $stmt->bind_param('isssss', $first, $second, $third, $fourth, $fifth, $sixth);
      $stmt->execute();
      return true;
   }

   public function querySevenParamsSevenBindsInsertSSSSSSS($sql, $first, $second, $third, $fourth, $fifth, $sixth, $seventh)
   {
      $pass_hash = password_hash($third, PASSWORD_DEFAULT);
      $stmt = $this->conn->prepare($sql);
      $stmt->bind_param('sssssss', $first, $second, $pass_hash, $fourth, $fifth, $sixth, $seventh);
      $stmt->execute();
      return true;
   }


   // Example methods for specific queries
   public function getDrugDisease($drug)
   {
      return $this->queryOneParamOneBindLikeS("SELECT disease, class, text, risk, refs FROM `drug_disease` WHERE drug LIKE ? ORDER BY risk", $drug);
   }

   public function getDrugDiseaseDrug()
   {
      return $this->queryAll("SELECT * FROM `drug_disease_drugs`");
   }

   public function searchDrugDiseaseByDrug($value)
   {
      return $this->queryOneParamOneBindLikeS("SELECT * FROM `drug_disease_drugs` WHERE label LIKE ? ORDER BY label", $value);
   }

   public function searchDrugDiseaseByDis($value)
   {
      return $this->queryOneParamOneBindLikeS("SELECT * FROM `drug_disease` WHERE disease LIKE ?", $value);
   }


   public function searchPregnancyDrug($drug, $is_pregnancy)
   {
      return $this->queryTwoParamsTwoBindsLikeSI("SELECT id, value, label, link FROM `drugs` WHERE value LIKE ? AND is_pregnancy=?", $drug, $is_pregnancy);
   }

   public function getPregnancyDrug($id)
   {
      return $this->queryOneParamOneBindS("SELECT id, label, pregnancy_fda, pregnancy_au, pregnancy_text, pregnancy_refs FROM `drugs` WHERE id=?", $id);
   }


   public function getDrugHeptoxList($is_heptox)
   {
      return $this->queryOneParamOneBindI("SELECT id, value, label, link, heptox_score FROM `drugs` WHERE is_heptox=? ORDER BY label", $is_heptox);
   }

   public function getDrugHeptoxItem($id)
   {
      return $this->queryOneParamOneBindS("SELECT id, label, heptox_score, heptox_text, heptox_note, heptox_outcome, heptox_refs FROM `drugs` WHERE id=?", $id);
   }


   public function getDrugPulmtoxList($class, $is_pulmtox)
   {
      return $this->queryTwoParamsTwoBindsSI("SELECT id, value, label, link FROM `drugs` WHERE pulmtox_class=? AND is_pulmtox=? ORDER BY label", $class, $is_pulmtox);
   }

   public function getDrugPulmtoxOtherList($class, $is_pulmtox)
   {
      return $this->queryTwoParamsTwoBindsSI("SELECT id, value, label, link FROM `other` WHERE pulmtox_class=? AND is_pulmtox=? ORDER BY label", $class, $is_pulmtox);
   }

   public function getDrugPulmtoxItem($id)
   {
      return $this->queryOneParamOneBindS("SELECT id, label, pulmtox_cases, pulmtox_subpatterns, pulmtox_subpatterns_cases, pulmtox_refs FROM `drugs` WHERE id=?", $id);
   }

   public function getDrugPulmtoxOtherItem($id)
   {
      return $this->queryOneParamOneBindS("SELECT id, label, pulmtox_cases, pulmtox_subpatterns, pulmtox_subpatterns_cases, pulmtox_refs FROM `other` WHERE id=?", $id);
   }

   public function getDrugPulmtoxSubpatternById($subpattern_id)
   {
      return $this->queryOneParamOneBindI("SELECT * FROM `pulmtox_subpattern` WHERE subpattern_id=?", $subpattern_id);
   }

   public function getDrugPulmtoxWithSubpatternId($subpattern_id)
   {
      return $this->queryOneParamOneBindLikeRegexS("SELECT id, label, link, pulmtox_subpatterns, pulmtox_subpatterns_cases FROM `drugs` WHERE pulmtox_subpatterns REGEXP ? ORDER BY label", $subpattern_id);
   }

   public function getDrugPulmtoxPattern()
   {
      return $this->queryAll("SELECT * FROM `pulmtox_pattern`");
   }

   public function getDrugPulmtoxByPatternId($pattern_id)
   {
      return $this->queryOneParamOneBindI("SELECT subpattern_id, subpattern_number, subpattern_title FROM `pulmtox_subpattern` WHERE pattern_id=?", $pattern_id);
   }


   public function getDrugNephtoxList($is_nephtox)
   {
      return $this->queryOneParamOneBindI("SELECT id, value, label, link FROM `drugs` WHERE is_nephtox=? ORDER BY label", $is_nephtox);
   }

   public function getDrugNephtoxItem($id)
   {
      return $this->queryOneParamOneBindS("SELECT id, label, link, nephtox_diseases, nephtox_morphologies, nephtox_refs FROM `drugs` WHERE id=?", $id);
   }

   public function getDrugNephtoxItemDisease($id)
   {
      return $this->queryOneParamOneBindI("SELECT * FROM `nephtox_disease` WHERE id=?", $id);
   }

   public function getDrugNephtoxItemMorphology($id)
   {
      return $this->queryOneParamOneBindI("SELECT * FROM `nephtox_morphology` WHERE id=?", $id);
   }

   public function getDrugNephtoxDisease()
   {
      return $this->queryAll("SELECT * FROM `nephtox_disease` ORDER BY name");
   }

   public function getDrugNephtoxDiseaseItem($id)
   {
      return $this->queryOneParamOneBindI("SELECT name FROM `nephtox_disease` WHERE id=?", $id);
   }

   public function getDrugNephtoxWithDisease($nephtox_diseases)
   {
      return $this->queryOneParamOneBindLikeRegexS("SELECT id, value, label, link FROM `drugs` WHERE nephtox_diseases REGEXP ? ORDER BY label", $nephtox_diseases);
   }

   public function getDrugNephtoxMorphology()
   {
      return $this->queryAll("SELECT * FROM `nephtox_morphology`");
   }

   public function getDrugNephtoxMorphologyItem($id)
   {
      return $this->queryOneParamOneBindI("SELECT * FROM `nephtox_morphology` WHERE id=?", $id);
   }

   public function getDrugNephtoxWithMorphology($nephtox_morphologies)
   {
      return $this->queryOneParamOneBindLikeRegexS("SELECT id, value, label, link FROM `drugs` WHERE nephtox_morphologies REGEXP ? ORDER BY label", $nephtox_morphologies);
   }


   public function searchDrugOlders($drug, $is_older)
   {
      return $this->queryTwoParamsTwoBindsLikeSI("SELECT id, value, label, link FROM `drugs` WHERE value LIKE ? AND is_older=?", $drug, $is_older);
   }

   public function getDrugOlders($id)
   {
      return $this->queryOneParamOneBindS("SELECT id, label, older_beers_1, older_beers_2, older_beers_3, older_beers_4, older_beers_5, older_text FROM `drugs` WHERE id=?", $id);
   }

   public function searchDrugQt($drug, $is_qt)
   {
      return $this->queryTwoParamsTwoBindsLikeSI("SELECT id, value, label, link FROM `drugs` WHERE value LIKE ? AND is_qt=?", $drug, $is_qt);
   }

   public function getDrugQt($id)
   {
      return $this->queryOneParamOneBindS("SELECT id, label, qt_category, qt_prolongation, qt_tdp, qt_ecg, qt_lqts, qt_contraindication FROM `drugs` WHERE id=?", $id);
   }

   public function searchDrugQtCalc($drug, $is_qt)
   {
      return $this->queryTwoParamsTwoBindsLikeSI("SELECT id, label, qt_category, qt_ecg FROM `drugs` WHERE value LIKE ? AND is_qt=?", $drug, $is_qt);
   }

   public function getDrugQtFactor()
   {
      return $this->queryAll("SELECT * FROM `qt_factors`");
   }

   public function getDrugQtIndication()
   {
      return $this->queryAll("SELECT * FROM `qt_indication`");
   }

   public function getDrugMethem($is_methem)
   {
      return $this->queryOneParamOneBindI("SELECT id, label, methem_text, methem_refs FROM `drugs` WHERE is_methem=? ORDER BY label", $is_methem);
   }

   public function getDrugDisl($is_disl)
   {
      return $this->queryOneParamOneBindI("SELECT id, label, disl_ic FROM `drugs` WHERE is_disl=? ORDER BY disl_ic DESC", $is_disl);
   }


   // auth and user
   public function checkRegisterEmail($email)
   {
      return $this->queryOneParamOneBindRowS("SELECT id, email FROM `user` WHERE email=?", $email);
   }

   public function checkRegisterUsername($email)
   {
      return $this->queryOneParamOneBindRowS("SELECT id, username FROM `user` WHERE username=?", $email);
   }

   public function registerUser($email, $username, $password, $name, $surname, $verify_code, $verify_code_time)
   {
      return $this->querySevenParamsSevenBindsInsertSSSSSSS("INSERT INTO `user` (id, email, username, password, name, surname, verify_code, verify_code_time) VALUES (null, ?, ?, ?, ?, ?, ?, ?)", $email, $username, $password, $name, $surname, $verify_code, $verify_code_time);
   }

   public function updateMobileRefreshToken($refresh_token, $device_token)
   {
      return $this->queryTwoParamsTwoBindsSetSS("UPDATE `user_app` SET refresh_token=? WHERE token=?", $refresh_token, $device_token);
   }

   public function checkMobileRefreshToken($uid, $device_token, $refresh_token)
   {
      return $this->queryThreeParamsThreeBindsISS("SELECT refresh_token FROM `user_app` WHERE user_id=? AND token=? AND refresh_token=?", $uid, $device_token, $refresh_token);
   }

   public function getRowUserWithEmail($email)
   {
      return $this->queryOneParamOneBindRowS("SELECT * FROM `user` WHERE email=?", $email);
   }

   public function getUserWithEmail($email)
   {
      return $this->queryOneParamOneBindS("SELECT * FROM `user` WHERE email=?", $email);
   }

   public function getUserWithId($id)
   {
      return $this->queryOneParamOneBindI("SELECT * FROM `user` WHERE id=?", $id);
   }


   // verify
   public function getUserVerifCode($verify_code)
   {
      return $this->queryOneParamOneBindS("SELECT email, username, verify_code, verify_code_time FROM `user` WHERE verify_code=?", $verify_code);
   }

   public function updateUserVerifCode($new_verify_code, $new_verify_code_time, $old_verify_code)
   {
      return $this->queryThreeParamsThreeBindsSetSSS("UPDATE `user` SET verify_code=?, verify_code_time=? WHERE verify_code=?", $new_verify_code, $new_verify_code_time, $old_verify_code);
   }

   public function updateUserVerifCodeFinally($new_verify_code, $verify_status, $new_verify_code_time, $old_verify_code)
   {
      return $this->queryFourParamsFourBindsSetSISS("UPDATE `user` SET verify_code=?, verify_status=?, verify_code_time=? WHERE verify_code=?", $new_verify_code, $verify_status, $new_verify_code_time, $old_verify_code);
   }

   public function addPassRecovery($pass_recovery, $pass_recovery_time, $email)
   {
      return $this->queryThreeParamsThreeBindsSetSSS("UPDATE `user` SET pass_recovery=?, pass_recovery_time=? WHERE email=?", $pass_recovery, $pass_recovery_time, $email);
   }

   public function getPassRecovery($pass_recovery)
   {
      return $this->queryOneParamOneBindS("SELECT * FROM `user` WHERE pass_recovery=?", $pass_recovery);
   }

   public function changePassRecoveryandPass($password, $pass_recovery_quantity, $pass_recover_time, $pass_recovery)
   {
      return $this->queryFourParamsFourBindsSetSISS("UPDATE `user` SET password=?, pass_recovery_quantity=?, pass_recovery=NULL, pass_recovery_time=? WHERE pass_recovery=?", $password, $pass_recovery_quantity, $pass_recover_time, $pass_recovery);
   }


   // userchange
   public function changeUserMail($new_email, $new_verify_code, $verify_status, $new_verify_code_time, $email_change_quantity, $old_email)
   {
      return $this->querySixParamsSixBindsSetSSISIS("UPDATE `user` SET email=?, verify_code=?, verify_status=?, verify_code_time=?, email_change_quantity=? WHERE email=?", $new_email, $new_verify_code, $verify_status, $new_verify_code_time, $email_change_quantity, $old_email);
   }

   public function changeUserPassword($newpass, $pass_recovery_quantity, $pass_recovery_time, $email)
   {
      return $this->queryFourParamsFourBindsSetSSSS("UPDATE `user` SET password=?, pass_recovery_quantity=?, pass_recovery_time=? WHERE email=?", $newpass, $pass_recovery_quantity, $pass_recovery_time, $email);
   }

   public function deleteUserAcc($uid)
   {
      return $this->queryOneParamOneBindDeleteI("DELETE FROM `user` WHERE id=?", $uid);
   }


   // payment
   public function getUserPayment($uid)
   {
      return $this->queryOneParamOneBindI("SELECT payment, payment_expire FROM `user` WHERE id=?", $uid);
   }


   public function getPathwaysArticles($page, $limit)
   {
      return $this->queryTwoParamsTwoBindsII("SELECT * FROM pathways_articles WHERE id ? ORDER BY id LIMIT ?", $page, $limit);
   }

   public function getPathway($link)
   {
      return $this->queryOneParamOneBindS("SELECT id, pathway FROM pathways WHERE link=?", $link);
   }

   public function getIsAppClose($close_id)
   {
      return $this->queryOneParamOneBindI("SELECT * FROM `app_close` WHERE id = ?", $close_id);
   }

   public function getDeviceToken($token)
   {
      return $this->queryOneParamOneBindS("SELECT user_id, token, unique_id, device_name, version FROM `user_app` WHERE token = ?", $token);
   }

   public function addUserApp($uid, $token, $unique_id, $device_name, $version, $user_ip)
   {
      return $this->querySixParamsSixBindsInsertISSSSS("INSERT INTO `user_app` (id, user_id, token, unique_id, device_name, version, user_ip) VALUES (null, ?, ?, ?, ?, ?, ?)", $uid, $token, $unique_id, $device_name, $version, $user_ip);
   }

   public function updateUserAppWithDeviceToken($uid, $unique_id, $device_name, $version, $user_ip, $token)
   {
      return $this->querySixParamsSixBindsSetISSSSS("UPDATE `user_app` SET user_id=?, unique_id=?, device_name=?, version=?, user_ip=? WHERE token=?", $uid, $unique_id, $device_name, $version, $user_ip, $token);
   }

   public function deleteUserAppWithUid($uid)
   {
      return $this->queryOneParamOneBindDeleteI("DELETE FROM `user_app` WHERE user_id=?", $uid);
   }

   public function deleteUserAppWithUniqueId($unique_id)
   {
      return $this->queryOneParamOneBindDeleteS("DELETE FROM `user_app` WHERE unique_id=? AND user_id IS NULL", $unique_id);
   }

   public function changeUserAppWithDeviceTokenAndUid($history, $refresh_token, $uid, $notif_token)
   {
      return $this->queryFourParamsFourBindsSetSSIS("UPDATE `user_app` SET user_id=null, history=?, refresh_token=? WHERE user_id=? AND token=?", $history, $refresh_token, $uid, $notif_token);
   }

   public function getUserAppWithDeviceTokenAndUid($uid, $device_token)
   {
      return $this->queryTwoParamsTwoBindsIS("SELECT * FROM `user_app` WHERE user_id=? AND token=?", $uid, $device_token);
   }

   public function getUserAppWithUid($uid)
   {
      return $this->queryOneParamOneBindI("SELECT * FROM `user_app` WHERE user_id=?", $uid);
   }

   public function getDeviceTokenWithToken($token)
   {
      return $this->queryOneParamOneBindS("SELECT user_id, token, block, unique_id, device_name, version FROM `user_app` WHERE token = ?", $token);
   }

   public function changeTokenBlockWithUid($num, $uid)
   {
      return $this->queryTwoParamsTwoBindsSetII("UPDATE `user_app` SET block=? WHERE user_id=?", $num, $uid);
   }

   public function changeTokenBlockWithUniqueId($num, $unique_id)
   {
      return $this->queryTwoParamsTwoBindsSetIS("UPDATE `user_app` SET block=? WHERE unique_id=?", $num, $unique_id);
   }


   //usernotif
   public function getUserNotification($uid)
   {
      return $this->queryOneParamOneBindI("SELECT notify FROM `user` WHERE id=?", $uid);
   }

   public function updateUserNotifications($number, $uid)
   {
      return $this->queryTwoParamsTwoBindsSetII("UPDATE `user` SET notify=? WHERE id=?", $number, $uid);
   }


   //screenshotQuantity
   public function getScreenshotsQuantWithUid($uid)
   {
      return $this->queryOneParamOneBindI("SELECT * FROM `user_screenshot_quantity` WHERE user_id=?", $uid);
   }

   public function addScreenshotsQuant($uid, $notify)
   {
      return $this->queryTwoParamsTwoBindsInsertIS("INSERT INTO `user_screenshot_quantity` (user_id, notify) VALUES (?, ?)", $uid, $notify);
   }

   public function changeScreenshotsQuant($notify, $uid)
   {
      return $this->queryTwoParamsTwoBindsSetSI("UPDATE `user_screenshot_quantity` SET number=number + 1, notify=? WHERE user_id=?", $notify, $uid);
   }

   //favorites
   public function getUserFavoritesWithUid($user_id)
   {
      return $this->queryOneParamOneBindI("SELECT category, favorites_id, title, link FROM `user_favorites` WHERE user_id=?", $user_id);
   }

   public function getUserFavoritesWithUidAndCategory($user_id, $category)
   {
      return $this->queryTwoParamsTwoBindsIS("SELECT id, favorites_id, title FROM `user_favorites` WHERE user_id=? AND category=?", $user_id, $category);
   }

   public function deleteUserFavorites($user_id, $favorites_id)
   {
      return $this->queryTwoParamsTwoBindsDeleteIS("DELETE FROM `user_favorites` WHERE user_id=? AND favorites_id=?", $user_id, $favorites_id);
   }

   public function addUserFavorites($user_id, $category, $favorites_id, $title, $link)
   {
      return $this->queryFiveParamsFiveBindsInsertISSSS("INSERT INTO `user_favorites` (user_id, category, favorites_id, title, link) VALUES (?, ?, ?, ?, ?)", $user_id, $category, $favorites_id, $title, $link);
   }
}