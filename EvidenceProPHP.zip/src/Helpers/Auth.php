<?php

namespace App\Helpers;

use Firebase\JWT\JWT;
use Firebase\JWT\Key;

class Auth
{
    public static function check()
    {
        $headers = getallheaders();
        $token = null;

        if (isset($headers['Authorization'])) {
            $token = $headers['Authorization'];
        } elseif (isset($headers['authorization'])) {
            $token = $headers['authorization'];
        }

        if (!$token) {
            http_response_code(401);
            echo json_encode(["status" => false, "message" => "No token provided"]);
            exit;
        }

        try {
            $token = str_replace('Bearer ', '', $token);
            $secretKey = $_ENV['SECRET_KEY'];
            $decoded = JWT::decode($token, new Key($secretKey, 'HS256'));

            return $decoded->data;
        } catch (\Exception $e) {
            http_response_code(401);
            echo json_encode(["status" => false, "message" => "Invalid token"]);
            exit;
        }
    }

    public static function checkPayment($model, $id, $platform)
    {
        if ($platform === 'android') {

        } else if ($platform === 'ios') {

        } else {
            $getUserPayment = $model->getUserPayment($id);

            if (!$getUserPayment || ($getUserPayment && $getUserPayment[0]['payment'] === 0)) {
                http_response_code(403);
                echo json_encode(["status" => false, "message" => "No payment"]);
                exit;
            }
        }


    }
}