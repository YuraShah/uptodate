<?php

namespace App\Helpers;


class Logout
{
   public static function out($model, $uid, $device_token, $email = '', $fname = '', $sname = '')
   {
      date_default_timezone_set('Europe/Moscow');

      $chars = '';
      if($email !== '' && $fname !== '' && $sname !== '') {
          $chars = '['.$email.'-'.$fname.'-'.$sname.']';
      }

      $history = "$uid";
      $currentDate = date("d.m.Y");
      $currentTime = date("H:i");
      $getUserAppWithDeviceTokenAndUid = $model->getUserAppWithDeviceTokenAndUid($uid, $device_token);
      
      if ($getUserAppWithDeviceTokenAndUid) {
         $history = $history . " ". $chars . " ($currentDate-$currentTime)+" . $getUserAppWithDeviceTokenAndUid[0]['history'];

         $filePath = __DIR__ . '../../data/logs/user_logs_app.txt';

         $user_id = $getUserAppWithDeviceTokenAndUid[0]['user_id'];
         $token = $getUserAppWithDeviceTokenAndUid[0]['token'];
         $unique_id = $getUserAppWithDeviceTokenAndUid[0]['unique_id'];
         $device_name = $getUserAppWithDeviceTokenAndUid[0]['device_name'];
         $version = $getUserAppWithDeviceTokenAndUid[0]['version'];
         $user_ip = $getUserAppWithDeviceTokenAndUid[0]['user_ip'];

         $logEntry = "User ID: $user_id, Device Token: $token, Device ID: $unique_id, Device: $device_name, App Version: $version, User IP: $user_ip\n";

         file_put_contents($filePath, $logEntry, FILE_APPEND);
      }

      $model->changeUserAppWithDeviceTokenAndUid($history, null, $uid, $device_token);
   }
}