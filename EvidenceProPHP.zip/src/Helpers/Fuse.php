<?php

namespace App\Helpers;


class Fuse
{
   public static function fuseSearch($fuseArray, $data)
   {
      $options = [
         'keys' => ['label'],
         'threshold' => 0.3,
         'distance' => 100,
         'location' => 0,
      ];

      $fuse = new \Fuse\Fuse($fuseArray, $options);
      $searchQuery = is_int($data) ? (string) $data : $data;

      if ($fuse) {
         $result = [];

         $fuseResult = count($fuse->search($searchQuery)) > 10 ? array_slice($fuse->search($searchQuery), 0, 10) : $fuse->search($searchQuery);

         foreach ($fuseResult as $key => $value) {
            $result[] = [
               'id' => $value['item']['id'],
               'value' => $value['item']['value'],
               'label' => $value['item']['label'],
            ];

            if (isset($value['item']['link']))
               $result[$key]['link'] = $value['item']['link'];
         }

         return $result;
      }

      return null;
   }
}