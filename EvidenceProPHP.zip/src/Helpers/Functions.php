<?php

namespace App\Helpers;

class Functions
{
   public static function firstLetterLowerCase($str, $encoding = 'UTF-8'): string
   {
      return mb_strtolower(mb_substr($str, 0, 1, $encoding), $encoding) . mb_substr($str, 1, null, $encoding);
   }

   public static function textTranslit($text): string
   {
      if (preg_match('/[а-яА-ЯёЁ]/u', $text)) {
         return $text;
      }

      $arrEng = ['A', 'a', 'B', 'b', 'V', 'v', 'G', 'g', 'D', 'd', 'E', 'e', 'Z', 'z', 'I', 'i', 'J', 'j', 'K', 'k', 'L', 'l', 'M', 'm', 'N', 'n', 'O', 'o', 'P', 'p', 'R', 'r', 'S', 's', 'T', 't', 'U', 'u', 'F', 'f', 'H', 'h', 'C', 'c', 'Y', 'y', 'Q', 'q', 'W', 'w', 'X', 'x'];
      $arrRus = ['а', 'а', 'б', 'б', 'в', 'в', 'г', 'г', 'д', 'д', 'е', 'е', 'з', 'з', 'и', 'и', 'дж', 'дж', 'к', 'к', 'л', 'л', 'м', 'м', 'н', 'н', 'о', 'о', 'п', 'п', 'р', 'р', 'с', 'с', 'т', 'т', 'у', 'у', 'ф', 'ф', 'х', 'х', 'ж', 'ж', 'й', 'й', 'к', 'к', 'в', 'в', 'х', 'х'];

      $text = str_replace($arrEng, $arrRus, $text);

      $text = preg_replace('/йу/ui', 'ю', $text);

      return $text;
   }

   public static function searchFullData($value, $what)
   {
      $full_data = file_get_contents(__DIR__ . '../../data/full-list.json');
      $full_data_decode = json_decode($full_data, true);
      $searchedData = '';

      foreach ($full_data_decode as $search) {
         if ($value === $search['id']) {
            $searchedData = $search[$what];
            break;
         }
      }

      return $searchedData;
   }


   public static function changeRefersToArr($separator, $refs)
   {
      $refsToArr = explode($separator, $refs);
      return $refsToArr;
   }
}