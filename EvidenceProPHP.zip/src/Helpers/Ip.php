<?php

namespace App\Helpers;


class Ip
{
   public static function get_client_ip()
   {
      return $_SERVER['HTTP_X_FORWARDED_FOR']
         ?? $_SERVER['REMOTE_ADDR']
         ?? $_SERVER['HTTP_CLIENT_IP']
         ?? '';
   }
}