<?php

namespace App\Helpers;

require '../../vendor/autoload.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;


class SendEmail
{
   public static function send($email, $subject, $body)
   {
      $mail = new PHPMailer(true);

      try {
         $mail->CharSet = 'UTF-8';
         $mail->isSMTP();
         $mail->Host = 'mail.ru.evidence.am';
         $mail->SMTPAuth = true;
         $mail->Username = 'info@ru.evidence.am';
         $mail->Password = 'O+;Z]fA]1$8O';
         $mail->SMTPSecure = 'ssl';
         $mail->Port = 465;
         $mail->setFrom('info@ru.evidence.am');
         $mail->addAddress($email);

         $mail->isHTML(true);
         $mail->Subject = $subject;
         $message = "<style>
            @media (max-width: 768px) {
               .responsive-img {
                  width: 100%;
                  height: 300px;
               }
            }
         </style>

         <div>
            <header style='background-color: #0492c2; text-align: center; padding: 15px;'>
               <img src='https://ru.evidence.am/logo512.png' width='150' />
            </header>

            <div style='margin: 5px 0;'>
               $body
            </div>

            <footer style='background-color: #0492c2; text-align: center; font-size: 18px; padding: 15px; color: #fff;'>
               <div style='margin: 7px 0;'>Эл.почта:
                  <a href='mailto:evidence_ebm@mail.ru' style='text-decoration: none; color: #000000;'>
                     evidence_ebm@mail.ru
                  </a>
               </div>
               <div style='margin: 7px 0;'>Телеграм:
                  <a href='https://vk.com/club230049359' style='text-decoration: none; color: #000000;'>
                     Evidence
                  </a>
               </div>
               <div style='margin: 7px 0;'>Вк:
                  <a href='https://t.me/evidence_ebm' style='text-decoration: none; color: #000000;'>
                     Evidence
                  </a>
               </div>
            </footer>
         </div>";
         $mail->Body = $message;
         $mail->AltBody = 'This is the body in plain text for non-HTML mail clients';

         $mail->send();
         return true;
      } catch (Exception $e) {
         // echo "Message could not be sent. Mailer Error: {$mail->ErrorInfo}";
         return false;
      }
   }

   public static function sendEmailAttention($email)
   {
      $mail = new PHPMailer(true);

      try {
         $mail->CharSet = 'UTF-8';
         //Server settings
         // $mail->SMTPDebug = SMTP::DEBUG_SERVER;                      //Enable verbose debug output
         $mail->isSMTP();                                            //Send using SMTP
         $mail->Host = 'mail.evidence.am';                     //Set the SMTP server to send through
         $mail->SMTPAuth = true;                                   //Enable SMTP authentication
         $mail->Username = 'info@evidence.am';                     //SMTP username
         $mail->Password = '*y=#dJ?8R427';                               //SMTP password
         $mail->SMTPSecure = 'ssl';            //Enable implicit TLS encryption
         $mail->Port = 465;                                    //TCP port to connect to; use 587 if you have set `SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS`

         //Recipients
         $mail->setFrom('info@evidence.am');
         $mail->addAddress($email);     //Add a recipient
         //  $mail->addAddress('ellen@example.com');               //Name is optional
         //  $mail->addReplyTo('info@example.com', 'Information');
         //  $mail->addCC('cc@example.com');
         //  $mail->addBCC('bcc@example.com');

         //Attachments
         //  $mail->addAttachment('/var/tmp/file.tar.gz');         //Add attachments
         //  $mail->addAttachment('/tmp/image.jpg', 'new.jpg');    //Optional name

         //Content
         $mail->isHTML(true);                                  //Set email format to HTML
         $mail->Subject = 'Գաղտնաբառի փոփոխություն';
         $mail->Body = "<h4 style='color: rgb(23, 88, 131); line-height: 1.6; font-size: 23px;'>Գաղտնաբառի փոփոխություն։</h4> <p style='margin: 5px 0; line-height: 1.6; font-size: 21px;'>Ձեր գատղտնաբառը փոխվեց։ </p> <p style='line-height: 1.6; font-size: 20px;'>Եթե գաղտնաբառը դուք չեք փոխել, ապա կապվեք մեզ հետ։</p>";
         $mail->AltBody = 'This is the body in plain text for non-HTML mail clients';

         $mail->send();
         // echo 'Message has been sent';
         return true;
      } catch (Exception $e) {
         // echo "Message could not be sent. Mailer Error: {$mail->ErrorInfo}";
         return false;
      }
   }
}