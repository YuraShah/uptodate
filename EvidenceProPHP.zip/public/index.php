<?php

require '../vendor/autoload.php';

use Dotenv\Dotenv;
use FastRoute\RouteCollector;

// Load environment variables from .env file
$dotenv = Dotenv::createImmutable(__DIR__ . '/../');
$dotenv->load();

// Include the routes definition
$routes = require '../routes.php';

$dispatcher = FastRoute\simpleDispatcher(function (RouteCollector $router) use ($routes) {

    // Include the routes setup from routes.php
    $routes($router);

});

// Fetch method and URI from somewhere
$httpMethod = $_SERVER['REQUEST_METHOD'];
$uri = $_SERVER['REQUEST_URI'];

// Strip query string (?foo=bar) and decode URI
if (false !== $pos = strpos($uri, '?')) {
    $uri = substr($uri, 0, $pos);
}
$uri = rawurldecode($uri);

// Function to set CORS headers for all responses
function setCorsHeaders(): void
{
    $origin = $_SERVER['HTTP_ORIGIN'] ?? '';
    $allowedOrigins = explode(',', $_ENV['ALLOWED_ORIGINS'] ?? 'http://localhost:3000');

    if (in_array($origin, $allowedOrigins)) {
        header("Access-Control-Allow-Origin: $origin");
    }

    header('Access-Control-Allow-Credentials: true');
    header('Access-Control-Allow-Methods: GET, POST, PATCH, PUT, DELETE, OPTIONS');
    header('Access-Control-Allow-Headers: Origin, Content-Type, X-Auth-Token, Authorization');
}

// Set CORS headers for all responses
setCorsHeaders();

// Handle preflight OPTIONS request
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(204);
    exit;
}

// require '../redis.php';

// Dispatch the route
$routeInfo = $dispatcher->dispatch($httpMethod, $uri);

switch ($routeInfo[0]) {
    case FastRoute\Dispatcher::NOT_FOUND:
        // Handle 404 Not Found
        http_response_code(404);
        header("Content-Type: application/json");

        echo json_encode(["status" => false, "message" => "Route not found"]);
        break;

    case FastRoute\Dispatcher::METHOD_NOT_ALLOWED:
        $allowedMethods = $routeInfo[1];

        // Handle 405 Method Not Allowed
        http_response_code(405);
        header("Content-Type: application/json");
        header("Allow: " . implode(", ", $allowedMethods));

        echo json_encode(["status" => false, "message" => "Method not allowed"]);
        break;

    case FastRoute\Dispatcher::FOUND:
        // Handle successful route matching
        $handler = $routeInfo[1];
        $vars = $routeInfo[2];

        // Set header for JSON response
        header("Content-Type: application/json");

        try {
            // auth check should happen here for protected pages

            // Call the route handler with the route variables
            call_user_func_array($handler, $vars);
        } catch (Throwable $ex) {
            http_response_code(500);
            echo json_encode([
                "message" => $ex->getMessage(),
                "error" => $ex->getTrace()
            ]);
        }
        break;
}