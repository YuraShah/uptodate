declare module '@env' {
   export const APPLEAPIKEY: string;
   export const GOOGLEAPIKEY: string;
}