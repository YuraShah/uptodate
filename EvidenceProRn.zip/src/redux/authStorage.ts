import * as SecureStore from 'expo-secure-store';
import { jwtDecode } from 'jwt-decode';
import { IUser } from '@/src/types/types';
import "core-js/stable/atob";

const ACCESS_TOKEN_KEY = 'auth_access_token';
const REFRESH_TOKEN_KEY = 'auth_refresh_token';

export const authStorage = {
    setAccessToken: (token: string) => SecureStore.setItemAsync(ACCESS_TOKEN_KEY, token),
    getAccessToken: () => SecureStore.getItemAsync(ACCESS_TOKEN_KEY),
    removeAccessToken: () => SecureStore.deleteItemAsync(ACCESS_TOKEN_KEY),

    setRefreshToken: (token: string) => SecureStore.setItemAsync(REFRESH_TOKEN_KEY, token),
    getRefreshToken: () => SecureStore.getItemAsync(REFRESH_TOKEN_KEY),
    removeRefreshToken: () => SecureStore.deleteItemAsync(REFRESH_TOKEN_KEY),

    setTokens: async (accessToken: string, refreshToken: string) => {
        await SecureStore.setItemAsync(ACCESS_TOKEN_KEY, accessToken);
        await SecureStore.setItemAsync(REFRESH_TOKEN_KEY, refreshToken);
    },

    removeTokens: async () => {
        await SecureStore.deleteItemAsync(ACCESS_TOKEN_KEY);
        await SecureStore.deleteItemAsync(REFRESH_TOKEN_KEY);
    },

    // Utility function to check if the user is logged in
    isLoggedIn: async () => {
        const accessToken = await SecureStore.getItemAsync(ACCESS_TOKEN_KEY);
        const refreshToken = await SecureStore.getItemAsync(REFRESH_TOKEN_KEY);
        return !!(accessToken && refreshToken);
    },

    getUserFromToken: async (): Promise<IUser | null> => {
        try {
            const token = await SecureStore.getItemAsync(ACCESS_TOKEN_KEY);
            if (!token) return null;

            const decodedToken = jwtDecode<{ data: IUser }>(token);
            return decodedToken.data;
        } catch (error) {
            // console.error('Error decoding token:', error);
            return null;
        }
    },
};