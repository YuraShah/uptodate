import { configureStore, ThunkAction, Action } from '@reduxjs/toolkit';
import verifyReducer from './features/verifyRecovery/verifySlice';
import fontSizeReducer from './features/fontSize/fontSizeSlice';
import authReducer from './features/auth/authSlice';
import notificationsReducer from './features/notifications/notificationsSlice';
import deviceReducer from './features/deviceParams/deviceParamsSlice';
import themeReducer from './features/theme/themeSlice';
import paymentReducer from './features/payment/paymentSlice';
import userReducer from './features/user/userSlice';

export const store = configureStore({
  reducer: {
    authStore: authReducer,
    verifyStore: verifyReducer,
    fontSizeStore: fontSizeReducer,
    notificationsStore: notificationsReducer,
    deviceStore: deviceReducer,
    themeStore: themeReducer,
    paymentStore: paymentReducer,
    userStore: userReducer,
  },
});

export type AppDispatch = typeof store.dispatch;
export type RootState = ReturnType<typeof store.getState>;
export type AppThunk<ReturnType = void> = ThunkAction<
  ReturnType,
  RootState,
  unknown,
  Action<string>
>;
