import axios, { AxiosError, AxiosInstance, InternalAxiosRequestConfig } from 'axios';
import { LINKS } from '@/src/types/types';
import { authStorage } from './authStorage';
import { logoutUser } from './features/auth/logoutAction';
import * as RootNavigation from '@/src/navigation/rootNavigation';
import { Toast } from 'toastify-react-native';

interface RefreshTokenResponse {
    accessToken: string;
}

const BASE_URL = 'http://192.168.18.3:8000';
// const BASE_URL = 'https://api.evidence.am';

const axiosInstance: AxiosInstance = axios.create({
    baseURL: BASE_URL,
    headers: {
        'Content-Type': 'application/json',
    },
});

axiosInstance.defaults.withCredentials = true;


axiosInstance.interceptors.request.use(
    async (config: InternalAxiosRequestConfig) => {
        const token = await authStorage.getAccessToken();
        if (token) {
            config.headers['Authorization'] = `Bearer ${token}`;
        }
        return config;
    },
    (error) => {
        return Promise.reject(error);
    }
);

axiosInstance.interceptors.response.use(
    (response) => response,
    async (error: AxiosError) => {
        if (!error.config) {
            return Promise.reject(error);
        }

        const originalRequest = error.config as InternalAxiosRequestConfig & { _retry?: boolean };

        if (error.response?.status === 401 && !originalRequest._retry) {
            originalRequest._retry = true;
            try {
                const refreshToken = await authStorage.getRefreshToken();

                if (!refreshToken) {
                    throw new Error('No refresh token available');
                }

                const refreshResponse = await axios.get<RefreshTokenResponse>(LINKS.TOKEN, {
                    headers: {
                        'Authorization': `Bearer ${refreshToken}`
                    }
                });

                const newToken = refreshResponse.data.accessToken;
                await authStorage.setAccessToken(newToken);

                if (originalRequest.headers) {
                    originalRequest.headers['Authorization'] = `Bearer ${newToken}`;
                }

                return axiosInstance(originalRequest);
            } catch (refreshError) {
                await logoutUser();

                Toast.error("Конец сеанса. Войдите снова", "top")

                return Promise.reject(refreshError);
            }
        }

        if (error.response?.status === 429) {
            RootNavigation.navigate('ManyRequests');
        }

        if (error.response?.status === 404) {
            RootNavigation.navigate('Home');
            Toast.error("Неверная ссылка", "top")
        }

        return Promise.reject(error);
    }
);

export default axiosInstance;