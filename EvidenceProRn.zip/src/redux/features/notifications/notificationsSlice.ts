import { createSlice, PayloadAction } from '@reduxjs/toolkit';
import { getSecureDeviceId, registerForPushNotifications } from './notificationsAPI';


interface INotificationsSlice {
   deviceToken: string | undefined,
   isPushReady: boolean,
}

const initialState: INotificationsSlice = {
   deviceToken: undefined,
   isPushReady: false,
}

const notificationsSlice = createSlice({
   name: 'notifications',
   initialState,
   reducers: {
   },
   extraReducers: (builder) => {
      builder
         .addCase(registerForPushNotifications.fulfilled, (state, action: PayloadAction<any>) => {
            state.deviceToken = action.payload.split('[')[1]?.split(']')[0];
            state.isPushReady = true;
         })

         .addCase(getSecureDeviceId.fulfilled, (state, action: PayloadAction<string | null>) => {
            state.deviceToken = action.payload || undefined;
            state.isPushReady = true;
         })
   }
})

export default notificationsSlice.reducer
export const {} = notificationsSlice.actions