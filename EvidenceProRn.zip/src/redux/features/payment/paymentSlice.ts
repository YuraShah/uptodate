import { createSlice } from "@reduxjs/toolkit"
import { getPaymentExpire, getPaymentStatus } from "./paymentAPI"
import { LoaderStatusType } from "@/src/types/types"


interface IPaymentSlice {
   paymentData: number[],
   paymentStatus: LoaderStatusType,
   paymentError: string | null,

   paymentExpire: string[],
}

const initialState: IPaymentSlice = {
   paymentData: [],
   paymentStatus: 'idle',
   paymentError: null,

   paymentExpire: [],
}

const paymentSlice = createSlice({
   name: 'payment',
   initialState,
   reducers: {
   },
   extraReducers: (builder) => {
      builder
         .addCase(getPaymentStatus.pending, (state) => {
            state.paymentData = []
            state.paymentStatus = 'loading'
            state.paymentError = null
         })
         .addCase(getPaymentStatus.fulfilled, (state, action) => {
            if (action.payload.data && action.payload.data.length > 0) {
               state.paymentData = action.payload.data
            }
            state.paymentStatus = 'succeeded'
            state.paymentError = null
         })
         .addCase(getPaymentStatus.rejected, (state, action) => {
            state.paymentData = []
            state.paymentStatus = 'failed'
            state.paymentError = action.error.message || 'An error occurred'
         })

         .addCase(getPaymentExpire.fulfilled, (state, action) => {
            if (action.payload.data && action.payload.data.length > 0) {
               state.paymentExpire = action.payload.data
            }
         })
   }
})

export default paymentSlice.reducer;
export const {} = paymentSlice.actions