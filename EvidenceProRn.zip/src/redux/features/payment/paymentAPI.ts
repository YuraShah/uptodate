import { createAsyncThunk } from "@reduxjs/toolkit"
import axiosInstance from '@/src/redux/api';
import { IResponseData, LINKS } from "@/src/types/types"
import { AxiosError } from "axios";

export const getPaymentStatus = createAsyncThunk<IResponseData<number>, string>(
   'payment/status',
   async (obj, thunkAPI) => {
      return await axiosInstance
         .post<IResponseData<number>>(
            LINKS.USERPAYMENTSTATUS,
            obj,
         )
         .then((response) => {
            return response.data
         })
         .catch((err) => {
            const error = err as AxiosError;
            return thunkAPI.rejectWithValue({
               message: error.message,
               status: error.response?.status,
            });
         })
   }
)

export const getPaymentExpire = createAsyncThunk<IResponseData<string>, string>(
   'payment/expire',
   async (obj, thunkAPI) => {
      return await axiosInstance
         .post<IResponseData<string>>(
            LINKS.USERPAYMENTEXPIRE,
            obj,
         )
         .then((response) => {
            return response.data
         })
         .catch((err) => {
            return thunkAPI.rejectWithValue(err)
         })
   }
)