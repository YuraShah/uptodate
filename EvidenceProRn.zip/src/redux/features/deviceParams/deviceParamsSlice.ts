import { createSlice } from '@reduxjs/toolkit';
import { getUserNotification } from './deviceParamsAPI';


interface IDeviceParamsSlice {
   userNotificationNumber: number[],
}

const initialState: IDeviceParamsSlice = {
   userNotificationNumber: [],
}


const deviceParamsSlice = createSlice({
   name: 'device-params',
   initialState,
   reducers: {
      userNotificationNumberChange: (state, action) => {
         if (state.userNotificationNumber.length > 0) {
            state.userNotificationNumber = [action.payload]
         }
      },
   },
   extraReducers: (builder) => {
      builder
         .addCase(getUserNotification.fulfilled, (state, action) => {
            state.userNotificationNumber = action.payload.data
         })
   }
})

export default deviceParamsSlice.reducer
export const { userNotificationNumberChange } = deviceParamsSlice.actions