import { createAsyncThunk } from '@reduxjs/toolkit';
import { IResponseData, IResponseEmpty, IResponseMessage, LINKS } from '@/src/types/types';
import axiosInstance from '@/src/redux/api';


export const getDeviceBlockNum = createAsyncThunk<IResponseData<number>, string>(
   'get/device-block-num',
   async (token, thunkAPI) => {
      return await axiosInstance
         .post<IResponseData<number>>(
            LINKS.DEVICEBLOCK,
            token,
         )
         .then((response) => {
            return response.data
         })
         .catch((err) => {
            return thunkAPI.rejectWithValue(err.response.data);
         })
   }
)

export const getUserNotification = createAsyncThunk<IResponseData<number>, string>(
   'get/user-notification',
   async (uid, thunkAPI) => {
      return await axiosInstance
         .post<IResponseData<number>>(
            LINKS.GETUSERNOTIFICATION,
            uid,
         )
         .then((response) => {
            return response.data
         })
         .catch((err) => {
            return thunkAPI.rejectWithValue(err.response.data);
         })
   }
)

export const changeUserNotification = createAsyncThunk<IResponseEmpty, string>(
   'change/user-notification',
   async (obj, thunkAPI) => {
      return await axiosInstance
         .post<IResponseEmpty>(
            LINKS.CHANGEUSERNOTIFICATION,
            obj,
         )
         .then((response) => {
            return response.data
         })
         .catch((err) => {
            return thunkAPI.rejectWithValue(err.response.data);
         })
   }
)

export const addAndGetScreenshotsQuantity = createAsyncThunk<IResponseMessage, string>(
   'get/user-screenshots-quantity',
   async (uid, thunkAPI) => {
      return await axiosInstance
         .post<IResponseMessage>(
            LINKS.USERSCREENSHOTQUANTITY,
            uid,
         )
         .then((response) => {
            return response.data
         })
         .catch((err) => {
            return thunkAPI.rejectWithValue(err.response.data);
         })
   }
)