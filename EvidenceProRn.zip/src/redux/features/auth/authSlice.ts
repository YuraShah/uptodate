import { createSlice, PayloadAction } from '@reduxjs/toolkit';
import { getUser, ILoginResponse, registerUser, signIn, signOut } from './authAPI';
import { IUser, LoaderStatusType } from '@/src/types/types';
import { authStorage } from '@/src/redux/authStorage';

interface AuthState {
   status: LoaderStatusType;
   error: string;
   user: IUser | null;
   signMessage: string[];

   registerMessage: string[];
   registerStatus: LoaderStatusType;
}

const initialState: AuthState = {
   status: 'idle',
   user: null,
   error: '',
   signMessage: [],

   registerMessage: [],
   registerStatus: 'idle',
}


const authSlice = createSlice({
   name: 'auth',
   initialState,
   reducers: {
      resetAuth: (state) => {
         state.user = initialState.user;
         state.status = initialState.status;
         state.error = initialState.error;
      },
      clearRegisterMessage: (state) => {
         state.registerMessage = []
      },
      clearSignMessage: (state) => {
         state.signMessage = []
         state.error = ''
      },
      updateUser: (state, action: PayloadAction<IUser>) => {
         state.user = { ...state.user, ...action.payload };
      },
   },
   extraReducers: (builder) => {
      builder

         // register
         .addCase(registerUser.pending, (state) => {
            state.registerStatus = 'loading'
            state.registerMessage = []
         })
         .addCase(registerUser.fulfilled, (state, action) => {
            state.registerStatus = 'succeeded'
            state.registerMessage = action.payload.message
         })
         .addCase(registerUser.rejected, (state, action) => {
            state.registerStatus = 'failed'
            state.registerMessage = []
         })

         // login
         .addCase(signIn.pending, (state) => {
            state.status = 'loading';
            state.signMessage = []
         })
         .addCase(signIn.fulfilled, (state, action: PayloadAction<ILoginResponse>) => {
            state.status = 'succeeded';
            if (action.payload.data && action.payload.data.user) {
               state.user = action.payload.data.user;
            }
            if (action.payload.message) {
               state.signMessage = action.payload.message
            }
         })
         .addCase(signIn.rejected, (state, action) => {
            state.status = 'failed';
            state.error = action.error.message || 'Something went wrong';
            state.signMessage = []
         })

         // logout
         .addCase(signOut.pending, (state) => {
            state.status = 'loading';
         })
         .addCase(signOut.fulfilled, (state) => {
            state.status = 'succeeded';
            state.user = null;
            authStorage.removeTokens();
         })
         .addCase(signOut.rejected, (state, action) => {
            state.status = 'failed';
            state.user = null;
            state.error = action.error.message || 'Something went wrong';
         })

         // getUser
         .addCase(getUser.fulfilled, (state, action) => {
            if (action.payload.status) {
               state.user = action.payload.data.user;
            }
         })
   }
})

export default authSlice.reducer
export const { resetAuth, clearRegisterMessage, clearSignMessage, updateUser } = authSlice.actions