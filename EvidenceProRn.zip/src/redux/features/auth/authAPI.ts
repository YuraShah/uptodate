import { createAsyncThunk } from '@reduxjs/toolkit';
import axios from 'axios';
import { IHeaders, IResponseEmpty, IResponseMessage, IUser, LINKS } from '@/src/types/types';
import axiosInstance from '@/src/redux/api';
import { authStorage } from '@/src/redux/authStorage';

const headers: IHeaders = {
   "Content-Type": "application/json",
   "Accept": "application/json",
   "X-Client-Type": "mobile"
};

export interface ILoginResponse {
   status: boolean;
   data?: {
      refreshToken: string;
      accessToken: string;
      user: IUser;
   };
   message?: string[];
}

export interface IUserResponse {
   status: boolean;
   data: {
      user: IUser;
   }
}

export const registerUser = createAsyncThunk<IResponseMessage, string>(
   'auth/register',
   async (obj, thunkAPI) => {
      return await axiosInstance.post<IResponseMessage>(
         LINKS.REGISTER,
         obj,
         { headers }
      )
         .then((response) => {
            return response.data;
         })
         .catch((err) => {
            return thunkAPI.rejectWithValue(err.response.data);
         });
   }
);

export const signIn = createAsyncThunk<ILoginResponse, string>(
   'auth/login',
   async (obj, thunkAPI) => {
      try {
         const response = await axiosInstance
            .post<ILoginResponse>(
               LINKS.LOGIN,
               obj,
               { headers }
            );

         if (response.data.data && response.data.data.accessToken) {
            const { accessToken, refreshToken } = response.data.data;
            await authStorage.setTokens(accessToken, refreshToken);
         }
         return response.data;
      } catch (error) {
         if (axios.isAxiosError(error)) {
            return thunkAPI.rejectWithValue(error.response?.data || error.message);
         }
         return thunkAPI.rejectWithValue('An unexpected error occurred');
      }
   }
);

export const signOut = createAsyncThunk<IResponseEmpty, string>(
   'auth/logout',
   async (obj, thunkAPI) => {
      try {
         await axiosInstance.post(
            LINKS.LOGOUT,
            obj,
            { headers }
         );
         await authStorage.removeTokens();
      } catch (err) {
         if (axios.isAxiosError(err) && err.response) {
            return thunkAPI.rejectWithValue(err.response.data);
         }
         return thunkAPI.rejectWithValue({ status: false, message: 'An error occurred during sign out' });
      }
   }
);

export const getUser = createAsyncThunk<IUserResponse, string>(
   'api/user',
   async (obj, thunkAPI) => {
      return await axiosInstance
         .post<IUserResponse>(
            LINKS.GETUSER,
            obj,
            { headers }
         )
         .then((response) => {
            return response.data;
         })
         .catch((err) => {
            return thunkAPI.rejectWithValue(err.response.data);
         });
   }
);