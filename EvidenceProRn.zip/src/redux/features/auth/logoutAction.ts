import { authStorage } from '@/src/redux/authStorage';

type LogoutCallback = () => void;

let logoutCallback: LogoutCallback | null = null;

export const setLogoutCallback = (callback: LogoutCallback) => {
    logoutCallback = callback;
};

export const logoutUser = async () => {
    try {
        // Clear secure storage
        await authStorage.removeTokens();

        // Call the logout callback if api
        if (logoutCallback) {
            logoutCallback();
        }
    } catch (error) {
        // console.error('Logout failed:', error);
        await authStorage.removeTokens();

        if (logoutCallback) {
            logoutCallback();
        }
    }
};