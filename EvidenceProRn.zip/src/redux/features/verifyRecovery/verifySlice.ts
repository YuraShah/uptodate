import { createSlice } from '@reduxjs/toolkit';
import { forgotPassword, verifyCodeResend } from './verifyAPI';
import { LoaderStatusType } from '@/src/types/types';

interface IVerifySlice {
   checkVerifyResendData: string[],
   checkVerifyResendStatus: LoaderStatusType,
   checkVerifyResendError: string | null

   forgetPasswordData: string[],
   forgetPasswordStatus: LoaderStatusType,
   forgetPasswordError: string | null,
}

const initialState: IVerifySlice = {
   checkVerifyResendData: [],
   checkVerifyResendStatus: 'idle',
   checkVerifyResendError: null,

   forgetPasswordData: [],
   forgetPasswordStatus: 'idle',
   forgetPasswordError: null,
}

const verifySlice = createSlice({
   name: 'verify',
   initialState,
   reducers: {
      clearForgetPasswordData: (state) => {
         state.forgetPasswordData = []
      },
      clearCheckVerifyResendData: (state) => {
         state.checkVerifyResendData = []
      }
   },
   extraReducers: (builder) => {
      builder
         .addCase(verifyCodeResend.pending, (state, action) => {
            state.checkVerifyResendStatus = 'loading'
            state.checkVerifyResendData = []
            state.checkVerifyResendError = null
         })
         .addCase(verifyCodeResend.fulfilled, (state, action) => {
            state.checkVerifyResendData = action.payload.message
            state.checkVerifyResendStatus = 'succeeded'
            state.checkVerifyResendError = null
         })
         .addCase(verifyCodeResend.rejected, (state, action) => {
            state.checkVerifyResendStatus = 'failed'
            state.checkVerifyResendData = []
            state.checkVerifyResendError = action.error.message || 'An error occurred'
         })

         .addCase(forgotPassword.pending, (state, action) => {
            state.forgetPasswordStatus = 'loading'
            state.forgetPasswordData = []
            state.forgetPasswordError = null
         })
         .addCase(forgotPassword.fulfilled, (state, action) => {
            state.forgetPasswordData = action.payload.message
            state.forgetPasswordStatus = 'succeeded'
            state.forgetPasswordError = null
         })
         .addCase(forgotPassword.rejected, (state, action) => {
            state.forgetPasswordStatus = 'failed'
            state.forgetPasswordData = []
            state.forgetPasswordError = action.error.message || 'An error occurred'
         })
   }
})

export default verifySlice.reducer
export const { clearForgetPasswordData, clearCheckVerifyResendData } = verifySlice.actions