import { createAsyncThunk } from '@reduxjs/toolkit';
import axiosInstance from '@/src/redux/api';
import { IHeaders, IResponseMessage, LINKS } from '@/src/types/types';

const headers: IHeaders = {
   "Content-Type": "application/json",
   "Accept": "application/json",
};


export const verifyCodeResend = createAsyncThunk<IResponseMessage, string>(
   'auth/verifyresend',
   async (obj, thunkAPI) => {
      return await axiosInstance
         .post<IResponseMessage>(
            LINKS.VERIFYRESEND,
            obj,
            { headers }
         )
         .then((response) => {
            return response.data
         })
         .catch((err) => {
            return thunkAPI.rejectWithValue(err.response.data);
         })
   }
);

export const forgotPassword = createAsyncThunk<IResponseMessage, string>(
   'auth/forgotpassword',
   async (obj, thunkAPI) => {
      return await axiosInstance
         .post<IResponseMessage>(
            LINKS.FORGOTPASSWORD,
            obj,
            { headers }
         )
         .then((response) => {
            return response.data
         })
         .catch((err) => {
            return thunkAPI.rejectWithValue(err.response.data);
         })
   }
);

export const checkSignDevice = createAsyncThunk<IResponseMessage, string>(
   'check/device',
   async (obj, thunkAPI) => {
      return await axiosInstance
         .post<IResponseMessage>(
            LINKS.CHECKSIGNDEVICE,
            obj,
            { headers }
         )
         .then((response) => {
            return response.data
         })
         .catch((err) => {
            return thunkAPI.rejectWithValue(err.response.data);
         })
   }
)