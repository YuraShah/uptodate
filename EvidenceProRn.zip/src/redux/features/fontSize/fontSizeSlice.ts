import { createSlice } from '@reduxjs/toolkit';

interface IFontSizeSlice {
   textSize: number,
   titleSize: number,
   refSize: number,
   minSize: number,
   homeTextSize: number,
   largTextSize: number
}

const initialState: IFontSizeSlice = {
   textSize: 16,
   titleSize: 17,
   refSize: 15,
   minSize: 15,
   homeTextSize: 16,
   largTextSize: 22
}

const fontSizeSlice = createSlice({
   name: 'fontSize',
   initialState,
   reducers: {
      setSmall: (state: IFontSizeSlice) => {
         state.textSize = 14
         state.titleSize = 15
         state.refSize = 13
         state.minSize = 13
         state.homeTextSize = 15
         state.largTextSize = 20
      },
      setMedium: (state: IFontSizeSlice) => {
         state.textSize = 16
         state.titleSize = 17
         state.refSize = 15
         state.minSize = 15
         state.homeTextSize = 16
         state.largTextSize = 22
      },
      setLarge: (state: IFontSizeSlice) => {
         state.textSize = 18
         state.titleSize = 19
         state.refSize = 17
         state.minSize = 15
         state.homeTextSize = 17
         state.largTextSize = 22
      },
   },
   extraReducers: (builder) => {
   }
})

export default fontSizeSlice.reducer
export const { setSmall, setMedium, setLarge } = fontSizeSlice.actions
