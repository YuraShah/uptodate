import { createSlice } from '@reduxjs/toolkit';
import { deleteUserAcc, getUserCalcs } from './userAPI';

interface IUserSlice {
   deleteAccError: string | null,
   
   userCalcsData: string[] | null,
   userCalcsError: string | null,
}

const initialState: IUserSlice = {
   deleteAccError: null,

   userCalcsData: null,
   userCalcsError: null,
}


const userSlice = createSlice({
   name: 'user',
   initialState,
   reducers: {
   },
   extraReducers: (builder) => {
      builder.addCase(deleteUserAcc.pending, (state) => {
         state.deleteAccError = null
      })
      builder.addCase(deleteUserAcc.fulfilled, (state) => {
         state.deleteAccError = null
      })
      builder.addCase(deleteUserAcc.rejected, (state, action) => {
         state.deleteAccError = action.error.message || 'An error occurred'
      })

      builder.addCase(getUserCalcs.fulfilled, (state, action) => {
         if (action.payload.data && action.payload.data.length > 0) {
            state.userCalcsData = action.payload.data
         } else {
            state.userCalcsData = []
         }
      })
      builder.addCase(getUserCalcs.rejected, (state, action) => {
         state.userCalcsError = action.error.message || 'An error occurred'
      })
   }
})

export default userSlice.reducer
export const { } = userSlice.actions