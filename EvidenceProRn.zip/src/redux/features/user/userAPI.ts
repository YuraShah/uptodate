import { createAsyncThunk } from '@reduxjs/toolkit';
import axiosInstance from '@/src/redux/api';
import { IResponseData, IResponseEmpty, LINKS } from '@/src/types/types';

export const deleteUserAcc = createAsyncThunk<IResponseEmpty, string>(
   'user/delete',
   async (obj, thunkAPI) => {
      return await axiosInstance.post(
         LINKS.DELETEUSERACC,
         obj
      )
         .then((response) => {
            return response.data
         })
         .catch((err) => {
            return thunkAPI.rejectWithValue(err.response.data);
         })
   }
) 

export const getUserCalcs = createAsyncThunk<IResponseData<string>>(
   'user/calcs',
   async (_, thunkAPI) => {
      return await axiosInstance.post<IResponseData<string>>(
         LINKS.USERFAVORITESCALCS,
      )
         .then((response) => {
            return response.data
         })
         .catch((err) => {
            return thunkAPI.rejectWithValue(err.response.data);
         })
   }
)

export const deleteUserFavorites = createAsyncThunk<string, string>(
   'user/favorites-delete',
   async (value, thunkAPI) => {
      return await axiosInstance.post(
         LINKS.USERFAVORITESDELETE,
         value
      )
         .then((response) => {
            return response.data
         })
         .catch((err) => {
            return thunkAPI.rejectWithValue(err.response.data);
         })
   }
)

export const addUserFavorites = createAsyncThunk<string, string>(
   'user/favorites-add',
   async (obj, thunkAPI) => {
      return await axiosInstance.post(
         LINKS.USERFAVORITESADD,
         obj
      )
         .then((response) => {
            return response.data
         })
         .catch((err) => {
            return thunkAPI.rejectWithValue(err.response.data);
         })
   }
)