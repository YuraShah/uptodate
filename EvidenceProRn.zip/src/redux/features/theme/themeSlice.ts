import { createSlice } from '@reduxjs/toolkit';

interface IThemeSlice {
   isDarkMode: boolean,
}

const initialState: IThemeSlice = {
   isDarkMode: false,
}

const themeSlice = createSlice({
   name: 'theme',
   initialState,
   reducers: {
      toggleTheme: (state) => {
         state.isDarkMode = !state.isDarkMode;
       },
   },
   extraReducers: (builder) => {
   }
})

export default themeSlice.reducer
export const { toggleTheme } = themeSlice.actions
