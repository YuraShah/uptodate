import { darkTheme, defaultTheme } from "@/src/constants/theme/myTheme";
import { useAppSelector } from "@/src/redux/hooks";

export const useTheme = () => {
   const { isDarkMode } = useAppSelector((state) => state.themeStore);
   return isDarkMode ? darkTheme : defaultTheme;
};