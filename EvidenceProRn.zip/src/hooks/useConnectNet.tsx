import * as Network from 'expo-network';
import { useEffect } from 'react';
import { useNavigation } from '@react-navigation/native';

export const useConnectNet = () => {
   const navigation = useNavigation()

   useEffect(() => {
      const isConnect = async () => {
         const connect = await Network.getNetworkStateAsync();
         if (connect.isConnected === false) {
            navigation.navigate('ConnectError');
         }
      }

      isConnect();
   }, [])
}