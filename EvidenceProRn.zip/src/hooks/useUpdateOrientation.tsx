import React, { useEffect, useState } from 'react'
import * as ScreenOrientation from 'expo-screen-orientation';

export const useUpdateOrientation = () => {
   const [resultHeight, setIsResultHeight] = useState(false)

   useEffect(() => {
      const updateOrientation = (event: any) => {
         const orientation = event.orientationInfo.orientation;
         if (orientation === 1 || orientation === 2) {
            setIsResultHeight(true);
         } else {
            setIsResultHeight(false);
         }
      };

      const addOrientation = ScreenOrientation.addOrientationChangeListener(updateOrientation);

      return () => {
         ScreenOrientation.removeOrientationChangeListener(addOrientation);
      };
   }, [])

   return resultHeight;
}
