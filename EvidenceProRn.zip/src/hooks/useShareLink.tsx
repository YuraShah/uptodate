import { RouteProp, useRoute } from '@react-navigation/native';
import { Share } from 'react-native';
import { MainStackParamList } from '@/src/types/navigationTypes';
import { MAIN_PATH } from '@/src/constants/Paths';
import { deepLinkScreens } from '@/src/navigation/deepLinkScreens';

const useShareLink = () => {
   const { name, params } = useRoute<RouteProp<MainStackParamList, keyof MainStackParamList>>();
   const currentDeepLink = deepLinkScreens[name as keyof typeof deepLinkScreens];

   if (!currentDeepLink) {
      return null;
   }

   let shareLinkPath = currentDeepLink;
   
   if (params) {
      const paramRecord = params as Record<string, string>;
      Object.keys(paramRecord).forEach(key => {
         const value = paramRecord[key];
         if (value) {
            shareLinkPath = shareLinkPath.replace(`:${key}`, value);
         }
      });
   }
   

   const shareLink = async () => {
      try {
         await Share.share({
            message: `${MAIN_PATH}${shareLinkPath}`,
         });
      } catch (error) {
      }
   };

   return shareLink;
};

export default useShareLink;