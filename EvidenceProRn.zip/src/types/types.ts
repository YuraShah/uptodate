import { IconDefinition } from "@fortawesome/fontawesome-svg-core"
import { MainStackParamList } from "./navigationTypes"

export enum LINKS {
   // TOKEN = 'https://api.evidence.am/api/auth/refresh-token',
   TOKEN = 'http://192.168.18.3:8000/api/auth/refresh-token',
   REGISTER = '/auth/register',
   LOGIN = '/auth/login',
   LOGOUT = '/api/auth/logout',
   VERIFYRESEND = '/auth/verify-resend',
   FORGOTPASSWORD = '/auth/forgot-password',
   CHECKSIGNUIDEMAIL = '/auth/check-user',
   CHECKSIGNDEVICE = '/api/auth/check-device/native',
   ISAPPCLOSE = '/is-close-app',

   GETUSER = '/api/user',
   USERPAYMENTSTATUS = '/api/user/payment-status',
   USERPAYMENTEXPIRE = '/api/user/payment-expire',
   CHANGEUSEREMAIL = '/api/user/change-email',
   CHANGEUSERPASSWORD = '/api/user/change-password',
   DELETEUSERACC = '/api/user/delete-user',
   USERFAVORITES = '/api/user/favorites',
   USERFAVORITESCALCS = '/api/user/favorites/calcs',
   USERFAVORITESDELETE = '/api/user/favorites-delete',
   USERFAVORITESADD = '/api/user/favorites-add',
   GETUSERNOTIFICATION = '/api/user/notifications',
   CHANGEUSERNOTIFICATION = '/api/user/notifications/change',
   USERSCREENSHOTQUANTITY = '/api/user/get-screenshots-quantity',
   DEVICEBLOCK = '/api/user/get-device-block',
   
   GETPATHWAY = '/api/eviway',
   DRUGDISEASE = '/api/drug-disease',
   DRUGDISEASESEARCH = '/api/drug-disease-search',
   DRUGPREGNANCYSEARCH = '/api/drug-pregnancy-search',
   DRUGPREGNANCY = '/api/drug-pregnancy',
   DRUGHEPTOXLIST = '/api/drug-heptox-list',
   DRUGHEPTOX = 'api/drug-heptox',
   DRUGPULMTOXLIST = '/api/drug-pulmtox-list',
   DRUGPULMTOX = 'api/drug-pulmtox',
   DRUGPULMTOXSUBPATTERN = 'api/drug-pulmtox-subpattern',
   DRUGPULMTOXPATTERN = '/api/drug-pulmtox-pattern',
   DRUGNEPHTOXLIST = '/api/drug-nephtox-list',
   DRUGNEPHTOX = 'api/drug-nephtox',
   DRUGNEPHTOXDISEASE = '/api/drug-nephtox-disease',
   DRUGNEPHTOXMORPHOLOGY = 'api/drug-nephtox-morphology',
   DRUGOLDERSSEARCH = '/api/drug-olders-search',
   DRUGOLDERS = '/api/drug-olders',
   DRUGQT = '/api/drug-qt',
   DRUGQTSEARCH = '/api/drug-qt-search',
   DRUGQTFACTOR = '/api/drug-qt-factor',
   DRUGQTINDICATION = '/api/drug-qt-indication',
   DRUGQTSEARCHCALC = '/api/drug-qt-search/calc',
   DRUGMETHEM = '/api/drug-methem',
   DRUGDISL = '/api/drug-disl',
}


// api 
export type IHeaders = {
   [key: string]: string
}

export type LoaderStatusType = 'idle' | 'loading' | 'succeeded' | 'failed'

export type IResponseMessage = {
   status: boolean;
   message: string[];
}

export type IResponseEmpty = {
}

export type IResponseData<T> = {
   status: boolean;
   data: T[];
}

export type IResponseDataAndText<T> = {
   status: boolean;
   data?: T[];
   text?: string[];
}

export type IResponseNumber = {
   status: boolean;
   data: number;
}

export type IResponseDataObj<T> = {
   status: boolean;
   data: T;
}

export type IDrugLabel = {
   id: string,
   value: string,
   label: string,
   link: string,
}

export type IOtherList = {
   id: number,
   name: string
}

export type IMenuList = {
   name: string,
   link: keyof MainStackParamList,
   param?: any,
   icon?: IconDefinition,
   lock?: boolean
}

export type IUser = {
   id: number,
   username: string,
   name: string,
   surname: string,
   email: string,
   dev: string,
   paym?: number;
   created_at?: string;
}

export type IPathwayChild = {
   mainTitle?: string,
   title?: string,
   description?: string | string[],
   exception?: {
      title?: string,
      description?: string | string[],
   },
   nest?: number,
   questions?: IPathwayQuestion[];
}
export type IPathwayQuestion = {
   question: string,
   children?: IPathwayChild[]
}
export type IPathway = {
   link: string,
   title: string,
   nest: number
   children: IPathwayChild[],
   sumNest: number,
   refers?: string[],
}

export type IPathwayArticle = {
   items: {
      id: number,
      title: string,
      link: string
   }[],
   nextCursor: number
}
