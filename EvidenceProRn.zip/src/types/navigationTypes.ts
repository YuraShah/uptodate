import { NavigatorScreenParams, RouteProp } from "@react-navigation/native";
import { NativeStackNavigationProp } from "@react-navigation/native-stack";

export type TabParamList = {
   Home: NavigatorScreenParams<MainStackParamList>,
   Favorites?: NavigatorScreenParams<FavoritesParamList>,
   Settings: NavigatorScreenParams<SettingsParamList>,
   BlockDevice: undefined,
   ManyRequests: undefined,
   ConnectError: undefined
};

export type MainStackParamList = {
   SignIn: undefined,
   Register: undefined,
   ForgotPassword: undefined,
   VerifyResend: undefined,
   Payment: undefined,
   WebView: { url: string },
   HomeScreen: undefined,
   DrugsMenu: undefined,
   DrugDisInt: undefined,
   DrugDisIntItem: { param: string },
   DrugPregnancy: undefined,
   DrugPregnancyItem: { param: string },
   DrugHeptox: undefined,
   DrugHeptoxItem: { param: string },
   DrugPulmtox: undefined,
   DrugPulmtoxDrug: undefined,
   DrugPulmtoxSubstance: undefined,
   DrugPulmtoxItem: { param: string },
   DrugPulmtoxSubpattern: { param: string },
   DrugPulmtoxPattern: undefined,
   DrugNephtox: undefined,
   DrugNephtoxDrug: undefined,
   DrugNephtoxItem: { param: string },
   DrugNephtoxDisease: undefined,
   DrugNephtoxDiseaseItem: { param: string },
   DrugNephtoxMorphology: undefined,
   DrugNephtoxMorphologyItem: { param: string },
   DrugOlders: undefined,
   DrugOldersItem: { param: string },
   DrugQt: undefined,
   DrugQtDrugs: undefined,
   DrugQtItem: { param: string },
   DrugQtFactor: undefined,
   DrugQtIndication: undefined,
   DrugMethem: undefined,
   DrugDisl: undefined,
   MenuCross: undefined,
   CrossItem: { param: string },
   Calcs: undefined,
   CalcsItem: { param: string },
}

export type SettingsParamList = {
   SettingHome: undefined,
   About: undefined,
   Privacy: undefined,
   PaymentReturns: undefined,
   ChangeEmail: undefined,
   ChangePassword: undefined,
   DeleteAcc: undefined,
   Disclaimer: undefined,
}

export type FavoritesParamList = {
   FavoritesHome: undefined
}

declare global {
   namespace ReactNavigation {
      interface RootParamList extends TabParamList { }
   }
}