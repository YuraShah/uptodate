import { Platform } from "react-native";

const WEB_FONT_STACK =
   'system-ui, Roboto, "Segoe UI", Helvetica, Arial, sans-serif, "Apple Color Emoji", "Segoe UI Emoji", "Segoe UI Symbol"';

export interface ITheme {
   colors: {
      mainBg: string,
      mainBgOpac: string,
      mainBgText: string,
      background: string,
      primary: string,
      primaryOpac: string,
      secondary: string,
      black: string,
      headerTintColor: string,
      primaryReverse: string,
      textReverse: string,
      updateCloseBg: string,
      updateOpenBg: string,
      borderBottomPrimary: string,
      angleRightPrimary: string,
      formBtn: string,
      formError: string,
      formAttention: string,
      checkboxColor: string,
      radioColor: string,
      inputBackground: string,
      inputPlaceholder: string,
      progressBarBg: string,
      refreshProgressBarBg: string,
      angleRightBlue: string,
      tableBorder: string,
      othTitle: string,
      pickerText: string,
      pickerTextReverse: string,
      pickerBg: string,
      link: string,
      title: string,
      calcBtnBg: string,
      calcResultBg: string,
      calcResultIcon: string,
      calcHeader: string,
      calcRadioSeparator: string,
      topTabsBg: string,
      topTabsIndicator: string,
      webViewRefresh: string,
      iconWhite: string,
      indicator: string,
      modalToastBg: string,
      vHRisk: string,
      hRisk: string,
      mRisk: string,
      lRisk: string,
      vLRisk: string,
      unRisk: string,
      pathBg: string,
      pathQuestBg: string,
      pathIcon: string,
      pathExcept: string,
      lockCenter: string
   };
   fonts: {
      ios: {
         regular: { fontFamily: string };
         bold: { fontFamily: string };
         italic: { fontFamily: string };
         boldItalic: { fontFamily: string };
      };
      android: {
         regular: { fontFamily: string };
         medium: { fontFamily: string };
         bold: { fontFamily: string };
         heavy: { fontFamily: string };
      };
      default?: {
         regular: { fontFamily: string };
         medium: { fontFamily: string };
         bold: { fontFamily: string };
         heavy: { fontFamily: string };
      };
      web: {
         regular: { fontFamily: string };
         medium: { fontFamily: string };
         bold: { fontFamily: string };
         heavy: { fontFamily: string };
      };
   };
}

export const defaultTheme: ITheme = {
   colors: {
      mainBg: '#0492c2',
      mainBgOpac: 'rgba(4, 146, 194, 0.5)',
      mainBgText: 'white',
      background: '#f2f2f2',
      primary: '#000',
      primaryOpac: 'rgba(235, 235, 235, 0.5)',
      secondary: '#999',
      black: 'black',
      headerTintColor: 'white',
      primaryReverse: 'white',
      textReverse: 'white',
      updateCloseBg: '#e8e8e8',
      updateOpenBg: '#01abe4',
      borderBottomPrimary: '#D0D0D0',
      angleRightPrimary: '#D0D0D0',
      formBtn: '#0f7fa5',
      formError: 'red',
      formAttention: '#0f7fa5',
      checkboxColor: '#1e6785',
      radioColor: '#1e6785',
      inputBackground: 'white',
      inputPlaceholder: '#757575',
      progressBarBg: '#e0e0df',
      refreshProgressBarBg: 'white',
      angleRightBlue: '#186482',
      tableBorder: '#0a5976',
      othTitle: 'rgb(38, 116, 148)',
      pickerText: '#000',
      pickerTextReverse: 'grey',
      pickerBg: 'white',
      link: "#14647f",
      title: 'rgb(26, 96, 134)',
      calcBtnBg: '#53a9df',
      calcResultBg: 'rgba(105, 188, 199, 1)',
      calcResultIcon: 'black',
      calcHeader: '#164b61',
      calcRadioSeparator: '#e8e8e8',
      topTabsBg: 'white',
      topTabsIndicator: '#0492c2',
      webViewRefresh: 'white',
      iconWhite: 'white',
      indicator: 'white',
      modalToastBg: 'white',
      vHRisk: "#003366",
      hRisk: "#005B96",
      mRisk: "#3399CC",
      lRisk: "#66CCFF",
      vLRisk: "#81D4FA",
      unRisk: "#9E9E9E",
      pathBg: '#E8E8E8',
      pathQuestBg: '#267eeb',
      pathIcon: '#555',
      pathExcept: 'rgba(204, 233, 242, 1)',
      lockCenter: 'rgba(4,146,194, 0.8)',
   },
   fonts: {
      ios: {
         regular: { fontFamily: 'Roboto-Regular' },
         bold: { fontFamily: 'Roboto-Bold' },
         italic: { fontFamily: 'Roboto-Italic' },
         boldItalic: { fontFamily: 'Roboto-BoldItalic' },
      },
      android: {
         regular: { fontFamily: WEB_FONT_STACK },
         medium: { fontFamily: WEB_FONT_STACK },
         bold: { fontFamily: WEB_FONT_STACK },
         heavy: { fontFamily: WEB_FONT_STACK },
      },
      web: {
         regular: { fontFamily: WEB_FONT_STACK },
         medium: { fontFamily: WEB_FONT_STACK },
         bold: { fontFamily: WEB_FONT_STACK },
         heavy: { fontFamily: WEB_FONT_STACK },
      },
      default: {
         regular: { fontFamily: WEB_FONT_STACK },
         medium: { fontFamily: WEB_FONT_STACK },
         bold: { fontFamily: WEB_FONT_STACK },
         heavy: { fontFamily: WEB_FONT_STACK },
      },
      ...Platform.select({
         ios: {
            regular: { fontFamily: 'Roboto-Regular' },
            bold: { fontFamily: 'Roboto-Bold' },
            italic: { fontFamily: 'Roboto-Italic' },
            boldItalic: { fontFamily: 'Roboto-BoldItalic' },
         },
         android: {
            regular: { fontFamily: WEB_FONT_STACK },
            medium: { fontFamily: WEB_FONT_STACK },
            bold: { fontFamily: WEB_FONT_STACK },
            heavy: { fontFamily: WEB_FONT_STACK },
         },
         web: {
            regular: { fontFamily: WEB_FONT_STACK },
            medium: { fontFamily: WEB_FONT_STACK },
            bold: { fontFamily: WEB_FONT_STACK },
            heavy: { fontFamily: WEB_FONT_STACK },
         },
         default: {
            regular: { fontFamily: WEB_FONT_STACK },
            medium: { fontFamily: WEB_FONT_STACK },
            bold: { fontFamily: WEB_FONT_STACK },
            heavy: { fontFamily: WEB_FONT_STACK },
         },
      }) as Partial<ITheme['fonts']>,
   },
};


export const darkTheme: ITheme = {
   colors: {
      mainBg: '#024157',
      mainBgOpac: 'rgba(4, 146, 194, 0.5)',
      mainBgText: 'white',
      background: '#2b303b',
      primary: '#ebebeb',
      primaryOpac: 'rgba(235, 235, 235, 0.5)',
      secondary: '#999',
      black: 'black',
      headerTintColor: 'white',
      primaryReverse: 'white',
      textReverse: 'black',
      updateCloseBg: '#e8e8e8',
      updateOpenBg: '#b2ddee',
      borderBottomPrimary: '#4e4e4e',
      angleRightPrimary: '#4e4e4e',
      formBtn: '#024157',
      formError: '#ff5a5f',
      formAttention: 'white',
      checkboxColor: '#4e4e4e',
      radioColor: '#ededed',
      inputBackground: '#ededed',
      inputPlaceholder: '#757575',
      progressBarBg: '#e0e0df',
      refreshProgressBarBg: 'white',
      angleRightBlue: 'white',
      tableBorder: '#999',
      othTitle: '#fff',
      pickerText: 'black',
      pickerTextReverse: '#999',
      pickerBg: '#2b303b',
      link: "white",
      title: '#fff',
      calcBtnBg: '#024157',
      calcResultBg: '#024157',
      calcResultIcon: 'white',
      calcHeader: 'white',
      calcRadioSeparator: '#4e4e4e',
      topTabsBg: '#024157',
      topTabsIndicator: 'white',
      webViewRefresh: 'white',
      iconWhite: 'white',
      indicator: 'white',
      modalToastBg: '#024157',
      vHRisk: "#003366",
      hRisk: "#005B96",
      mRisk: "#3399CC",
      lRisk: "#66CCFF",
      vLRisk: "#81D4FA",
      unRisk: "#9E9E9E",
      pathBg: '#E8E8E8',
      pathQuestBg: '#267eeb',
      pathIcon: '#555',
      pathExcept: 'rgba(204, 233, 242, 1)',
      lockCenter: 'rgba(255,255,255, 0.5)',
   },
   fonts: {
      ...defaultTheme.fonts
   }
}