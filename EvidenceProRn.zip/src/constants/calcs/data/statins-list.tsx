export const statinList = [
   {
      statin: "Аторвастатин",
      statinEn: "atorvastatin",
      data: [
         {
            dose: "10",
            hdl: "6",
            ldl: "38",
            tg: "20"
         },
         {
            dose: "20",
            hdl: "7-10",
            ldl: "42",
            tg: "25-30"
         },
         {
            dose: "40",
            hdl: "7-10",
            ldl: "48",
            tg: "25-40"
         },
         {
            dose: "80",
            hdl: "7-10",
            ldl: "55",
            tg: "30-45"
         },
      ]
   },
   {
      statin: "Розувастатин",
      statinEn: "rosuvastatin",
      data: [
         {
            dose: "5",
            hdl: "7",
            ldl: "40",
            tg: "10-19"
         },
         {
            dose: "10",
            hdl: "8",
            ldl: "45",
            tg: "20"
         },
         {
            dose: "20",
            hdl: "10-14",
            ldl: "51",
            tg: "21-30"
         },
         {
            dose: "40",
            hdl: "10-15",
            ldl: "57",
            tg: "25-35"
         },
      ]
   },
   {
      statin: "Симвастатин",
      statinEn: "simvastatin",
      data: [
         {
            dose: "10",
            hdl: "5",
            ldl: "28",
            tg: "12"
         },
         {
            dose: "20",
            hdl: "6-10",
            ldl: "32",
            tg: "15"
         },
         {
            dose: "40",
            hdl: "6-10",
            ldl: "37",
            tg: "20-25"
         },
         {
            dose: "80",
            hdl: "6-10",
            ldl: "42",
            tg: "26-30"
         },
      ]
   },
   {
      statin: "Флувастатин",
      statinEn: "fluvastatin",
      data: [
         {
            dose: "20",
            hdl: "1",
            ldl: "17",
            tg: "5"
         },
         {
            dose: "40",
            hdl: "5",
            ldl: "23",
            tg: "10"
         },
         {
            dose: "80",
            hdl: "10",
            ldl: "30",
            tg: "15"
         },
      ]
   },
   {
      statin: "Правастатин",
      statinEn: "pravastatin",
      data: [
         {
            dose: "10",
            hdl: "3",
            ldl: "20",
            tg: "8"
         },
         {
            dose: "20",
            hdl: "7",
            ldl: "24",
            tg: "12"
         },
         {
            dose: "40",
            hdl: "8-10",
            ldl: "29",
            tg: "15-25"
         },
         {
            dose: "80",
            hdl: "8-10",
            ldl: "33",
            tg: "20-30"
         },
      ]
   },
   {
      statin: "Ловастатин",
      statinEn: "lovastatin",
      data: [
         {
            dose: "10",
            hdl: "4",
            ldl: "23",
            tg: "10"
         },
         {
            dose: "20",
            hdl: "7",
            ldl: "29",
            tg: "12"
         },
         {
            dose: "40",
            hdl: "9",
            ldl: "33",
            tg: "18-25"
         },
         {
            dose: "80",
            hdl: "10",
            ldl: "38",
            tg: "20-28"
         },
      ]
   },
   {
      statin: "Питавастатин",
      statinEn: "pitavastatin",
      data: [
         {
            dose: "1",
            hdl: "5-8",
            ldl: "30",
            tg: "10-15"
         },
         {
            dose: "2",
            hdl: "10",
            ldl: "38",
            tg: "15-20"
         },
         {
            dose: "4",
            hdl: "12",
            ldl: "44",
            tg: "20-25"
         },
      ]
   },
]