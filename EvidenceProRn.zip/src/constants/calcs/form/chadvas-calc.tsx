export const chadvascCalc = {
   id: "EV-CALC-19",
   link: "cha2ds2vasc",
   title: "Шкала CHA2DS2VASc",
   text: "Оценка риска инсульта и тромбоэмболических осложнений при фибрилляции и трепетании предсердий",
   description: {
      descriptionMain: [
         "Эта шкала представляет собой простой метод оценки риска инсульта и тромбоэмболических осложнений у пациентов с мерцательной аритмией.",
         [
            "CHA2DS2-VASc — это аббревиатура, состоящая из:",
            "Congestive heart failure - хроническая сердечная недостаточность",
            "Hypertension - гипертоническая болезнь",
            "Age - возраст старше 75 лет",
            "Diabetes mellitus - сахарный диабет",
            "Stroke - инсульт в анамнезе, транзиторная ишемическая атака, системная эмболия",
            "Vascular disease - сосудистые заболевания (инфаркт миокарда в анамнезе, атеросклероз периферических сосудов и аорты)",
            "Age - 65-74 года",
            "Sex category - пол (женский)",
         ]
      ],
      descriptionTable: [
         {
            headData: ['Сумма баллов по шкале CHA2DS2-VAS', 'Ожидаемая частота инсультов в год'],
            bodyData: [
               ['0', '0.0%'],
               ['1', '1.3%'],
               ['2', '2.2%'],
               ['3', '3.2%'],
               ['4', '4.0%'],
               ['5', '6.7%'],
               ['6', '9.8%'],
               ['7', '9.6%'],
               ['8', '6.7%'],
               ['9', '15.2%'],
            ],
            flexNums: [1, 1]
         },
         {
            headData: ['Категория риска', 'Сумма баллов по шкале CHA2DS2-VASc', 'Рекомендуемое антитромботическое лечение'],
            bodyData: [
               ['Факторы риска отсутствуют', '0', 'Аспирин 75-325 мг в день или отсутствие антитромботического лечения (предпочтительно)'],
               ['1 клинически значимый фактор «невысокого риска» (все, за исключением возраста >75 лет и истории инсульта, транзиторной ишемической атаки, системной эмболии)', '1', 'Пероральный антикоагулянт (предпочтительно) или аспирин 75–325 мг в день'],
               ['1 фактор «высокого» риска или ≥2 клинически значимых фактора «невысокого риска»', '≥2', 'Антагонист витамина К (например, варфарин) с целевым МНО (международным нормализованным отношением) 2.5 (МНО может быть выше в случаях механических протезов клапанов сердца)'],
            ],
            widthNums: [300, 200, 300]
         }
      ]
   },
   form: [
      {
         type: 'checkbox',
         inputId: 'heartFailure',
         label: 'Сердечная недостаточность или систолическая дисфункция левого желудочка',
      }, 
      {
         type: 'checkbox',
         inputId: 'hypertension',
         label: 'Артериальная гипертония',
      }, 
      {
         type: 'radio',
         radioButtons: [
            {
               id: '2',
         label: 'Возраст 75 лет и старше',
         value: '2',
            },
            {
               id: '1',
         label: 'Возраст 65-74',
         value: '1',
            }
         ],
         label: 'Возраст',
         inputId: 'age1',
         required: 'no',
      },
      {
         type: 'checkbox',
         inputId: 'diabetes',
         label: 'Сахарный диабет',
      }, 
      {
         type: 'checkbox',
         inputId: 'stroke',
         label: 'Инсульт, транзиторная ишемическая атака и другие эмболические осложнения',
      }, 
      {
         type: 'checkbox',
         inputId: 'vascular',
         label: 'Сосудистые заболевания (инфаркт миокарда в анамнезе, атеросклероз аорты и периферических сосудов)',
      }, 
      {
         type: 'checkbox',
         inputId: 'gender',
         label: 'Женский пол (если указан только женский пол, оценка равна нулю)',
      }, 
   ],
   refers: [
      "Lip GY, Frison L, Halperin JL, Lane DA. Identifying patients at high risk for stroke despite anticoagulation: a comparison of contemporary stroke risk stratification schemes in an anticoagulated atrial fibrillation cohort. Stroke. 2010;41(12):2731-8",
      "Camm AJ, Lip GY, De Caterina R, et al. 2012 focused update of the ESC Guidelines for the management of atrial fibrillation: an update of the 2010 ESC Guidelines for the management of atrial fibrillation. Eur Heart J. 2012;33(21):2719-47",
      "Guyatt GH, Akl EA, Crowther M, et al. Executive summary: Antithrombotic Therapy and Prevention of Thrombosis, 9th ed: American College of Chest Physicians Evidence-Based Clinical Practice Guidelines. Chest. 2012;141(2 Suppl):7S-47S",
      "Lip GY, Nieuwlaat R, Pisters R, et al. Refining clinical risk stratification for predicting stroke and thromboembolism in atrial fibrillation using a novel risk factor-based approach: the euro heart survey on atrial fibrillation. Chest. 2010;137(2):263-72",
   ]
}