export const hemorr2hagesCalc = {
   id: "EV-CALC-23",
   link: "hemorr2hages",
   title: "Шкала HEMORR₂HAGES",
   text: "Оценка риска большого кровотечения при фибрилляции предсердий",
   description: {
      descriptionMain: [
         "Шкала HEMORR₂HAGES помогает оценить риск большого кровотечения при фибрилляции предсердий. Оценка риска необходима для определения необходимости антикоагулянтной терапии у пациентов с фибрилляцией предсердий и перевешивает ли ожидаемая польза потенциальное кровотечение."
      ],
      descriptionTable: [
         {
            headData: ['Результат', 'Баллы'],
            bodyData: [
               ['Риск кровотечения 1.9 (0.6 - 4.4) (100 человеко-лет [95% доверительный интервал])', '0'],
               ['Риск кровотечения 2.5 (1.3 - 4.3) (100 человеко-лет [95% доверительный интервал])', '1'],
               ['Риск кровотечения 5.3 (3.4 - 8.1) (100 человеко-лет [95% доверительный интервал])', '2'],
               ['Риск кровотечения 8.4 (4.9 - 13.6) (100 человеко-лет [95% доверительный интервал])', '3'],
               ['Риск кровотечения 10.4 (5.1 - 18.9) (100 человеко-лет [95% доверительный интервал])', '4'],
               ['Риск кровотечения 12.3 (5.8 - 23.1) (100 человеко-лет [95% доверительный интервал])', '5 и больше'],
            ],
            flexNums: [2, 1]
         }
      ]
   },
   form: [
      {
         type: 'checkbox',
         inputId: 'kidliv',
         label: 'Заболевания печени или почек',
      }, 
      {
         type: 'checkbox',
         inputId: 'alcohol',
         label: 'Злоупотребление алкоголем',
      }, 
      {
         type: 'checkbox',
         inputId: 'oncol',
         label: 'Анамнез злокачественных новообразований',
      }, 
      {
         type: 'checkbox',
         inputId: 'age',
         label: 'Возраст старше 75 лет',
      }, 
      {
         type: 'checkbox',
         inputId: 'thromboc',
         label: 'Снижение количества или функции тромбоцитов (включая использование аспирина, любую тромбоцитопению или дискразию крови [например, гемофилию])',
      }, 
      {
         type: 'checkbox',
         inputId: 'blood',
         label: 'Риск кровотечения (предыдущий анамнез кровотечения)',
      }, 
      {
         type: 'checkbox',
         inputId: 'hypert',
         label: 'Артериальная гипертензия (неконтролируемая)',
      }, 
      {
         type: 'checkbox',
         inputId: 'anemia',
         label: 'Анемия (Hb < 130 г/л у мужчин, Hb < 120 г/л у женщин)',
      }, 
      {
         type: 'checkbox',
         inputId: 'genetic',
         label: 'Генетические факторы (полиморфизмы мононуклеотидов CYP 2C9)',
      }, 
      {
         type: 'checkbox',
         inputId: 'fall',
         label: 'Очень высокий риск падения',
      }, 
      {
         type: 'checkbox',
         inputId: 'stroke',
         label: 'Анамнез инсульта',
      }, 
   ],
   refers: [
      "Gage BF, Yan Y, Milligan PE, et al. Clinical classification schemes for predicting hemorrhage: results from the National Registry of Atrial Fibrillation. Am Heart J 2006; 151:713-9",
      "Apostolakis S, Lane DA, Guo Y, Buller H, Lip GYH. Performance of the HEMORR(2)HAGES, ATRIA, and HAS-BLED bleeding risk-prediction scores in patients with atrial fibrillation undergoing anticoagulation: the AMADEUS (Evaluating the use of sr34006 compared to warfarin or acenocoumarol in patients with atrial fibrillation) study. J Am Coll Cardiol. 2012;60(9):861-867",
      "Caldeira D, Costa J, Fernandes RM, Pinto FJ, Ferreira JJ. Performance of the HAS-BLED high bleeding-risk category, compared to ATRIA and HEMORR2HAGES in patients with atrial fibrillation: a systematic review and meta-analysis. J Interv Card Electrophysiol. 2014;40(3):277-284",
   ]
}