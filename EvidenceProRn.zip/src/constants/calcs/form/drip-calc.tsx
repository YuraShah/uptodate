export const dripCalc = {
   id: "EV-CALC-55",
   link: "drip",
   title: "Калькулятор лекарственной устойчивости при пневмонии (DRIP)",
   text: "Помогает определить, когда следует использовать антибиотики широкого спектра действия",
   description: {
      descriptionMain: [
         "Помогает определить, когда использовать антибиотики широкого спектра действия, чтобы обеспечить эффективность лечения и избежать высокой устойчивости к антибиотикам. Оценка DRIP более чувствительна (82% против 79%), более специфична (81% против 65%) и снижает использование ненадлежащих антибиотиков широкого спектра действия на 38% по сравнению со шкалой HCAHPS (Hospital Consumer Assessment of Healthcare Providers and Systems). Оценка DRIP также оказалась более точной и специфичной, чем восемь других прогностических моделей, включая шкалу Schorr. Шкалу DRIP следует использовать только для бактериальных причин пневмонии»."
      ],
      descriptionTable: [
         {
            headData: ['Баллы', 'Результат'],
            bodyData: [
               ['≥4', 'Высокий риск лекарственно-устойчивой пневмонии. Вероятно, потребуются антибиотики широкого спектра действия'],
               ['<4', 'Низкий риск лекарственно-устойчивой пневмонии. Рассмотрите вариант лечения без антибиотиков широкого спектра действия'],
            ],
            flexNums: [1, 1.5]
         }
      ]
   },
   form: [
      {
         type: 'title',
         formTitle: 'Большие факторы риска',
      },
      {
         type: 'radio',
         radioButtons: [
            {
               id: '0',
               label: 'Нет',
               value: '0',
            },
            {
               id: '2',
               label: 'Да',
               value: '2',
            },
         ],
         label: 'Применение антибиотиков за последние 60 дней',
         inputId: 'antib',
         required: 'yes',
         numeric: 'yes',
      },
      {
         type: 'radio',
         radioButtons: [
            {
               id: '0',
               label: 'Нет',
               value: '0',
            },
            {
               id: '2',
               label: 'Да',
               value: '2',
            }
         ],
         label: 'Пациент учреждения длительного ухода (включая длительную интенсивную терапию, стационарную реабилитацию, но не пребывание в доме престарелых)',
         inputId: 'term',
         required: 'yes',
         numeric: 'yes',
      },
      {
         type: 'radio',
         radioButtons: [
            {
               id: '0',
               label: 'Нет',
               value: '0',
            },
            {
               id: '2',
               label: 'Да',
               value: '2',
            }
         ],
         label: 'Зондовое питание (назогастральный зонд, чрескожная эндоскопическая гастростомия)',
         inputId: 'tube',
         required: 'yes',
         numeric: 'yes',
      },
      {
         type: 'radio',
         radioButtons: [
            {
               id: '0',
               label: 'Нет',
               value: '0',
            },
            {
               id: '2',
               label: 'Да',
               value: '2',
            }
         ],
         label: 'Предыдущий диагноз лекарственно-устойчивой пневмонии в течение последнего года',
         inputId: 'prior',
         required: 'yes',
         numeric: 'yes',
      },
      {
         type: 'title',
         formTitle: 'Маленькие факторы риска',
      },
      {
         type: 'radio',
         radioButtons: [
            {
               id: '0',
               label: 'Нет',
               value: '0',
            },
            {
               id: '1',
               label: 'Да',
               value: '1',
            },
         ],
         label: 'Госпитализация за последние 60 дней',
         inputId: 'hosp',
         required: 'yes',
         numeric: 'yes',
      },
      {
         type: 'radio',
         radioButtons: [
            {
               id: '0',
               label: 'Нет',
               value: '0',
            },
            {
               id: '1',
               label: 'Да',
               value: '1',
            },
         ],
         label: 'Хроническое заболевание легких',
         inputId: 'dis',
         required: 'yes',
         numeric: 'yes',
      },
      {
         type: 'title',
         formTitle: '➪ Калькулятор индекса трудоспособности Карновского',
         link: 'calcs/karnofsky-scale',
      },
      {
         type: 'radio',
         radioButtons: [
            {
               id: '0',
               label: 'Нет',
               value: '0',
            },
            {
               id: '1',
               label: 'Да',
               value: '1',
            }
         ],
         label: 'Плохое функциональное состояние (<70 баллов по шкале Карновского или невозможность ходить)',
         inputId: 'funct',
         required: 'yes',
         numeric: 'yes',
      },
      {
         type: 'radio',
         radioButtons: [
            {
               id: '0',
               label: 'Нет',
               value: '0',
            },
            {
               id: '1',
               label: 'Да',
               value: '1',
            }
         ],
         label: 'Применение блокаторов Н2-гистаминовых рецепторов или ингибиторов протонной помпы в течение последних 14 дней',
         inputId: 'h2',
         required: 'yes',
         numeric: 'yes',
      },
      {
         type: 'radio',
         radioButtons: [
            {
               id: '0',
               label: 'Нет',
               value: '0',
            },
            {
               id: '1',
               label: 'Да',
               value: '1',
            }
         ],
         label: 'Активный уход за раной во время поступления',
         inputId: 'wound',
         required: 'yes',
         numeric: 'yes',
      },
      {
         type: 'radio',
         radioButtons: [
            {
               id: '0',
               label: 'Нет',
               value: '0',
            },
            {
               id: '1',
               label: 'Да',
               value: '1',
            }
         ],
         label: 'Колонизация MRSA в течение 1 года',
         inputId: 'mrsa',
         required: 'yes',
         numeric: 'yes',
      },
   ],
   refers: [
      "Webb BJ, Dascomb K, Stenehjem E, et al. Derivation and Multicenter Validation of the Drug Resistance in Pneumonia Clinical Prediction Score. Antimicrob Agents Chemother. 2016;60(5):2652-63.",
      "Webb BJ, Sorensen J, Mecham I, et al. Antibiotic Use and Outcomes After Implementation of the Drug Resistance in Pneumonia Score in ED Patients With Community-Onset Pneumonia. Chest. 2019.",
   ]
}