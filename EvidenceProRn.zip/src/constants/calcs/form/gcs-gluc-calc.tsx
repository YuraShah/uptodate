export const gcsGlucCalc = {
   id: "EV-CALC-01",
   link: "gcsconverter",
   title: "Конвертация кортикостероидов (глюкокортикоидный эффект)",
   text: "Расчет эквивалентных доз кортикостероидов (глюкокортикоидный эффект)",
   description: {
      descriptionMain: [
         "Калькулятор позволяет рассчитать эквивалентные дозы наиболее часто используемых глюкокортикостероидов. Важно помнить о продолжительности действия глюкокортикостероидов: препараты с длительным периодом полувыведения принимают реже. Основной принцип лечения — достижение максимального терапевтического эффекта минимальными дозами. Эффект глюкокортикоидов отвечает за противовоспалительное, иммунодепрессивное действие и регуляцию углеводного, белкового и жирового обмена.",
         "Дозозависимый эффект применим только к пероральному или внутривенному введению, поскольку эффект ГК после внутримышечных или внутрисуставных инъекций может значительно различаться."
      ],
      descriptionTable: [
         {
            headData: ['Лекартсво', 'Способ введения', 'Эквивалентная доза, мг', 'Противовоспалительный эффект', 'Длительность эффекта, ч'],
            bodyData: [
               ['Кортизон', 'пероральный (per os)', '25', '0.8', '8-12'],
               ['Гидрокортизон', 'пероральный (per os) или внутривенный', '20', '1', '8-12'],
               ['Дексаметазон', 'пероральный (per os) или внутривенный', '0.75', '30', '36-72'],
               ['Бетаметазон', 'внутривенный', '0.6', '25-35', '36-72'],
               ['Преднизон', 'пероральный (per os)', '5', '3.5', '12-36'],
               ['Преднизолон', 'пероральный (per os)', '5', '4', '12-36'],
               ['Метилпреднизолон', 'пероральный (per os) или внутривенный', '4', '5', '8-12'],
               ['Триамцинолон', 'внутривенный', '4', '5', '12-36'],
            ],
            widthNums: [150, 150, 150, 150, 150],
         }
      ]
   },
   form: [
      {
         type: 'select',
         label: 'От дозы препарата',
         inputId: 'firstGcs',
         required: 'yes',
         items: [
            { value: 'cortisone', label: 'Кортизон' },
            { value: 'hydrocortisone', label: 'Гидрокортизон' },
            { value: 'dexamethasone', label: 'Дексаметазон' },
            { value: 'bethamethasone', label: 'Бетаметазон' },
            { value: 'prednisone', label: 'Преднизон' },
            { value: 'prednisolone', label: 'Преднизолон' },
            { value: 'methylprednisolone', label: 'Метилпреднизолон' },
            { value: 'triamcinolone', label: 'Триамцинолон' },
         ]
      },
      {
         type: 'input',
         label: 'Доза',
         inputId: 'dose',
         placeholder: '',
         error: 'Доза должна быть числом и больше 0',
         span: 'мг',
         min: 0.00001,
         max: 100000,
         required: 'yes',
         pattern: "dot",
         ext: 0
      },
      {
         type: 'select',
         label: 'В дозу препарата',
         inputId: 'secondGcs',
         required: 'yes',
         items: [
            { value: 'cortisone', label: 'Кортизон' },
            { value: 'hydrocortisone', label: 'Гидрокортизон' },
            { value: 'dexamethasone', label: 'Дексаметазон' },
            { value: 'bethamethasone', label: 'Бетаметазон' },
            { value: 'prednisone', label: 'Преднизон' },
            { value: 'prednisolone', label: 'Преднизолон' },
            { value: 'methylprednisolone', label: 'Метилпреднизолон' },
            { value: 'triamcinolone', label: 'Триамцинолон' },
         ]
      },
   ],
   refers: [
      "Dose equivalency evaluation of major corticosteroids: pharmacokinetics and cell trafficking and cortisol dynamics. J Clin Pharmacol. 2003 Nov;43(11):1216-27. doi: 10.1177/0091270003258651."
   ]
}