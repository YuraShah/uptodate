export const cockcroftGaultCalc = {
   id: "EV-CALC-40",
   link: "egfr-cockcroft",
   title: "Калькулятор скорости клубочковой фильтрации (формула Cockcroft-Gault)",
   text: "Калькулятор скорости клубочковой фильтрации формулой Cockcroft and Gault",
   description: {
      descriptionMain: [
         "Cockcroft and Gault формула (CG) была разработана в 1973 году с использованием данных 249 мужчин с клиренсом креатинина (ClCr) приблизительно 30-130 мл/м². Она не скорректирована с учетом площади поверхности тела. CG больше не рекомендуется для использования, поскольку она основана на нестандартизированных значениях креатинина. Это означает, что она может давать неточные результаты.",
         "Ее не следует использовать для оценки дозы препарата или скорости клубочковой фильтрации (СКФ). Формула  Cockcroft-Gault (CG) предназначена только для исследовательских целей. Лучшим способом определения дозы препарата является формула CKD-EPI (2009) или MDRD. Оба они точнее формулы CG. СКФ является лучшим общим показателем функции почек.",
         "Клиренс креатинина для пациентов с недостаточным весом (ИМТ [индекс массы тела] 18,3 кг/м²) рассчитывается с использованием фактической массы тела (без корректировки). В остальных случаях он рассчитывается с использованием идеальной и скорректированной массы тела.",
      ],
      descriptionTable: [
         {
            headData: ['Стадия', 'Описание', 'СКФ, мл/мин/1,73 м²'],
            bodyData: [
               ['1', 'Симптомы нефропатии, нормальный СКФ', '>90'],
               ['2', 'Симптомы нефропатии, малое снижение СКФ', '60-89'],
               ['3А', 'Умеренное снижение СКФ', '45-59'],
               ['3Б', 'Выраженное снижение СКФ', '30-44'],
               ['4', 'Сильное снижение СКФ', '15-29'],
               ['5', 'Терминальная стадия почечной недостаточности', '<15'],
            ],
            flexNums: [1, 2, 1]
         }
      ],
      descriptionLink: [
         {
            "name": "CKD-EPI",
            "link": 'calcs/egfr-ckd-epi',
         },
         {
            "name": "MDRD",
            "link": 'calcs/egfr-mdrd',
         }
      ]
   },
   form: [
      {
         type: 'radio',
         radioButtons: [
            {
               id: '1',
               label: 'Мужской',
               value: '1',
            },
            {
               id: '0',
               label: 'Женский',
               value: '0',
            }
         ],
         label: 'Пол',
         inputId: 'gender',
         required: 'yes',
         numeric: 'no',
      },
      {
         type: 'input',
         label: 'Возраст',
         inputId: 'age',
         placeholder: '1 - 100',
         error: 'Возраст должен быть 1-100',
         span: 'лет',
         min: 1,
         max: 100,
         required: 'yes',
         pattern: "nodot",
         ext: 0,
         spanWidth: 115
      },
      {
         type: 'input',
         label: 'Вес',
         inputId: 'weight',
         placeholder: '1 - 300',
         error: 'Это поле должно быть в диапазоне 1 - 300',
         span: 'кг',
         min: 1,
         max: 300,
         required: 'yes',
         pattern: "dot",
         ext: 0,
         spanWidth: 115
      },
      {
         type: 'input',
         label: 'Креатинин плазмы',
         inputId: 'creatinine',
         placeholder1: '0.01 - 10',
         placeholder: '0.9 - 880',
         error1: 'Креатинин должен быть 0.01 - 10',
         error: 'Креатинин должен быть 0.9 - 880',
         span1: 'мг/дл',
         span: 'мкмоль/л',
         min1: 0.01,
         min: 0.9,
         max1: 10,
         max: 880,
         required: 'yes',
         pattern: "dot",
         ext: 1,
         spanWidth: 55
      },
      {
         type: 'input',
         label: 'Рост',
         inputId: 'height',
         placeholder: '20 - 213',
         error: 'Рост должен быть 20 - 213',
         span: 'см',
         min: 20,
         max: 203,
         required: 'yes',
         pattern: "nodot",
         ext: 0,
         spanWidth: 115
      },
   ],
   refers: [
      "Cockcroft DW, Gault MH. Prediction of creatinine clearance from serum creatinine. Nephron. 1976;16(1):31-41. PubMed PMID: 1244564",
      "Winter MA, Guhr KN, Berg GM. Impact of various body weights and serum creatinine concentrations on the bias and accuracy of the Cockcroft-Gault equation. Pharmacotherapy. 2012 Jul;32(7):604-12",
      "Brown DL, Masselink AJ, Lalla CD. Functional range of creatinine clearance for renal drug dosing: a practical solution to the controversy of which weight to use in the Cockcroft-Gault equation. Ann Pharmacother. 2013 Jul-Aug;47(7-8):1039-44",
      "Coresh, J. and L.A. Stevens. Kidney function estimating equations: where do we stand? Curr Opin Nephrol Hypertens. May 2006;15(3): 276-84",
      "Stevens LA, Nolin TD, Richardson MM, et al. Comparison of drug dosing recommendations based on measured GFR and kidney function estimating equations. Am J Kidney Dis. 2010;55(4):660-670",
      "Levey AS, Stevens LA. Estimating GFR using the CKD Epidemiology Collaboration (CKD-EPI) creatinine equation: more accurate GFR estimates, lower CKD prevalence estimates, and better risk predictions. Am J Kidney Dis. Apr 2010;55(4):622-627",
      "Inker, AS. Frequently Asked Questions About GFR Estimates. New York: The National Kidney Foundation; 2011",
   ]
}