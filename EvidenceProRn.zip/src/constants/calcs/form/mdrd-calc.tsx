export const mdrdCalc = {
   id: "EV-CALC-41",
   link: "egfr-mdrd",
   title: "Калькулятор скорости клубочковой фильтрации (формула MDRD)",
   text: "Калькулятор скорости клубочковой фильтрации по формуле MDRD",
   description: {
      descriptionMain: [
         "Формула MDRD оценивает скорость клубочковой фильтрации (СКФ) с поправкой на площадь поверхности тела. Она точнее, чем клиренс креатинина, который рассчитывается по 24-часовому сбору мочи или по формуле Кокрофта-Голта. СКФ является наилучшим общим показателем функции почек.",
      ],
      descriptionTable: [
         {
            headData: ['Стадия', 'Описание', 'СКФ, мл/мин/1,73²'],
            bodyData: [
               ['1', 'Симптомы нефропатии, нормальный СКФ', '>90'],
               ['2', 'Симптомы нефропатии, малое снижение СКФ', '60-89'],
               ['3А', 'Умеренное снижение СКФ', '45-59'],
               ['3Б', 'Выраженное снижение СКФ', '30-44'],
               ['4', 'Сильное снижение СКФ', '15-29'],
               ['5', 'Терминальная стадия почечной недостаточности', '<15'],
            ],
            flexNums: [1, 2, 1]
         }
      ],
      descriptionLink: [
         {
            "name": "Cockcroft-Gault",
            "link": 'calcs/egfr-cockcroft',
         }
      ]
   },
   form: [
      {
         type: 'radio',
         radioButtons: [
            {
               id: '1',
               label: 'Мужской',
               value: '1',
            },
            {
               id: '0',
               label: 'Женский',
               value: '0',
            }
         ],
         label: 'Пол',
         inputId: 'gender',
         required: 'yes',
      },
      {
         type: 'radio',
         radioButtons: [
            {
               id: '0',
               label: 'Нет',
               value: '0',
               selected: true
            },
            {
               id: '1',
               label: 'Да',
               value: '1',
            },
         ],
         label: 'Негроидная раса',
         inputId: 'race',
         required: 'yes',
      },
      {
         type: 'input',
         label: 'Возраст',
         inputId: 'age',
         placeholder: '1 - 100',
         error: 'Возраст должен быть в диапазоне 1-100',
         span: 'лет',
         min: 1,
         max: 100,
         required: 'yes',
         pattern: "nodot",
         spanWidth: 115,
         ext: 0,
      },
      {
         type: 'input',
         label: 'Креатинин плазмы',
         inputId: 'creatinine',
         placeholder1: '0.01 - 10',
         placeholder: '0.9 - 880',
         error1: 'Креатинин должен быть 0.01 - 10',
         error: 'Креатинин должен быть 0.9 - 880',
         span1: 'мг/дл',
         span: 'мкмоль/л',
         min1: 0.01,
         min: 0.9,
         max1: 10,
         max: 880,
         required: 'yes',
         pattern: "dot",
         ext: 1,
         spanWidth: 55
      },
   ],
   refers: [
      "Levey AS, Bosch JP, Lewis JB, Greene T, Rogers N, Roth D. A more accurate method to estimate glomerular filtration rate from serum creatinine: a new prediction equation. Modification of Diet in Renal Disease Study Group. Ann Intern Med. 1999;130(6):461-70",
      "Rule AD, Larson TS, Bergstralh EJ, Slezak JM, Jacobsen SJ, Cosio FG. Using serum creatinine to estimate glomerular filtration rate: accuracy in good health and in chronic kidney disease. Ann Intern Med. 2004;141(12):929-37",
      "Levey AS, Coresh J, Greene T, et al. Using standardized serum creatinine values in the modification of diet in renal disease study equation for estimating glomerular filtration rate. Ann Intern Med. 2006;145(4):247-54",
      "Levey AS, Greene T, Kusek JW, Beck GJ. A simplified equation to predict glomerular filtration rate from serum creatinine [Abstract]. J Am Soc Nephrol. 2000;11:A0828",
      "Levey AS, Coresh J, Greene T, et al. Expressing the Modification of Diet in Renal Disease Study equation for estimating glomerular filtration rate with standardized serum creatinine values. Clin Chem. Apr 2007;53(4):766-772",
      "Stevens LA, Manzi J, Levey AS, et al. Impact of creatinine calibration on performance of GFR estimating equations in a pooled individual patient database. Am J Kidney Dis. Jul 2007;50(1):21-35",
   ]
}