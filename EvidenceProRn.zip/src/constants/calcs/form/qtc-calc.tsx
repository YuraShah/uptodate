export const qtcCalc = {
   id: "EV-CALC-31",
   link: "qtc",
   title: "Корректированный интервал QT (QTc)",
   text: "Корректирует интервал QT для экстремальных значений частоты сердечных сокращений",
   description: {
      descriptionMain: [
         "Корректирует интервал QT для экстремальных значений частоты сердечных сокращений (выберите формулу Bazett, Fridericia, Framingham, Hodges или Rautaharju). Используется у пациентов с обмороками, которые получают несколько препаратов, удлиняющих интервал QT. Длинный интервал QT связан с повышенным риском желудочковой тахикардии типа «пируэт». Этот калькулятор корректирует QT на основе QT при частоте сердечных сокращений 60 ударов в минуту.",
         "Нормальный QTc ≤440 мсек. Более длинный QTc увеличивает риск развития желудочковой тахикардии типа «пируэт».",
         [
            "Некоторые причины удлинения интервала QT:",
            "Электролитные нарушения",
            [
               "Гипокальциемия",
               "Гипокалиемия",
               "Гипомагнемия",
            ],
            "Внутренние сердечные причины",
            [
               "Ишемия миокарда",
               "После остановки сердца",
               "Ишемическая болезнь сердца",
               "Кардиомиопатия",
               "Тяжелая брадикардия, атриовентрикулярная блокада высокой степени",
               "Врожденный синдром удлиненного интервала QT"
            ],
            "Центральные причины",
            [
               "Повышенное внутричерепное давление",
               "Вегетативная дисфункция",
               "Гипотиреоз",
            ],
            "Лекарства",
            [
               "Антиаритмические препараты",
               "Психотропы",
               "Другие"
            ]
         ]
      ]
   },
   form: [
      {
         type: 'select',
         label: 'Формула',
         inputId: 'formula',
         required: 'yes',
         items: [
            { value: 'bazett', label: 'Bazett (Базетт)' },
            { value: 'fridericia', label: 'Fridericia (Фридеричи)' },
            { value: 'framingham', label: 'Framingham (Фрамингем)' },
            { value: 'hodges', label: 'Hodges (Ходжес)' },
            { value: 'rautaharju', label: 'Rautaharju (Раутахарью)' },
         ]
      },
      {
         type: 'input',
         label: 'Частота сердечных сокращений/пульс',
         inputId: 'rate',
         placeholder: '20 - 200',
         error: 'Поле должно быть в диапазоне 20 - 200',
         span: 'удар/мин',
         min: 20,
         max: 200,
         required: 'yes',
         pattern: "nodot",
         ext: 0,
         spanWidth: 150
      },
      {
         type: 'radio',
         radioButtons: [
            {
               id: '25',
               label: '25 мм/сек',
               value: '25',
            },
            {
               id: '50',
               label: '50 мм/сек',
               value: '50',
            }
         ],
         label: 'Скорость бумаги',
         inputId: 'speed',
         required: 'yes',
         numeric: 'no',
      },
      {
         type: 'input',
         label: 'QT интервал',
         inputId: 'qt',
         placeholder: '',
         placeholder1: '',
         error1: 'Поле должно быть в диапазоне 0.01 - 10000',
         error: 'Поле должно быть в диапазоне 1 - 600',
         span1: 'мсек',
         span: 'маленький квадрат',
         min1: 0.01,
         min: 1,
         max1: 10000,
         max: 600,
         required: 'yes',
         pattern: "dot",
         ext: 1,
         spanWidth: 90
      },
      {
         type: 'custom',
         img: require('@/assets/images/calcs/qtc.jpg'),
         height: 200,
         heightL: 300
      }
   ],
   refers: [
      "Bazett HC. An analysis of the time-relations of electrocardiograms. Heart 1920; (7): 353–37.",
      "Fridericia LS. The duration of systole in an electrocardiogram in normal humans and in patients with heart disease. 1920. Ann Noninvasive Electrocardiol. 2003;8(4):343-51.",
      "Hodges MS, Salerno D, Erlinen D. Bazett's QT correction reviewed: evidence that a linear QT correction for heart rate is better. J Am Coll Cardiol. 1983;1:694.",
      "Sagie A, Larson MG, Goldberg RJ, Bengston JR, Levy D. An improved method for adjusting the QT interval for heart rate (the Framingham Heart Study) The American Journal of Cardiology 1992; 70; 797-801.",
      "Rautaharju PM, Mason JW, Akiyama T. New age- and sex-specific criteria for QT prolongation based on rate correction formulas that minimize bias at the upper normal limits. Int J Cardiol. 2014;174(3):535-540.",
      "Chan A, Isbister GK, Kirkpatrick CMJ, Dufful SB. Drug-induced QT prolongation and torsades de pointes: evaluation of a QT nomogram. QJM. 2007;100(10):609-615.",
      "Othong R, Wattanasansomboon S, Kruutsaha T, Chesson D, Arj-Ong Vallibhakara S, Kazzi Z. Utility of QT interval corrected by Rautaharju method to predict drug-induced torsade de pointes. Clin Toxicol (Phila). 2019;57(4):234-239.",
      "Lesson III. Characteristics of the Normal ECG Frank G. Yanowitz, MD. Professor of Medicine. University of Utah School of Medicine",
      "Vandenberk B, Vandael E, Robyns T, et al. Which QT Correction Formulae to Use for QT Monitoring?. J Am Heart Assoc. 2016;5(6).",
   ]
}