export const copdAssessmentForm = {
   id: "EV-CALC-60",
   link: "copd-assessment",
   title: "Оценочный тест ХОБЛ (CAT)",
   text: "Количественно оценивает влияние симптомов ХОБЛ на общее состояние здоровья",
   description: {
      descriptionMain: [
         "Количественно оценивает влияние симптомов ХОБЛ на общее состояние здоровья пациентов. Используется у пациентов с диагнозом ХОБЛ для оценки прогрессирования заболевания легких и снижения функциональности.",
         "Было показано, что результаты теста оценки ХОБЛ коррелируют со смертностью (Husebø 2016), а также с улучшением симптомов, о котором сообщают пациенты (Dodd 2011).",
         "Рекомендовано руководством GOLD (вместе со шкалой одышки mMRC) для оценки всех пациентов с ХОБЛ.",
         "Посоветуйте всем бросить курить, пройти профилактическое лечение и снизить воздействие факторов риска обострений."
      ],
      descriptionLink: [{
         "name": "Шкала одышки mMRC",
         "link": 'calcs/mmrc',
      }]
   },
   form: [
      {
         type: 'radio',
         radioButtons: [
            {
               id: '0',
               label: '0 [Никогда не кашляю]',
               value: '0',
            },
            {
               id: '1',
               label: '1',
               value: '1',
            },
            {
               id: '2',
               label: '2',
               value: '2',
            },
            {
               id: '3',
               label: '3',
               value: '3',
            },
            {
               id: '4',
               label: '4',
               value: '4',
            },
            {
               id: '5',
               label: '5 [Всегда кашляю]',
               value: '5',
            }
         ],
         label: 'Кашель',
         inputId: 'cough',
         required: 'yes',
         numeric: 'yes',
      },
      {
         type: 'radio',
         radioButtons: [
            {
               id: '0',
               label: '0 [Никогда не было]',
               value: '0',
            },
            {
               id: '1',
               label: '1',
               value: '1',
            },
            {
               id: '2',
               label: '2',
               value: '2',
            },
            {
               id: '3',
               label: '3',
               value: '3',
            },
            {
               id: '4',
               label: '4',
               value: '4',
            },
            {
               id: '5',
               label: '5 [Всегда есть]',
               value: '5',
            }
         ],
         label: 'Выделение мокроты',
         inputId: 'phlegm',
         required: 'yes',
         numeric: 'yes',
      },
      {
         type: 'radio',
         radioButtons: [
            {
               id: '0',
               label: '0 [Никогда не было]',
               value: '0',
            },
            {
               id: '1',
               label: '1',
               value: '1',
            },
            {
               id: '2',
               label: '2',
               value: '2',
            },
            {
               id: '3',
               label: '3',
               value: '3',
            },
            {
               id: '4',
               label: '4',
               value: '4',
            },
            {
               id: '5',
               label: '5 [Всегда есть]',
               value: '5',
            }
         ],
         label: 'Ощущение стеснения в груди',
         inputId: 'chestTightness',
         required: 'yes',
         numeric: 'yes',
      },
      {
         type: 'radio',
         radioButtons: [
            {
               id: '0',
               label: '0 [Когда поднимаюсь в гору или на один пролет лестницы, у меня не возникает одышки]',
               value: '0',
            },
            {
               id: '1',
               label: '1',
               value: '1',
            },
            {
               id: '2',
               label: '2',
               value: '2',
            },
            {
               id: '3',
               label: '3',
               value: '3',
            },
            {
               id: '4',
               label: '4',
               value: '4',
            },
            {
               id: '5',
               label: '5 [Возникает одышка, когда я поднимаюсь в гору или на один пролет лестницы]',
               value: '5',
            }
         ],
         label: 'Затруднённое дыхание',
         inputId: 'breathlessness',
         required: 'yes',
         numeric: 'yes',
      },
      {
         type: 'radio',
         radioButtons: [
            {
               id: '0',
               label: '0 [Я не ограничен в выполнении каких-либо действий дома]',
               value: '0',
            },
            {
               id: '1',
               label: '1',
               value: '1',
            },
            {
               id: '2',
               label: '2',
               value: '2',
            },
            {
               id: '3',
               label: '3',
               value: '3',
            },
            {
               id: '4',
               label: '4',
               value: '4',
            },
            {
               id: '5',
               label: '5 [Я очень ограничен в возможности заниматься какой-либо деятельностью дома]',
               value: '5',
            }
         ],
         label: 'Ограничение физической активности',
         inputId: 'activity',
         required: 'yes',
         numeric: 'yes',
      },
      {
         type: 'radio',
         radioButtons: [
            {
               id: '0',
               label: '0 [Я уверенно выхожу из дома, несмотря на состояние моих легких]',
               value: '0',
            },
            {
               id: '1',
               label: '1',
               value: '1',
            },
            {
               id: '2',
               label: '2',
               value: '2',
            },
            {
               id: '3',
               label: '3',
               value: '3',
            },
            {
               id: '4',
               label: '4',
               value: '4',
            },
            {
               id: '5',
               label: '5 [Из-за заболевания легких я чувствую себя неуверенно, выходя из дома]',
               value: '5',
            }
         ],
         label: 'Уровень уверенности',
         inputId: 'confidence',
         required: 'yes',
         numeric: 'yes',
      },
      {
         type: 'radio',
         radioButtons: [
            {
               id: '0',
               label: '0 [Сплю спокойно]',
               value: '0',
            },
            {
               id: '1',
               label: '1',
               value: '1',
            },
            {
               id: '2',
               label: '2',
               value: '2',
            },
            {
               id: '3',
               label: '3',
               value: '3',
            },
            {
               id: '4',
               label: '4',
               value: '4',
            },
            {
               id: '5',
               label: '5 [Из-за своих легких не могу нормально спать]',
               value: '5',
            }
         ],
         label: 'Сон',
         inputId: 'sleep',
         required: 'yes',
         numeric: 'yes',
      },
      {
         type: 'radio',
         radioButtons: [
            {
               id: '0',
               label: '0 [У меня много энергии]',
               value: '0',
            },
            {
               id: '1',
               label: '1',
               value: '1',
            },
            {
               id: '2',
               label: '2',
               value: '2',
            },
            {
               id: '3',
               label: '3',
               value: '3',
            },
            {
               id: '4',
               label: '4',
               value: '4',
            },
            {
               id: '5',
               label: '5 [У меня совсем нет энергии]',
               value: '5',
            }
         ],
         label: 'Энергия',
         inputId: 'energy',
         required: 'yes',
         numeric: 'yes',
      }
   ],
   refers: [
      "Jones PW, Harding G, Berry P, Wiklund I, Chen WH, Kline Leidy N. Development and first validation of the COPD Assessment Test. Eur Respir J. 2009;34(3):648-54.",
      "Dodd JW, Hogg L, Nolan J, et al. COPD assessment test (CAT): response to pulmonary rehabilitation. A multicentre, prospective study. The Thorax. 2011;66(5):425-9.",
      "Husebø, G, Köll R, Nielsen A et al. CAT-score is a predictor for mortality in COPD. 6.1 Epidemiology. Eur Respir J. 2016;48:PA3106.",
      "Global Initiative for Chronic Obstructive Lung Disease (GOLD). Global Strategy for the Diagnosis, Management, and Prevention of COPD. 2024 Report.",
      "Jones PW, Tabberer M, Chen WH. Creating scenarios of the impact of COPD and their relationship to COPD Assessment Test (CAT™) scores. BMC Pulm Med. 2011;11:42.",
   ]
}