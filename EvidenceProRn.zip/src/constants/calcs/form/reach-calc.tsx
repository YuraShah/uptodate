export const reachCalc = {
   id: "EV-CALC-25",
   link: "reach",
   title: "Шкала REACH",
   text: "Оценка риска серьезного кровотечения у стабильного пациента с атеросклерозом",
   description: {
      descriptionMain: [
         "Шкала REACH (REduction of Atherothrombosis for Continued Health) - создана для расчета риска серьезного кровотечения у пациента с атеросклерозом (у которого нет мерцательной аритмии, острого коронарного синдрома, не проводилось эндоваскулярное лечение).",
         "Риск кровотечения резко возрастает, если балл равен 10 и выше."
      ],
      descriptionTable: [
         {
            headData: ['Результат', 'Баллы'],
            bodyData: [
               ['Уровень риска: 0.46%', 'До 6 (включительно)'],
               ['Уровень риска: 0.95%', '7 - 8'],
               ['Уровень риска: 1.25%', '9 - 10'],
               ['Уровень риска: 2.76%', '11 и больше'],
            ],
            flexNums: [1, 1]
         }
      ]
   },
   form: [
      {
         type: 'radio',
         radioButtons: [
            {
               id: '0',
               label: '45 - 54',
               value: '0',
            },
            {
               id: '2',
               label: '54 - 64',
               value: '2',
            },
            {
               id: '4',
               label: '65 - 74',
               value: '4',
            },
            {
               id: '6',
               label: 'больше 75',
               value: '6',
            }
         ],
         label: 'Возраст',
         inputId: 'age',
         required: 'yes',
         numeric: 'yes',
      },
      {
         type: 'radio',
         radioButtons: [
            {
               id: '0',
               label: 'Нету',
               value: '0',
            },
            {
               id: '1',
               label: 'Есть',
               value: '1',
            }
         ],
         label: 'Периферический атеросклероз',
         inputId: 'atherosclerosis',
         required: 'yes',
         numeric: 'yes',
      },
      {
         type: 'radio',
         radioButtons: [
            {
               id: '0',
               label: 'Нету',
               value: '0',
            },
            {
               id: '1',
               label: 'Есть',
               value: '1',
            }
         ],
         label: 'Сердечная недостаточность',
         inputId: 'heart',
         required: 'yes',
         numeric: 'yes',
      },
      {
         type: 'radio',
         radioButtons: [
            {
               id: '0',
               label: 'Нету',
               value: '0',
            },
            {
               id: '1',
               label: 'Есть',
               value: '1',
            }
         ],
         label: 'Сахарный диабет',
         inputId: 'diabetes',
         required: 'yes',
         numeric: 'yes',
      },
      {
         type: 'radio',
         radioButtons: [
            {
               id: '0',
               label: 'Нету',
               value: '0',
            },
            {
               id: '1',
               label: 'Есть',
               value: '1',
            }
         ],
         label: 'Гиперхолестеринемия',
         inputId: 'chol',
         required: 'yes',
         numeric: 'yes',
      },
      {
         type: 'radio',
         radioButtons: [
            {
               id: '0',
               label: 'Нету',
               value: '0',
            },
            {
               id: '1',
               label: 'Есть',
               value: '1',
            }
         ],
         label: 'Артериальная гипертония',
         inputId: 'hypertension',
         required: 'yes',
         numeric: 'yes',
      },
      {
         type: 'radio',
         radioButtons: [
            {
               id: '0',
               label: 'Не курю',
               value: '0',
            },
            {
               id: '1',
               label: 'Раньше курил',
               value: '1',
            },
            {
               id: '2',
               label: 'Продолжаю курить',
               value: '2',
            }
         ],
         label: 'Курение',
         inputId: 'smoke',
         required: 'yes',
         numeric: 'yes',
      },
      {
         type: 'radio',
         radioButtons: [
            {
               id: '0',
               label: 'Не принимаю',
               value: '0',
            },
            {
               id: '1',
               label: 'Аспирин',
               value: '1',
            },
            {
               id: '2',
               label: 'Другие препараты',
               value: '2',
            },
            {
               id: '4',
               label: 'Комбинации',
               value: '4',
            }
         ],
         label: 'Прием антикоагулянтов',
         inputId: 'antithromb',
         required: 'yes',
         numeric: 'yes',
      },
      {
         type: 'radio',
         radioButtons: [
            {
               id: '0',
               label: 'Не принимаю',
               value: '0',
            },
            {
               id: '1',
               label: 'Принимаю',
               value: '1',
            }
         ],
         label: 'Прием антикоагулянтов (перорально)',
         inputId: 'anticoag',
         required: 'yes',
         numeric: 'yes',
      },
   ],
   refers: [
      "Ohman EM, Bhatt DL, Steg PG, Goto S, Hirsch AT, Liau CS, Mas JL, Richard AJ, Röther J, Wilson PW, REACH Registry Investigators. The REduction of Atherothrombosis for Continued Health (REACH) Registry: an international, prospective, observational investigation in subjects at risk for atherothrombotic events-study design. American Heart Journal, 01 Apr 2006, 151(4):786.e1-10 PMID: 16569533",
      "Heatherton, T. F., L. T. Kozlowski, et al. (1991). The Fagerstrom Test for Nicotine Dependence: a revision of the Fagerstrom Tolerance Questionnaire. Br J Addict 86(9): 1119-1127.",
      "Kozlowski, L. T., C. Q. Porter, et al. (1994). Predicting smoking cessation with self-reported measures of nicotine dependence: FTQ, FTND, and HSI. Drug Alcohol Depend 34(3): 211-216.",
   ]
}