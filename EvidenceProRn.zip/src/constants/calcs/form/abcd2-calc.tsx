export const abcd2Calc = {
   id: "EV-CALC-18",
   link: "abcd2",
   title: "Шкала ABCD2",
   text: "Оценка риска развития раннего инсульта после транзиторной ишемической атаки",
   description: {
      descriptionMain: [
         "ABCD2 шкала (Age, Blood pressure, Clinical features, Duration of symptoms, Diabetes mellitus) - предназначен для быстрой оценки риска развития раннего инсульта в первые 2, 7 и 90 дней после транзиторной ишемической атаки.",
      ],
      descriptionTable: [{
         headData: ['Результат', 'Баллы'],
         bodyData: [
            ['Низкий риск', '3 и меньше'],
            ['Средний риск', '4-5'],
            ['Высокий риск', '6 и больше']
         ],
         flexNums: [1, 1]
      }]
   },
   form: [
      {
         type: 'radio',
         radioButtons: [
            {
               id: '0',
               label: 'Меньше 60',
               value: '0',
            },
            {
               id: '1',
               label: 'Больше 60',
               value: '1',
            }
         ],
         label: 'Возраст',
         inputId: 'age',
         required: 'yes',
         numeric: 'yes',
      },
      {
         type: 'radio',
         radioButtons: [
            {
               id: '0',
               label: 'Нормальный',
               value: '0',
            },
            {
               id: '1',
               label: 'Больше 140/90 мм рт.с.',
               value: '1',
            }
         ],
         label: 'Систолическое давление',
         inputId: 'hypertension',
         required: 'yes',
         numeric: 'yes',
      },
      {
         type: 'radio',
         radioButtons: [
            {
               id: '0',
               label: 'Гемипарез',
               value: '0',
            },
            {
               id: '1',
               label: 'Нарушение речи без гемипареза',
               value: '1',
            },
            {
               id: '2',
               label: 'Другие симптомы',
               value: '2',
            }
         ],
         label: 'Клинические симптомы',
         inputId: 'clinic',
         required: 'yes',
         numeric: 'yes',
      },
      {
         type: 'radio',
         radioButtons: [
            {
               id: '0',
               label: 'менее 10 минут',
               value: '0',
            },
            {
               id: '1',
               label: '10 - 59 минут',
               value: '1',
            },
            {
               id: '2',
               label: 'более 60 минут',
               value: '2',
            }
         ],
         label: 'Продолжительность симптомов',
         inputId: 'duration',
         required: 'yes',
         numeric: 'yes',
      },
      {
         type: 'radio',
         radioButtons: [
            {
               id: '0',
               label: 'Нет',
               value: '0',
            },
            {
               id: '1',
               label: 'Да',
               value: '1',
            }
         ],
         label: 'Сахарный диабет',
         inputId: 'diabetes',
         required: 'yes',
         numeric: 'yes',
      }
   ],
   refers: [
      "Johnston SC, Rothwell PM, Nguyen-Huynh MN, Giles MF, Elkins JS, Bernstein AL, Sidney S. Validation and refinement of scores to predict very early stroke risk after transient ischaemic attack. Lancet. 2007 Jan 27;369(9558):283-92",
      "Josephson SA, Sidney S, Pham TN, Bernstein AL, Johnston SC. Higher ABCD2 score predicts patients most likely to have true transient ischemic attack. Stroke. 2008 Nov;39(11):3096-8. doi: 10.1161/STROKEAHA.108.514562. Epub 2008 Aug 7",
      "Rothwell PM, Giles MF, Flossmann E, Lovelock CE, Redgrave JN, Warlow CP, Mehta Z. A simple score (ABCD) to identify individuals at high early risk of stroke after transient ischaemic attack. Lancet. 2005 Jul 2-8;366(9479):29-36",
      "Sanders LM, Srikanth VK, Blacker DJ, Jolley DJ, Cooper KA, Phan TG.Performance of the ABCD2 score for stroke risk post TIA: meta-analysis and probability modeling. Neurology. 2012 Sep 4;79(10):971-80. doi: 10.1212/WNL.0b013e31825f9d02. Epub 2012 Jun 13. PubMed PMID: 22700810",
      "Stead LG, Suravaram S, Bellolio MF, Enduri S, Rabinstein A, Gilmore RM, Bhagra A, Manivannan V, Decker WW. An assessment of the incremental value of the ABCD2 score in the emergency department evaluation of transient ischemic attack. Ann Emerg Med. 2011 Jan;57(1):46-51. doi: 10.1016/j.annemergmed.2010.07.001. Epub 2010 Sep 19. PubMed PMID: 20855130",
      "Perry JJ, Sharma M, Sivilotti ML, Sutherland J, Symington C, Worster A, Émond M, Stotts G, Jin AY, Oczkowski WJ, Sahlas DJ, Murray HE, MacKey A, Verreault S, Wells GA, Stiell IG. Prospective validation of the ABCD2 score for patients in the emergency department with transient ischemic attack. CMAJ. 2011 Jul 12;183(10):1137-45. doi: 10.1503/cmaj.101668. Epub 2011 Jun 6. PubMed PMID: 21646462"
   ]
}