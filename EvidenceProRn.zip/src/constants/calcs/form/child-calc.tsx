export const childPughCalc = {
   id: "EV-CALC-56",
   link: "child-pugh-score",
   title: "Шкала Child-Pugh",
   text: "Помогает оценить тяжесть цирроза",
   description: {
      descriptionMain: [
         "Шкала Child-Pugh может быть полезна для прогнозирования прогноза у пациентов с циррозом, но более современные шкалы, такие как MELD и MELD-Na, все чаще используются из-за их лучшей прогностической ценности.",
      ],
      descriptionTable: [
         {
            headData: ['Баллы', 'Результат'],
            bodyData: [
               ['5-6', 'Child класс A'],
               ['7-9', 'Child класс B'],
               ['10-15', 'Child класс C'],
            ],
            flexNums: [1, 1],
         }
      ],
      descriptionLink: [
         {
            "name": "MELD",
            "link": 'calcs/meld-score-3',
         },
         {
            "name": "MELD-Na",
            "link": 'calcs/meld-score-na',
         },
      ]
   },
   form: [
      {
         type: 'radio',
         label: 'Билирубин (общий)',
         inputId: 'bilirubin',
         required: 'yes',
         numeric: 'yes',
         radioButtons: [
            {
               id: '1',
               label: '<34.2 ммоль/л (<2 мг/дл) [при первичном билиарном циррозе 17-68 ммоль/л (1-4 мг/дл)]',
               value: '1',
            },
            {
               id: '2',
               label: '34.2-51.3 ммоль/л (2-3 мг/дл) [при первичном билиарном циррозе 69-171 ммоль/л (4-10 мг/дл)]',
               value: '2',
            },
            {
               id: '3',
               label: '>51.3 ммоль/л (>3 мг/дл) [при первичном билиарном циррозе >171 ммоль/л (>10 мг/дл)]',
               value: '3',
            }
         ],
      },
      {
         type: 'radio',
         label: 'Альбумин',
         inputId: 'albumin',
         required: 'yes',
         numeric: 'yes',
         radioButtons: [
            {
               id: '1',
               label: '>35 г/л (>3.5 г/дл)',
               value: '1',
            },
            {
               id: '2',
               label: '28-35 г/л (>2.8-3.5 г/дл)',
               value: '2',
            },
            {
               id: '3',
               label: '<28 г/л (<2.8 г/дл)',
               value: '3',
            }
         ],
      },
      {
         type: 'radio',
         label: 'Международное нормализованное отношение',
         inputId: 'inr',
         required: 'yes',
         numeric: 'yes',
         radioButtons: [
            {
               id: '1',
               label: '<1.7',
               value: '1',
            },
            {
               id: '2',
               label: '1.7-2.3',
               value: '2',
            },
            {
               id: '3',
               label: '>2.3',
               value: '3',
            }
         ],
      },
      {
         type: 'radio',
         label: 'Асцит',
         inputId: 'ascites',
         required: 'yes',
         numeric: 'yes',
         radioButtons: [
            {
               id: '1',
               label: 'Отсутствует',
               value: '1',
            },
            {
               id: '2',
               label: 'Незначительный',
               value: '2',
            },
            {
               id: '3',
               label: 'Умеренный',
               value: '3',
            }
         ],
      },
      {
         type: 'radio',
         label: 'Энцефалопатия',
         inputId: 'enceph',
         required: 'yes',
         numeric: 'yes',
         radioButtons: [
            {
               id: '1',
               label: 'Отсутствует',
               value: '1',
            },
            {
               id: '2',
               label: 'Степень 1 (тревожность, нарушение сна, раздражительность/возбуждение, тремор, нарушение почерка, волны 5 циклов в секунду) или степень 2 (летаргия, дезориентация во времени, неадекватность, астериксис, атаксия, медленные трехфазные волны)',
               value: '2',
            },
            {
               id: '3',
               label: 'Степень 3 (сонливость, ступор, дезориентация, гиперактивные рефлексы, ригидность, медленные волны) или степень 4 (терминальная кома, отсутствие личности/поведения, децеребрация, медленная дельта-активность 2-3 цикла в секунду)',
               value: '3',
            }
         ],
      },
   ],
   refers: [
      "Child CG, Turcotte JG. Surgery and portal hypertension. In: The liver and portal hypertension. Edited by CG Child. Philadelphia: Saunders 1964:50-64.",
      "Pugh RN, Murray-Lyon IM, Dawson JL, Pietroni MC, Williams R (1973). Transection of the oesophagus for bleeding oesophageal varices. The British journal of surgery 60 (8).",
   ]
}