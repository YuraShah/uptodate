export const smokingIndexCalc = {
   id: "EV-CALC-05",
   link: "smokingindex",
   title: "Калькулятор индекса курения",
   text: "Калькулятор индекса курения",
   description: {
      descriptionMain: [
         "Если индекс курения превышает 10, это является фактором риска развития хронической обструктивной болезни легких.",
         "Хроническая обструктивная болезнь легких (ХОБЛ) — это заболевание, при котором наблюдается частичное ограничение воздушного потока в дыхательных путях. Это препятствует нормальному дыханию. Ранее назывался хроническим бронхитом и эмфиземой, сейчас эти термины больше не используются.",
         [
            "Несколько фактов о ХОБЛ:",
            "Ежегодно от ХОБЛ умирают 3 миллиона человек, что составляет 6% всех случаев смерти в мире.",
            "Более 90% случаев смерти от ХОБЛ происходит в странах со средним и низким уровнем дохода.",
            "Основной причиной ХОБЛ является табачный дым (в результате курения сигарет или вдыхания вторичного дыма [вдыхания сигаретного дыма других людей]).",
            "В настоящее время ХОБЛ поражает мужчин и женщин в равной степени, поскольку женщины в странах с высоким уровнем дохода чаще употребляют табак.",
            "ХОБЛ неизлечима, но лечение может замедлить прогрессирование заболевания.",
         ]
      ]
   },
   form: [
      {
         type: 'input',
         label: 'Количество',
         inputId: 'quantity',
         placeholder: '',
         error: 'Поле должно быть в диапазоне 0 - 999',
         span: 'сигарет в день',
         min: 0,
         max: 999,
         required: 'yes',
         pattern: "dot",
         ext: 0,
         spanWidth: 200
      },
      {
         type: 'input',
         label: 'Стаж курения',
         inputId: 'years',
         placeholder: '',
         error: 'Стаж курения должен быть в диапазоне 0 - 99',
         span: 'лет',
         min: 0,
         max: 99,
         required: 'yes',
         pattern: "dot",
         ext: 0,
         spanWidth: 80
      },
   ],
   refers: [
      "Xin Feng, Zenghui Qian, Baorui Zhang, Erkang Guo, Luyao Wang, Peng Liu, Xiaolong Wen, Wenjuan Xu, Chuhan Jiang, Youxiang Li, Zhongxue Wu, and Aihua Liu. Number of Cigarettes Smoked Per Day, Smoking Index, and Intracranial Aneurysm Rupture: A Case-Control Study. doi: 10.3389/fneur.2018.00380",
      "Douglas E. Wood MD, Ella A. Kazerooni MD, Scott L. Baum MD, George A. Eapen MD, David S. Ettinger MD, Lifang Hou MD, PhD, David M. Jackman MD, Donald Klippenstein MD, Rohit Kumar MD, Rudy P. Lackner MD, Lorriana E. Leard MD, Inga T. Lennes MD, MPH, MBA, Ann N.C. Leung MD, Samir S. Makani MD, Pierre P. Massion MD. Lung Cancer Screening, Version 3.2018, NCCN Clinical Practice Guidelines in Oncology. DOI: 10.6004/jnccn.2018.0020",
      "Screening for Lung Cancer: Recommendation Statement. Am Fam Physician. 2014;90(2):116A-116D",
   ]
}