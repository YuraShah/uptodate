export const gcsMineralCalc = {
   id: "EV-CALC-02",
   link: "csconverter-mineral",
   title: "Конвертация кортикостероидов (минералокортикоидный эффект)",
   text: "Расчет эквивалентных доз кортикостероидов (минералокортикоидный эффект)",
   description: {
      descriptionMain: [
         "Калькулятор позволяет рассчитать эквивалентные дозы минералокортикоидного эффекта наиболее часто используемых кортикостероидов. Важно помнить о длительности действия кортикостероидов: препараты с длительным периодом полувыведения принимаются реже. Основной принцип лечения — достижение максимального терапевтического эффекта минимальными дозами. Минералокортикоидный эффект отвечает за задержку натрия и выведение калия/водорода. В терапевтическом плане этот эффект часто используется для увеличения объема плазмы.",
         "Эквивалентные дозы применимы только для перорального или внутривенного введения."
      ],
      descriptionTable: [
         {
            headData: ['Лекартсво', 'Способ введения', 'Эквивалентная доза, мг', 'Минералокортикоидный эффект', 'Длительность эффекта, ч'],
            bodyData: [
               ['Кортизон', 'пероральный (per os)', '25', '0.8', '8-12'],
               ['Гидрокортизон', 'пероральный (per os) или внутривенный', '20', '1', '8-12'],
               ['Дексаметазон', 'пероральный (per os) или внутривенный', '0.75', '0', '36-72'],
               ['Бетаметазон', 'внутривенный', '0.6', '0', '36-72'],
               ['Преднизон', 'пероральный (per os)', '5', '0.6', '12-36'],
               ['Преднизолон', 'пероральный (per os)', '5', '0.6', '12-36'],
               ['Метилпреднизолон', 'пероральный (per os) или внутривенный', '4', '0.25', '8-12'],
               ['Триамцинолон', 'внутривенный', '4', '0', '12-36'],
            ],
            widthNums: [150, 150, 150, 150, 150],
         }
      ]
   },
   form: [
      {
         type: 'select',
         label: 'От дозы препарата',
         inputId: 'firstGcs',
         required: 'yes',
         items: [
            { value: 'hydrocortisone', label: 'Гидрокортизон' },
            { value: 'prednisone', label: 'Преднизон' },
            { value: 'prednisolone', label: 'Преднизолон' },
         ]
      },
      {
         type: 'input',
         label: 'Доза',
         inputId: 'dose',
         placeholder: '',
         error: 'Доза должна быть числом и больше 0',
         span: 'мг',
         min: 0.00001,
         max: 100000,
         required: 'yes',
         pattern: "dot",
         ext: 0
      },
      {
         type: 'select',
         label: 'В дозу препарата',
         inputId: 'secondGcs',
         required: 'yes',
         items: [
            { value: 'hydrocortisone', label: 'Гидрокортизон' },
            { value: 'prednisone', label: 'Преднизон' },
            { value: 'prednisolone', label: 'Преднизолон' },
         ]
      },
   ],
   refers: [
      "Liu D, Ahmet A, Ward L, et al. A practical guide to the monitoring and management of the complications of systemic corticosteroid therapy. Allergy Asthma Clin Immunol. 2013 Aug 15;9(1):30.",
      "Schimmer BP, Funder J. ACTH, Adrenal Steroids, and the Adrenal Cortex. In: Brunton LL, Hilal-Dandan R, Knollmann BC, eds. Goodman & Gilman's: The Pharmacological Basis of Therapeutics. 13th ed. New York, NY: McGraw-Hill Education; 2017."
   ]
}