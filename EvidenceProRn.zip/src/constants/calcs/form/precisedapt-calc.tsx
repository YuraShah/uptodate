export const preciseDaptCalc = {
   id: "EV-CALC-24",
   link: "precisedapt",
   title: "Шкала PRECISE-DAPT",
   text: "Оценка риска антиагрегантной терапии при коронарном стентировании",
   description: {
      descriptionMain: [
         "Применяется для расчета риска геморрагических осложнений с целью определения длительности двойной антиагрегантной терапии у пациентов, перенесших чрескожное коронарное вмешательство. Шкала PRECISE-DAPT была рекомендована в 2017 году Европейским обществом кардиологов. Шкала позволяет выявить пациентов с высоким риском кровотечения в течение 12 месяцев и сократить длительность двойной антиагрегантной терапии до 3 - 6 месяцев.",
      ]
   },
   form: [
      {
         type: 'input',
         label: 'Гемоглобин',
         inputId: 'hgb',
         placeholder1: '10 - 300',
         placeholder: '1 - 30',
         error1: 'Гемоглобин должен быть в диапазоне 10 - 300',
         error: 'Гемоглобин должен быть в диапазоне 1 - 30',
         span1: 'г/л',
         span: 'г/дл',
         min1: 10,
         min: 1,
         max1: 300,
         max: 30,
         required: 'yes',
         pattern: "dot",
         ext: 1,
         spanWidth: 55
      },
      {
         type: 'input',
         label: 'Лейкоциты',
         inputId: 'wbc',
         placeholder: '0 - 90',
         error: 'Лейкоциты должны быть в диапазоне >0 - 90',
         span: '10⁹/л',
         min: 0,
         max: 90,
         required: 'yes',
         pattern: "dot",
         ext: 0,
         spanWidth: 115
      },
      {
         type: 'input',
         label: 'Возраст',
         inputId: 'age',
         placeholder: '1 - 100',
         error: 'Возраст должен быть 1-100',
         span: 'лет',
         min: 1,
         max: 100,
         required: 'yes',
         pattern: "nodot",
         ext: 0,
         spanWidth: 115
      },
      {
         type: 'input',
         label: 'Клиренс креатинина',
         inputId: 'creat',
         placeholder: '0 - 200',
         error: 'Клиренс креатинина должен быть в диапазоне 0 - 200',
         span: 'мл/мин',
         min: 0,
         max: 200,
         required: 'yes',
         pattern: "dot",
         ext: 0,
         spanWidth: 115
      },
      {
         type: 'radio',
         radioButtons: [
            {
               id: '26',
               label: 'Да',
               value: '26',
            },
            {
               id: '0',
               label: 'Нет',
               value: '0',
            }
         ],
         label: 'Ранее перенесённые кровотечения',
         inputId: 'blood',
         required: 'yes',
         numeric: 'no',
      }
   ],
   refers: [
      "Costa, F., van Klaveren, D., James, S., Heg, D., Räber, L., Feres, F., Valgimigli, M. (2017). Derivation and validation of the predicting bleeding complications in patients undergoing stent implantation and subsequent dual antiplatelet therapy (PRECISE-DAPT) score: a pooled analysis of individual-patient datasets from clinical trials. The Lancet, 389(10073), 1025-1034."
   ]
}