export const score2DiabCalc = {
   id: "EV-CALC-17",
   link: "score2-diabetes",
   title: "Шкала SCORE2-Diabetes",
   text: "10-летний риск сердечно-сосудистых событий у пациентов с сахарным диабетом 2 типа",
   description: {
      descriptionMain: [
         "SCORE2-Diabetes: прогнозирует 10-летний риск сердечно-сосудистых событий у пациентов с сахарным диабетом 2 типа. Используйте эту оценку для прогнозирования 10-летнего риска сердечно-сосудистых событий у европейских пациентов в возрасте до 70 лет, у которых ранее не было сердечно-сосудистых заболеваний, но был диабет.",
         [
            "Регионы риска сердечно-сосудистых заболеваний по данным ВОЗ",
            "Низкий риск: Бельгия, Дания, Франция, Израиль, Люксембург, Норвегия, Испания, Швейцария, Нидерланды, Великобритания",
            "Средний риск: Австрия, Кипр, Финляндия, Германия, Греция, Исландия, Ирландия, Италия, Мальта, Португалия, Сан-Марино, Словения, Швеция",
            "Высокий риск: Албания, Босния и Герцеговина, Хорватия, Чешская Республика, Эстония, Венгрия, Казахстан, Польша, Словакия, Турция",
            "Очень высокий риск: Армения, Алжир, Беларусь, Болгария, Грузия, Киргизия, Азербайджан, Египет, Латвия, Литва, Ливан, Ливия, Черногория, Марокко, Молдова, Румыния, Россия, Сербия, Сирия, Македония, Тунис, Украина, Узбекистан"
         ]
      ],
      descriptionTable: [
         {
            headData: ['', '<50 лет', '50-69 лет', '≥70 лет'],
            bodyData: [
               ['Низкий риск', '<2.5%', '<5%', '<7.5%'],
               ['Средний риск', '2.5% - <7.5%', '5% - <10%', '7.5% - <15%'],
               ['Высокий риск', '≥7.5%', '≥10%', '≥15%'],
            ],
            flexNums: [1, 1, 1, 1]
         }
      ]
   },
   form: [
      {
         type: 'custom',
         text: 'Поскольку Россия расположена в регионе очень высокого риска, выберите очень высокий риск.\nПримечание: исследование проводилось на европейских пациентах.',
      },
      {
         type: 'select',
         label: 'Риск по географическому региону',
         inputId: 'riskRegion',
         required: 'yes',
         items: [
            { value: "low", label: 'Низкий' },
            { value: "moderate", label: 'Средний' },
            { value: "high", label: 'Высокий' },
            { value: "very high", label: 'Очень высокий' },
         ]
      },
      {
         type: 'radio',
         radioButtons: [
            {
               id: '1',
               label: 'Мужчина',
               value: '1',
            },
            {
               id: '2',
               label: 'Женщина',
               value: '2',
            }
         ],
         label: 'Пол',
         inputId: 'gender',
         required: 'yes',
         numeric: 'no',
      },
      {
         type: 'radio',
         radioButtons: [
            {
               id: '0',
               label: 'Нет',
               value: '0',
            },
            {
               id: '1',
               label: 'Да',
               value: '1',
            }
         ],
         label: 'Курение',
         inputId: 'smoking',
         required: 'yes',
         numeric: 'no',
      },
      {
         type: 'input',
         label: 'Возраст',
         inputId: 'age',
         placeholder: '40 - 100',
         error: 'Возраст должен быть в диапазоне 40-100',
         span: 'лет',
         min: 40,
         max: 100,
         required: 'yes',
         pattern: "nodot",
         ext: 0,
         spanWidth: 115
      },
      {
         type: 'input',
         label: 'Систолическое артериальное давление',
         inputId: 'sbp',
         placeholder: '60 - 250',
         error: 'Систолическое АД должен быть в диапазоне 60-250',
         span: 'мм рт. ст.',
         min: 60,
         max: 250,
         required: 'yes',
         pattern: "dot",
         ext: 0,
         spanWidth: 115
      },
      {
         type: 'input',
         label: 'Общий холестерин',
         inputId: 'tchol',
         placeholder1: '3 - 9',
         placeholder: '116 - 348',
         error1: 'Общий холестерин должен быть в диапазоне 3-9',
         error: 'Общий холестерин должен быть в диапазоне 116-348',
         span1: 'ммоль/л',
         span: 'мг/дл',
         min1: 3,
         min: 116,
         max1: 9,
         max: 348,
         required: 'yes',
         pattern: "dot",
         ext: 1
      },
      {
         type: 'input',
         label: 'Холестерин высокой плотности',
         inputId: 'hdlchol',
         placeholder1: '0.7 - 2.5',
         placeholder: '20 - 100',
         error1: 'Холестерин высокой плотности должен быть в диапазоне 0.7-2.5',
         error: 'Холестерин высокой плотности должен быть в диапазоне 20-100',
         span1: 'ммоль/л',
         span: 'мг/дл',
         min1: 0.7,
         min: 2.5,
         max1: 20,
         max: 100,
         required: 'yes',
         pattern: "dot",
         ext: 1
      },
      {
         type: 'input',
         label: 'Возраст при постановке диагноза диабета',
         inputId: 'agediab',
         placeholder: '1 - 69',
         error: 'Поле должно быть в диапазоне 1-69',
         span: 'лет',
         min: 1,
         max: 69,
         required: 'yes',
         pattern: "nodot",
         ext: 0,
         spanWidth: 115
      },
      {
         type: 'input',
         label: 'HbA1c (гликированный гемоглобин)',
         inputId: 'hba1c',
         placeholder: '1 - 20',
         error: 'HbA1c должен быть в диапазоне 1-20',
         span: '%',
         min: 1,
         max: 20,
         required: 'yes',
         pattern: "dot",
         ext: 0,
         spanWidth: 115
      },
      {
         type: 'title',
         formTitle: '➪ eGFR',
         link: 'calcs/egfr-ckd-epi',
      },
      {
         type: 'input',
         label: 'eGFR (расчетная скорость клубочковой фильтрации)',
         inputId: 'egfr',
         placeholder: '1 - 160',
         error: 'eGFR должен быть в диапазоне 1-160',
         span: 'мл/мин/1,73 м²',
         min: 1,
         max: 160,
         required: 'yes',
         pattern: "dot",
         ext: 0,
         spanWidth: 180
      },
   ],
   refers: [
      "2021 ESC Guidelines on cardio prevention in clinical practice. European Heart Journal (2021) 00, 1111 doi:10.1093/eurheartj/ehab484",
      "SCORE2-OP risk prediction algorithms: estimating incident cardiovascular event risk in older persons in four geographical risk regions. European Heart Journal (2021) 00, 1-13 doi:10.1093/eurheartj/ehab312",
      "SCORE2 risk prediction algorithms: new models to estimate 10-year risk of cardiovascular disease in Europe. European Heart Journal, Volume 42, Issue 25, 1 July 2021, Pages 2439-2454, https://doi.org/10.1093/eurheartj/ehab309",
   ]
}