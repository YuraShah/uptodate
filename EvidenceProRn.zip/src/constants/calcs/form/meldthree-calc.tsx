export const meldThreeCalc = {
   id: "EV-CALC-59",
   link: "meld-score-na",
   title: "Шкала MELD 3.0 (OPTN)",
   text: "Помогает определить прогноз и приоритетность трансплантации печени",
   description: {
      descriptionMain: [
         "Шкала MELD 3.0 помогает определить прогноз и приоритетность трансплантации печени. Результаты не должны быть старше 48 часов. MELD можно применять у любого пациента с терминальной стадией заболевания печени, независимо от этиологии цирроза. Хотя математически возможно получить оценку MELD >40, OPTN (Сеть по закупке и трансплантации органов) принимает максимальную оценку 40 для трансплантации печени. В июне 2022 года OPTN обновила предложенную модель MELD до MELD 3.0.",
      ],
      descriptionTable: [
         {
            headData: ['Балл', 'Смертность'],
            bodyData: [
               ['≤9', '1.9%'],
               ['10-19', '6.0%'],
               ['20-29', '19.6%'],
               ['30-39', '52.6%'],
               ['≥40', '71.3%'],
            ],
            flexNums: [1, 1]
         }
      ]
   },
   form: [
      {
         type: 'radio',
         radioButtons: [
            {
               id: '0',
               label: '<18 лет',
               value: '0',
            },
            {
               id: '1',
               label: '≥18 лет',
               value: '1',
            }
         ],
         label: 'Возраст',
         inputId: 'age',
         required: 'yes',
         numeric: 'no',
      },
      {
         type: 'radio',
         radioButtons: [
            {
               id: '0',
               label: 'Женский',
               value: '0',
            },
            {
               id: '1',
               label: 'Мужской',
               value: '1',
            }
         ],
         label: 'Пол',
         inputId: 'gender',
         required: 'yes',
         numeric: 'no',
      },
      {
         type: 'radio',
         radioButtons: [
            {
               id: '0',
               label: 'Нет',
               value: '0',
            },
            {
               id: '1',
               label: 'Да',
               value: '1',
            }
         ],
         label: 'Не менее 2 сеансов диализа за последнюю неделю или ≥24 часов непрерывного вено-венозного гемодиализа за последнюю неделю перед анализом креатинина плазмы',
         inputId: 'dialysis',
         required: 'yes',
         numeric: 'no',
      },
      {
         type: 'input',
         label: 'Креатинин',
         inputId: 'creatinine',
         placeholder1: '1 - 850',
         placeholder: '0.01 - 10',
         error1: 'Креатинин должен быть в диапазоне 1 - 850',
         error: 'Креатинин должен быть 0.01 - 10',
         span1: 'ммоль/л',
         span: 'мг/дл',
         min1: 1,
         min: 0.01,
         max1: 850,
         max: 10,
         required: 'yes',
         pattern: "dot",
         ext: 1,
         spanWidth: 55,
         extIndex: 0
      },
      {
         type: 'input',
         label: 'Билирубин',
         inputId: 'bilirubin',
         placeholder1: '0.01 - 340',
         placeholder: '0.01 - 20',
         error1: 'Билирубин должен быть в диапазоне 0.01 - 340',
         error: 'Билирубин должен быть в диапазоне 0.01 - 20',
         span1: 'ммоль/л',
         span: 'мг/дл',
         min1: 0.01,
         min: 0.01,
         max1: 340,
         max: 20,
         required: 'yes',
         pattern: "dot",
         ext: 1,
         spanWidth: 55,
         extIndex: 0
      },
      {
         type: 'input',
         label: 'Международное нормализованное отношение',
         inputId: 'inr',
         placeholder: '0.5 - 10',
         error: 'Это поле должно быть в диапазоне 0.5 - 10',
         span: 'единиц',
         min: 0.5,
         max: 10,
         required: 'yes',
         pattern: "dot",
         ext: 0,
         spanWidth: 115
      },
      {
         type: 'input',
         label: 'Натрий',
         inputId: 'sodium',
         placeholder1: '100 - 170',
         placeholder: '100 - 170',
         error1: 'Натрий должен быть в диапазоне 100 - 170',
         error: 'Натрий должен быть в диапазоне 100 - 170',
         span1: 'ммоль/л',
         span: 'мэкв/л',
         min1: 100,
         min: 100,
         max1: 170,
         max: 170,
         required: 'yes',
         pattern: "dot",
         ext: 1,
         spanWidth: 55,
         extIndex: 1
      },
      {
         type: 'input',
         label: 'Альбумин',
         inputId: 'albumin',
         placeholder: '0.01 - 6',
         placeholder1: '10 - 60',
         error: 'Альбумин должен быть в диапазоне 0.01 - 6',
         error1: 'Альбумин должен быть в диапазоне 10 - 60',
         span: 'г/дл',
         span1: 'г/л',
         min: 0.01,
         min1: 10,
         max: 6,
         max1: 60,
         required: 'yes',
         pattern: "dot",
         ext: 1,
         spanWidth: 55,
         extIndex: 2
      },
   ],
   refers: [
      "Kamath PS, Wiesner RH, Malinchoc M, Kremers W, Therneau TM, Kosberg CL, D'Amico G, Dickson ER, Kim WR. A model to predict survival in patients with end-stage liver disease. Hepatology. 2001 Feb;33(2):464-70.",
      "Kim WR, Mannalithara A, Heimbach JK, et al. Meld 3. 0: the model for end-stage liver disease updated for the modern era. Gastroenterology. 2021;161(6):1887-1895.e4.",
      "Wiesner R, United Network for Organ Sharing Liver Disease Severity Score Committee, et al. Model for end-stage liver disease (MELD) and allocation of donor livers.Gastroenterology. 2003 Jan;124(1):91-6.",
      "Kremers WK, van IJperen M, Kim WR, Freeman RB, Harper AM, Kamath PS, Wiesner RH. MELD score as a predictor of pretransplant and posttransplant survival in OPTN/UNOS status 1 patients.Hepatology. 2004 Mar;39(3):764-9.",
      "Kamath PS, Kim WR; Advanced Liver Disease Study Group. The model for end-stage liver disease (MELD). Hepatology. 2007 Mar;45(3):797-805.",
      "OPTN 2016 MELD Policy Changes",
      "Freeman RB Jr, Gish RG, Harper A, Davis GL, Vierling J, Lieblein L, Klintmalm G, Blazek J, Hunter R, Punch J. Model for end-stage liver disease (MELD) exception guidelines: results and recommendations from the MELD Exception Study Group and Conference (MESSAGE) for the approval of patients who need liver transplantation with diseases not considered by the standard MELD formula.Liver Transpl. 2006;12(12 Suppl 3):S128.",
      "Trivedi HD. The evolution of the meld score and its implications in liver transplant allocation: a beginner’s guide for trainees. ACG Case Rep J. 2022;9(5):e00763.",
   ]
}