export const acetamToxCalc = {
   id: "EV-CALC-50",
   link: "acetaminophen-toxicity-assessment",
   title: "Калькулятор оценки токсичности парацетамола",
   text: "Калькулятор оценки токсичности парацетамола",
   description: {
      descriptionMain: [
         "Этот калькулятор основан на данных, полученных по номограмме Рамака-Мэтью (Rumack-Matthew). Предназначен только для пациентов, принявших однократную дозу парацетамола перорально. Уровни препарата, определенные ранее, чем через 4 часа, могут не отражать истинный пик абсорбции.",
      ],
      descriptionLink: [
         {
            "name": "Калькулятор дозировки N-ацетилцистеина при передозировке парацетамола",
            "link": 'calcs/acetaminophen-overdose-nac-dosing',
         }
      ]
   },
   form: [
      {
         type: 'input',
         label: 'Прошло часов с момента поступления',
         inputId: 'hour',
         placeholder: '4-24',
         error: 'Часы должен быть от 4 до 24.',
         span: 'час',
         min: 4,
         max: 24,
         required: 'yes',
         pattern: "dot",
         ext: 0,
         spanWidth: 60
      },
      {
         type: 'input',
         label: 'Уровень парацетамола',
         inputId: 'point',
         placeholder: '',
         placeholder1: '',
         error: 'Поле обязательно и должно быть числом',
         error1: 'Поле обязательно и должно быть числом',
         span: 'мкмоль/л',
         span1: 'мг/л',
         min: 0.000001,
         min1: 0.000001,
         max: 100000,
         max1: 100000,
         required: 'yes',
         pattern: "dot",
         ext: 1
      },
   ],
   refers: [
      "Rumack BH, Matthew H. Acetaminophen poisoning and toxicity. Pediatrics. 1975 Jun;55(6):871-6.",
      "White SJ, Rumack BH. The acetaminophen toxicity equations: solutions for acetaminophen toxicity based on the Rumack-Matthew nomogram. Ann Emerg Med. 2005 May;45(5):563-4.",
      "Buckley NA, Whyte IM, O'Connell DL, et al. Activated charcoal reduces the need for N-acetylcysteine treatment after acetaminophen (paracetamol) overdose. J Toxicol Clin Toxicol. 1999;37(6):753-7.",
      "Vale JA, Proudfoot AT. Paracetamol (acetaminophen) poisoning. Lancet. 1995 Aug 26;346(8974):547-52.",
   ]
}