export const intravenousCalc = {
   id: "EV-CALC-03",
   link: "volumespeed",
   title: "Калькулятор скорости внутривенной инфузии",
   text: "Калькулятор скорости внутривенного капельного введения",
   description: {
      descriptionMain: [
         "Этот калькулятор предназначен для точного расчета скорости внутривенного введения лекарств."
      ]
   },
   form: [
      {
         type: 'input',
         label: 'Объем раствора',
         inputId: 'volume',
         placeholder: '',
         error: 'Объем раствора должен быть в диапазоне 0.01 - 1000',
         span: 'мл',
         min: 0.01,
         max: 1000,
         required: 'yes',
         pattern: "dot",
         ext: 0
      },
      {
         type: 'input',
         label: 'Время введения',
         inputId: 'time',
         placeholder: '',
         error: 'Время введения должен быть в диапазоне 1 - 3000',
         error1: 'Время введения должен быть в диапазоне 0.01 - 50',
         span: 'минут',
         span1: 'часов',
         min: 1,
         min1: 0.01,
         max: 3000,
         max1: 50,
         required: 'yes',
         pattern: "dot",
         ext: 1
      },
   ],
   refers: [
      "Evidence",
   ]
}