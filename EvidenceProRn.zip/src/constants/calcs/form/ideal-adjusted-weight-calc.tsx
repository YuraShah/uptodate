export const idealAdjustedWeightCalc = {
   id: "EV-CALC-10",
   link: "ideal-adjusted-weight",
   title: "Калькулятор идеального и скорректированного веса тела",
   text: "Калькулятор идеального и скорректированного веса тела",
   description: {
      descriptionMain: [
         "Идеальный и скорректированный вес тела часто используются в клинических целях для корректировки доз лекарственных препаратов у пациентов с патологическим ожирением, оценки функции почек и оценки фармакокинетики. Скорректированный вес тела также используется диетологами для расчета потребностей в питании."
      ],
      descriptionImage: [
         {
            image: require('@/assets/images/calcs/ideal-weight-chart.png'),
            imageSup: 'Для роста <152 см рекомендуется использовать таблицу ниже'
         }
      ]
   },
   form: [
      {
         type: 'radio',
         radioButtons: [
            {
               id: '1',
               label: 'Мужской',
               value: 'male',
            },
            {
               id: '2',
               label: 'Женский',
               value: 'female',
            }
         ],
         label: 'Пол',
         inputId: 'gender',
         required: 'yes',
         numeric: 'no',
      },
      {
         type: 'input',
         label: 'Рост',
         inputId: 'height',
         placeholder: '102 - 203',
         error: 'Рост должен быть в диапазоне 102 - 203',
         span: 'см',
         min: 102,
         max: 203,
         required: 'yes',
         pattern: "dot",
         ext: 0
      },
      {
         type: 'input',
         label: 'Фактическая масса тела (необязательно, необходимо для расчета скорректированной массы тела)',
         inputId: 'weight',
         placeholder: '1 - 225',
         error: 'Вес должен быть в диапазоне 1-225',
         span: 'кг',
         min: 1,
         max: 225,
         required: 'no',
         pattern: "dot",
         ext: 0
      },
   ],
   refers: [
      "Pai MP, Paloucek FP. The origin of the 'ideal' body weight equations. Ann Pharmacother. 2000;34(9):1066-9. PMID 10981254",
      "Bauer LA. Applied clinical pharmacokinetics. New York: McGraw Hill, Medical Publishing Division; 2001:93-179",
      "Winter, M.E., 2004. Basic pharmacokinetics. London: Lippincott Williams and Williams",
      "Murphy JE. Introduction. In: Murphy JE, ed. Clinical Pharmacokinetics, 5th ed. Bethesda, MD: American Society of Health-System Pharmacists, 2011",
   ]
}