export const centorCalc = {
   id: "EV-CALC-44",
   link: "centor",
   title: "Калькулятор шкалы Centor (модифицированный/McIsaac)",
   text: "Оценивает вероятность стрептококкового фарингита",
   description: {
      descriptionMain: [
         "Большинство фарингитов имеют вирусную природу. Шкала Centor помогает отличить бактериальный тонзиллофарингит («ангину») от вирусного тонзиллофарингита и определить, каких пациентов следует обследовать в первую очередь."
      ],
      descriptionTable: [{
         headData: ['Centor баллы', 'Вероятность стрептококковой ангины', 'Рекомендации'],
         bodyData: [
            ['0 или 1', '1-2.5% или 5-10%', 'Никаких дополнительных анализов или антибиотиков не требуется'],
            ['2', '11-17%', 'Селективное экспресс-тестирование и/или посев на стрептококки'],
            ['3', '28-35%', 'Рассмотрите возможность экспресс-тестирования и/или посева'],
            ['≥4', '51-53%', 'Рассмотрите возможность экспресс-тестирования и/или посева. В зависимости от конкретного случая может быть целесообразной эмпирическая антибактериальная терапия'],
         ],
         widthNums: [150, 150, 300]
      }],
   },
   form: [
      {
         type: 'radio',
         radioButtons: [
            {
               id: '1',
               label: '3-14 лет',
               value: '1',
            },
            {
               id: '0',
               label: '15-44 лет',
               value: '0',
            },
            {
               id: '-1',
               label: '≥45 лет',
               value: '-1',
            }
         ],
         label: 'Возраст (стрептококк группы А редко встречается у детей до 3 лет)',
         inputId: 'age',
         required: 'yes',
         numeric: 'yes',
      },
      {
         type: 'radio',
         radioButtons: [
            {
               id: '0',
               label: 'Нет',
               value: '0',
            },
            {
               id: '1',
               label: 'Да',
               value: '1',
            }
         ],
         label: 'Отекшие миндалины или наличие налета на миндалинах',
         inputId: 'tonsil',
         required: 'yes',
         numeric: 'yes',
      },
      {
         type: 'radio',
         radioButtons: [
            {
               id: '0',
               label: 'Нет',
               value: '0',
            },
            {
               id: '1',
               label: 'Да',
               value: '1',
            }
         ],
         label: 'Отекшие/болезненные передние шейные лимфатические узлы',
         inputId: 'lymph',
         required: 'yes',
         numeric: 'yes',
      },
      {
         type: 'radio',
         radioButtons: [
            {
               id: '0',
               label: 'Нет',
               value: '0',
            },
            {
               id: '1',
               label: 'Да',
               value: '1',
            }
         ],
         label: 'Лихорадка >38°C (100.4°F)',
         inputId: 'temp',
         required: 'yes',
         numeric: 'yes',
      },
      {
         type: 'radio',
         radioButtons: [
            {
               id: '0',
               label: 'Есть',
               value: '0',
            },
            {
               id: '1',
               label: 'Отсутствует',
               value: '1',
            }
         ],
         label: 'Кашель',
         inputId: 'cough',
         required: 'yes',
         numeric: 'yes',
      }
   ],
   refers: [
      "Centor RM, Witherspoon JM, Dalton HP, Brody CE, Link K. The diagnosis of strep throat in adults in the emergency room. Med Decis Making. 1981;1(3):239-46",
      "McIsaac WJ, White D, Tannenbaum D, Low DE. A clinical score to reduce unnecessary antibiotic use in patients with sore throat. CMAJ. 1998 Jan 13;158(1):75-83. PubMed PMID: 9475915; PubMed Central PMCID: PMC1228750",
      "McIsaac WJ, Kellner JD, Aufricht P, Vanjaka A, Low DE. Empirical Validation of Guidelines for the Management of Pharyngitis in Children and Adults. JAMA.2004;291(13):1587-1595",
      "Fine AM, Nizet V, Mandl KD. Large-Scale Validation of the Centor and McIsaac Scores to Predict Group A Streptococcal Pharyngitis. Archives of internal medicine 2012;172(11):847-852",
      "Mitchell MS, Sorrentino A, Centor RM. Adolescent pharyngitis: a review of bacterial causes. Clin Pediatr (Phila). 2011;50(12):1091-5",
      "Shulman ST, et. al. Clinical Practice Guideline for the Diagnosis and Management of Group A Streptococcal Pharyngitis: 2012 Update by the Infectious Diseases Society of America. Clin Infect Dis. 2012 Nov 15;55(10):1279-82",
      "Harris AM, Hicks LA, Qaseem A, for the High Value Care Task Force of the American College of Physicians and for the Centers for Disease Control and Prevention. Appropriate Antibiotic Use for Acute Respiratory Tract Infection in Adults: Advice for High-Value Care From the American College of Physicians and the Centers for Disease Control and Prevention. Ann Intern Med. 2016 Jan 19",
      "Kalra MG, Higgins KE, Perez ED. Common Questions About Streptococcal Pharyngitis. Am Fam Physician. 2016;94(1):24-31",
   ]
}