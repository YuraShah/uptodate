export const dentTAMaxCalc = {
   id: "EV-CALC-43",
   link: "dent-ta-max",
   title: "Калькулятор максимальных доз местных анестетиков, используемых в стоматологии",
   text: "Калькулятор максимальных доз местных анестетиков, используемых в стоматологии",
   description: {
      descriptionMain: [
         "Этот калькулятор применим для пациентов в возрасте 18 лет и старше. Помогает рассчитать максимально допустимую дозу данного анестетика и максимальное количество карпул."
      ]
   },
   form: [
      {
         type: 'select',
         label: 'Местный анестетик',
         inputId: 'locan',
         required: 'yes',
         items: [
            { value: 'Убистезин 1,7 мл', label: 'Убистезин 1,7 мл (артикаин 4%/эпинефрин 1:200,000)' },
            { value: 'Убистезин Форте 1,7 мл', label: 'Убистезин Форте 1,7 мл (артикаин 4%/эпинефрин 1:100,000)' },
            { value: 'Септанест 1:100,000 1,7 мл', label: 'Септанест 1:100,000 1,7 мл (артикаин 4%/эпинефрин 1:100,000)' },
            { value: 'Септанест 1:200,000 1,7 мл', label: 'Септанест 1:200,000 1,7 мл (артикаин 4%/эпинефрин 1:200,000)' },
            { value: 'Ораблок 1,8 мл', label: 'Ораблок 1,8 мл (артикаин 4%/эпинефрин 1:100,000)' },
            { value: 'Артинибса 1,8 мл', label: 'Артинибса 1,8 мл (артикаин 4%/эпинефрин 1:100,000)' },
            { value: 'Лигноспан 1,8 мл', label: 'Лигноспан 1,8 мл (Лидокаин 2%/эпинефрин 1:80,000)' },
            { value: 'Лигноспан стандарт 1,7 мл', label: 'Лигноспан стандарт 1,7 мл (Лидокаин 2%/эпинефрин 1:100,000)' },
            { value: 'Ксилестезин-А 1,7 мл', label: 'Ксилестезин-А 1,7 мл (Лидокаин 2%/эпинефрин 1:100,000)' },
            { value: 'Лидокаин', label: 'Лидокаин 2 мл (Лидокаин 2%)' },
            { value: 'Скандонест 1,8 мл', label: 'Скандонест 1,8 мл (мепивакаин 3%)' },
            { value: 'Мепивастезин 1,8 мл', label: 'Мепивастезин 1,8 мл (мепивакаин 3%)' },
         ]
      },
      {
         type: 'input',
         label: 'Вес',
         inputId: 'weight',
         placeholder: '1 - 200',
         error: 'Вес должен быть 1 - 200',
         span: 'кг',
         min: 1,
         max: 200,
         required: 'yes',
         pattern: "dot",
         ext: 0
      },
   ],
   refers: [
      "Derek Decloux, Aviv Ouanounou. Local Anaesthesia in Dentistry: A Review. International Dental Journal 71(2) September 2020",
      "Richard L Finder, Paul A Moore. Adverse drug reactions to local anesthesia. Dental Clinics of North America 46(4):747-57 November 2002",
      "Malamed S. Handbook of Local Anesthesia. 6th ed. St. Louis: Elsevier Mosby; 2013",
      "Malamed S. Handbook of Local Anesthesia. 5th ed. St. Louis: Elsevier Mosby; 2004",
      "Bassett K, DiMarco A, Naughton D. Local Anesthesia for Dental Professionals. Upper Saddle River, NJ: Pearson; 2009",
      "Malamed SF. What's new in local anesthesia. Dimensions of Dental Hygiene. 2013:11(7):21-22",
   ]
}