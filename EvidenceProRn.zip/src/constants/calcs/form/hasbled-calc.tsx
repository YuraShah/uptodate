export const hasbledCalc = {
   id: "EV-CALC-30",
   link: "has-bled",
   title: "Шкала HAS-BLED",
   text: "Помогает оценить риск-польза антикоагулянтной терапии при лечении мерцательной аритмии",
   description: {
      descriptionMain: [
         "HAS-BLED оценивает риск возникновения массивного кровотечения у пациентов, получающих антикоагулянтную терапию, для оценки соотношения риска и пользы лечения мерцательной аритмии. Шкала HAS-BLED была разработана в качестве практической оценки риска для определения годового риска возникновения массивного кровотечения у пациентов с мерцательной аритмией.",
         "Рассмотрите возможность использования шкалы HAS-BLED в качестве инструмента для начала антикоагулянтной терапии у пациентов с мерцательной аритмией.",
         "Рассмотрите возможность использования шкалы HAS-BLED вместо или в сочетании с другими шкалами риска кровотечения, такими как HEMORR₂HAGES и ATRIA, для определения риска серьезного кровотечения у пациента с мерцательной аритмией.",
         "Сравните риск обширного кровотечения, рассчитанный по шкале HAS-BLED, с риском тромбоэмболических событий, рассчитанным по шкале CHA₂DS₂-VASc, чтобы определить, перевешивает ли польза от антикоагуляции риск.",
      ],
      descriptionTable: [
         {
            headData: ['HAS-BLED балл', 'Группа риска', 'Риск крупного кровотечения', 'Кровотечение на 100 пациенто-лет', 'Рекомендация'],
            bodyData: [
               ['0 или 1', 'Относительно низкий', '0,9% или 3,4%', '1,13 или 1,02', 'Следует рассмотреть возможность антикоагуляции'],
               ['2', 'Средний', '4,1%', '1,88', 'Можно рассмотреть использование антикоагулянтов'],
               ['3 или 4 или 5', 'Высокий', '5,8% или 8,9% или 9,1%', '3,72 или 8,70 или 12,50', 'Следует рассмотреть альтернативные варианты антикоагуляции'],
               ['>5', 'Очень высокий', '-', '-', 'Следует рассмотреть альтернативы антикоагуляции'],
            ],
            widthNums: [150, 150, 150, 150, 150]
         }
      ],
      descriptionLink: [
         {
            "name": "HEMORR₂HAGES",
            "link": 'calcs/hemorr2hages',
         },
         {
            "name": "CHA₂DS₂-VASc",
            "link": 'calcs/cha2ds2vasc',
         }
      ]
   },
   form: [
      {
         type: 'radio',
         radioButtons: [
            {
               id: '0',
               label: 'Нет',
               value: '0',
            },
            {
               id: '1',
               label: 'Да',
               value: '1',
            },
         ],
         label: 'Гипертония (неконтролируемая, систолическое >160 мм рт. ст.)',
         inputId: 'hyper',
         required: 'yes',
         numeric: 'yes',
      },
      {
         type: 'radio',
         radioButtons: [
            {
               id: '0',
               label: 'Нет',
               value: '0',
            },
            {
               id: '1',
               label: 'Да',
               value: '1',
            },
         ],
         label: 'Заболевание почек (диализ, трансплантация, креатинин >2,26 мг/дл или >200 мкмоль/л)',
         inputId: 'renal',
         required: 'yes',
         numeric: 'yes',
      },
      {
         type: 'radio',
         radioButtons: [
            {
               id: '0',
               label: 'Нет',
               value: '0',
            },
            {
               id: '1',
               label: 'Да',
               value: '1',
            },
         ],
         label: 'Заболевание печени (цирроз или билирубин >2 раз выше верхней границы нормы при АСТ/АЛТ/ЩФ >3 раз выше верхней границы нормы)',
         inputId: 'liver',
         required: 'yes',
         numeric: 'yes',
      },
      {
         type: 'radio',
         radioButtons: [
            {
               id: '0',
               label: 'Нет',
               value: '0',
            },
            {
               id: '1',
               label: 'Да',
               value: '1',
            },
         ],
         label: 'История инсульта',
         inputId: 'stroke',
         required: 'yes',
         numeric: 'yes',
      },
      {
         type: 'radio',
         radioButtons: [
            {
               id: '0',
               label: 'Нет',
               value: '0',
            },
            {
               id: '1',
               label: 'Да',
               value: '1',
            },
         ],
         label: 'Предыдущее кровотечение или предрасположенность к кровотечению',
         inputId: 'mbleed',
         required: 'yes',
         numeric: 'yes',
      },
      {
         type: 'radio',
         radioButtons: [
            {
               id: '0',
               label: 'Нет',
               value: '0',
            },
            {
               id: '1',
               label: 'Да',
               value: '1',
            },
         ],
         label: 'Изменчивое международное нормализованное отношение (нестабильное, высокое МНО, время <60% в терапевтическом диапазоне)',
         inputId: 'inr',
         required: 'yes',
         numeric: 'yes',
      },
      {
         type: 'radio',
         radioButtons: [
            {
               id: '0',
               label: 'Нет',
               value: '0',
            },
            {
               id: '1',
               label: 'Да',
               value: '1',
            },
         ],
         label: 'Возраст >65',
         inputId: 'age',
         required: 'yes',
         numeric: 'yes',
      },
      {
         type: 'radio',
         radioButtons: [
            {
               id: '0',
               label: 'Нет',
               value: '0',
            },
            {
               id: '1',
               label: 'Да',
               value: '1',
            },
         ],
         label: 'Применение лекарств, предрасполагающих к кровотечению (аспирин, клопидогрель, нестероидные противовоспалительные препараты)',
         inputId: 'medic',
         required: 'yes',
         numeric: 'yes',
      },
      {
         type: 'radio',
         radioButtons: [
            {
               id: '0',
               label: 'Нет',
               value: '0',
            },
            {
               id: '1',
               label: 'Да',
               value: '1',
            },
         ],
         label: 'Употребление алкоголя (≥8 единиц/неделю)',
         inputId: 'alco',
         required: 'yes',
         numeric: 'yes',
      },
   ],
   refers: [
      "Pisters R, Lane DA, Nieuwlaat R, et al. A Novel User-Friendly Score (Has-Bled) To Assess 1-Year Risk Of Major Bleeding In Patients With Atrial Fibrillation: The Euro Heart Survey. Chest. 2010;138(5):1093-1100.",
      "Lip GY, Frison L, Halperin JL, Lane DA. Comparative validation of a novel risk score for predicting bleeding risk in anticoagulated patients with atrial fibrillation: the HAS-BLED (Hypertension, Abnormal Renal/Liver Function, Stroke, Bleeding History or Predisposition, Labile INR, Elderly, Drugs/Alcohol Concomitantly) score. J Am Coll Cardiol. 2011 Jan 11;57(2):173-80. doi: 10.1016/j.jacc.2010.09.024. Epub 2010 Nov 24.",
   ]
}