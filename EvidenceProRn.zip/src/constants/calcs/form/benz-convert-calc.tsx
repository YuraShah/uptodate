export const benzConvertCalc = {
   id: "EV-CALC-39",
   link: "benzodiazepine-conversion",
   title: "Конвертация бензодиазепинов",
   text: "Помогает определить эквивалентные дозы различных бензодиазепинов",
   description: {
      descriptionMain: [
         "Помогает определить эквивалентные дозы различных бензодиазепинов. Эквивалентные дозы бензодиазепинов приводятся в виде диапазонов из-за недостатка литературы по точным конвертациям; поэтому указанные диапазоны основаны на мнении экспертов и клиническом опыте, опубликованном в психиатрической литературе. Не используйте для расчета начальной дозы у пациента, который ранее не получал бензодиазепины.",
         "Этот калькулятор не учитывает возраст, функцию органов и характеристики пациента, которые могут повлиять на фармакокинетику, максимальный эффект и продолжительность эффекта.",
         "Выбор дозы на нижнем пределе указанного диапазона может снизить риск нежелательной чрезмерной седации.",
         "Конвертация дозы может быть не эквивалентной при таких состояниях, как эпилептический статус или алкогольная абстиненция. Следует использовать рекомендации, специфичные для конкретного заболевания.",
         [
            'Продолжительность эффекта:',
            "Очень кратковременный: <6 часов",
            "Кратковременный: 6-12 часов (алпразолам, триазолам)",
            "Средний: 12-24 часов (лоразепам)",
            "Длительный: >24 часов (диазепам)"
         ]
      ]
   },
   form: [
      {
         type: 'select',
         label: 'Из бензодиазепина',
         inputId: 'firstBenz',
         required: 'yes',
         items: [
            { value: 'Алпразолам', label: 'Алпразолам' },
            { value: 'Диазепам', label: 'Диазепам' },
            { value: 'Лоразепам', label: 'Лоразепам' },
            { value: 'Триазолам', label: 'Триазолам' },
         ]
      },
      {
         type: 'input',
         label: 'Доза',
         inputId: 'dose',
         placeholder: '0.001 - 1000',
         error: 'Доза должна быть в диапазоне 0.001-1000',
         span: 'мг',
         min: 0.001,
         max: 1000,
         required: 'yes',
         pattern: "dot",
         ext: 0
      },
      {
         type: 'select',
         label: 'В бензодиазепин',
         inputId: 'secondBenz',
         required: 'yes',
         items: [
            { value: 'Алпразолам', label: 'Алпразолам' },
            { value: 'Диазепам', label: 'Диазепам' },
            { value: 'Лоразепам', label: 'Лоразепам' },
            { value: 'Триазолам', label: 'Триазолам' },
         ]
      },
   ],
   refers: [
      "Gelenberg AJ, Bassuk, EL. Practitioner's Guide to Psychoactive Drugs. 4th Edition. Springer, 1997.",
      "Ashton H. Benzodiazepines: How they work and how to withdraw. The Ashton Manual, 2002.",
      "Gitlow S. Practical Guides in Psychiatry: Substance Use Disorders, 2nd Edition. Lippincott Williams & Wilkins, 2006.",
      "Tyrer PJ, Silk KR. Cambridge Textbook of Effective Treatments in Psychiatry. Cambridge University Press, 2008.",
      "Latt N, Conigrave K, Saunders JB, Marshall EJ, Nutt D. Addition Medicine, 2nd Edition. Oxford Specialist Handbooks, 2009.",
      "Labatte LA, Fava M, Rosenbaum JF, Arana GW. Handbook of Psychiatric Drug Therapy, 6th Edition. Lippincott Williams & Wilkins, 2010.",
      "Procyshyn RM, Bezchlibnyk-Butler KZ, Jeffries JJ. Clinical Handbook of Psychotropic Drugs, 22nd Edition. Hogrefe, 2017.",
   ]
}