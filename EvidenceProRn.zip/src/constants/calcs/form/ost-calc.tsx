export const ostCalc = {
   id: "EV-CALC-48",
   link: "ost",
   title: "Инструмент самооценки остеопороза",
   text: "Оценка риска остеопороза",
   description: {
      descriptionMain: [
         "Подходит для женщин в постменопаузе и мужчин, у которых ранее не был диагностирован остеопороз. Особенно полезен в условиях ограниченных ресурсов для оценки состояния мужчин и женщин в возрасте до 65 лет, когда решения о проведении исследования минеральной плотности костной ткани принимаются на основе конкретных клинических факторов. Одобрено для использования у мужчин и женщин в возрасте 40 лет и старше.",
      ],
      descriptionTable: [
         {
            headData: ['Баллы (мужчины)', 'Баллы (женщины)', 'Риск'],
            bodyData: [
               ['>3', '>1', 'Низкий'],
               ['-1 - 3', '-3 - 1', 'Средний'],
               ['<-1', '<-3', 'Высокий'],
            ],
            widthNums: [150, 150, 150]
         }
      ]
   },
   form: [
      {
         type: 'input',
         label: 'Возраст',
         inputId: 'age',
         placeholder: '1 - 100',
         error: 'Возраст должен быть в диапазоне 1-100',
         span: 'лет',
         min: 1,
         max: 100,
         required: 'yes',
         pattern: "nodot",
         ext: 0,
         spanWidth: 120
      },
      {
         type: 'radio',
         radioButtons: [
            {
               id: '0',
               label: 'Мужской',
               value: '0',
            },
            {
               id: '1',
               label: 'Женский',
               value: '1',
            }
         ],
         label: 'Пол',
         inputId: 'gender',
         required: 'yes',
         numeric: 'no',
      },
      {
         type: 'input',
         label: 'Вес',
         inputId: 'weight',
         placeholder: '1 - 227',
         error: 'Вес должен быть в диапазоне 1-227',
         span: 'кг',
         min: 1,
         max: 227,
         required: 'yes',
         pattern: "dot",
         ext: 0,
         spanWidth: 120
      },
   ],
   refers: [
      "Koh LKH, Ben Sedrine W, Torralba TP, et al. A simple tool to identify asian women at increased risk of osteoporosis. Osteoporosis International. 2001;12(8):699-705.",
      "Adler RA, Tran MT, Petkov VI. Performance of the osteoporosis self-assessment screening tool for osteoporosis in american men. Mayo Clinic Proceedings. 2003;78(6):723-727.",
      "Richy F, Gourlay M, Ross PD, et al. Validation and comparative evaluation of the osteoporosis self-assessment tool (Ost) in a Caucasian population from Belgium. QJM: An International Journal of Medicine. 2004;97(1):39-46.",
      "Richards JS, Lazzari AA, Teves Qualler DA, Desale S, Howard R, Kerr GS. Validation of the osteoporosis self-assessment tool in us male veterans. Journal of Clinical Densitometry. 2014;17(1):32-37.",
      "Screening for osteoporosis to prevent fractures: recommendation statement. afp. 2018;98(10):online-online.",
      "Rubin KH, Abrahamsen B, Friis-Holmberg T, et al. Comparison of different screening tools (Frax®, ost, orai, osiris, score and age alone) to identify women with increased risk of fracture. A population-based prospective study. Bone. 2013;56(1):16-22.",
      "Pecina JL, Romanovsky L, Merry SP, Kennel KA, Thacher TD. Comparison of clinical risk tools for predicting osteoporosis in women ages 50-64. The Journal of the American Board of Family Medicine. 2016;29(2):233-239.",
   ]
}