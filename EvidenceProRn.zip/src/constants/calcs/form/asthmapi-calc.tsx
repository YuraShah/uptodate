export const asthmapiCalc = {
   id: "EV-CALC-54",
   link: "asthma-predictive-index",
   title: "Индекс прогнозирования астмы",
   text: "Определяет вероятность развития детской астмы у пациентов детского возраста",
   description: {
      descriptionMain: [
         "Определяет вероятность развития детской астмы у пациентов детского возраста. Данная оценка применима к детям в возрасте ≤3 лет. Несмотря на высокую специфичность, этот метод не является хорошим скрининговым инструментом: он не выявляет многих пациентов, у которых впоследствии будет диагностирована астма."
      ]
   },
   form: [
      {
         type: 'radio',
         radioButtons: [
            {
               id: '1',
               label: '≥3',
               value: '1',
            },
            {
               id: '0',
               label: '<3',
               value: '0',
            },
         ],
         label: 'Эпизоды хрипов/год',
         inputId: 'wheezing',
         required: 'yes',
         numeric: 'yes',
      },
      {
         type: 'title',
         formTitle: 'Большие критерии',
      },
      {
         type: 'radio',
         radioButtons: [
            {
               id: '0',
               label: 'Нет',
               value: '0',
            },
            {
               id: '1',
               label: 'Да',
               value: '1',
            }
         ],
         label: 'Родитель с астмой',
         inputId: 'parent',
         required: 'yes',
         numeric: 'yes',
      },
      {
         type: 'radio',
         radioButtons: [
            {
               id: '0',
               label: 'Нет',
               value: '0',
            },
            {
               id: '1',
               label: 'Да',
               value: '1',
            },
         ],
         label: 'Пациент с экземой',
         inputId: 'eczema',
         required: 'yes',
         numeric: 'yes',
      },
      {
         type: 'title',
         formTitle: 'Маленькие критерии',
      },
      {
         type: 'radio',
         radioButtons: [
            {
               id: '0',
               label: 'Нет',
               value: '0',
            },
            {
               id: '1',
               label: 'Да',
               value: '1',
            },
         ],
         label: 'У пациента аллергический ринит',
         inputId: 'rhinit',
         required: 'yes',
         numeric: 'yes',
      },
      {
         type: 'radio',
         radioButtons: [
            {
               id: '0',
               label: 'Нет',
               value: '0',
            },
            {
               id: '1',
               label: 'Да',
               value: '1',
            },
         ],
         label: 'Одышка, за исключением случаев простуды',
         inputId: 'cold',
         required: 'yes',
         numeric: 'yes',
      },
      {
         type: 'radio',
         radioButtons: [
            {
               id: '0',
               label: 'Нет',
               value: '0',
            },
            {
               id: '1',
               label: 'Да',
               value: '1',
            },
         ],
         label: 'Эозинофилия (≥4% в общем анализе крови)',
         inputId: 'eosin',
         required: 'yes',
         numeric: 'yes',
      },
   ],
   refers: [
      "Castro-Rodríguez JA, et al. A clinical index to define risk of asthma in young children with recurrent wheezing. Am J Respir Crit Care Med. 2000; 162: 1403-1406.",
      "Leonardi NA, et al. Validation of the Asthma Predictive Index and comparison with simpler clinical prediction rules. J Allergy Clin Immunol. 2011 Jun;127(6):1466-72.e6."
   ]
}