export const graceCalc = {
   id: "EV-CALC-21",
   link: "grace",
   title: "Шкала GRACE",
   text: "Риск инфаркта миокарда и летальность на госпитальном этапе",
   description: {
      descriptionMain: [
         "Шкала GRACE (Global Registry of Acute Coronary Events) - позволяет оценить риск инфаркта миокарда и летальности на госпитальном этапе и в последующие 6 месяцев."
      ]
   },
   form: [
      {
         type: 'input',
         label: 'Возраст',
         inputId: 'age',
         placeholder: '1 - 120',
         error: 'Возраст должен быть 1 - 120',
         span: 'лет',
         min: 1,
         max: 120,
         required: 'yes',
         pattern: "nodot",
         ext: 0,
         spanWidth: 120
      },
      {
         type: 'input',
         label: 'Частота сердечных сокращений',
         inputId: 'heartbeat',
         placeholder: '1 - 300',
         error: 'Должен быть в диапазоне 1 - 300',
         span: 'удар/мин',
         min: 1,
         max: 300,
         required: 'yes',
         pattern: "dot",
         ext: 0,
         spanWidth: 130
      },
      {
         type: 'input',
         label: 'Систолическое артериальное давление',
         inputId: 'syst',
         placeholder: '60 - 300',
         error: 'Должен быть в диапазоне 60 - 300',
         span: 'мм рт․с․',
         min: 60,
         max: 300,
         required: 'yes',
         pattern: "nodot",
         ext: 0,
         spanWidth: 120
      },
      {
         type: 'input',
         label: 'Креатинин плазмы',
         inputId: 'creatinine',
         placeholder1: '1 - 3000',
         placeholder: '>0 - 34',
         error1: 'Должен быть в диапазоне 1 - 3000',
         error: 'Должен быть в диапазоне 0.001 - 34',
         span1: 'мкмоль/л',
         span: 'мг/дл',
         min1: 1,
         min: 0.001,
         max1: 3000,
         max: 34,
         required: 'yes',
         pattern: "dot",
         ext: 1,
         spanWidth: 60
      },
      {
         type: 'checkbox',
         inputId: 'cardiacarrest',
         label: 'Остановка сердца (при поступлении)',
      },
      {
         type: 'checkbox',
         inputId: 'stt',
         label: 'Отклонение сегмента ST, инверсия зубца T',
      },
      {
         type: 'checkbox',
         inputId: 'necrosisMarker',
         label: 'Высокий уровень маркеров некроза миокарда в крови',
      },
      {
         type: 'select',
         label: 'Класс сердечной недостаточности (по классификации Киллипа)',
         inputId: 'heartClass',
         required: 'yes',
         items: [
            { value: '0', label: 'Отсутствие признаков застойной сердечной недостаточности (I)' },
            { value: '20', label: 'Наличие хрипов в легких и/или высокое давление в яремных венах (II)' },
            { value: '39', label: 'Острый отек легких (III)' },
            { value: '59', label: 'Кардиогенный шок (IV)' },
         ]
      },
   ],
   refers: [
      "Keith A A Fox 1, Gordon Fitzgerald, Etienne Puymirat, Wei Huang, Kathryn Carruthers, Tabassome Simon, Pierre Coste, Jacques Monsegu, Philippe Gabriel Steg, Nicolas Danchin, Fred Anderson. Should patients with acute coronary disease be stratified for management according to their risk? Derivation, external validation and outcomes using the updated GRACE risk score. DOI: 10.1136/bmjopen-2013-004425",
      "Keith A A Fox 1, Omar H Dabbous, Robert J Goldberg, Karen S Pieper, Kim A Eagle, Frans Van de Werf, Alvaro Avezum, Shaun G Goodman, Marcus D Flather, Frederick A Anderson Jr, Christopher B Granger. Prediction of risk of death and myocardial infarction in the six months after presentation with acute coronary syndrome: prospective multinational observational study (GRACE). DOI: 10.1136/bmj.38985.646481.55",
   ]
}