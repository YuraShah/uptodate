export const garfieldCalculator = {
   id: "EV-CALC-34",
   link: "garfield",
   title: "Шкала GARFIELD-AF",
   text: "Помогает предсказать риск смерти, инсульта и сильного кровотечения",
   description: {
      descriptionMain: [
         "Шкала GARFIELD-AF помогает прогнозировать риск смерти, ишемического инсульта и массивного кровотечения (включая геморрагический инсульт) у пациентов, получающих и не получающих антикоагулянтную терапию. Она оценивает риск через 6 месяцев, 1 год и 2 года после постановки диагноза мерцательной аритмии.",
         "Используйте у пациентов с впервые диагностированной мерцательной аритмией для определения рисков лечения антикоагулянтами.",
         "Регистр GARFIELD-AF является крупнейшим перспективным регистром пациентов с впервые диагностированной фибрилляцией предсердий."
      ]
   },
   form: [
   {
      type: 'radio',
      label: 'Пол',
      inputId: 'gender',
      required: 'yes',
      numeric: 'no',
      radioButtons: [
         {
            id: '0',
            label: 'Мужской',
            value: '0',
         },
         {
            id: '1',
            label: 'Женский',
            value: '1',
         },
      ]
   },
   {
      type: 'input',
      label: 'Возраст',
      inputId: 'age',
      placeholder: '1-100',
      error: 'Возраст должен быть 1-100',
      span: 'лет',
      min: 1,
      max: 100,
      required: 'yes',
      pattern: "nodot",
      ext: 0,
      spanWidth: 150
   },
   {
      type: 'input',
      label: 'Вес',
      inputId: 'weight',
      placeholder: '1-282',
      error: 'Вес должен быть 1 - 282',
      span: 'кг',
      min: 1,
      max: 282,
      required: 'yes',
      pattern: "dot",
      ext: 0,
      spanWidth: 150
   },
   {
      type: 'radio',
      label: 'Сердечная недостаточность',
      inputId: 'heartfail',
      required: 'yes',
      numeric: 'no',
      radioButtons: [
         {
            id: '0',
            label: 'Нет',
            value: '0',
         },
         {
            id: '1',
            label: 'Да',
            value: '1',
         },
      ]
   },
   {
      type: 'radio',
      label: 'Сосудистые заболевания',
      inputId: 'vasc',
      required: 'yes',
      numeric: 'no',
      radioButtons: [
         {
            id: '0',
            label: 'Нет',
            value: '0',
         },
         {
            id: '1',
            label: 'Да',
            value: '1',
         },
      ]
   },
   {
      type: 'radio',
      label: 'Предыдущий инсульт',
      inputId: 'stroke',
      required: 'yes',
      numeric: 'no',
      radioButtons: [
         {
            id: '0',
            label: 'Нет',
            value: '0',
         },
         {
            id: '1',
            label: 'Да',
            value: '1',
         },
      ]
   },
   {
      type: 'radio',
      label: 'История кровотечения',
      inputId: 'bleed',
      required: 'yes',
      numeric: 'no',
      radioButtons: [
         {
            id: '0',
            label: 'Нет',
            value: '0',
         },
         {
            id: '1',
            label: 'Да',
            value: '1',
         },
      ]
   },
   {
      type: 'radio',
      label: 'Каротидная окклюзивная болезнь',
      inputId: 'carotid',
      required: 'yes',
      numeric: 'no',
      radioButtons: [
         {
            id: '0',
            label: 'Нет',
            value: '0',
         },
         {
            id: '1',
            label: 'Да',
            value: '1',
         },
      ]
   },
   {
      type: 'radio',
      label: 'Сахарный диабет',
      inputId: 'diab',
      required: 'yes',
      numeric: 'no',
      radioButtons: [
         {
            id: '0',
            label: 'Нет',
            value: '0',
         },
         {
            id: '1',
            label: 'Да',
            value: '1',
         },
      ]
   },
   {
      type: 'radio',
      label: 'Хроническое заболевание почек средней и тяжёлой степени',
      inputId: 'ckd',
      required: 'yes',
      numeric: 'no',
      radioButtons: [
         {
            id: '0',
            label: 'Нет',
            value: '0',
         },
         {
            id: '1',
            label: 'Да',
            value: '1',
         },
      ]
   },
   {
      type: 'radio',
      label: 'Деменция',
      inputId: 'dementia',
      required: 'yes',
      numeric: 'no',
      radioButtons: [
         {
            id: '0',
            label: 'Нет',
            value: '0',
         },
         {
            id: '1',
            label: 'Да',
            value: '1',
         },
      ]
   },
   {
      type: 'radio',
      label: 'Активный курильщик',
      inputId: 'smoker',
      required: 'yes',
      numeric: 'no',
      radioButtons: [
         {
            id: '0',
            label: 'Нет',
            value: '0',
         },
         {
            id: '1',
            label: 'Да',
            value: '1',
         },
      ]
   },
   {
      type: 'radio',
      label: 'Антитромбоцитарная терапия',
      inputId: 'antiplatelet',
      required: 'yes',
      numeric: 'no',
      radioButtons: [
         {
            id: '0',
            label: 'Нет',
            value: '0',
         },
         {
            id: '1',
            label: 'Да',
            value: '1',
         },
      ]
   },
   {
      type: 'select',
      label: 'Этническая принадлежность',
      inputId: 'ethnicity',
      required: 'yes',
      items: [
         { value: '0', label: 'Европеоидная' },
         { value: '1', label: 'Латиноамериканская' },
         { value: '2', label: 'Монголоидная' },
         { value: '3', label: 'Негроидная/смешанная/другая' }
      ]
   },
   {
      type: 'input',
      label: 'Пульс',
      inputId: 'pulse',
      placeholder: '1-220',
      error: 'Пульса должен быть 1 - 220',
      span: 'удар/мин',
      min: 1,
      max: 200,
      required: 'yes',
      pattern: "nodot",
      ext: 0,
      spanWidth: 150
   },
   {
      type: 'input',
      label: 'Диастолическое артериальное давление',
      inputId: 'diastolic',
      placeholder: '20-200',
      error: 'Это поле должно быть в диапазоне 20 - 200',
      span: 'мм рт.с.',
      min: 20,
      max: 200,
      required: 'yes',
      pattern: "nodot",
      ext: 0,
      spanWidth: 150
   },
   {
      type: 'select',
      label: 'Пероральная антикоагулянтная терапия',
      inputId: 'oac',
      required: 'yes',
      items: [
         { value: '0', label: 'Нет' },
         { value: '1', label: 'Новые оральные антикоагулянты' },
         { value: '2', label: 'Антагонисты витамина К' }
      ]
   }
],
refers: [
   "Fox KAA, Lucas JE, Pieper KS, et al. Improved risk stratification of patients with atrial fibrillation: an integrated GARFIELD-AF tool for the prediction of mortality, stroke and bleed in patients with and without anticoagulation. BMJ Open. 2017;7(12):e017157.",
   "Fox KAA, Virdone S, Pieper KS, et al. GARFIELD-AF risk score for mortality, stroke, and bleeding within 2 years in patients with atrial fibrillation. Eur Heart J Qual Care Clin Outcomes. 2022;8(2):214-227.",
   "Dalgaard F, Pieper K, Verheugt F, et al. GARFIELD-AF model for prediction of stroke and major bleeding in atrial fibrillation: a Danish nationwide validation study. BMJ Open. 2019;9(11):e033283.",
]
}