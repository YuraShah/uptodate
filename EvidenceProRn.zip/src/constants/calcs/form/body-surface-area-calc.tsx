export const bodySurfaceAreaCalc = {
   id: "EV-CALC-11",
   link: "body-surface-area",
   title: "Калькулятор площади поверхности тела",
   text: "Калькулятор площади поверхности тела",
   description: {
      descriptionMain: [
         "Дозы некоторых лекарств рассчитываются с учетом площади поверхности тела."
      ]
   },
   form: [
      {
         type: 'input',
         label: 'Вес',
         inputId: 'weight',
         placeholder: '',
         error: 'Вес должен быть 1-225',
         span: 'кг',
         min: 1,
         max: 225,
         required: 'yes',
         pattern: "dot",
         ext: 0
      },
      {
         type: 'input',
         label: 'Рост',
         inputId: 'height',
         placeholder: '',
         error: 'Рост должен быть 15-203',
         span: 'см',
         min: 15,
         max: 203,
         required: 'yes',
         pattern: "dot",
         ext: 0
      },
   ],
   refers: [
      "Gadzik J. 'How much should I weigh?' Quetelet's equation, upper weight limits, and BMI prime.Connecticut Medicine. (2006). 70 (2): 81-8. PMID 16768059",
      "BMI Classification. Global Database on Body Mass Index. World Health Organization. 2006. Retrieved July 27, 2012"
   ]
}