export const crusadeCalc = {
   id: "EV-CALC-26",
   link: "crusade",
   title: "Шкала CRUSADE",
   text: "Оценка риска кровотечения у пациентов с острым коронарным синдромом без подъема сегмента ST",
   description: {
      descriptionMain: [
         "Шкала CRUSADE (Can Rapid risk stratifi cation of Unstable angina patients Suppress ADverse outcomes with Early implementation of the ACC/AHA guidelines) - оценивает 30-дневный риск кровотечения у пациентов с острым коронарным синдромом без подъема сегмента ST во время госпитализации. Использование шкалы рекомендовано Европейским обществом кардиологов."
      ],
      descriptionTable: [
         {
            headData: ['Результат', 'Баллы'],
            bodyData: [
               ['Риск сильного кровотечения в больнице очень низок (3.1%)', '20 и меньше'],
               ['Риск сильного кровотечения в больнице низкий (5.5%)', '21 - 30'],
               ['Риск сильного кровотечения в больнице умеренный (8.6%)', '31 - 40'],
               ['Риск сильного кровотечения в больнице высок (11.9%)', '41 - 50'],
               ['Риск сильного кровотечения в больнице очень высок (19.5%)', '51 и больше'],
            ],
            flexNums: [1, 1]
         }
      ]
   },
   form: [
      {
         type: 'radio',
         radioButtons: [
            {
               id: '9',
               label: 'меньше 31',
               value: '9',
            },
            {
               id: '7',
               label: '31 - 33.9',
               value: '7',
            },
            {
               id: '3',
               label: '34 - 36.9',
               value: '3',
            },
            {
               id: '2',
               label: '37 - 39.9',
               value: '2',
            },
            {
               id: '0',
               label: 'больше 39.9',
               value: '0',
            }
         ],
         label: 'Начальный гематокрит, %',
         inputId: 'hct',
         required: 'yes',
         numeric: 'yes',
      },
      {
         type: 'radio',
         radioButtons: [
            {
               id: '39',
               label: 'меньше 15',
               value: '39',
            },
            {
               id: '35',
               label: '15 - 30',
               value: '35',
            },
            {
               id: '28',
               label: '30 - 60',
               value: '28',
            },
            {
               id: '17',
               label: '60 - 90',
               value: '17',
            },
            {
               id: '7',
               label: '90 - 120',
               value: '7',
            },
            {
               id: '0',
               label: 'больше 120',
               value: '0',
            }
         ],
         label: 'Клиренс креатинина, мл/мин',
         inputId: 'creatinine',
         required: 'yes',
         numeric: 'yes',
      },
      {
         type: 'radio',
         radioButtons: [
            {
               id: '0',
               label: 'меньше 71',
               value: '0',
            },
            {
               id: '1',
               label: '71 - 80',
               value: '1',
            },
            {
               id: '3',
               label: '81 - 90',
               value: '3',
            },
            {
               id: '6',
               label: '91 - 100',
               value: '6',
            },
            {
               id: '8',
               label: '101 - 110',
               value: '8',
            },
            {
               id: '10',
               label: '111 - 120',
               value: '10',
            },
            {
               id: '11',
               label: 'больше 120',
               value: '11',
            }
         ],
         label: 'Частота сердечных сокращений',
         inputId: 'heartbeat',
         required: 'yes',
         numeric: 'yes',
      },
      {
         type: 'radio',
         radioButtons: [
            {
               id: '0',
               label: 'Мужской',
               value: '0',
            },
            {
               id: '8',
               label: 'Женский',
               value: '8',
            }
         ],
         label: 'Пол',
         inputId: 'gender',
         required: 'yes',
         numeric: 'yes',
      },
      {
         type: 'radio',
         radioButtons: [
            {
               id: '0',
               label: 'Нет',
               value: '0',
            },
            {
               id: '7',
               label: 'Да',
               value: '7',
            }
         ],
         label: 'Признаки сердечной недостаточности во время госпитализации',
         inputId: 'heartD',
         required: 'yes',
         numeric: 'yes',
      },
      {
         type: 'radio',
         radioButtons: [
            {
               id: '0',
               label: 'Нет',
               value: '0',
            },
            {
               id: '6',
               label: 'Да',
               value: '6',
            }
         ],
         label: 'История сосудистых заболеваний (периферический атеросклероз или инсульт)',
         inputId: 'vascularD',
         required: 'yes',
         numeric: 'yes',
      },
      {
         type: 'radio',
         radioButtons: [
            {
               id: '0',
               label: 'Нет',
               value: '0',
            },
            {
               id: '6',
               label: 'Да',
               value: '6',
            }
         ],
         label: 'Сахарный диабет',
         inputId: 'diabetes',
         required: 'yes',
         numeric: 'yes',
      },
      {
         type: 'radio',
         radioButtons: [
            {
               id: '10',
               label: 'меньше 91',
               value: '10',
            },
            {
               id: '8',
               label: '91 - 100',
               value: '8',
            },
            {
               id: '5',
               label: '101 - 120',
               value: '5',
            },
            {
               id: '1',
               label: '121 - 180',
               value: '1',
            },
            {
               id: '3',
               label: '181 - 200',
               value: '3',
            },
            {
               id: '50',
               label: '201 и больше',
               value: '5',
            }
         ],
         label: 'Систолическое артериальное давление',
         inputId: 'syst',
         required: 'yes',
         numeric: 'yes',
      },
   ],
   refers: [
      "FSubherwal S, Bach RG, Chen AY, Gage BF, Rao SV, Newby LK, Wang TY, Gibler WB, Ohman EM, Roe MT, Pollack CV Jr.,Peterson ED, Alexander KP. Baseline risk of major bleeding in non-ST-segment-elevation myocardial infarction: the CRUSADE (Can Rapid risk stratification of Unstable angina patients Suppress Adverse outcomes with Early Implementation of the ACC/AHA Guidelines) Bleeding Score. Circulation. 2009; 119:1873-1882",
      "Abu-Assi E, Gracía-Acuña JM, Ferreira-González I, et al. Evaluating the Performance of the Can Rapid Risk Stratification of Unstable Angina Patients Suppress Adverse Outcomes With Early Implementation of the ACC/AHA Guidelines (CRUSADE) bleeding score in a contemporary Spanish cohort of patients with non-ST-segment elevation acute myocardial infarction. Circulation 2010; 121(22):2419-26",
      "Abu-Assi E, Raposeiras-Roubin S, Lear P, et al. Comparing the predictive validity of three contemporary bleeding risk scores in acute coronary syndrome. Eur Heart J Acute Cardiovasc Care 2012; 1(3):222-31",
      "Ariza-Solé A, Sánchez-Elvira G, Sánchez-Salado JC, et al. CRUSADE bleeding risk score validation for ST-segment-elevation myocardial infarction undergoing primary percutaneous coronary intervention. Thromb Res 2013; 132(6):652-8",
      "Flores-Ríos X, Couto-Mallón D, Rodríguez-Garrido J, et al. Comparison of the performance of the CRUSADE, ACUITY-HORIZONS, and ACTION bleeding risk scores in STEMI undergoing primary PCI: insights from a cohort of 1391 patients. Eur Heart J Acute Cardiovasc Care 2013; 2(1):19-26",
   ]
}