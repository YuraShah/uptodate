export const nicotineDependenceCalc = {
   id: "EV-CALC-06",
   link: "nicotinetest",
   title: "Тест Фагерстрема (никотиновая зависимость)",
   text: "Тест Фагерстрёма: оценка степени никотиновой зависимости",
   description: {
      descriptionMain: [
         "Помогает определить, насколько серьезна никотиновая зависимость и требуется ли терапевтическое вмешательство."
      ]
   },
   form: [
      {
         type: 'radio',
         radioButtons: [
            {
               id: '3',
               label: '5 минут',
               value: '3',
            },
            {
               id: '2',
               label: '6 -30 минут',
               value: '2',
            }
         ],
         label: 'Сколько времени проходит после пробуждения, чтобы выкурить первую сигарету?',
         inputId: 'first',
         required: 'yes',
         numeric: 'yes',
      },
      {
         type: 'radio',
         radioButtons: [
            {
               id: '1',
               label: 'Да',
               value: '1',
            },
            {
               id: '0',
               label: 'Нет',
               value: '0',
            }
         ],
         label: 'Трудно ли не курить в местах, где курение запрещено?',
         inputId: 'second',
         required: 'yes',
         numeric: 'yes',
      },
      {
         type: 'radio',
         radioButtons: [
            {
               id: '1',
               label: 'Первого утром',
               value: '1',
            },
            {
               id: '0',
               label: 'От всех остальных',
               value: '0',
            }
         ],
         label: 'От каких сигарет вы можете легко отказаться?',
         inputId: 'third',
         required: 'yes',
         numeric: 'yes',
      },
      {
         type: 'radio',
         radioButtons: [
            {
               id: '0',
               label: '10 и меньше',
               value: '0',
            },
            {
               id: '1',
               label: '11 - 21',
               value: '1',
            },
            {
               id: '2',
               label: '21 - 30',
               value: '2',
            },
            {
               id: '3',
               label: '31 и больше',
               value: '3',
            }
         ],
         label: 'Сколько сигарет выкуриваете в день?',
         inputId: 'fourth',
         required: 'yes',
         numeric: 'yes',
      },
      {
         type: 'radio',
         radioButtons: [
            {
               id: '1',
               label: 'Да',
               value: '1',
            },
            {
               id: '0',
               label: 'Нет',
               value: '0',
            }
         ],
         label: 'Вы курите чаще после пробуждения утром, чем в течение дня?',
         inputId: 'fifth',
         required: 'yes',
         numeric: 'yes',
      },
      {
         type: 'radio',
         radioButtons: [
            {
               id: '1',
               label: 'Да',
               value: '1',
            },
            {
               id: '0',
               label: 'Нет',
               value: '0',
            }
         ],
         label: 'Вы курите, когда болеете и весь день лежите в постели?',
         inputId: 'sixth',
         required: 'yes',
         numeric: 'yes',
      },
   ],
   refers: [
      "Fagerstrom, K. (2012). Determinants of tobacco use and renaming the FTND to the Fagerstrom Test for Cigarette Dependence. Nicotine Tob Res 14(1): 75-78.",
      "Heatherton, T. F., L. T. Kozlowski, et al. (1991). The Fagerstrom Test for Nicotine Dependence: a revision of the Fagerstrom Tolerance Questionnaire. Br J Addict 86(9): 1119-1127.",
      "Kozlowski, L. T., C. Q. Porter, et al. (1994). Predicting smoking cessation with self-reported measures of nicotine dependence: FTQ, FTND, and HSI. Drug Alcohol Depend 34(3): 211-216.",
   ]
}