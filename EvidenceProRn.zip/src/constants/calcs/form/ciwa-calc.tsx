export const ciwaCalc = {
   id: "EV-CALC-37",
   link: "ciwa-b",
   title: "Шкала оценки симптомов отмены бензодиазепинов (Clinical Institute Withdrawal Assessment Scale - Benzodiazepines)",
   text: "Clinical Institute Withdrawal Assessment Scale - Benzodiazepines",
   description: {
      descriptionMain: [
         "Clinical Institute Withdrawal Assessment Scale - Benzodiazepines - клиническая шкала для оценки симптомов отмены при прекращении приема или снижении дозы бензодиазепинов. Этот инструмент используется медицинскими работниками для мониторинга состояния пациента и определения необходимости медицинского вмешательства при отмене этих препаратов.",
         "Для каждого из следующих пунктов укажите число, которое лучше всего описывает, что чувствуете."
      ],
      descriptionTable: [
         {
            headData: ['Баллы', 'Результат'],
            bodyData: [
              ['61-80', 'Очень тяжелый абстинентный синдром'],
              ['41-60', 'Тяжелый абстинентный синдром'],
              ['40-21', 'Умеренный абстинентный синдром'],
              ['1-20', 'Слабый абстинентный синдром'],
            ],
            flexNums: [1, 3]
         }
      ]
   },
   form: [
      {
         type: 'title',
         formTitle: "Опрос пациента или самоотчет"
      },
      {
         type: 'radio',
         label: 'Вы чувствуете раздражение',
         inputId: 'irrit',
         required: 'yes',
         radioButtons: [
            {
               id: '0',
               label: '0 Совсем нет',
               value: '0',
            },
            {
               id: '1',
               label: '1',
               value: '1',
            },
            {
               id: '2',
               label: '2',
               value: '2',
            },
            {
               id: '3',
               label: '3',
               value: '3',
            },
            {
               id: '4',
               label: '4 Очень-очень',
               value: '4',
            }
         ],
         numeric: 'yes',
      },
      {
         type: 'radio',
         label: 'Вы чувствуете усталость',
         inputId: 'fatig',
         required: 'yes',
         radioButtons: [
            {
               id: '0',
               label: '0 Совсем нет',
               value: '0',
            },
            {
               id: '1',
               label: '1',
               value: '1',
            },
            {
               id: '2',
               label: '2',
               value: '2',
            },
            {
               id: '3',
               label: '3',
               value: '3',
            },
            {
               id: '4',
               label: '4 Невозможно выполнить ни одну функцию',
               value: '4',
            }
         ],
         numeric: 'yes',
      },
      {
         type: 'radio',
         label: 'Вы чувствуете напряжение',
         inputId: 'tense',
         required: 'yes',
         radioButtons: [
            {
               id: '0',
               label: '0 Совсем нет',
               value: '0',
            },
            {
               id: '1',
               label: '1',
               value: '1',
            },
            {
               id: '2',
               label: '2',
               value: '2',
            },
            {
               id: '3',
               label: '3',
               value: '3',
            },
            {
               id: '4',
               label: '4 Очень-очень',
               value: '4',
            }
         ],
         numeric: 'yes',
      },
      {
         type: 'radio',
         label: 'Есть трудности с концентрацией внимания',
         inputId: 'concen',
         required: 'yes',
         radioButtons: [
            {
               id: '0',
               label: '0 Совсем нет',
               value: '0',
            },
            {
               id: '1',
               label: '1',
               value: '1',
            },
            {
               id: '2',
               label: '2',
               value: '2',
            },
            {
               id: '3',
               label: '3',
               value: '3',
            },
            {
               id: '4',
               label: '4 Невозможно сосредоточиться',
               value: '4',
            }
         ],
         numeric: 'yes',
      },
      {
         type: 'radio',
         label: 'Есть потеря аппетита',
         inputId: 'appet',
         required: 'yes',
         radioButtons: [
            {
               id: '0',
               label: '0 Совсем нет',
               value: '0',
            },
            {
               id: '1',
               label: '1',
               value: '1',
            },
            {
               id: '2',
               label: '2',
               value: '2',
            },
            {
               id: '3',
               label: '3',
               value: '3',
            },
            {
               id: '4',
               label: '4 Аппетита нет, есть невозможно',
               value: '4',
            }
         ],
         numeric: 'yes',
      },
      {
         type: 'radio',
         label: 'Есть онемение или покалывание на лице или конечностях',
         inputId: 'burn',
         required: 'yes',
         radioButtons: [
            {
               id: '0',
               label: '0 Нет онемения/покалывания',
               value: '0',
            },
            {
               id: '1',
               label: '1',
               value: '1',
            },
            {
               id: '2',
               label: '2',
               value: '2',
            },
            {
               id: '3',
               label: '3',
               value: '3',
            },
            {
               id: '4',
               label: '4 Сильное онемение/покалывание',
               value: '4',
            }
         ],
         numeric: 'yes',
      },
      {
         type: 'radio',
         label: 'Есть учащенное сердцебиение',
         inputId: 'racing',
         required: 'yes',
         radioButtons: [
            {
               id: '0',
               label: '0 Нет изменений',
               value: '0',
            },
            {
               id: '1',
               label: '1',
               value: '1',
            },
            {
               id: '2',
               label: '2',
               value: '2',
            },
            {
               id: '3',
               label: '3',
               value: '3',
            },
            {
               id: '4',
               label: '4 Постоянное учащенное сердцебиение',
               value: '4',
            }
         ],
         numeric: 'yes',
      },
      {
         type: 'radio',
         label: 'Есть головная боль',
         inputId: 'head',
         required: 'yes',
         radioButtons: [
            {
               id: '0',
               label: '0 Совсем нет',
               value: '0',
            },
            {
               id: '1',
               label: '1',
               value: '1',
            },
            {
               id: '2',
               label: '2',
               value: '2',
            },
            {
               id: '3',
               label: '3',
               value: '3',
            },
            {
               id: '4',
               label: '4 Сильная головная боль',
               value: '4',
            }
         ],
         numeric: 'yes',
      },
      {
         type: 'radio',
         label: 'Есть мышечная боль или скованность',
         inputId: 'muscle',
         required: 'yes',
         radioButtons: [
            {
               id: '0',
               label: '0 Совсем нет',
               value: '0',
            },
            {
               id: '1',
               label: '1',
               value: '1',
            },
            {
               id: '2',
               label: '2',
               value: '2',
            },
            {
               id: '3',
               label: '3',
               value: '3',
            },
            {
               id: '4',
               label: '4 Сильная мышечная боль или скованность',
               value: '4',
            }
         ],
         numeric: 'yes',
      },
      {
         type: 'radio',
         label: 'Есть беспокойство или нервозность',
         inputId: 'anxious',
         required: 'yes',
         radioButtons: [
            {
               id: '0',
               label: '0 Совсем нет',
               value: '0',
            },
            {
               id: '1',
               label: '1',
               value: '1',
            },
            {
               id: '2',
               label: '2',
               value: '2',
            },
            {
               id: '3',
               label: '3',
               value: '3',
            },
            {
               id: '4',
               label: '4 Очень-очень',
               value: '4',
            }
         ],
         numeric: 'yes',
      },
      {
         type: 'radio',
         label: 'Чувствует себя грустным',
         inputId: 'upset',
         required: 'yes',
         radioButtons: [
            {
               id: '0',
               label: '0 Совсем нет',
               value: '0',
            },
            {
               id: '1',
               label: '1',
               value: '1',
            },
            {
               id: '2',
               label: '2',
               value: '2',
            },
            {
               id: '3',
               label: '3',
               value: '3',
            },
            {
               id: '4',
               label: '4 Очень-очень',
               value: '4',
            }
         ],
         numeric: 'yes',
      },
      {
         type: 'radio',
         label: 'Насколько спокойным был ваш сон прошлой ночью',
         inputId: 'sleep',
         required: 'yes',
         radioButtons: [
            {
               id: '0',
               label: '0 Очень спокойным',
               value: '0',
            },
            {
               id: '1',
               label: '1',
               value: '1',
            },
            {
               id: '2',
               label: '2',
               value: '2',
            },
            {
               id: '3',
               label: '3',
               value: '3',
            },
            {
               id: '4',
               label: '4 Было совсем не спокойным',
               value: '4',
            }
         ],
         numeric: 'yes',
      },
      {
         type: 'radio',
         label: 'Чувствуете слабость',
         inputId: 'weak',
         required: 'yes',
         radioButtons: [
            {
               id: '0',
               label: '0 Совсем нет',
               value: '0',
            },
            {
               id: '1',
               label: '1',
               value: '1',
            },
            {
               id: '2',
               label: '2',
               value: '2',
            },
            {
               id: '3',
               label: '3',
               value: '3',
            },
            {
               id: '4',
               label: '4 Очень-очень',
               value: '4',
            }
         ],
         numeric: 'yes',
      },
      {
         type: 'radio',
         label: 'Считаете ли, что хорошо спали прошлой ночью',
         inputId: 'sleep2',
         required: 'yes',
         radioButtons: [
            {
               id: '0',
               label: '0 Совсем нет',
               value: '0',
            },
            {
               id: '1',
               label: '1',
               value: '1',
            },
            {
               id: '2',
               label: '2',
               value: '2',
            },
            {
               id: '3',
               label: '3',
               value: '3',
            },
            {
               id: '4',
               label: '4 Очень-очень',
               value: '4',
            }
         ],
         numeric: 'yes',
      },
      {
         type: 'radio',
         label: 'Есть ли какие-либо нарушения зрения (светочувствительность, нечеткость зрения)',
         inputId: 'visual',
         required: 'yes',
         radioButtons: [
            {
               id: '0',
               label: '0 Совсем нет',
               value: '0',
            },
            {
               id: '1',
               label: '1',
               value: '1',
            },
            {
               id: '2',
               label: '2',
               value: '2',
            },
            {
               id: '3',
               label: '3',
               value: '3',
            },
            {
               id: '4',
               label: '4 Очень чувствителен к свету, нечеткое зрение',
               value: '4',
            }
         ],
         numeric: 'yes',
      },
      {
         type: 'radio',
         label: 'Вы боитесь',
         inputId: 'fearful',
         required: 'yes',
         radioButtons: [
            {
               id: '0',
               label: '0 Совсем нет',
               value: '0',
            },
            {
               id: '1',
               label: '1',
               value: '1',
            },
            {
               id: '2',
               label: '2',
               value: '2',
            },
            {
               id: '3',
               label: '3',
               value: '3',
            },
            {
               id: '4',
               label: '4 Очень-очень',
               value: '4',
            }
         ],
         numeric: 'yes',
      },
      {
         type: 'radio',
         label: 'В последнее время беспокоитесь о возможных несчастьях',
         inputId: 'worry',
         required: 'yes',
         radioButtons: [
            {
               id: '0',
               label: '0 Совсем нет',
               value: '0',
            },
            {
               id: '1',
               label: '1',
               value: '1',
            },
            {
               id: '2',
               label: '2',
               value: '2',
            },
            {
               id: '3',
               label: '3',
               value: '3',
            },
            {
               id: '4',
               label: '4 Очень-очень',
               value: '4',
            }
         ],
         numeric: 'yes',
      },
      {
         type: 'title',
         formTitle: "Объективная физиологическая оценка"
      },
      {
         type: 'radio',
         label: 'Контролируйте потоотделение, беспокойство и возбуждение пациента',
         inputId: 'agit',
         required: 'yes',
         radioButtons: [
            {
               id: '0',
               label: '0 Нормальная активность',
               value: '0',
            },
            {
               id: '1',
               label: '1',
               value: '1',
            },
            {
               id: '2',
               label: '2 Беспокойство',
               value: '2',
            },
            {
               id: '3',
               label: '3',
               value: '3',
            },
            {
               id: '4',
               label: '4 Ходит назад-вперед, не может усидеть на месте',
               value: '4',
            }
         ],
         numeric: 'yes',
      },
      {
         type: 'radio',
         label: 'Следите за тремором пациента',
         inputId: 'tremor',
         required: 'yes',
         radioButtons: [
            {
               id: '0',
               label: '0 Нет тремора',
               value: '0',
            },
            {
               id: '1',
               label: '1 Не видно, можно почувствовать пальцами',
               value: '1',
            },
            {
               id: '2',
               label: '2 Видимый, но слабый',
               value: '2',
            },
            {
               id: '3',
               label: '3 Умеренно с вытянутыми руки',
               value: '3',
            },
            {
               id: '4',
               label: '4 Сильные с невытянутыми руками',
               value: '4',
            }
         ],
         numeric: 'yes',
      },
      {
         type: 'radio',
         label: 'Следуйте за ладонями пациента',
         inputId: 'palms',
         required: 'yes',
         radioButtons: [
            {
               id: '0',
               label: '0 Потоотделение не наблюдается',
               value: '0',
            },
            {
               id: '1',
               label: '1 Едва заметное потоотделение, ладони влажные',
               value: '1',
            },
            {
               id: '2',
               label: '2 Ладони и лоб влажные, что указывает на повышенное потоотделение в подмышках',
               value: '2',
            },
            {
               id: '3',
               label: '3 Капли пота на лбу',
               value: '3',
            },
            {
               id: '4',
               label: '4 Сильное потоотделение',
               value: '4',
            }
         ],
         numeric: 'yes',
      },
   ],
   refers: [
      "Adapted from Busto, U.E., Sykora, K. & Sellers, E.M. (1989). A clinical scale to assess benzodiazepine withdrawal. Journal of Clinical Psychopharmacology, 9 (6), 412-416."
    ]
}