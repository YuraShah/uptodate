export const adaCalc = {
   id: "EV-CALC-46",
   link: "ada-risk",
   title: "Калькулятор риска Американской диабетической ассоциации",
   text: "Прогнозирует риск недиагностированного диабета",
   description: {
      descriptionMain: [
         "Прогнозирует риск недиагностированного диабета для определения лиц, которым необходимо пройти скрининг.",
      ]
   },
   form: [
      {
         type: 'radio',
         radioButtons: [
            {
               id: '0',
               label: '<40',
               value: '0',
            },
            {
               id: '1',
               label: '40-49',
               value: '1',
            },
            {
               id: '2',
               label: '50-59',
               value: '2',
            },
            {
               id: '3',
               label: '≥60',
               value: '3',
            }
         ],
         label: 'Возраст',
         inputId: 'age',
         required: 'yes',
         numeric: 'yes',
      },
      {
         type: 'radio',
         radioButtons: [
            {
               id: '1',
               label: 'Мужской',
               value: '1',
            },
            {
               id: '0',
               label: 'Женский',
               value: '0',
            },
         ],
         label: 'Пол',
         inputId: 'gender',
         required: 'yes',
         numeric: 'yes',
      },
      {
         type: 'radio',
         radioButtons: [
            {
               id: '0',
               label: 'Нет',
               value: '0',
            },
            {
               id: '1',
               label: 'Да',
               value: '1',
            }
         ],
         label: 'Родственник первой степени родства с диабетом',
         inputId: 'degree',
         required: 'yes',
         numeric: 'yes',
      },
      {
         type: 'radio',
         radioButtons: [
            {
               id: '0',
               label: 'Нет',
               value: '0',
            },
            {
               id: '1',
               label: 'Да',
               value: '1',
            }
         ],
         label: 'Гипертония (в анамнезе, назначенные антигипертензивные препараты, АД ≥140/90)',
         inputId: 'hypert',
         required: 'yes',
         numeric: 'yes',
      },
      {
         type: 'radio',
         radioButtons: [
            {
               id: '1',
               label: 'Нет',
               value: '1',
            },
            {
               id: '0',
               label: 'Да',
               value: '0',
            }
         ],
         label: 'Физическая активность',
         inputId: 'phys',
         required: 'yes',
         numeric: 'yes',
      },
      {
         type: 'radio',
         radioButtons: [
            {
               id: '0',
               label: '<25',
               value: '0',
            },
            {
               id: '1',
               label: '25-30',
               value: '1',
            },
            {
               id: '2',
               label: '30-40',
               value: '2',
            },
            {
               id: '3',
               label: '≥40',
               value: '3',
            }
         ],
         label: 'Индекс массы тела',
         inputId: 'bmi',
         required: 'yes',
         numeric: 'yes',
      },
      {
         type: 'radio',
         radioButtons: [
            {
               id: '0',
               label: 'Нет',
               value: '0',
            },
            {
               id: '1',
               label: 'Да',
               value: '1',
            }
         ],
         label: 'Предшествующий гестационный диабет (у женщин)',
         inputId: 'gest',
         required: 'yes',
         numeric: 'yes',
      },
   ],
   refers: [
      "Bang H, Edwards AM, Bomback AS, et al. Development and validation of a patient self-assessment score for diabetes risk. Ann Intern Med. 2009;151(11):775-83.",
      "Poltavskiy E, Kim DJ, Bang H. Comparison of screening scores for diabetes and prediabetes. Diabetes Res Clin Pract. 2016;118:146-53.",
      "Woo YC, Lee CH, Fong CHY, Tso AWK, Cheung BMY, Lam KSL. Validation of the diabetes screening tools proposed by the American Diabetes Association in an aging Chinese population. PLoS ONE. 2017;12(9):e0184840.",
      "American Diabetes Association. 2. Classification and Diagnosis of Diabetes. Diabetes Care. 2016;39 Suppl 1:S13-22.",
      "Lee YH, Bang H, Kim DJ. How to Establish Clinical Prediction Models. Endocrinol Metab (Seoul). 2016;31(1):38-44.",
      "Buijsse B, Simmons RK, Griffin SJ, Schulze MB. Risk assessment tools for identifying individuals at risk of developing type 2 diabetes. Epidemiol Rev. 2011;33:46-62.",
   ]
}