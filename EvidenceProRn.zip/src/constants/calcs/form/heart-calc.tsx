export const heartCalc = {
   id: "EV-CALC-22",
   link: "heart",
   title: "Шкала HEART",
   text: "6-недельная оценка риска серьезных сердечных событий",
   description: {
      descriptionMain: [
         "Шкала HEART (History, EKG, Age, Risk factors, Troponin - HEART) - оценивает 6-недельный риск серьезных сердечных событий. Ее можно использовать у всех пациентов с недифференцированной болью в груди при подозрении на острый коронарный синдром. \nШкала была разработана Backus-ом в 2008 году. Когорта (группа) состояла из 122 пациентов отделения неотложной помощи, у которых была боль после операции в груди. Все пациенты, у которых была боль в груди, были включены, независимо от возраста, первоначального диагноза и лечения. В исследование не были включены пациенты со значительным отклонением сегмента ST."
      ],
      descriptionTable: [
         {
            headData: ['Результат', 'Баллы'],
            bodyData: [
               ['Риск неблагоприятного сердечного события: 0.9 - 1.7%', 'До 3 (включительно)'],
               ['Риск неблагоприятного сердечного события: 12 - 16.6%', '4 - 6'],
               ['Риск неблагоприятного сердечного события: 50 - 65%', '7 и больше'],
            ],
            flexNums: [1, 1]
         }
      ]
   },
   form: [
      {
         type: 'radio',
         radioButtons: [
            {
               id: '0',
               label: 'Небольшое сомнение',
               value: '0',
            },
            {
               id: '1',
               label: 'Умеренное сомнение',
               value: '1',
            },
            {
               id: '2',
               label: 'Большое сомнение',
               value: '2',
            }
         ],
         label: 'Анамнез (история болезни)',
         inputId: 'anamnesis',
         required: 'yes',
         numeric: 'yes',
         smallText: 'Например: боль за грудиной, давящая боль, отдающая в челюсть/левое плечо/руку, продолжительность боли 5-15 минут, боли усиливаются при физической нагрузке/эмоциях/холоде, сопровождаются потоотделением, тошнотой/рвотой, реакция на нитраты возникает в течение нескольких минут. Признаки боли в груди низкого риска включают: четко локализованную, острую, не давящую, без потоотделения, без тошноты/рвоты и воспроизводимую при пальпации.'
      },
      {
         type: 'radio',
         radioButtons: [
            {
               id: '0',
               label: 'Норма',
               value: '0',
            },
            {
               id: '1',
               label: 'Неспецифическое расстройство реполяризации',
               value: '1',
            },
            {
               id: '2',
               label: 'Значительное отклонение сегмента ST',
               value: '2',
            }
         ],
         label: 'Электрокардиограмма',
         inputId: 'ecg',
         required: 'yes',
         numeric: 'yes',
         smallText: 'Выберите вариант 2, если нет отклонения сегмента ST, но есть блокада левой ножки пучка Гиса, гипертрофия левого желудочка или измененная реполяризация (например, дигоксин). Выберите вариант 3, если отклонение сегмента ST не связано с блокадой левой ножки пучка Гиса, гипертрофией левого желудочка или приемом дигоксина.'
      },
      {
         type: 'radio',
         radioButtons: [
            {
               id: '0',
               label: 'До 45',
               value: '0',
            },
            {
               id: '1',
               label: '45 - 64',
               value: '1',
            },
            {
               id: '2',
               label: '65 и больше',
               value: '2',
            }
         ],
         label: 'Возраст',
         inputId: 'age',
         required: 'yes',
         numeric: 'yes',
      },
      {
         type: 'radio',
         radioButtons: [
            {
               id: '0',
               label: 'Нет выявленных факторов риска',
               value: '0',
            },
            {
               id: '1',
               label: '1–2 фактора риска',
               value: '1',
            },
            {
               id: '2',
               label: '3 или более факторов риска или наличие атеросклеротического заболевания',
               value: '2',
            }
         ],
         label: 'Факторы риска',
         inputId: 'risks',
         required: 'yes',
         numeric: 'yes',
         smallText: 'Гипертония, гиперхолестеринемия, сахарный диабет, ожирение (индекс массы тела >30 кг/м2), курение (текущее или прекращение курения ≤3 месяцев назад), положительный семейный анамнез (родители, братья и сестры с сердечно-сосудистыми заболеваниями в возрасте до 65 лет), атеросклеротическое заболевание: инфаркт миокарда, чрескожное коронарное вмешательство/аортокоронарное шунтирование, нарушение мозгового кровообращения/транзиторная ишемическая атака или заболевание периферических сосудов.'
      },
      {
         type: 'radio',
         radioButtons: [
            {
               id: '0',
               label: 'Нормально или ниже',
               value: '0',
            },
            {
               id: '1',
               label: 'В нормальном диапазоне 1 - 3',
               value: '1',
            },
            {
               id: '2',
               label: 'В нормальном 3 и выше',
               value: '2',
            }
         ],
         label: 'Начальный тропонин',
         inputId: 'troponin',
         required: 'yes',
         numeric: 'yes',
         smallText: 'Используйте результаты локального анализа чувствительности к тропонину и соответствующие пороговые значения.'
      }
   ],
   refers: [
      "Six AJ, Backus BE, Kelder JC. Chest pain in the emergency room: value of the HEART score. Neth Heart J. 2008;16(6):191-6",
      "Backus BE, Six AJ, Kelder JC, et al. Chest pain in the emergency room: a multicenter validation of the HEART Score. Crit Pathw Cardiol. 2010;9(3):164-9",
      "Backus BE, Six AJ, Kelder JC, et al. A prospective validation of the HEART score for chest pain patients at the emergency department. Int J Cardiol. 2013;168(3):2153-8",
      "Stopyra JP, Riley RF, Hiestand BC, et al. The HEART Pathway Randomized Controlled Trial One Year Outcomes. Acad Emerg Med. 2018",
      "Ljung L, Lindahl B, Eggers KM, et al. A Rule-Out Strategy Based on High-Sensitivity Troponin and HEART Score Reduces Hospital Admissions. Ann Emerg Med. 2019;73(5):491-499",
      "Mahler SA, Riley RF, Hiestand BC, et al. The HEART Pathway randomized trial: identifying emergency department patients with acute chest pain for early discharge. Circ Cardiovasc Qual Outcomes. 2015;8(2):195-203",
      "Nieuwets A, Poldervaart JM, Reitsma JB, et al. Medical consumption compared for TIMI and HEART score in chest pain patients at the emergency department: a retrospective cost analysis. BMJ Open. 2016;6(6):e010694",
      "Poldervaart JM, Langedijk M, Backus BE, et al. Comparison of the GRACE, HEART and TIMI score to predict major adverse cardiac events in chest pain patients at the emergency department. Int J Cardiol. 2017;227:656-661",
      "Poldervaart JM, Reitsma JB, Backus BE, et al. Effect of Using the HEART Score in Patients With Chest Pain in the Emergency Department: A Stepped-Wedge, Cluster Randomized Trial. Ann Intern Med. 2017",
   ]
}