export const cambridgeDiabCalc = {
   id: "EV-CALC-47",
   link: "cambridge-diabetes-risk",
   title: "Кембриджская шкала риска диабета",
   text: "Прогнозирует риск ранее недиагностированного диабета 2 типа",
   description: {
      descriptionMain: [
         "Прогнозирует риск ранее недиагностированного диабета 2 типа. Используется для оценки риска, что у пациента в настоящее время имеется недиагностированный диабет (т. е. НЕ риска развития диабета в будущем). В исследовании приняли участие преимущественно белые пациенты из числа англичан, поэтому следует соблюдать осторожность при использовании препарата в других группах населения.",
      ]
   },
   form: [
   {
      type: 'radio',
      radioButtons: [
            {
               id: '0',
               label: 'Мужской',
               value: '0',
            },
            {
               id: '1',
               label: 'Женский',
               value: '1',
            }
      ],
      label: 'Пол',
      inputId: 'gender',
      required: 'yes',
      numeric: 'no',
   },
   {
      type: 'radio',
      radioButtons: [
            {
               id: '0',
               label: 'Нет',
               value: '0',
            },
            {
               id: '1',
               label: 'Да',
               value: '1',
            }
      ],
      label: 'Назначенные антигипертензивные препараты',
      inputId: 'hypert',
      required: 'yes',
      numeric: 'no',
   },
   {
      type: 'radio',
      radioButtons: [
            {
               id: '0',
               label: 'Нет',
               value: '0',
            },
            {
               id: '1',
               label: 'Да',
               value: '1',
            }
      ],
      label: 'Назначенные стероиды',
      inputId: 'ster',
      required: 'yes',
      numeric: 'no',
   },
   {
      type: 'input',
      label: 'Возраст',
      inputId: 'age',
      placeholder: '1 - 100',
      error: 'Возраст должен быть 1-100',
      span: 'лет',
      min: 1,
      max: 100,
      required: 'yes',
      pattern: "nodot",
      ext: 0,
      spanWidth: 120
   },
   {
      type: 'radio',
      radioButtons: [
            {
               id: '0',
               label: '<25',
               value: '0',
            },
            {
               id: '0.699',
               label: '≥25 - <27,5',
               value: '0.699',
            },
            {
               id: '1.97',
               label: '≥27,5 - <30',
               value: '1.97',
            },
            {
               id: '2.518',
               label: '≥30',
               value: '2.518',
            }
      ],
      label: 'Индекс массы тела (кг/м²)',
      inputId: 'bmi',
      required: 'yes',
      numeric: 'no',
   },
   {
      type: 'radio',
      radioButtons: [
            {
               id: '0',
               label: 'Нет родственников первой степени родства, больных диабетом',
               value: '0',
            },
            {
               id: '0.728',
               label: 'У родителя или брата/сестры диабет',
               value: '0.728',
            },
            {
               id: '0.753',
               label: 'У родителя и брата/сестры диабет',
               value: '0.753',
            }
      ],
      label: 'Семейный анамнез',
      inputId: 'famil',
      required: 'yes',
      numeric: 'no',
   },
   {
      type: 'radio',
      radioButtons: [
            {
               id: '0',
               label: 'Некурящий',
               value: '0',
            },
            {
               id: '-0.218',
               label: 'Бывший курильщик',
               value: '-0.218',
            },
            {
               id: '0.855',
               label: 'Курильщик',
               value: '0.855',
            }
      ],
      label: 'Анамнез курения',
      inputId: 'smoking',
      required: 'yes',
      numeric: 'no',
   },
],
refers: [
   "Griffin SJ, Little PS, Hales CN, Kinmonth AL, Wareham NJ. Diabetes risk score: towards earlier detection of type 2 diabetes in general practice. Diabetes Metab Res Rev. 2000;16(3):164-71.",
   "Park PJ, Griffin SJ, Sargeant L, Wareham NJ. The performance of a risk score in predicting undiagnosed hyperglycemia. Diabetes Care. 2002;25(6):984-8.",
   "Chamnan P, Simmons RK, Hori H, et al. A simple risk score using routine data for predicting cardiovascular disease in primary care. Br J Gen Pract. 2010;60(577):e327-34.",
   "Rahman M, Simmons RK, Harding AH, Wareham NJ, Griffin SJ. A simple risk score identifies individuals at high risk of developing Type 2 diabetes: a prospective cohort study. Fam Pract. 2008;25(3):191-6.",
   "Spijkerman AM, Yuyun MF, Griffin SJ, Dekker JM, Nijpels G, Wareham NJ. The performance of a risk score as a screening test for undiagnosed hyperglycemia in ethnic minority groups: data from the 1999 health survey for England. Diabetes Care. 2004;27(1):116-22.",
   "Kengne AP, Beulens JW, Peelen LM, et al. Non-invasive risk scores for prediction of type 2 diabetes (EPIC-InterAct): a validation of existing models. Lancet Diabetes Endocrinol. 2014;2(1):19-29.",
   "Wareham NJ, Griffin SJ. Risk scores for predicting type 2 diabetes: comparing axes and spades. Diabetologia. 2011;54(5):994-5.",
   "Simmons RK, Harding AH, Wareham NJ, Griffin SJ. Do simple questions about diet and physical activity help to identify those at risk of Type 2 diabetes?. Diabet Med. 2007;24(8):830-5.",
   "Heldgaard PE, Griffin SJ. Routinely collected general practice data aids identification of people with hyperglycaemia and metabolic syndrome. Diabet Med. 2006;23(9):996-1002.",
   "Spijkerman A, Griffin S, Dekker J, Nijpels G, Wareham NJ. What is the risk of mortality for people who are screen positive in a diabetes screening programme but who do not have diabetes on biochemical testing? Diabetes screening programmes from a public health perspective. J Med Screen. 2002;9(4):187-90.",
]
}