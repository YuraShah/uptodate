export const benzQuestCalc = {
   id: "EV-CALC-36",
   link: "benzodiazepine-questionnaire",
   title: "Опросник симптомов отмены бензодиазепинов",
   text: "Помогает обнаружить и оценить симптомы отмены бензодиазепинов",
   description: {
      descriptionMain: [
         "Опросник симптомов отмены бензодиазепинов используется для выявления и оценки симптомов, которые могут возникнуть при прекращении приема бензодиазепинов. Это важный инструмент для медицинских работников, позволяющий им оценить тяжесть симптомов отмены и разработать соответствующий план лечения для пациентов, которые переживают период отмены этих препаратов",
         "Если человек набирает в общей сложности более 20 баллов, вероятность возникновения симптомов отмены высока."
      ]
   },
   form: [
      {
         type: 'radio',
         radioButtons: [
            {
               id: '0',
               label: 'Нет',
               value: '0',
            },
            {
               id: '1',
               label: 'Да - средний',
               value: '1',
            },
            {
               id: '2',
               label: 'Да - тяжелый',
               value: '2',
            }
         ],
         label: 'Чувство нереальности',
         inputId: 'unreal',
         required: 'yes',
         numeric: 'yes',
      },
      {
         type: 'radio',
         radioButtons: [
            {
               id: '0',
               label: 'Нет',
               value: '0',
            },
            {
               id: '1',
               label: 'Да - средний',
               value: '1',
            },
            {
               id: '2',
               label: 'Да - тяжелый',
               value: '2',
            }
         ],
         label: 'Очень чувствителен к шуму',
         inputId: 'noise',
         required: 'yes',
         numeric: 'yes',
      },
      {
         type: 'radio',
         radioButtons: [
            {
               id: '0',
               label: 'Нет',
               value: '0',
            },
            {
               id: '1',
               label: 'Да - средний',
               value: '1',
            },
            {
               id: '2',
               label: 'Да - тяжелый',
               value: '2',
            }
         ],
         label: 'Очень чувствителен к свету',
         inputId: 'light',
         required: 'yes',
         numeric: 'yes',
      },
      {
         type: 'radio',
         radioButtons: [
            {
               id: '0',
               label: 'Нет',
               value: '0',
            },
            {
               id: '1',
               label: 'Да - средний',
               value: '1',
            },
            {
               id: '2',
               label: 'Да - тяжелый',
               value: '2',
            }
         ],
         label: 'Очень чувствителен к запаху',
         inputId: 'smell',
         required: 'yes',
         numeric: 'yes',
      },
      {
         type: 'radio',
         radioButtons: [
            {
               id: '0',
               label: 'Нет',
               value: '0',
            },
            {
               id: '1',
               label: 'Да - средний',
               value: '1',
            },
            {
               id: '2',
               label: 'Да - тяжелый',
               value: '2',
            }
         ],
         label: 'Очень чувствителен к прикосновению',
         inputId: 'touch',
         required: 'yes',
         numeric: 'yes',
      },
      {
         type: 'radio',
         radioButtons: [
            {
               id: '0',
               label: 'Нет',
               value: '0',
            },
            {
               id: '1',
               label: 'Да - средний',
               value: '1',
            },
            {
               id: '2',
               label: 'Да - тяжелый',
               value: '2',
            }
         ],
         label: 'Необычный привкус во рту',
         inputId: 'mouth',
         required: 'yes',
         numeric: 'yes',
      },
      {
         type: 'radio',
         radioButtons: [
            {
               id: '0',
               label: 'Нет',
               value: '0',
            },
            {
               id: '1',
               label: 'Да - средний',
               value: '1',
            },
            {
               id: '2',
               label: 'Да - тяжелый',
               value: '2',
            }
         ],
         label: 'Мышечная боль',
         inputId: 'pain',
         required: 'yes',
         numeric: 'yes',
      },
      {
         type: 'radio',
         radioButtons: [
            {
               id: '0',
               label: 'Нет',
               value: '0',
            },
            {
               id: '1',
               label: 'Да - средний',
               value: '1',
            },
            {
               id: '2',
               label: 'Да - тяжелый',
               value: '2',
            }
         ],
         label: 'Мышечные судороги',
         inputId: 'twitch',
         required: 'yes',
         numeric: 'yes',
      },
      {
         type: 'radio',
         radioButtons: [
            {
               id: '0',
               label: 'Нет',
               value: '0',
            },
            {
               id: '1',
               label: 'Да - средний',
               value: '1',
            },
            {
               id: '2',
               label: 'Да - тяжелый',
               value: '2',
            }
         ],
         label: 'Покалывание',
         inputId: 'pins',
         required: 'yes',
         numeric: 'yes',
      },
      {
         type: 'radio',
         radioButtons: [
            {
               id: '0',
               label: 'Нет',
               value: '0',
            },
            {
               id: '1',
               label: 'Да - средний',
               value: '1',
            },
            {
               id: '2',
               label: 'Да - тяжелый',
               value: '2',
            }
         ],
         label: 'Головокружение',
         inputId: 'dizz',
         required: 'yes',
         numeric: 'yes',
      },
      {
         type: 'radio',
         radioButtons: [
            {
               id: '0',
               label: 'Нет',
               value: '0',
            },
            {
               id: '1',
               label: 'Да - средний',
               value: '1',
            },
            {
               id: '2',
               label: 'Да - тяжелый',
               value: '2',
            }
         ],
         label: 'Чувство слабости',
         inputId: 'faint',
         required: 'yes',
         numeric: 'yes',
      },
      {
         type: 'radio',
         radioButtons: [
            {
               id: '0',
               label: 'Нет',
               value: '0',
            },
            {
               id: '1',
               label: 'Да - средний',
               value: '1',
            },
            {
               id: '2',
               label: 'Да - тяжелый',
               value: '2',
            }
         ],
         label: 'Тошнота',
         inputId: 'sick',
         required: 'yes',
         numeric: 'yes',
      },
      {
         type: 'radio',
         radioButtons: [
            {
               id: '0',
               label: 'Нет',
               value: '0',
            },
            {
               id: '1',
               label: 'Да - средний',
               value: '1',
            },
            {
               id: '2',
               label: 'Да - тяжелый',
               value: '2',
            }
         ],
         label: 'Депрессия',
         inputId: 'depr',
         required: 'yes',
         numeric: 'yes',
      },
      {
         type: 'radio',
         radioButtons: [
            {
               id: '0',
               label: 'Нет',
               value: '0',
            },
            {
               id: '1',
               label: 'Да - средний',
               value: '1',
            },
            {
               id: '2',
               label: 'Да - тяжелый',
               value: '2',
            }
         ],
         label: 'Глазная боль',
         inputId: 'sore',
         required: 'yes',
         numeric: 'yes',
      },
      {
         type: 'radio',
         radioButtons: [
            {
               id: '0',
               label: 'Нет',
               value: '0',
            },
            {
               id: '1',
               label: 'Да - средний',
               value: '1',
            },
            {
               id: '2',
               label: 'Да - тяжелый',
               value: '2',
            }
         ],
         label: 'Ощущение движения объектов, когда они неподвижны',
         inputId: 'feel',
         required: 'yes',
         numeric: 'yes',
      },
      {
         type: 'radio',
         radioButtons: [
            {
               id: '0',
               label: 'Нет',
               value: '0',
            },
            {
               id: '1',
               label: 'Да - средний',
               value: '1',
            },
            {
               id: '2',
               label: 'Да - тяжелый',
               value: '2',
            }
         ],
         label: 'Видеть или слышать вещи, которых на самом деле нет (галлюцинации)',
         inputId: 'seein',
         required: 'yes',
         numeric: 'yes',
      },
      {
         type: 'radio',
         radioButtons: [
            {
               id: '0',
               label: 'Нет',
               value: '0',
            },
            {
               id: '1',
               label: 'Да - средний',
               value: '1',
            },
            {
               id: '2',
               label: 'Да - тяжелый',
               value: '2',
            }
         ],
         label: 'Невозможность управления движением',
         inputId: 'unable',
         required: 'yes',
         numeric: 'yes',
      },
      {
         type: 'radio',
         radioButtons: [
            {
               id: '0',
               label: 'Нет',
               value: '0',
            },
            {
               id: '1',
               label: 'Да - средний',
               value: '1',
            },
            {
               id: '2',
               label: 'Да - тяжелый',
               value: '2',
            }
         ],
         label: 'Потеря памяти',
         inputId: 'memory',
         required: 'yes',
         numeric: 'yes',
      },
      {
         type: 'radio',
         radioButtons: [
            {
               id: '0',
               label: 'Нет',
               value: '0',
            },
            {
               id: '1',
               label: 'Да - средний',
               value: '1',
            },
            {
               id: '2',
               label: 'Да - тяжелый',
               value: '2',
            }
         ],
         label: 'Потеря аппетита',
         inputId: 'appetite',
         required: 'yes',
         numeric: 'yes',
      },
   ],
   refers: [
      "Tyrer P, Murphy S, Riley P (1990). ‘The benzodiazepine withdrawal symptom questionnaire’. Journal of Affective Disorders, 19(1): 53-61."
   ]
}