export const cmaiCalc = {
   id: "EV-CALC-38",
   link: "cohen-mansfield-agitation-inventory",
   title: "Опросник по агитации Коэна-Мэнсфилда (Cohen-Mansfield Agitation Inventory)",
   text: "Инструмент для оценки уровня возбуждения и беспокойного поведения у пожилых людей",
   description: {
      descriptionMain: [
         "Опросник по агитации Коэна-Мэнсфилда - инструмент для оценки уровня возбуждения и беспокойного поведения у пожилых людей, особенно у тех, кто страдает деменцией или другими когнитивными нарушениями. Эта шкала используется для мониторинга пациентов.",
         "Чем выше общий балл, тем тяжелее симптомы агитации у пациента.",
         "Агитация: состояние повышенной тревожности, раздражительности или волнения, выражающееся в физическом или вербальном поведении. Это часто встречается у людей с когнитивными нарушениями, такими как деменция, и может включать беспокойные движения, повторяющееся поведение, агрессивные вспышки или словесные выражения разочарования и волнения.",
      ],
      descriptionTable: [
         {
            headData: ['Баллы', 'Уровень агитации'],
            bodyData: [
               ["29-46", "Низкий"],
               ["47-87", "Средний"],
               ["≥88", "Высокий"]
            ],
            flexNums: [1, 1]
         }
      ]
   },
   form: [
      {
         type: 'title',
         formTitle: 'Физический/агрессивный'
      },
      {
         type: 'radio',
         label: 'Ударить (включая себя)',
         inputId: 'hit',
         required: 'yes',
         radioButtons: [
            {
               id: '1',
               label: 'Никогда',
               value: '1',
            },
            {
               id: '2',
               label: 'Реже одного раза в неделю',
               value: '2',
            },
            {
               id: '3',
               label: '1 или 2 раза в неделю',
               value: '3',
            },
            {
               id: '4',
               label: 'Несколько раз в неделю',
               value: '4',
            },
            {
               id: '5',
               label: '1 или 2 раза в день',
               value: '5',
            },
            {
               id: '6',
               label: 'Несколько раз в день',
               value: '6',
            },
            {
               id: '7',
               label: 'Несколько раз в час',
               value: '7',
            }
         ],
         numeric: 'yes',
      },
      {
         type: 'radio',
         label: 'Удар ногой',
         inputId: 'kick',
         required: 'yes',
         radioButtons: [
            {
               id: '1',
               label: 'Никогда',
               value: '1',
            },
            {
               id: '2',
               label: 'Реже одного раза в неделю',
               value: '2',
            },
            {
               id: '3',
               label: '1 или 2 раза в неделю',
               value: '3',
            },
            {
               id: '4',
               label: 'Несколько раз в неделю',
               value: '4',
            },
            {
               id: '5',
               label: '1 или 2 раза в день',
               value: '5',
            },
            {
               id: '6',
               label: 'Несколько раз в день',
               value: '6',
            },
            {
               id: '7',
               label: 'Несколько раз в час',
               value: '7',
            }
         ],
         numeric: 'yes',
      },
      {
         type: 'radio',
         label: 'Ловить людей',
         inputId: 'grab',
         required: 'yes',
         radioButtons: [
            {
               id: '1',
               label: 'Никогда',
               value: '1',
            },
            {
               id: '2',
               label: 'Реже одного раза в неделю',
               value: '2',
            },
            {
               id: '3',
               label: '1 или 2 раза в неделю',
               value: '3',
            },
            {
               id: '4',
               label: 'Несколько раз в неделю',
               value: '4',
            },
            {
               id: '5',
               label: '1 или 2 раза в день',
               value: '5',
            },
            {
               id: '6',
               label: 'Несколько раз в день',
               value: '6',
            },
            {
               id: '7',
               label: 'Несколько раз в час',
               value: '7',
            }
         ],
         numeric: 'yes',
      },
      {
         type: 'radio',
         label: 'Толкать',
         inputId: 'push',
         required: 'yes',
         radioButtons: [
            {
               id: '1',
               label: 'Никогда',
               value: '1',
            },
            {
               id: '2',
               label: 'Реже одного раза в неделю',
               value: '2',
            },
            {
               id: '3',
               label: '1 или 2 раза в неделю',
               value: '3',
            },
            {
               id: '4',
               label: 'Несколько раз в неделю',
               value: '4',
            },
            {
               id: '5',
               label: '1 или 2 раза в день',
               value: '5',
            },
            {
               id: '6',
               label: 'Несколько раз в день',
               value: '6',
            },
            {
               id: '7',
               label: 'Несколько раз в час',
               value: '7',
            }
         ],
         numeric: 'yes',
      },
      {
         type: 'radio',
         label: 'Бросание предметов',
         inputId: 'throw',
         required: 'yes',
         radioButtons: [
            {
               id: '1',
               label: 'Никогда',
               value: '1',
            },
            {
               id: '2',
               label: 'Реже одного раза в неделю',
               value: '2',
            },
            {
               id: '3',
               label: '1 или 2 раза в неделю',
               value: '3',
            },
            {
               id: '4',
               label: 'Несколько раз в неделю',
               value: '4',
            },
            {
               id: '5',
               label: '1 или 2 раза в день',
               value: '5',
            },
            {
               id: '6',
               label: 'Несколько раз в день',
               value: '6',
            },
            {
               id: '7',
               label: 'Несколько раз в час',
               value: '7',
            }
         ],
         numeric: 'yes',
      },
      {
         type: 'radio',
         label: 'Укусить',
         inputId: 'bit',
         required: 'yes',
         radioButtons: [
            {
               id: '1',
               label: 'Никогда',
               value: '1',
            },
            {
               id: '2',
               label: 'Реже одного раза в неделю',
               value: '2',
            },
            {
               id: '3',
               label: '1 или 2 раза в неделю',
               value: '3',
            },
            {
               id: '4',
               label: 'Несколько раз в неделю',
               value: '4',
            },
            {
               id: '5',
               label: '1 или 2 раза в день',
               value: '5',
            },
            {
               id: '6',
               label: 'Несколько раз в день',
               value: '6',
            },
            {
               id: '7',
               label: 'Несколько раз в час',
               value: '7',
            }
         ],
         numeric: 'yes',
      },
      {
         type: 'radio',
         label: 'Царапать',
         inputId: 'scratch',
         required: 'yes',
         radioButtons: [
            {
               id: '1',
               label: 'Никогда',
               value: '1',
            },
            {
               id: '2',
               label: 'Реже одного раза в неделю',
               value: '2',
            },
            {
               id: '3',
               label: '1 или 2 раза в неделю',
               value: '3',
            },
            {
               id: '4',
               label: 'Несколько раз в неделю',
               value: '4',
            },
            {
               id: '5',
               label: '1 или 2 раза в день',
               value: '5',
            },
            {
               id: '6',
               label: 'Несколько раз в день',
               value: '6',
            },
            {
               id: '7',
               label: 'Несколько раз в час',
               value: '7',
            }
         ],
         numeric: 'yes',
      },
      {
         type: 'radio',
         label: 'Плюнуть',
         inputId: 'split',
         required: 'yes',
         radioButtons: [
            {
               id: '1',
               label: 'Никогда',
               value: '1',
            },
            {
               id: '2',
               label: 'Реже одного раза в неделю',
               value: '2',
            },
            {
               id: '3',
               label: '1 или 2 раза в неделю',
               value: '3',
            },
            {
               id: '4',
               label: 'Несколько раз в неделю',
               value: '4',
            },
            {
               id: '5',
               label: '1 или 2 раза в день',
               value: '5',
            },
            {
               id: '6',
               label: 'Несколько раз в день',
               value: '6',
            },
            {
               id: '7',
               label: 'Несколько раз в час',
               value: '7',
            }
         ],
         numeric: 'yes',
      },
      {
         type: 'radio',
         label: 'Причинение вреда себе или другим',
         inputId: 'hurt',
         required: 'yes',
         radioButtons: [
            {
               id: '1',
               label: 'Никогда',
               value: '1',
            },
            {
               id: '2',
               label: 'Реже одного раза в неделю',
               value: '2',
            },
            {
               id: '3',
               label: '1 или 2 раза в неделю',
               value: '3',
            },
            {
               id: '4',
               label: 'Несколько раз в неделю',
               value: '4',
            },
            {
               id: '5',
               label: '1 или 2 раза в день',
               value: '5',
            },
            {
               id: '6',
               label: 'Несколько раз в день',
               value: '6',
            },
            {
               id: '7',
               label: 'Несколько раз в час',
               value: '7',
            }
         ],
         numeric: 'yes',
      },
      {
         type: 'radio',
         label: 'Уничтожение объектов или имущества',
         inputId: 'tear',
         required: 'yes',
         radioButtons: [
            {
               id: '1',
               label: 'Никогда',
               value: '1',
            },
            {
               id: '2',
               label: 'Реже одного раза в неделю',
               value: '2',
            },
            {
               id: '3',
               label: '1 или 2 раза в неделю',
               value: '3',
            },
            {
               id: '4',
               label: 'Несколько раз в неделю',
               value: '4',
            },
            {
               id: '5',
               label: '1 или 2 раза в день',
               value: '5',
            },
            {
               id: '6',
               label: 'Несколько раз в день',
               value: '6',
            },
            {
               id: '7',
               label: 'Несколько раз в час',
               value: '7',
            }
         ],
         numeric: 'yes',
      },
      {
         type: 'radio',
         label: 'Физические сексуальные домогательства',
         inputId: 'sexual',
         required: 'yes',
         radioButtons: [
            {
               id: '1',
               label: 'Никогда',
               value: '1',
            },
            {
               id: '2',
               label: 'Реже одного раза в неделю',
               value: '2',
            },
            {
               id: '3',
               label: '1 или 2 раза в неделю',
               value: '3',
            },
            {
               id: '4',
               label: 'Несколько раз в неделю',
               value: '4',
            },
            {
               id: '5',
               label: '1 или 2 раза в день',
               value: '5',
            },
            {
               id: '6',
               label: 'Несколько раз в день',
               value: '6',
            },
            {
               id: '7',
               label: 'Несколько раз в час',
               value: '7',
            }
         ],
         numeric: 'yes',
      },
      {
         type: 'title',
         formTitle: 'Физический/неагрессивный'
      },
      {
         type: 'radio',
         label: 'Бесцельно бродить',
         inputId: 'pace',
         required: 'yes',
         radioButtons: [
            {
               id: '1',
               label: 'Никогда',
               value: '1',
            },
            {
               id: '2',
               label: 'Реже одного раза в неделю',
               value: '2',
            },
            {
               id: '3',
               label: '1 или 2 раза в неделю',
               value: '3',
            },
            {
               id: '4',
               label: 'Несколько раз в неделю',
               value: '4',
            },
            {
               id: '5',
               label: '1 или 2 раза в день',
               value: '5',
            },
            {
               id: '6',
               label: 'Несколько раз в день',
               value: '6',
            },
            {
               id: '7',
               label: 'Несколько раз в час',
               value: '7',
            }
         ],
         numeric: 'yes',
      },
      {
         type: 'radio',
         label: 'Неподобающая одежда или раздевание',
         inputId: 'dress',
         required: 'yes',
         radioButtons: [
            {
               id: '1',
               label: 'Никогда',
               value: '1',
            },
            {
               id: '2',
               label: 'Реже одного раза в неделю',
               value: '2',
            },
            {
               id: '3',
               label: '1 или 2 раза в неделю',
               value: '3',
            },
            {
               id: '4',
               label: 'Несколько раз в неделю',
               value: '4',
            },
            {
               id: '5',
               label: '1 или 2 раза в день',
               value: '5',
            },
            {
               id: '6',
               label: 'Несколько раз в день',
               value: '6',
            },
            {
               id: '7',
               label: 'Несколько раз в час',
               value: '7',
            }
         ],
         numeric: 'yes',
      },
      {
         type: 'radio',
         label: 'Попытка появиться в другом месте',
         inputId: 'place',
         required: 'yes',
         radioButtons: [
            {
               id: '1',
               label: 'Никогда',
               value: '1',
            },
            {
               id: '2',
               label: 'Реже одного раза в неделю',
               value: '2',
            },
            {
               id: '3',
               label: '1 или 2 раза в неделю',
               value: '3',
            },
            {
               id: '4',
               label: 'Несколько раз в неделю',
               value: '4',
            },
            {
               id: '5',
               label: '1 или 2 раза в день',
               value: '5',
            },
            {
               id: '6',
               label: 'Несколько раз в день',
               value: '6',
            },
            {
               id: '7',
               label: 'Несколько раз в час',
               value: '7',
            }
         ],
         numeric: 'yes',
      },
      {
         type: 'radio',
         label: 'Преднамеренное падение',
         inputId: 'falling',
         required: 'yes',
         radioButtons: [
            {
               id: '1',
               label: 'Никогда',
               value: '1',
            },
            {
               id: '2',
               label: 'Реже одного раза в неделю',
               value: '2',
            },
            {
               id: '3',
               label: '1 или 2 раза в неделю',
               value: '3',
            },
            {
               id: '4',
               label: 'Несколько раз в неделю',
               value: '4',
            },
            {
               id: '5',
               label: '1 или 2 раза в день',
               value: '5',
            },
            {
               id: '6',
               label: 'Несколько раз в день',
               value: '6',
            },
            {
               id: '7',
               label: 'Несколько раз в час',
               value: '7',
            }
         ],
         numeric: 'yes',
      },
      {
         type: 'radio',
         label: 'Есть/пить неподходящие вещества',
         inputId: 'eating',
         required: 'yes',
         radioButtons: [
            {
               id: '1',
               label: 'Никогда',
               value: '1',
            },
            {
               id: '2',
               label: 'Реже одного раза в неделю',
               value: '2',
            },
            {
               id: '3',
               label: '1 или 2 раза в неделю',
               value: '3',
            },
            {
               id: '4',
               label: 'Несколько раз в неделю',
               value: '4',
            },
            {
               id: '5',
               label: '1 или 2 раза в день',
               value: '5',
            },
            {
               id: '6',
               label: 'Несколько раз в день',
               value: '6',
            },
            {
               id: '7',
               label: 'Несколько раз в час',
               value: '7',
            }
         ],
         numeric: 'yes',
      },
      {
         type: 'radio',
         label: 'Неправильное обращение с предметами',
         inputId: 'handling',
         required: 'yes',
         radioButtons: [
            {
               id: '1',
               label: 'Никогда',
               value: '1',
            },
            {
               id: '2',
               label: 'Реже одного раза в неделю',
               value: '2',
            },
            {
               id: '3',
               label: '1 или 2 раза в неделю',
               value: '3',
            },
            {
               id: '4',
               label: 'Несколько раз в неделю',
               value: '4',
            },
            {
               id: '5',
               label: '1 или 2 раза в день',
               value: '5',
            },
            {
               id: '6',
               label: 'Несколько раз в день',
               value: '6',
            },
            {
               id: '7',
               label: 'Несколько раз в час',
               value: '7',
            }
         ],
         numeric: 'yes',
      },
      {
         type: 'radio',
         label: 'Хранение предметов',
         inputId: 'hiding',
         required: 'yes',
         radioButtons: [
            {
               id: '1',
               label: 'Никогда',
               value: '1',
            },
            {
               id: '2',
               label: 'Реже одного раза в неделю',
               value: '2',
            },
            {
               id: '3',
               label: '1 или 2 раза в неделю',
               value: '3',
            },
            {
               id: '4',
               label: 'Несколько раз в неделю',
               value: '4',
            },
            {
               id: '5',
               label: '1 или 2 раза в день',
               value: '5',
            },
            {
               id: '6',
               label: 'Несколько раз в день',
               value: '6',
            },
            {
               id: '7',
               label: 'Несколько раз в час',
               value: '7',
            }
         ],
         numeric: 'yes',
      },
      {
         type: 'radio',
         label: 'Накопление предметов',
         inputId: 'hoarding',
         required: 'yes',
         radioButtons: [
            {
               id: '1',
               label: 'Никогда',
               value: '1',
            },
            {
               id: '2',
               label: 'Реже одного раза в неделю',
               value: '2',
            },
            {
               id: '3',
               label: '1 или 2 раза в неделю',
               value: '3',
            },
            {
               id: '4',
               label: 'Несколько раз в неделю',
               value: '4',
            },
            {
               id: '5',
               label: '1 или 2 раза в день',
               value: '5',
            },
            {
               id: '6',
               label: 'Несколько раз в день',
               value: '6',
            },
            {
               id: '7',
               label: 'Несколько раз в час',
               value: '7',
            }
         ],
         numeric: 'yes',
      },
      {
         type: 'radio',
         label: 'Выполнение повторяющихся форм',
         inputId: 'performing',
         required: 'yes',
         radioButtons: [
            {
               id: '1',
               label: 'Никогда',
               value: '1',
            },
            {
               id: '2',
               label: 'Реже одного раза в неделю',
               value: '2',
            },
            {
               id: '3',
               label: '1 или 2 раза в неделю',
               value: '3',
            },
            {
               id: '4',
               label: 'Несколько раз в неделю',
               value: '4',
            },
            {
               id: '5',
               label: '1 или 2 раза в день',
               value: '5',
            },
            {
               id: '6',
               label: 'Несколько раз в день',
               value: '6',
            },
            {
               id: '7',
               label: 'Несколько раз в час',
               value: '7',
            }
         ],
         numeric: 'yes',
      },
      {
         type: 'radio',
         label: 'Общая тревожность',
         inputId: 'restless',
         required: 'yes',
         radioButtons: [
            {
               id: '1',
               label: 'Никогда',
               value: '1',
            },
            {
               id: '2',
               label: 'Реже одного раза в неделю',
               value: '2',
            },
            {
               id: '3',
               label: '1 или 2 раза в неделю',
               value: '3',
            },
            {
               id: '4',
               label: 'Несколько раз в неделю',
               value: '4',
            },
            {
               id: '5',
               label: '1 или 2 раза в день',
               value: '5',
            },
            {
               id: '6',
               label: 'Несколько раз в день',
               value: '6',
            },
            {
               id: '7',
               label: 'Несколько раз в час',
               value: '7',
            }
         ],
         numeric: 'yes',
      },
      {
         type: 'title',
         formTitle: 'Вербальный/агрессивный'
      },
      {
         type: 'radio',
         label: 'Крики',
         inputId: 'scream',
         required: 'yes',
         radioButtons: [
            {
               id: '1',
               label: 'Никогда',
               value: '1',
            },
            {
               id: '2',
               label: 'Реже одного раза в неделю',
               value: '2',
            },
            {
               id: '3',
               label: '1 или 2 раза в неделю',
               value: '3',
            },
            {
               id: '4',
               label: 'Несколько раз в неделю',
               value: '4',
            },
            {
               id: '5',
               label: '1 или 2 раза в день',
               value: '5',
            },
            {
               id: '6',
               label: 'Несколько раз в день',
               value: '6',
            },
            {
               id: '7',
               label: 'Несколько раз в час',
               value: '7',
            }
         ],
         numeric: 'yes',
      },
      {
         type: 'radio',
         label: 'Вербальные сексуальные домогательства',
         inputId: 'verbalsex',
         required: 'yes',
         radioButtons: [
            {
               id: '1',
               label: 'Никогда',
               value: '1',
            },
            {
               id: '2',
               label: 'Реже одного раза в неделю',
               value: '2',
            },
            {
               id: '3',
               label: '1 или 2 раза в неделю',
               value: '3',
            },
            {
               id: '4',
               label: 'Несколько раз в неделю',
               value: '4',
            },
            {
               id: '5',
               label: '1 или 2 раза в день',
               value: '5',
            },
            {
               id: '6',
               label: 'Несколько раз в день',
               value: '6',
            },
            {
               id: '7',
               label: 'Несколько раз в час',
               value: '7',
            }
         ],
         numeric: 'yes',
      },
      {
         type: 'radio',
         label: 'Оскорбление или вербальная агрессия',
         inputId: 'verbagress',
         required: 'yes',
         radioButtons: [
            {
               id: '1',
               label: 'Никогда',
               value: '1',
            },
            {
               id: '2',
               label: 'Реже одного раза в неделю',
               value: '2',
            },
            {
               id: '3',
               label: '1 или 2 раза в неделю',
               value: '3',
            },
            {
               id: '4',
               label: 'Несколько раз в неделю',
               value: '4',
            },
            {
               id: '5',
               label: '1 или 2 раза в день',
               value: '5',
            },
            {
               id: '6',
               label: 'Несколько раз в день',
               value: '6',
            },
            {
               id: '7',
               label: 'Несколько раз в час',
               value: '7',
            }
         ],
         numeric: 'yes',
      },
      {
         type: 'title',
         formTitle: 'Вербальный/неагрессивный'
      },
      {
         type: 'radio',
         label: 'Повторяющиеся предложения или вопросы',
         inputId: 'sent',
         required: 'yes',
         radioButtons: [
            {
               id: '1',
               label: 'Никогда',
               value: '1',
            },
            {
               id: '2',
               label: 'Реже одного раза в неделю',
               value: '2',
            },
            {
               id: '3',
               label: '1 или 2 раза в неделю',
               value: '3',
            },
            {
               id: '4',
               label: 'Несколько раз в неделю',
               value: '4',
            },
            {
               id: '5',
               label: '1 или 2 раза в день',
               value: '5',
            },
            {
               id: '6',
               label: 'Несколько раз в день',
               value: '6',
            },
            {
               id: '7',
               label: 'Несколько раз в час',
               value: '7',
            }
         ],
         numeric: 'yes',
      },
      {
         type: 'radio',
         label: 'Странные звуки (странный смех или плач)',
         inputId: 'noise',
         required: 'yes',
         radioButtons: [
            {
               id: '1',
               label: 'Никогда',
               value: '1',
            },
            {
               id: '2',
               label: 'Реже одного раза в неделю',
               value: '2',
            },
            {
               id: '3',
               label: '1 или 2 раза в неделю',
               value: '3',
            },
            {
               id: '4',
               label: 'Несколько раз в неделю',
               value: '4',
            },
            {
               id: '5',
               label: '1 или 2 раза в день',
               value: '5',
            },
            {
               id: '6',
               label: 'Несколько раз в день',
               value: '6',
            },
            {
               id: '7',
               label: 'Несколько раз в час',
               value: '7',
            }
         ],
         numeric: 'yes',
      },
      {
         type: 'radio',
         label: 'Жалобы',
         inputId: 'complain',
         required: 'yes',
         radioButtons: [
            {
               id: '1',
               label: 'Никогда',
               value: '1',
            },
            {
               id: '2',
               label: 'Реже одного раза в неделю',
               value: '2',
            },
            {
               id: '3',
               label: '1 или 2 раза в неделю',
               value: '3',
            },
            {
               id: '4',
               label: 'Несколько раз в неделю',
               value: '4',
            },
            {
               id: '5',
               label: '1 или 2 раза в день',
               value: '5',
            },
            {
               id: '6',
               label: 'Несколько раз в день',
               value: '6',
            },
            {
               id: '7',
               label: 'Несколько раз в час',
               value: '7',
            }
         ],
         numeric: 'yes',
      },
      {
         type: 'radio',
         label: 'Негативизм',
         inputId: 'negativ',
         required: 'yes',
         radioButtons: [
            {
               id: '1',
               label: 'Никогда',
               value: '1',
            },
            {
               id: '2',
               label: 'Реже одного раза в неделю',
               value: '2',
            },
            {
               id: '3',
               label: '1 или 2 раза в неделю',
               value: '3',
            },
            {
               id: '4',
               label: 'Несколько раз в неделю',
               value: '4',
            },
            {
               id: '5',
               label: '1 или 2 раза в день',
               value: '5',
            },
            {
               id: '6',
               label: 'Несколько раз в день',
               value: '6',
            },
            {
               id: '7',
               label: 'Несколько раз в час',
               value: '7',
            }
         ],
         numeric: 'yes',
      },
      {
         type: 'radio',
         label: 'Постоянная необоснованная просьба о внимании или помощи',
         inputId: 'attent',
         required: 'yes',
         radioButtons: [
            {
               id: '1',
               label: 'Никогда',
               value: '1',
            },
            {
               id: '2',
               label: 'Реже одного раза в неделю',
               value: '2',
            },
            {
               id: '3',
               label: '1 или 2 раза в неделю',
               value: '3',
            },
            {
               id: '4',
               label: 'Несколько раз в неделю',
               value: '4',
            },
            {
               id: '5',
               label: '1 или 2 раза в день',
               value: '5',
            },
            {
               id: '6',
               label: 'Несколько раз в день',
               value: '6',
            },
            {
               id: '7',
               label: 'Несколько раз в час',
               value: '7',
            }
         ],
         numeric: 'yes',
      },
   ],
   refers: [
      "Adapted from Busto, U.E., Sykora, K. & Sellers, E.M. (1989). A clinical scale to assess benzodiazepine withdrawal. Journal of Clinical Psychopharmacology, 9 (6), 412-416."
   ]
}