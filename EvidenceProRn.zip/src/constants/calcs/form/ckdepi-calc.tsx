export const ckdepiCalc = {
   id: "EV-CALC-42",
   link: "egfr-ckd-epi",
   title: "Калькулятор скорости клубочковой фильтрации (формула CKD-EPI)",
   text: "Калькулятор скорости клубочковой фильтрации формулой CKD-EPI",
   description: {
      descriptionMain: [
         "Рекомендуемый метод оценки скорости клубочковой фильтрации (СКФ) у взрослых. Более точная формула, чем формула MDRD, особенно у людей с более высокими уровнями СКФ. Национальный почечный фонд рекомендует клиническим лабораториям начать использовать формулу CKD-EPI для оценки СКФ у взрослых. СКФ — лучший общий показатель функции почек.",
      ],
      descriptionTable: [
         {
            headData: ['Стадия', 'Описание', 'СКФ, мл/мин/1,73 м²'],
            bodyData: [
               ['1', 'Симптомы нефропатии, нормальный СКФ', '>90'],
               ['2', 'Симптомы нефропатии, малое снижение СКФ', '60-89'],
               ['3А', 'Умеренное снижение СКФ', '45-59'],
               ['3Б', 'Выраженное снижение СКФ', '30-44'],
               ['4', 'Сильное снижение СКФ', '15-29'],
               ['5', 'Терминальная стадия почечной недостаточности', '<15'],
            ],
            flexNums: [1, 2, 1]
         }
      ],
      descriptionLink: [
         {
            "name": "MDRD",
            "link": 'calcs/egfr-mdrd',
         }
      ]
   },
   form: [
      {
         type: 'radio',
         radioButtons: [
            {
               id: '1',
               label: 'Мужской',
               value: '1',
            },
            {
               id: '0',
               label: 'Женский',
               value: '0',
            }
         ],
         label: 'Пол',
         inputId: 'gender',
         required: 'yes',
      },
      {
         type: 'input',
         label: 'Возраст',
         inputId: 'age',
         placeholder: '1 - 100',
         error: 'Возраст должен быть 1-100',
         span: 'лет',
         min: 1,
         max: 100,
         required: 'yes',
         pattern: "nodot",
         spanWidth: 115,
         ext: 0,
      },
      {
         type: 'input',
         label: 'Креатинин плазмы',
         inputId: 'creatinine',
         placeholder1: '0.01 - 10',
         placeholder: '0.9 - 880',
         error1: 'Креатинин должен быть 0.01 - 10',
         error: 'Креатинин должен быть 0.9 - 880',
         span1: 'мг/дл',
         span: 'мкмоль/л',
         min1: 0.01,
         min: 0.9,
         max1: 10,
         max: 880,
         required: 'yes',
         pattern: "dot",
         ext: 1,
         spanWidth: 55
      },
   ],
   refers: [
      "Levey AS, Stevens LA, Schmid CH, et al. A new equation to estimate glomerular filtration rate. Ann Intern Med. 2009;150(9):604-12",
      "Inker LA, Schmid CH, Tighiouart H, et al. Estimating glomerular filtration rate from serum creatinine and cystatin C. N Engl J Med. 2012;367(1):20-9",
      "Inker LA, Eneanya ND, Coresh J, et al. New creatinine- and cystatin c-based equations to estimate gfr without race. N Engl J Med. Published online September 23, 2021",
      "KDIGO 2012 Clinical Practice Guideline for the Evaluation and Management of Chronic Kidney Disease",
      "KDIGO 2022 Clinical Practice Guideline for Diabetes Management in Chronic Kidney Disease",
      "Levey AS, Stevens LA. Estimating GFR using the CKD Epidemiology Collaboration (CKD-EPI) creatinine equation: more accurate GFR estimates, lower CKD prevalence estimates, and better risk predictions. Am J Kidney Dis. 2010;55(4):622-627",
      "Matsushita K, Selvin E, Bash LD, Astor BC, Coresh J. Risk implications of the new CKD Epidemiology Collaboration (CKD-EPI) equation compared with the MDRD Study equation for estimated GFR: the Atherosclerosis Risk in Communities (ARIC) Study. Am J Kidney Dis. 2010;55(4):648-659",
      "White SL, Polkinghorne KR, Atkins RC, Chadban SJ. Comparison of the prevalence and mortality risk of CKD in Australia using the CKD Epidemiology Collaboration (CKD-EPI) and Modification of Diet in Renal Disease (MDRD) Study GFR estimating equations: the AusDiab (Australian Diabetes, Obesity and Lifestyle) Study. Am J Kidney Dis. 2010;55(4):660-670",
      "Becker BN, Vassalotti JA. A software upgrade: CKD testing in 2010. Am J Kidney Dis. 2009;55(1):8-10",
   ]
}