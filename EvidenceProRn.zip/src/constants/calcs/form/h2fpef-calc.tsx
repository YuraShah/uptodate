export const h2fpefCalc = {
   id: "EV-CALC-27",
   link: "h2fpef",
   title: "Шкала H2FPEF",
   text: "Дифференциация одышки при сердечной недостаточности с сохраненной фракцией выброса от внесердечных причин",
   description: {
      descriptionMain: [
         "Дифференциация одышки при сердечной недостаточности с сохраненной фракцией выброса от внесердечных причин.",
      ],
   },
   form: [
      {
         type: 'input',
         label: 'Возраст',
         inputId: 'age',
         placeholder: '1 - 100',
         error: 'Возраст должен быть в диапазоне 1-100',
         span: 'лет',
         min: 1,
         max: 100,
         required: 'yes',
         pattern: "nodot",
         ext: 0,
         spanWidth: 115
      },
      {
         type: 'title',
         formTitle: '➪ Индекс массы тела',
         link: 'calcs/bmi',
      },
      {
         type: 'input',
         label: 'Индекс массы тела',
         inputId: 'bmi',
         placeholder: '10 - 30',
         error: 'Индекс массы тела должен быть в диапазоне 10 - 30',
         span: 'кг/м²',
         min: 10,
         max: 30,
         required: 'yes',
         pattern: "dot",
         ext: 0,
         spanWidth: 115
      },
      {
         type: 'input',
         label: 'Соотношение скорости раннего митрального потока к ранней диастолической скорости митрального кольца (E/e`)',
         inputId: 'ee',
         placeholder: '0 - 20',
         error: 'Значение должно быть в диапазоне 0 - 20',
         span: 'значение',
         min: 0,
         max: 20,
         required: 'yes',
         pattern: "nodot",
         ext: 0,
         spanWidth: 115
      },
      {
         type: 'input',
         label: 'Систолическое давление в легочной артерии',
         inputId: 'ps',
         placeholder: '0 - 100',
         error: 'Систолическое давление в легочной артерии должен быть в диапазоне 0 - 100',
         span: 'мм рт․с․',
         min: 0,
         max: 100,
         required: 'yes',
         pattern: "dot",
         ext: 0,
         spanWidth: 115
      },
      {
         type: 'radio',
         radioButtons: [
            {
               id: '1',
               label: 'Да',
               value: '1',
            },
            {
               id: '0',
               label: 'Нет',
               value: '0',
            }
         ],
         label: 'Мерцательная аритмия (из истории болезни и ЭКГ)',
         inputId: 'af',
         required: 'yes',
         numeric: 'no',
      }
   ],
   refers: [
      "Yogesh N.V. Reddy, Rickey E. Carter, Masaru Obokata, Margaret M. Redfield and Barry A. Borlaug. A Simple, Evidence-Based Approach to Help Guide Diagnosis of Heart Failure With Preserved Ejection Fraction. Circulation. 2018;138(9)",
      "Chao Ma, Huan Luo. Heart failure with preserved ejection fraction: an update on pathophysiology, diagnosis, treatment, and prognosis. June 2020, Brazilian journal of medical and biological research = Revista brasileira de pesquisas medicas e biologicas / Sociedade Brasileira de Biofisica [et al.] 53(7):e9646",
   ]
}