export const framinghamScoreCalc = {
   id: "EV-CALC-20",
   link: "framinghamscore",
   title: "Фрамингемская шкала",
   text: "Оценка риска инсульта в ближайшие 10 лет при наличии сердечно-сосудистых заболеваний",
   description: {
      descriptionMain: [
         "Фрамингемская шкала - оценивает риск фатальных и нефатальных сосудистых событий (в частности, инсульта) в ближайшие 10 лет. Шкала была создана в американском городе Фрамингем в 1994 году и основана на 12-летнем исследовании.",
      ]
   },
   form: [
      {
         type: 'input',
         label: 'Возраст',
         inputId: 'age',
         placeholder: '1 - 120',
         error: 'Возраст должен быть 1 - 120',
         span: 'лет',
         min: 1,
         max: 120,
         required: 'yes',
         pattern: "nodot",
         ext: 0,
         spanWidth: 120
      },
      {
         type: 'input',
         label: 'Систолическое давление',
         inputId: 'syst',
         placeholder: '60 - 300',
         error: 'Систолическое давление должен быть 60 - 300',
         span: 'мм рт․с․',
         min: 60,
         max: 300,
         required: 'yes',
         pattern: "nodot",
         ext: 0,
         spanWidth: 120
      },
      {
         type: 'select',
         label: 'Лечение артериальной гипертонии',
         inputId: 'hypTr',
         required: 'yes',
         items: [
            { value: '0', label: 'Нет' },
            { value: '2', label: 'Да' }
         ]
      },
      {
         type: 'select',
         label: 'Сахарный диабет',
         inputId: 'diabetes',
         required: 'yes',
         items: [
            { value: '0', label: 'Нет' },
            { value: '2', label: 'Да' }
         ]
      },
      {
         type: 'select',
         label: 'Курение',
         inputId: 'smoking',
         required: 'yes',
         items: [
            { value: '0', label: 'Нет' },
            { value: '3', label: 'Да' }
         ]
      },
      {
         type: 'select',
         label: 'Анамнез сердечно-сосудистых заболеваний',
         inputId: 'anamnesis',
         required: 'yes',
         items: [
            { value: '0', label: 'Нет' },
            { value: '3', label: 'Да' }
         ]
      },
      {
         type: 'select',
         label: 'Мерцательная аритмия',
         inputId: 'arythm',
         required: 'yes',
         items: [
            { value: '0', label: 'Нет' },
            { value: '4', label: 'Да' }
         ]
      },
      {
         type: 'select',
         label: 'Гипертрофия левого желудочка по данным электрокардиографии',
         inputId: 'hypertr',
         required: 'yes',
         items: [
            { value: '0', label: 'Нет' },
            { value: '6', label: 'Да' }
         ]
      },
   ],
   refers: [
      "Ralph B., Agostino, Sr, Ramachandran S. Vasan, Michael J. Pencina, Philip A. Wolf, Mark Cobain, Joseph M. Massaro and William B. Kannel. General cardiovascular risk profile for use in primary care: the Framingham Heart Study. Circulation 2008 February 12, 117 (6): 743-53",
      "McPherson R et al. Canadian Cardiovascular Society position statement—recommendations for the diagnosis and treatment of dyslipidemia and prevention of cardiovascular disease. Canadian Journal of Cardiology 2006, 22 (11): 913-27",
      "Ian Graham et al. European guidelines on cardiovascular disease prevention in clinical practice: executive summary: Fourth Joint Task Force of the European Society of Cardiology and Other Societies on Cardiovascular Disease Prevention in Clinical Practice (Constituted by representatives of nine societies and by invited experts). European Heart Journal, Volume 28, Issue 19, October 2007, Pages 2375-2414",
   ]
}