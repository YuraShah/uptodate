export const apgarCalc = {
   id: "EV-CALC-53",
   link: "apgar-score",
   title: "Шкала Апгар",
   text: "Система оценки состояния новорожденного («клинического статуса») в первые минуты жизни",
   description: {
      descriptionMain: [
         "Шкала Апгар — это система оценки состояния новорожденного («клинического статуса») в первые минуты жизни. Согласно Программе реанимации новорожденных (NRP), оценка продолжается с 5-минутными интервалами до тех пор, пока не будет достигнута оценка 7 или пока не будет достигнуто 20 минут жизни. Ее не следует использовать для прогнозирования индивидуального риска смертности или неблагоприятного неврологического исхода. На оценку по шкале Апгар могут влиять гестационный возраст, седация матери, врожденные пороки развития, травмы и вариабельность оценки разными наблюдателями. Эта шкала надежна в использовании, поскольку различия между независимыми оценщиками минимальны."
      ],
      descriptionTable: [{
         headData: ['Баллы', 'Результат'],
         bodyData: [
            ['≥7', 'В целом нормально'],
            ['4-6', 'Довольно низкий'],
            ['≤3', 'Очень низкий, требуется вмешательство'],
         ],
         flexNums: [1, 1],
      }]
   },
   form: [
      {
         type: 'radio',
         radioButtons: [
            {
               id: '2',
               label: 'Активный',
               value: '2',
            },
            {
               id: '1',
               label: 'Частичное сгибание конечностей',
               value: '1',
            },
            {
               id: '0',
               label: 'Хромота',
               value: '0',
            },
         ],
         label: 'Активность/мышечный тонус',
         inputId: 'activity',
         required: 'yes',
         numeric: 'yes',
      },
      {
         type: 'radio',
         radioButtons: [
            {
               id: '2',
               label: '≥100 ударов/мин',
               value: '2',
            },
            {
               id: '1',
               label: '<100 ударов/мин',
               value: '1',
            },
            {
               id: '0',
               label: 'Отсутствует',
               value: '0',
            },
         ],
         label: 'Пульс',
         inputId: 'pulse',
         required: 'yes',
         numeric: 'yes',
      },
      {
         type: 'radio',
         radioButtons: [
            {
               id: '2',
               label: 'Чихание/кашель',
               value: '2',
            },
            {
               id: '1',
               label: 'Гримаса',
               value: '1',
            },
            {
               id: '0',
               label: 'Отсутствует',
               value: '0',
            }
         ],
         label: 'Гримаса',
         inputId: 'grimace',
         required: 'yes',
         numeric: 'yes',
      },
      {
         type: 'radio',
         radioButtons: [
            {
               id: '2',
               label: 'Все розовое',
               value: '2',
            },
            {
               id: '1',
               label: 'Голубые конечности, розовое тело',
               value: '1',
            },
            {
               id: '0',
               label: 'Синий/бледный',
               value: '0',
            }
         ],
         label: 'Внешний вид/цвет',
         inputId: 'appearance',
         required: 'yes',
         numeric: 'yes',
      },
      {
         type: 'radio',
         radioButtons: [
            {
               id: '2',
               label: 'Хорошое/плачет',
               value: '2',
            },
            {
               id: '1',
               label: 'Нерегулярно/медленно',
               value: '1',
            },
            {
               id: '0',
               label: 'Отсутствует',
               value: '0',
            }
         ],
         label: 'Дыхание',
         inputId: 'respirations',
         required: 'yes',
         numeric: 'yes',
      },
   ],
   refers: [
      "Apgar V. A proposal for a new method of evaluation of the newborn infant. Curr. Res. Anesth. Analg. 1953;32(4): 260-267. doi:10.1213/00000539-195301000-00041. PMID 13083014.",
      "Finster M, Wood M. The Apgar score has survived the test of time. Anesthesiology. 2005;102 (4): 855-857. doi:10.1097/00000542-200504000-00022. PMID 15791116.",
      "Apgar V, Holaday D, Stanley James L, et al. Evaluation of the Newborn Infant - Second Report. JAMA. 1958; 168(15): 1985-8.",
      "Casey BM, McIntire DD Leveno KJ The continuing value of the Apgar score for the assessment of newborn infants. N Engl J Med. 2001; 344 (7): 467-471.doi:10.1056/NEJM200102153440701. PMID 11172187",
      "The American Academy of Pediatrics Committee on Fetus and Newborn, The American College of Obstetricians and Gynecologists Committee on Obstetric Practice. The Apgar Score. Pediatrics. 2015; 136: 819-22.",
   ]
}