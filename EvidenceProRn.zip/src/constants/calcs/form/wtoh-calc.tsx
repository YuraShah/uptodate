export const wtohCalc = {
   id: "EV-CALC-15",
   link: "whtr",
   title: "Калькулятор соотношения талии к росту",
   text: "Определяет соотношение талии и роста",
   description: {
      descriptionMain: [
         "Определяет соотношение талии и роста (WHtR). Статистические данные подтверждают, что WHtR является лучшим предиктором сердечных заболеваний, диабета и риска инсульта, чем индекс массы тела (ИМТ), поскольку он учитывает распределение абдоминального жира, который, как известно, увеличивает вышеуказанные риски. Абдоминальный жир оказывает более негативное влияние на такие органы, как сердце, печень и почки, с точки зрения кардиометаболического риска, чем жир в области бедер и ягодиц.",
         "В метаанализе Lee et al., которые рассмотрели 10 исследований, ИМТ оказался наихудшим дискриминирующим фактором для сердечно-сосудистых факторов риска, тогда как WHtR оказался лучшим дискриминирующим фактором для гипертонии, диабета и дислипидемии у обоих полов."
      ],
      descriptionLink: [
         {
            "name": "Индекс массы тела",
            "link": 'calcs/bmi',
         }
      ],
      descriptionTable: [
         {
            headData: ['Классификация WHtR', 'Женщина', 'Мужчина', 'Дети <15 лет'],
            bodyData: [
               ['Очень худой', '≤0.34', '≤0.34', '≤0.34'],
               ['Худой', '0.35-0.41', '0.35-0.42', '0.35-0.45'],
               ['Здоровый', '0.42-0.48', '0.43-0.52', '0.46-0.51'],
               ['Избыточный вес', '0.49-0.53', '0.53-0.57', '0.52-0.63'],
               ['Большой избыточный вес', '0.54-0.57', '0.58-0.62', '-'],
               ['Ожирение', '≥0.58', '≥0.63', '≥0.64'],
            ],
            flexNums: [1, 1, 1, 1]
         }
      ],
      descriptionImage: [
         {
            image: require('@/assets/images/calcs/how-measure.jpg'),
            height: 200,
            heightL: 300
         }
      ]
   },
   form: [
      {
         type: 'input',
         label: 'Окружность талии',
         inputId: 'waist',
         placeholder: '0.1 - 200',
         error: 'Поле должно быть в диапазоне 0.1 - 200',
         span: 'см',
         min: 0.1,
         max: 200,
         required: 'yes',
         pattern: "dot",
         ext: 0
      },
      {
         type: 'input',
         label: 'Рост',
         inputId: 'height',
         placeholder: '15 - 203',
         error: 'Рост должен быть 15-203',
         span: 'см',
         min: 15,
         max: 203,
         required: 'yes',
         pattern: "nodot",
         ext: 0,
         spanWidth: 50
      },
      {
         type: 'select',
         label: 'Группа',
         inputId: 'gend_cat',
         required: 'yes',
         items: [
            { value: '2', label: 'Мужчины' },
            { value: '1', label: 'Женщины' },
            { value: '0', label: 'Дети <15 лет' }
         ]
      },
   ],
   refers: [
      "Ashwell M, Gunn P, Gibson S. Waist-to-height ratio is a better screening tool than waist circumference and BMI for adult cardiometabolic risk factors: systematic review and meta-analysis. Obesity Reviews. 2012; 13, pp.275-286.",
      "Schneider HJ et al. The predictive value of different measures of obesity for incident cardiovascular events and mortality. The Journal of clinical endocrinology and metabolism. 2010; 95(4), pp.1777-85.",
      "Ashwell M, Gibson S. Waist-to-height ratio as an indicator of ‘early health risk’: simpler and more predictive than using a ‘matrix’ based on BMI and waist circumference. BMJ Open 2016; 6:e010159.",
      "Browning LM, Hsieh SD, Ashwell M. A Systematic Review of Waist-To-Height Ratio as a Screening Tool for the Prediction of Cardiovascular Disease and Diabetes: 0·5 Could Be a Suitable Global Boundary Value. Nutr Res Rev. 2010; 23(2):247-69.",
      "Lee CMY, Huxley RR, Wildman RP, Woodward M. Indices of Abdominal Obesity Are Better Discriminators of Cardiovascular Risk Factors Than BMI: A Meta-Analysis. J Clin Epidemiol. 2008; 61(7):646-53.",
   ]
}