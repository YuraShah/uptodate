export const caHypoalbCalc = {
   id: "EV-CALC-45",
   link: "ca-correction-hypoalbum",
   title: "Коррекция концентрации кальция при гипоальбуминемии",
   text: "Коррекция концентрации кальция при гипоальбуминемии",
   description: {
      descriptionMain: [
         "Около 50% общего кальция плазмы связано с альбумином плазмы, остальная часть находится в физиологически активном ионизированном свободном состоянии. В случаях, когда уровень альбумина плазмы низкий, общий уровень кальция плазмы часто оценивается по связанному с белком кальцию. \nПри составлении формул средний уровень альбумина обычно принимается равным 40 г/л (4 г/дл)."
      ]
   },
   form: [
      {
         type: 'input',
         label: 'Уровень кальция в плазме',
         inputId: 'ca',
         placeholder1: '1 - 4.5',
         placeholder: '5 - 12',
         error1: 'Уровень кальция в плазме должен быть 1 - 4.5',
         error: 'Уровень кальция в плазме должен быть 5 - 12',
         span1: 'ммоль/л',
         span: 'мг/дл',
         min1: 1,
         min: 5,
         max1: 4.5,
         max: 12,
         required: 'yes',
         pattern: "dot",
         ext: 1,
         spanWidth: 80,
         extIndex: 0
      },
      {
         type: 'input',
         label: 'Уровень альбумина в плазме',
         inputId: 'alb',
         placeholder1: '10 - 60',
         placeholder: '1 - 6',
         error1: 'Уровень альбумина в плазме должен быть 10 - 60',
         error: 'Уровень альбумина в плазме должен быть 1 - 6',
         span1: 'г/л',
         span: 'г/дл',
         min1: 10,
         min: 1,
         max1: 60,
         max: 6,
         required: 'yes',
         pattern: "dot",
         ext: 1,
         spanWidth: 80,
         extIndex: 1
      },
   ],
   refers: [
      "Payne RB, Little AJ, Williams RB, Milner JR. Interpretation of Serum Calcium in Patients with Abnormal Serum Proteins. British Medical Journal. 1973;4(5893):643-646.",
      "Parent X, et. al. Corrected calcium: calcium status underestimation in non-hypoalbuminemic patients and in hypercalcemic patients. Ann Biol Clin (Paris). 2009 Jul-Aug;67(4):411-8. doi: 10.1684/abc.2009.0348.",
   ]
}