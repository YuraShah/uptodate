export const bodyMassIndexCalc = {
   id: "EV-CALC-09",
   link: "bmi",
   title: "Калькулятор индекса массы тела",
   text: "Калькулятор индекса массы тела",
   description: {
      descriptionMain: [
         "Индекс массы тела подвергался критике за то, что он является неподходящим показателем для людей с развитой мускулатурой, находящихся в отличной физической форме, а также за то, что он является неподходящим показателем для определенных этнических групп."
      ],
      descriptionTable: [{
         headData: ['Индекс массы тела, кг/м²', 'Вес'],
         bodyData: [
            ['<18.5', 'Ниже нормы (недостаточный вес)'],
            ['18.5-24.9', 'Нормальный вес'],
            ['25-29.9', 'Избыточный вес'],
            ['30-34.9', 'Ожирение I степени'],
            ['35-39.9', 'Ожирение II степени'],
            ['≥40', 'Ожирение III степени'],
         ],
         flexNums: [1, 1],
      }]
   },
   form: [
      {
         type: 'input',
         label: 'Вес',
         inputId: 'weight',
         placeholder: '',
         error: 'Вес должен быть 1-225',
         error1: 'string',
         span: 'кг',
         min: 1,
         max: 225,
         required: 'yes',
         pattern: "dot",
         ext: 0
      },
      {
         type: 'input',
         label: 'Рост',
         inputId: 'height',
         placeholder: '',
         error: 'Рост должен быть 15-203',
         span: 'см',
         min: 15,
         max: 203,
         required: 'yes',
         pattern: "dot",
         ext: 0
      },
      {
         type: 'input',
         label: 'Целевой индекс массы тела (необязательно, введите целевой индекс массы тела, чтобы определить вес, необходимый для его достижения)',
         inputId: 'targetbmi',
         placeholder: '',
         error: 'Целевой индекс массы тела должен быть 10-30',
         span: 'кг/м²',
         min: 10,
         max: 30,
         required: 'no',
         pattern: "dot",
         spanWidth: 70,
         ext: 0
      },
   ],
   refers: [
      "Gadzik J. 'How much should I weigh?' Quetelet's equation, upper weight limits, and BMI prime.Connecticut Medicine. (2006). 70 (2): 81-8. PMID 16768059",
      "BMI Classification. Global Database on Body Mass Index. World Health Organization. 2006. Retrieved July 27, 2012",
   ]
}