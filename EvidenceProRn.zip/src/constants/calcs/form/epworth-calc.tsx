export const epworthCalc = {
   id: "EV-CALC-12",
   link: "epworth-sleepiness-scale",
   title: "Шкала сонливости Epworth",
   text: "Оценка сонливости и наличия нарколепсии",
   description: {
      descriptionMain: [
         "Шкала сонливости Epworth - опросник, специально разработанный для оценки сонливости и вероятности нарколепсии."
      ],
      descriptionTable: [
         {
            bodyData: [
               ['1-6 балл', 'Нормальный сон'],
               ['7-8 балл', 'Умеренная сонливость'],
               ['9-24 балл', 'Аномальная (возможно патологическая) сонливость'],
            ],
            flexNums: [1, 2]
         }
      ]
   },
   form: [
      {
         type: 'radio',
         radioButtons: [
            {
               id: '0',
               label: 'Нет вероятности заснуть',
               value: '0',
            },
            {
               id: '1',
               label: 'Небольшая вероятность заснуть',
               value: '1',
            },
            {
               id: '2',
               label: 'Умеренная вероятность заснуть',
               value: '2',
            },
            {
               id: '3',
               label: 'Высокая вероятность заснуть',
               value: '3',
            }
         ],
         label: 'Сидите и читаете',
         inputId: 'read',
         required: 'yes',
         numeric: 'yes',
      },
      {
         type: 'radio',
         radioButtons: [
            {
               id: '0',
               label: 'Нет вероятности заснуть',
               value: '0',
            },
            {
               id: '1',
               label: 'Небольшая вероятность заснуть',
               value: '1',
            },
            {
               id: '2',
               label: 'Умеренная вероятность заснуть',
               value: '2',
            },
            {
               id: '3',
               label: 'Высокая вероятность заснуть',
               value: '3',
            }
         ],
         label: 'Смотрите телевизор',
         inputId: 'tv',
         required: 'yes',
         numeric: 'yes',
      },
      {
         type: 'radio',
         radioButtons: [
            {
               id: '0',
               label: 'Нет вероятности заснуть',
               value: '0',
            },
            {
               id: '1',
               label: 'Небольшая вероятность заснуть',
               value: '1',
            },
            {
               id: '2',
               label: 'Умеренная вероятность заснуть',
               value: '2',
            },
            {
               id: '3',
               label: 'Высокая вероятность заснуть',
               value: '3',
            }
         ],
         label: 'Спокойно сидите в общественном месте',
         inputId: 'soc',
         required: 'yes',
         numeric: 'yes',
      },
      {
         type: 'radio',
         radioButtons: [
            {
               id: '0',
               label: 'Нет вероятности заснуть',
               value: '0',
            },
            {
               id: '1',
               label: 'Небольшая вероятность заснуть',
               value: '1',
            },
            {
               id: '2',
               label: 'Умеренная вероятность заснуть',
               value: '2',
            },
            {
               id: '3',
               label: 'Высокая вероятность заснуть',
               value: '3',
            }
         ],
         label: 'Сидите в течение часа как пассажир автомобиля',
         inputId: 'aut',
         required: 'yes',
         numeric: 'yes',
      },
      {
         type: 'radio',
         radioButtons: [
            {
               id: '0',
               label: 'Нет вероятности заснуть',
               value: '0',
            },
            {
               id: '1',
               label: 'Небольшая вероятность заснуть',
               value: '1',
            },
            {
               id: '2',
               label: 'Умеренная вероятность заснуть',
               value: '2',
            },
            {
               id: '3',
               label: 'Высокая вероятность заснуть',
               value: '3',
            }
         ],
         label: 'Лежите и отдыхаете после обеда',
         inputId: 'bed',
         required: 'yes',
         numeric: 'yes',
      },
      {
         type: 'radio',
         radioButtons: [
            {
               id: '0',
               label: 'Нет вероятности заснуть',
               value: '0',
            },
            {
               id: '1',
               label: 'Небольшая вероятность заснуть',
               value: '1',
            },
            {
               id: '2',
               label: 'Умеренная вероятность заснуть',
               value: '2',
            },
            {
               id: '3',
               label: 'Высокая вероятность заснуть',
               value: '3',
            }
         ],
         label: 'Сидите и разговариваете с кем-то',
         inputId: 'talk',
         required: 'yes',
         numeric: 'yes',
      },
      {
         type: 'radio',
         radioButtons: [
            {
               id: '0',
               label: 'Нет вероятности заснуть',
               value: '0',
            },
            {
               id: '1',
               label: 'Небольшая вероятность заснуть',
               value: '1',
            },
            {
               id: '2',
               label: 'Умеренная вероятность заснуть',
               value: '2',
            },
            {
               id: '3',
               label: 'Высокая вероятность заснуть',
               value: '3',
            }
         ],
         label: 'Сидите молча после обеда (без употребления алкоголя)',
         inputId: 'lan',
         required: 'yes',
         numeric: 'yes',
      },
      {
         type: 'radio',
         radioButtons: [
            {
               id: '0',
               label: 'Нет вероятности заснуть',
               value: '0',
            },
            {
               id: '1',
               label: 'Небольшая вероятность заснуть',
               value: '1',
            },
            {
               id: '2',
               label: 'Умеренная вероятность заснуть',
               value: '2',
            },
            {
               id: '3',
               label: 'Высокая вероятность заснуть',
               value: '3',
            }
         ],
         label: 'Сидите в автомобиле, который остановился на несколько минут из-за дорожной ситуации',
         inputId: 'stop',
         required: 'yes',
         numeric: 'yes',
      },
   ],
   refers: [
      "Johns MW. A new method for measuring daytime sleepiness: the Epworth sleepiness scale. Sleep. 1991;14:540-5"
   ]
}