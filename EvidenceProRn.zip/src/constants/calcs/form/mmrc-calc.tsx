export const mmrcCalc = {
   id: "EV-CALC-61",
   link: "mmrc",
   title: "Шкала одышки mMRC (Modified Medical Research Council)",
   text: "Указывает на выраженность одышки при заболеваниях органов дыхания",
   description: {
      descriptionMain: [
         "Стратифицирует тяжесть одышки при респираторных заболеваниях, в частности при хронической обструктивной болезни легких (ХОБЛ). Пациентам с респираторными заболеваниями для оценки степени исходной функциональной нетрудоспособности (инвалидности) из-за проблем с дыханием.",
         [
            "",
            "Описывает начальную одышку, но не дает четкого количественного ответа на лечение ХОБЛ.",
            "Не имеет устойчивой корреляции со спирометрическими измерениями (например, ОФВ1) у пациентов с респираторными заболеваниями, связанными с ХОБЛ.",
            "По крайней мере умеренно связано с качеством жизни, связанным со здоровьем, особенно у пациентов с ХОБЛ (Henoch 2016).",
            "Баллы связаны с заболеваемостью (госпитализация и неблагоприятные сердечно-сосудистые исходы), а в некоторых исследованиях — со смертностью.",
         ]
      ]
   },
   form: [
      {
         type: 'radio',
         radioButtons: [
            {
               id: '0',
               label: 'Одышка только при тяжелой физической нагрузке',
               value: '0',
            },
            {
               id: '1',
               label: 'Одышка при быстрой ходьбе или подъёме на небольшую высоту (например, по лестнице)',
               value: '1',
            },
            {
               id: '2',
               label: 'Идёт медленнее, чем люди того же возраста из-за одышки или вынужден останавливаться, чтобы восстановить дыхание при ходьбе в собственном темпе',
               value: '2',
            },
            {
               id: '3',
               label: 'Останавливается, чтобы восстановить дыхание после прохождения 91 метра или через несколько минут ходьбы',
               value: '3',
            },
            {
               id: '4',
               label: 'Одышка настолько выражена, что трудно выйти из дома или она возникает при одевании',
               value: '4',
            }
         ],
         label: 'Тяжесть симптома (ходьба должна оцениваться на ровной поверхности)',
         inputId: 'symptomSeverity',
         required: 'yes',
      }
   ],
   refers: [
      "Mahler DA, Wells CK. Evaluation of clinical methods for rating dyspnea. Chest. 1988;93(3):580-6.",
      "Hajiro T, Nishimura K, Tsukino M, Ikeda A, Koyama H, Izumi T. Analysis of clinical methods used to evaluate dyspnea in patients with chronic obstructive pulmonary disease. Am J Respir Crit Care Med. 1998;158(4):1185-9.",
      "Nishiyama O, Taniguchi H, Kondoh Y, et al. A simple assessment of dyspnoea as a prognostic indicator in idiopathic pulmonary fibrosis. Eur Respir J. 2010;36(5):1067-72.",
      "Launois C, Barbe C, Bertin E, et al. The modified Medical Research Council scale for the assessment of dyspnea in daily living in obesity: a pilot study. BMC Pulm Med. 2012;12:61.",
      "Celli BR, Cote CG, Marin JM, Casanova C, de Oca MM, Mendez RA, et al. The body mass index, airflow obstruction, dyspnea, and exercise capacity index in chronic obstructive pulmonary disease. N Engl J Med. 2004;350:1005–12.",
      "Chhabra SK, Gupta AK, Khuma MZ. Evaluation of three scales of dyspnea in chronic obstructive pulmonary disease. Ann Thorac Med. 2009;4(3):128-32.",
      "GOLD: Global Initiative for Obstructive Lung Disease Global Strategy for the Diagnosis, Management and Prevention of Chronic Obstructive Pulmonary Disease 2011 Available from: http://www.goldcopd.com Accessed August 2nd, 2017",
      "Fletcher CM. Discussion on the diagnosis of pulmonary emphysema. Proc R Soc Med. 1952;45:576-585.",
      "Henoch I, Strang S, Löfdahl CG, Ekberg-Jansson A. Health-related quality of life in a nationwide cohort of patients with COPD related to other characteristics. Eur Clin Respir J. 2016;3:31459.",
      "Rennard S, Decramer M, Calverley PM, et al. Impact of COPD in North America and Europe in 2000: subjects’ perspective of confronting COPD International Survey. Eur Respir J. 2002;20(4):799–805.",
   ]
}