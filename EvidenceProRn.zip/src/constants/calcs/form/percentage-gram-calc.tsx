export const percentageGramCalc = {
   id: "EV-CALC-04",
   link: "pgsolution",
   title: "Расчет содержания вещества в растворе",
   text: "Расчет содержания вещества в растворе (из % в г)",
   description: {
      descriptionMain: [
         "Расчет производится по формуле, исходя из того, что в 100 мл 1% раствора содержится 1 грамм вещества."
      ]
   },
   form: [
      {
         type: 'input',
         label: 'Процентное содержание',
         inputId: 'percent',
         placeholder: '0.01 - 100',
         error: 'Процентное содержание должен быть в диапазоне 0.01 - 100',
         span: '%',
         min: 0.01,
         max: 100,
         required: 'yes',
         pattern: "dot",
         ext: 0
      },
      {
         type: 'input',
         label: 'Объем ампулы',
         inputId: 'volume',
         placeholder: '',
         error: 'Объем должно быть больше 0',
         span: 'мл',
         min: 0.000001,
         max: 10000,
         required: 'yes',
         pattern: "dot",
         ext: 0
      },
   ],
   refers: [
      "Evidence",
   ]
}