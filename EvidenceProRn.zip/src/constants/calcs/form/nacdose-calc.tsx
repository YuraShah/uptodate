export const nacDoseCalc = {
   id: "EV-CALC-51",
   link: "acetaminophen-overdose-nac-dosing",
   title: "Калькулятор дозировки N-ацетилцистеина при передозировке парацетамолом",
   text: "Калькулятор дозировки N-ацетилцистеина при передозировке парацетамолом",
   description: {
      descriptionMain: [
         "Этот калькулятор помогает рассчитать дозу перорального/внутривенного N-ацетилцистеина в случае передозировки парацетамолом. Раннее введение N-ацетилцистеина (<8 часов после приема парацетамола) имеет жизненно важное значение для снижения риска гепатотоксичности."
      ]
   },
   form: [
      {
         type: 'select',
         label: 'Способ введения N-ацетилцистеина',
         inputId: 'route',
         required: 'yes',
         items: [
            { value: '0', label: 'Внутривенный' },
            { value: '1', label: 'Пероральный' }
         ]
      },
      {
         type: 'input',
         label: 'Вес',
         inputId: 'weight',
         placeholder: '1-150',
         error: 'Вес должен быть в диапазоне 1 - 150',
         span: 'кг',
         min: 1,
         max: 150,
         required: 'yes',
         pattern: "dot",
         ext: 0,
         spanWidth: 60
      },
   ],
   refers: [
      "Rumack BH, Peterson RC, Koch GG, Amara IA. Acetaminophen overdose: 662 cases with evaluation of oral acetylcysteine treatment. Arch Intern Med. 1981;141:380-5.",
      "Prescott LF, Illingworth RN, Critchley JA, Stewart MJ, Adam RD, Proudfoot AT. Intravenous N-acetylcysteine: the treatment of choice for paracetamol poisoning. BMJ. 1979;2:1097-1100.",
      "Smilkstein MJ, Knapp GL, Kulig KW, Rumack BH. Efficacy of oral N-acetylcysteine in the treatment of acetaminophen overdose: Analysis of the National Multicenter Study. N Engl J Med. 1988;319:1557-62.",
   ]
}