export const maiCalc = {
   id: "EV-CALC-08",
   link: "g-mai",
   title: "Калькулятор индекса целесообразности приема лекарств",
   text: "Помогает определить, насколько конкретное лекарство соответствует целям лечения у пожилых людей",
   description: {
      descriptionMain: [
         "Индекс целесообразности приема лекарств помогает определить, насколько конкретное лекарство соответствует целям лечения у пожилых людей. Другими словами, следует ли продолжать принимать лекарство или в этом нет необходимости? Он был разработан Джозефом Хэнлоном в 1992 году и усовершенствован итальянцем А. Грациоли в 2021 году. Общий балл варьируется от 0 до 18. Чем выше балл, тем больше вероятность того, что назначенное лекарство следует отменить."
      ]
   },
   form: [
      {
         type: 'radio',
         radioButtons: [
            {
               id: '3',
               label: 'Нет',
               value: '3',
            },
            {
               id: '0',
               label: 'Да',
               value: '0',
            }
         ],
         label: 'Есть ли какие-либо показания для приема лекарства?',
         inputId: 'indic',
         required: 'yes',
         numeric: 'yes',
      },
      {
         type: 'radio',
         radioButtons: [
            {
               id: '3',
               label: 'Нет',
               value: '3',
            },
            {
               id: '0',
               label: 'Да',
               value: '0',
            }
         ],
         label: 'Эффективен ли препарат при лечении текущего состояния пациента?',
         inputId: 'effect',
         required: 'yes',
         numeric: 'yes',
      },
      {
         type: 'radio',
         radioButtons: [
            {
               id: '2',
               label: 'Нет',
               value: '2',
            },
            {
               id: '0',
               label: 'Да',
               value: '0',
            }
         ],
         label: 'Правильна ли выбранная доза?',
         inputId: 'dose',
         required: 'yes',
         numeric: 'yes',
      },
      {
         type: 'radio',
         radioButtons: [
            {
               id: '2',
               label: 'Нет',
               value: '2',
            },
            {
               id: '0',
               label: 'Да',
               value: '0',
            }
         ],
         label: 'Знает ли пациент, как правильно принимать лекарство?',
         inputId: 'know',
         required: 'yes',
         numeric: 'yes',
      },
      {
         type: 'radio',
         radioButtons: [
            {
               id: '1',
               label: 'Нет',
               value: '1',
            },
            {
               id: '0',
               label: 'Да',
               value: '0',
            }
         ],
         label: 'Соблюдает ли пациент инструкции?',
         inputId: 'do',
         required: 'yes',
         numeric: 'yes',
      },
      {
         type: 'radio',
         radioButtons: [
            {
               id: '2',
               label: 'Нет',
               value: '2',
            },
            {
               id: '0',
               label: 'Да',
               value: '0',
            }
         ],
         label: 'Есть ли какие-либо лекарственные взаимодействия?',
         inputId: 'inter',
         required: 'yes',
         numeric: 'yes',
      },
      {
         type: 'radio',
         radioButtons: [
            {
               id: '2',
               label: 'Нет',
               value: '2',
            },
            {
               id: '0',
               label: 'Да',
               value: '0',
            }
         ],
         label: 'Может ли препарат оказать отрицательное воздействие на пациента?',
         inputId: 'side',
         required: 'yes',
         numeric: 'yes',
      },
      {
         type: 'radio',
         radioButtons: [
            {
               id: '1',
               label: 'Нет',
               value: '1',
            },
            {
               id: '0',
               label: 'Да',
               value: '0',
            }
         ],
         label: 'Принимается ли аналогичный данному препарату препарат (это относится к ситуации, когда 2 препарата из одной и той же группы были назначены по одной и той же причине)',
         inputId: 'bro',
         required: 'yes',
         numeric: 'yes',
      },
      {
         type: 'radio',
         radioButtons: [
            {
               id: '1',
               label: 'Нет',
               value: '1',
            },
            {
               id: '0',
               label: 'Да',
               value: '0',
            }
         ],
         label: 'Достаточна ли продолжительность лечения?',
         inputId: 'dur',
         required: 'yes',
         numeric: 'yes',
      },
      {
         type: 'radio',
         radioButtons: [
            {
               id: '1',
               label: 'Нет',
               value: '1',
            },
            {
               id: '0',
               label: 'Да',
               value: '0',
            }
         ],
         label: 'Является ли этот препарат самым эффективным препаратом на рынке по соотношению цена/эффективность?',
         inputId: 'better',
         required: 'yes',
         numeric: 'yes',
      },
   ],
   refers: [
      "Johnston SC, Rothwell PM, Nguyen-Huynh MN, Giles MF, Elkins JS, Bernstein AL, Sidney S. Validation and refinement of scores to predict very early stroke risk after transient ischaemic attack. Lancet. 2007 Jan 27;369(9558):283-92",
      "Josephson SA, Sidney S, Pham TN, Bernstein AL, Johnston SC. Higher ABCD2 score predicts patients most likely to have true transient ischemic attack. Stroke. 2008 Nov;39(11):3096-8. doi: 10.1161/STROKEAHA.108.514562. Epub 2008 Aug 7",
      "Rothwell PM, Giles MF, Flossmann E, Lovelock CE, Redgrave JN, Warlow CP, Mehta Z. A simple score (ABCD) to identify individuals at high early risk of stroke after transient ischaemic attack. Lancet. 2005 Jul 2-8;366(9479):29-36",
      "Sanders LM, Srikanth VK, Blacker DJ, Jolley DJ, Cooper KA, Phan TG.Performance of the ABCD2 score for stroke risk post TIA: meta-analysis and probability modeling. Neurology. 2012 Sep 4;79(10):971-80. doi: 10.1212/WNL.0b013e31825f9d02. Epub 2012 Jun 13. PubMed PMID: 22700810",
      "Stead LG, Suravaram S, Bellolio MF, Enduri S, Rabinstein A, Gilmore RM, Bhagra A, Manivannan V, Decker WW. An assessment of the incremental value of the ABCD2 score in the emergency department evaluation of transient ischemic attack. Ann Emerg Med. 2011 Jan;57(1):46-51. doi: 10.1016/j.annemergmed.2010.07.001. Epub 2010 Sep 19. PubMed PMID: 20855130",
      "Perry JJ, Sharma M, Sivilotti ML, Sutherland J, Symington C, Worster A, Émond M, Stotts G, Jin AY, Oczkowski WJ, Sahlas DJ, Murray HE, MacKey A, Verreault S, Wells GA, Stiell IG. Prospective validation of the ABCD2 score for patients in the emergency department with transient ischemic attack. CMAJ. 2011 Jul 12;183(10):1137-45. doi: 10.1503/cmaj.101668. Epub 2011 Jun 6. PubMed PMID: 21646462",
   ]
}