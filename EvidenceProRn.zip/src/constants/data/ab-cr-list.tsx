export const abList = [
   {
      class: "Пенициллины",
      children: [
         {
            title: 'Пенициллин',
            id: 1,
            children: [
               {
                  childTitle: 'Пиперациллин',
                  childClass: 'penicillin',
                  childNumber: 5
               },
               {
                  childTitle: 'Ампицилин',
                  childClass: 'penicillin',
                  childNumber: 4
               },
               {
                  childTitle: 'Амоксициллин (и +клавулановая кислота)',
                  childClass: 'penicillin',
                  childNumber: 4
               },
               {
                  childTitle: 'Клоксациллин',
                  childClass: 'penicillin',
                  childNumber: 5
               },
               {
                  childTitle: 'Цефокситин',
                  childClass: 'cef2',
                  childNumber: 3
               },]
         },
         {
            title: 'Пиперациллин',
            id: 2,
            children: [
               {
                  childTitle: 'Пенициллин',
                  childClass: 'penicillin',
                  childNumber: 5
               },
               {
                  childTitle: 'Ампицилин',
                  childClass: 'penicillin',
                  childNumber: 3
               },
               {
                  childTitle: 'Амоксициллин (и +клавулановая кислота)',
                  childClass: 'penicillin',
                  childNumber: 3
               },
               {
                  childTitle: 'Клоксациллин',
                  childClass: 'penicillin',
                  childNumber: 5
               },
               {
                  childTitle: 'Цефадроксил',
                  childClass: 'cef1',
                  childNumber: 3
               },
               {
                  childTitle: 'Цефалексин',
                  childClass: 'cef1',
                  childNumber: 3
               },
               {
                  childTitle: 'Цефпрозил',
                  childClass: 'cef2',
                  childNumber: 3
               }]
         },
         {
            title: 'Ампицилин',
            id: 3,
            children: [
               {
                  childTitle: 'Пиперациллин',
                  childClass: 'penicillin',
                  childNumber: 3
               },
               {
                  childTitle: 'Пенициллин',
                  childClass: 'penicillin',
                  childNumber: 4
               },
               {
                  childTitle: 'Амоксициллин (и +клавулановая кислота)',
                  childClass: 'penicillin',
                  childNumber: 1
               },
               {
                  childTitle: 'Клоксациллин',
                  childClass: 'penicillin',
                  childNumber: 5
               },
               {
                  childTitle: 'Цефадроксил',
                  childClass: 'cef1',
                  childNumber: 2
               },
               {
                  childTitle: 'Цефалексин',
                  childClass: 'cef1',
                  childNumber: 2
               },
               {
                  childTitle: 'Цефпрозил',
                  childClass: 'cef2',
                  childNumber: 2
               }]
         },
         {
            title: 'Амоксициллин (и +клавулановая кислота)',
            id: 4,
            children: [
               {
                  childTitle: 'Пиперациллин',
                  childClass: 'penicillin',
                  childNumber: 3
               },
               {
                  childTitle: 'Пенициллин',
                  childClass: 'penicillin',
                  childNumber: 4
               },
               {
                  childTitle: 'Ампицилин',
                  childClass: 'penicillin',
                  childNumber: 1
               },
               {
                  childTitle: 'Клоксациллин',
                  childClass: 'penicillin',
                  childNumber: 5
               },
               {
                  childTitle: 'Цефадроксил',
                  childClass: 'cef1',
                  childNumber: 1
               },
               {
                  childTitle: 'Цефалексин',
                  childClass: 'cef1',
                  childNumber: 1
               },
               {
                  childTitle: 'Цефпрозил',
                  childClass: 'cef2',
                  childNumber: 2
               }]
         },
         {
            title: 'Клоксациллин',
            id: 5,
            children: [
               {
                  childTitle: 'Пиперациллин',
                  childClass: 'penicillin',
                  childNumber: 5
               },
               {
                  childTitle: 'Пенициллин',
                  childClass: 'penicillin',
                  childNumber: 5
               },
               {
                  childTitle: 'Ампицилин',
                  childClass: 'penicillin',
                  childNumber: 5
               },
               {
                  childTitle: 'Амоксициллин (и +клавулановая кислота)',
                  childClass: 'penicillin',
                  childNumber: 5
               }]
         },
      ]
   },
   {
      class: "Цефалоспорины I поколения",
      children: [
         {
            title: 'Цефадроксил',
            id: 6,
            children: [
               {
                  childTitle: 'Пиперациллин',
                  childClass: 'penicillin',
                  childNumber: 3
               },
               {
                  childTitle: 'Ампицилин',
                  childClass: 'penicillin',
                  childNumber: 2
               },
               {
                  childTitle: 'Амоксициллин (и +клавулановая кислота)',
                  childClass: 'penicillin',
                  childNumber: 1
               },
               {
                  childTitle: 'Цефалексин',
                  childClass: 'cef1',
                  childNumber: 1
               },
               {
                  childTitle: 'Цефпрозил',
                  childClass: 'cef2',
                  childNumber: 2
               }]
         },
         {
            title: 'Цефазолин',
            id: 7,
            children: null
         },
         {
            title: 'Цефалексин',
            id: 8,
            children: [
               {
                  childTitle: 'Пиперациллин',
                  childClass: 'penicillin',
                  childNumber: 3
               },
               {
                  childTitle: 'Ампицилин',
                  childClass: 'penicillin',
                  childNumber: 2
               },
               {
                  childTitle: 'Амоксициллин (и +клавулановая кислота)',
                  childClass: 'penicillin',
                  childNumber: 1
               },
               {
                  childTitle: 'Цефадроксил',
                  childClass: 'cef1',
                  childNumber: 1
               },
               {
                  childTitle: 'Цефпрозил',
                  childClass: 'cef2',
                  childNumber: 2
               }]
         },
      ]
   },
   {
      class: "Цефалоспорины II поколения",
      children: [
         {
            title: 'Цефокситин',
            id: 9,
            children: [
               {
                  childTitle: 'Пенициллин',
                  childClass: 'penicillin',
                  childNumber: 3
               },
               {
                  childTitle: 'Цефуроксим',
                  childClass: 'cef2',
                  childNumber: 2
               }]
         },
         {
            title: 'Цефпрозил',
            id: 10,
            children: [
               {
                  childTitle: 'Пиперациллин',
                  childClass: 'penicillin',
                  childNumber: 3
               },
               {
                  childTitle: 'Ампицилин',
                  childClass: 'penicillin',
                  childNumber: 2
               },
               {
                  childTitle: 'Амоксициллин (и +клавулановая кислота)',
                  childClass: 'penicillin',
                  childNumber: 2
               },
               {
                  childTitle: 'Цефадроксил',
                  childClass: 'cef1',
                  childNumber: 2
               },
               {
                  childTitle: 'Цефалексин',
                  childClass: 'cef1',
                  childNumber: 2
               }]
         },
         {
            title: 'Цефуроксим',
            id: 11,
            children: [
               {
                  childTitle: 'Цефокситин',
                  childClass: 'cef2',
                  childNumber: 2
               },
               {
                  childTitle: 'Цефиксим',
                  childClass: 'cef3',
                  childNumber: 3
               },
               {
                  childTitle: 'Цефотаксим',
                  childClass: 'cef3',
                  childNumber: 1
               },
               {
                  childTitle: 'Цефтазидим',
                  childClass: 'cef3',
                  childNumber: 3
               },
               {
                  childTitle: 'Цефтриаксон',
                  childClass: 'cef3',
                  childNumber: 1
               },
               {
                  childTitle: 'Цефепим',
                  childClass: 'cef4',
                  childNumber: 2
               }]
         },
      ]
   },
   {
      class: "Цефалоспорины III поколения",
      children: [
         {
            title: 'Цефиксим',
            id: 12,
            children: [
               {
                  childTitle: 'Цефуроксим',
                  childClass: 'cef2',
                  childNumber: 3
               },
               {
                  childTitle: 'Цефотаксим',
                  childClass: 'cef3',
                  childNumber: 3
               },
               {
                  childTitle: 'Цефтазидим',
                  childClass: 'cef3',
                  childNumber: 3
               },
               {
                  childTitle: 'Цефтриаксон',
                  childClass: 'cef3',
                  childNumber: 3
               },
               {
                  childTitle: 'Цефепим',
                  childClass: 'cef4',
                  childNumber: 3
               }]
         },
         {
            title: 'Цефотаксим',
            id: 13,
            children: [
               {
                  childTitle: 'Цефуроксим',
                  childClass: 'cef2',
                  childNumber: 1
               },
               {
                  childTitle: 'Цефиксим',
                  childClass: 'cef3',
                  childNumber: 3
               },
               {
                  childTitle: 'Цефтазидим',
                  childClass: 'cef3',
                  childNumber: 3
               },
               {
                  childTitle: 'Цефтриаксон',
                  childClass: 'cef3',
                  childNumber: 1
               },
               {
                  childTitle: 'Цефепим',
                  childClass: 'cef4',
                  childNumber: 1
               }]
         },
         {
            title: 'Цефтазидим',
            id: 14,
            children: [
               {
                  childTitle: 'Цефуроксим',
                  childClass: 'cef2',
                  childNumber: 3
               },
               {
                  childTitle: 'Цефиксим',
                  childClass: 'cef3',
                  childNumber: 3
               },
               {
                  childTitle: 'Цефотаксим',
                  childClass: 'cef3',
                  childNumber: 3
               },
               {
                  childTitle: 'Цефтриаксон',
                  childClass: 'cef3',
                  childNumber: 3
               },
               {
                  childTitle: 'Цефепим',
                  childClass: 'cef4',
                  childNumber: 3
               }]
         },
         {
            title: 'Цефтриаксон',
            id: 15,
            children: [
               {
                  childTitle: 'Цефуроксим',
                  childClass: 'cef2',
                  childNumber: 1
               },
               {
                  childTitle: 'Цефиксим',
                  childClass: 'cef3',
                  childNumber: 3
               },
               {
                  childTitle: 'Цефотаксим',
                  childClass: 'cef3',
                  childNumber: 1
               },
               {
                  childTitle: 'Цефтазидим',
                  childClass: 'cef3',
                  childNumber: 3
               },
               {
                  childTitle: 'Цефепим',
                  childClass: 'cef4',
                  childNumber: 1
               }]
         },
      ]
   },
   {
      class: "Цефалоспорины IV поколения",
      children: [
         {
            title: 'Цефепим',
            id: 16,
            children: [
               {
                  childTitle: 'Цефуроксим',
                  childClass: 'cef2',
                  childNumber: 2
               },
               {
                  childTitle: 'Цефиксим',
                  childClass: 'cef3',
                  childNumber: 3
               },
               {
                  childTitle: 'Цефотаксим',
                  childClass: 'cef3',
                  childNumber: 1
               },
               {
                  childTitle: 'Цефтазидим',
                  childClass: 'cef3',
                  childNumber: 3
               },
               {
                  childTitle: 'Цефтриаксон',
                  childClass: 'cef3',
                  childNumber: 1
               }]
         },
      ]
   },
   {
      class: "Карбапенемы",
      children: [

         {
            title: 'Эртапенем',
            id: 17,
            children: [
               {
                  childTitle: 'Имипенем',
                  childClass: 'carb',
                  childNumber: 5
               },
               {
                  childTitle: 'Меропенем',
                  childClass: 'carb',
                  childNumber: 5
               }]
         },
         {
            title: 'Имипенем',
            id: 18,
            children: [
               {
                  childTitle: 'Эртапенем',
                  childClass: 'carb',
                  childNumber: 5
               },
               {
                  childTitle: 'Меропенем',
                  childClass: 'carb',
                  childNumber: 5
               }]
         },
         {
            title: 'Меропенем',
            id: 19,
            children: [
               {
                  childTitle: 'Эртапенем',
                  childClass: 'carb',
                  childNumber: 5
               },
               {
                  childTitle: 'Имипенем',
                  childClass: 'carb',
                  childNumber: 5
               }]
         }
      ]
   }
]