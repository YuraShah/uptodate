export const sterList = [
   {
      class: 'Группа А (тип гидрокортизона)',
      children: [
         {
            title: 'Гидрокортизон (ацетат, сукцинат, фосфат)',
            id: 1,
            children: [
               {
                  childTitle: 'Метилпреднизолон ацетат (ацетат, сукцинат, фосфат)',
                  childClass: 'A'
               },
               {
                  childTitle: 'Преднизолон',
                  childClass: 'A'
               },
               {
                  childTitle: 'Преднизолон ацетат',
                  childClass: 'A'
               },
               {
                  childTitle: 'Тиксокортол пивалат',
                  childClass: 'A'
               },
               {
                  childTitle: 'Флутиказон и предникарбат',
                  childClass: 'D2'
               },
               {
                  childTitle: 'Гидрокортизон-17-бутират',
                  childClass: 'D2'
               },
               {
                  childTitle: 'Гидрокортизон-17-пропионат',
                  childClass: 'D2'
               },
               {
                  childTitle: 'Метилпреднизолон ацепонат',
                  childClass: 'D2'
               },
            ]
         },
         {
            title: 'Метилпреднизолон ацетат (ацетат, сукцинат, фосфат)',
            id: 2,
            children: [
               {
                  childTitle: 'Гидрокортизон (ацетат, сукцинат, фосфат)',
                  childClass: 'A'
               },
               {
                  childTitle: 'Преднизолон',
                  childClass: 'A'
               },
               {
                  childTitle: 'Преднизолон ацетат',
                  childClass: 'A'
               },
               {
                  childTitle: 'Тиксокортол пивалат',
                  childClass: 'A'
               },
               {
                  childTitle: 'Флутиказон и предникарбат',
                  childClass: 'D2'
               },
               {
                  childTitle: 'Гидрокортизон-17-бутират',
                  childClass: 'D2'
               },
               {
                  childTitle: 'Гидрокортизон-17-пропионат',
                  childClass: 'D2'
               },
               {
                  childTitle: 'Метилпреднизолон ацепонат',
                  childClass: 'D2'
               },
            ]
         },
         {
            title: 'Преднизолон',
            id: 3,
            children: [
               {
                  childTitle: 'Гидрокортизон (ацетат, сукцинат, фосфат)',
                  childClass: 'A'
               },
               {
                  childTitle: 'Метилпреднизолон ацетат (ацетат, сукцинат, фосфат)',
                  childClass: 'A'
               },
               {
                  childTitle: 'Преднизолон ацетат',
                  childClass: 'A'
               },
               {
                  childTitle: 'Тиксокортол пивалат',
                  childClass: 'A'
               },
               {
                  childTitle: 'Флутиказон и предникарбат',
                  childClass: 'D2'
               },
               {
                  childTitle: 'Гидрокортизон-17-бутират',
                  childClass: 'D2'
               },
               {
                  childTitle: 'Гидрокортизон-17-пропионат',
                  childClass: 'D2'
               },
               {
                  childTitle: 'Метилпреднизолон ацепонат',
                  childClass: 'D2'
               },
            ]
         },
         {
            title: 'Преднизолон ацетат',
            id: 4,
            children: [
               {
                  childTitle: 'Гидрокортизон (ацетат, сукцинат, фосфат)',
                  childClass: 'A'
               },
               {
                  childTitle: 'Метилпреднизолон ацетат (ацетат, сукцинат, фосфат)',
                  childClass: 'A'
               },
               {
                  childTitle: 'Преднизолон',
                  childClass: 'A'
               },
               {
                  childTitle: 'Тиксокортол пивалат',
                  childClass: 'A'
               },
               {
                  childTitle: 'Флутиказон и предникарбат',
                  childClass: 'D2'
               },
               {
                  childTitle: 'Гидрокортизон-17-бутират',
                  childClass: 'D2'
               },
               {
                  childTitle: 'Гидрокортизон-17-пропионат',
                  childClass: 'D2'
               },
               {
                  childTitle: 'Метилпреднизолон ацепонат',
                  childClass: 'D2'
               },
            ]
         },
         {
            title: 'Тиксокортол пивалат',
            id: 5,
            children: [
               {
                  childTitle: 'Гидрокортизон (ацетат, сукцинат, фосфат)',
                  childClass: 'A'
               },
               {
                  childTitle: 'Метилпреднизолон ацетат (ацетат, сукцинат, фосфат)',
                  childClass: 'A'
               },
               {
                  childTitle: 'Преднизолон',
                  childClass: 'A'
               },
               {
                  childTitle: 'Преднизолон ацетат',
                  childClass: 'A'
               },
               {
                  childTitle: 'Флутиказон и предникарбат',
                  childClass: 'D2'
               },
               {
                  childTitle: 'Гидрокортизон-17-бутират',
                  childClass: 'D2'
               },
               {
                  childTitle: 'Гидрокортизон-17-пропионат',
                  childClass: 'D2'
               },
               {
                  childTitle: 'Метилпреднизолон ацепонат',
                  childClass: 'D2'
               },
            ]
         },
      ]
   },
   {
      class: 'Группа B (тип триамцинолон ацетонида)',
      children: [
         {
            title: 'Амцинонид',
            id: 6,
            children: [
               {
                  childTitle: 'Будесонид',
                  childClass: 'B'
               },
               {
                  childTitle: 'Десонид',
                  childClass: 'B'
               },
               {
                  childTitle: 'Флунизолид',
                  childClass: 'B'
               },
               {
                  childTitle: 'Флуоцинолон ацетонид',
                  childClass: 'B'
               },
               {
                  childTitle: 'Флуоцинонид',
                  childClass: 'B'
               },
               {
                  childTitle: 'Галцинонид',
                  childClass: 'B'
               },
               {
                  childTitle: 'Триамцинолон',
                  childClass: 'B'
               },
               {
                  childTitle: 'Триамцинолон ацетонид',
                  childClass: 'B'
               },
               {
                  childTitle: 'Флутиказон и предникарбат',
                  childClass: 'D2'
               },
               {
                  childTitle: 'Гидрокортизон-17-бутират',
                  childClass: 'D2'
               },
               {
                  childTitle: 'Гидрокортизон-17-пропионат',
                  childClass: 'D2'
               },
               {
                  childTitle: 'Метилпреднизолон ацепонат',
                  childClass: 'D2'
               },
            ]
         },
         {
            title: 'Будесонид',
            id: 7,
            children: [
               {
                  childTitle: 'Амцинонид',
                  childClass: 'B'
               },
               {
                  childTitle: 'Десонид',
                  childClass: 'B'
               },
               {
                  childTitle: 'Флунизолид',
                  childClass: 'B'
               },
               {
                  childTitle: 'Флуоцинолон ацетонид',
                  childClass: 'B'
               },
               {
                  childTitle: 'Флуоцинонид',
                  childClass: 'B'
               },
               {
                  childTitle: 'Галцинонид',
                  childClass: 'B'
               },
               {
                  childTitle: 'Триамцинолон',
                  childClass: 'B'
               },
               {
                  childTitle: 'Триамцинолон ацетонид',
                  childClass: 'B'
               },
               {
                  childTitle: 'Флутиказон и предникарбат',
                  childClass: 'D2'
               },
               {
                  childTitle: 'Гидрокортизон-17-бутират',
                  childClass: 'D2'
               },
               {
                  childTitle: 'Гидрокортизон-17-пропионат',
                  childClass: 'D2'
               },
               {
                  childTitle: 'Метилпреднизолон ацепонат',
                  childClass: 'D2'
               },
            ]
         },
         {
            title: 'Десонид',
            id: 8,
            children: [
               {
                  childTitle: 'Амцинонид',
                  childClass: 'B'
               },
               {
                  childTitle: 'Будесонид',
                  childClass: 'B'
               },
               {
                  childTitle: 'Флунизолид',
                  childClass: 'B'
               },
               {
                  childTitle: 'Флуоцинолон ацетонид',
                  childClass: 'B'
               },
               {
                  childTitle: 'Флуоцинонид',
                  childClass: 'B'
               },
               {
                  childTitle: 'Галцинонид',
                  childClass: 'B'
               },
               {
                  childTitle: 'Триамцинолон',
                  childClass: 'B'
               },
               {
                  childTitle: 'Триамцинолон ацетонид',
                  childClass: 'B'
               },
               {
                  childTitle: 'Флутиказон и предникарбат',
                  childClass: 'D2'
               },
               {
                  childTitle: 'Гидрокортизон-17-бутират',
                  childClass: 'D2'
               },
               {
                  childTitle: 'Гидрокортизон-17-пропионат',
                  childClass: 'D2'
               },
               {
                  childTitle: 'Метилпреднизолон ацепонат',
                  childClass: 'D2'
               },
            ]
         },
         {
            title: 'Флунизолид',
            id: 9,
            children: [
               {
                  childTitle: 'Амцинонид',
                  childClass: 'B'
               },
               {
                  childTitle: 'Будесонид',
                  childClass: 'B'
               },
               {
                  childTitle: 'Десонид',
                  childClass: 'B'
               },
               {
                  childTitle: 'Флуоцинолон ацетонид',
                  childClass: 'B'
               },
               {
                  childTitle: 'Флуоцинонид',
                  childClass: 'B'
               },
               {
                  childTitle: 'Галцинонид',
                  childClass: 'B'
               },
               {
                  childTitle: 'Триамцинолон',
                  childClass: 'B'
               },
               {
                  childTitle: 'Триамцинолон ацетонид',
                  childClass: 'B'
               },
               {
                  childTitle: 'Флутиказон и предникарбат',
                  childClass: 'D2'
               },
               {
                  childTitle: 'Гидрокортизон-17-бутират',
                  childClass: 'D2'
               },
               {
                  childTitle: 'Гидрокортизон-17-пропионат',
                  childClass: 'D2'
               },
               {
                  childTitle: 'Метилпреднизолон ацепонат',
                  childClass: 'D2'
               },
            ]
         },
         {
            title: 'Флуоцинолон ацетонид',
            id: 10,
            children: [
               {
                  childTitle: 'Амцинонид',
                  childClass: 'B'
               },
               {
                  childTitle: 'Будесонид',
                  childClass: 'B'
               },
               {
                  childTitle: 'Десонид',
                  childClass: 'B'
               },
               {
                  childTitle: 'Флунизолид',
                  childClass: 'B'
               },
               {
                  childTitle: 'Флуоцинонид',
                  childClass: 'B'
               },
               {
                  childTitle: 'Галцинонид',
                  childClass: 'B'
               },
               {
                  childTitle: 'Триамцинолон',
                  childClass: 'B'
               },
               {
                  childTitle: 'Триамцинолон ацетонид',
                  childClass: 'B'
               },
               {
                  childTitle: 'Флутиказон и предникарбат',
                  childClass: 'D2'
               },
               {
                  childTitle: 'Гидрокортизон-17-бутират',
                  childClass: 'D2'
               },
               {
                  childTitle: 'Гидрокортизон-17-пропионат',
                  childClass: 'D2'
               },
               {
                  childTitle: 'Метилпреднизолон ацепонат',
                  childClass: 'D2'
               },
            ]
         },
         {
            title: 'Флуоцинонид',
            id: 11,
            children: [
               {
                  childTitle: 'Амцинонид',
                  childClass: 'B'
               },
               {
                  childTitle: 'Будесонид',
                  childClass: 'B'
               },
               {
                  childTitle: 'Десонид',
                  childClass: 'B'
               },
               {
                  childTitle: 'Флунизолид',
                  childClass: 'B'
               },
               {
                  childTitle: 'Флуоцинолон ацетонид',
                  childClass: 'B'
               },
               {
                  childTitle: 'Галцинонид',
                  childClass: 'B'
               },
               {
                  childTitle: 'Триамцинолон',
                  childClass: 'B'
               },
               {
                  childTitle: 'Триамцинолон ацетонид',
                  childClass: 'B'
               },
               {
                  childTitle: 'Флутиказон и предникарбат',
                  childClass: 'D2'
               },
               {
                  childTitle: 'Гидрокортизон-17-бутират',
                  childClass: 'D2'
               },
               {
                  childTitle: 'Гидрокортизон-17-пропионат',
                  childClass: 'D2'
               },
               {
                  childTitle: 'Метилпреднизолон ацепонат',
                  childClass: 'D2'
               },
            ]
         },
         {
            title: 'Галцинонид',
            id: 12,
            children: [
               {
                  childTitle: 'Амцинонид',
                  childClass: 'B'
               },
               {
                  childTitle: 'Будесонид',
                  childClass: 'B'
               },
               {
                  childTitle: 'Десонид',
                  childClass: 'B'
               },
               {
                  childTitle: 'Флунизолид',
                  childClass: 'B'
               },
               {
                  childTitle: 'Флуоцинолон ацетонид',
                  childClass: 'B'
               },
               {
                  childTitle: 'Флуоцинонид',
                  childClass: 'B'
               },
               {
                  childTitle: 'Триамцинолон',
                  childClass: 'B'
               },
               {
                  childTitle: 'Триамцинолон ацетонид',
                  childClass: 'B'
               },
               {
                  childTitle: 'Флутиказон и предникарбат',
                  childClass: 'D2'
               },
               {
                  childTitle: 'Гидрокортизон-17-бутират',
                  childClass: 'D2'
               },
               {
                  childTitle: 'Гидрокортизон-17-пропионат',
                  childClass: 'D2'
               },
               {
                  childTitle: 'Метилпреднизолон ацепонат',
                  childClass: 'D2'
               },
            ]
         },
         {
            title: 'Триамцинолон',
            id: 13,
            children: [
               {
                  childTitle: 'Амцинонид',
                  childClass: 'B'
               },
               {
                  childTitle: 'Будесонид',
                  childClass: 'B'
               },
               {
                  childTitle: 'Десонид',
                  childClass: 'B'
               },
               {
                  childTitle: 'Флунизолид',
                  childClass: 'B'
               },
               {
                  childTitle: 'Флуоцинолон ацетонид',
                  childClass: 'B'
               },
               {
                  childTitle: 'Флуоцинонид',
                  childClass: 'B'
               },
               {
                  childTitle: 'Галцинонид',
                  childClass: 'B'
               },
               {
                  childTitle: 'Триамцинолон ацетонид',
                  childClass: 'B'
               },
               {
                  childTitle: 'Флутиказон и предникарбат',
                  childClass: 'D2'
               },
               {
                  childTitle: 'Гидрокортизон-17-бутират',
                  childClass: 'D2'
               },
               {
                  childTitle: 'Гидрокортизон-17-пропионат',
                  childClass: 'D2'
               },
               {
                  childTitle: 'Метилпреднизолон ацепонат',
                  childClass: 'D2'
               },
            ]
         },
         {
            title: 'Триамцинолон ацетонид',
            id: 14,
            children: [
               {
                  childTitle: 'Амцинонид',
                  childClass: 'B'
               },
               {
                  childTitle: 'Будесонид',
                  childClass: 'B'
               },
               {
                  childTitle: 'Десонид',
                  childClass: 'B'
               },
               {
                  childTitle: 'Флунизолид',
                  childClass: 'B'
               },
               {
                  childTitle: 'Флуоцинолон ацетонид',
                  childClass: 'B'
               },
               {
                  childTitle: 'Флуоцинонид',
                  childClass: 'B'
               },
               {
                  childTitle: 'Галцинонид',
                  childClass: 'B'
               },
               {
                  childTitle: 'Триамцинолон',
                  childClass: 'B'
               },
               {
                  childTitle: 'Флутиказон и предникарбат',
                  childClass: 'D2'
               },
               {
                  childTitle: 'Гидрокортизон-17-бутират',
                  childClass: 'D2'
               },
               {
                  childTitle: 'Гидрокортизон-17-пропионат',
                  childClass: 'D2'
               },
               {
                  childTitle: 'Метилпреднизолон ацепонат',
                  childClass: 'D2'
               },
            ]
         },
      ]
   },
   {
      class: 'Группа C (тип бетаметазона)',
      children: [
         {
            title: 'Бетаметазон',
            id: 15,
            children: [
               {
                  childTitle: 'Дезоксиметазон',
                  childClass: 'C'
               },
               {
                  childTitle: 'Дексаметазон',
                  childClass: 'C'
               },
               {
                  childTitle: 'Параметазон',
                  childClass: 'C'
               },
               {
                  childTitle: 'Флуокортолон',
                  childClass: 'C'
               }
            ]
         },
         {
            title: 'Дезоксиметазон',
            id: 16,
            children: [
               {
                  childTitle: 'Бетаметазон',
                  childClass: 'C'
               },
               {
                  childTitle: 'Дексаметазон',
                  childClass: 'C'
               },
               {
                  childTitle: 'Параметазон',
                  childClass: 'C'
               },
               {
                  childTitle: 'Флуокортолон',
                  childClass: 'C'
               }
            ]
         },
         {
            title: 'Дексаметазон',
            id: 17,
            children: [
               {
                  childTitle: 'Бетаметазон',
                  childClass: 'C'
               },
               {
                  childTitle: 'Дезоксиметазон',
                  childClass: 'C'
               },
               {
                  childTitle: 'Параметазон',
                  childClass: 'C'
               },
               {
                  childTitle: 'Флуокортолон',
                  childClass: 'C'
               }
            ]
         },
         {
            title: 'Параметазон',
            id: 18,
            children: [
               {
                  childTitle: 'Бетаметазон',
                  childClass: 'C'
               },
               {
                  childTitle: 'Дезоксиметазон',
                  childClass: 'C'
               },
               {
                  childTitle: 'Дексаметазон',
                  childClass: 'C'
               },
               {
                  childTitle: 'Флуокортолон',
                  childClass: 'C'
               }
            ]
         },
         {
            title: 'Флуокортолон',
            id: 19,
            children: [
               {
                  childTitle: 'Бетаметазон',
                  childClass: 'C'
               },
               {
                  childTitle: 'Дезоксиметазон',
                  childClass: 'C'
               },
               {
                  childTitle: 'Дексаметазон',
                  childClass: 'C'
               },
               {
                  childTitle: 'Параметазон',
                  childClass: 'C'
               }
            ]
         },
      ]
   },
   {
      class: 'Группа D1 (тип гидрокортизон-17-бутирата)',
      children: [
         {
            title: 'Беклометазон дипропионат',
            id: 20,
            children: [
               {
                  childTitle: 'Бетаметазон валерат',
                  childClass: 'D1'
               },
               {
                  childTitle: 'Бетаметазон дипропионат',
                  childClass: 'D1'
               },
               {
                  childTitle: 'Клобетазон-17-бутират',
                  childClass: 'D1'
               },
               {
                  childTitle: 'Клобетазол-17-пропионат',
                  childClass: 'D1'
               },
               {
                  childTitle: 'Мометазон',
                  childClass: 'D1'
               }
            ]
         },
         {
            title: 'Бетаметазон валерат',
            id: 21,
            children: [
               {
                  childTitle: 'Беклометазон дипропионат',
                  childClass: 'D1'
               },
               {
                  childTitle: 'Бетаметазон дипропионат',
                  childClass: 'D1'
               },
               {
                  childTitle: 'Клобетазон-17-бутират',
                  childClass: 'D1'
               },
               {
                  childTitle: 'Клобетазол-17-пропионат',
                  childClass: 'D1'
               },
               {
                  childTitle: 'Мометазон',
                  childClass: 'D1'
               }
            ]
         },
         {
            title: 'Бетаметазон дипропионат',
            id: 22,
            children: [
               {
                  childTitle: 'Беклометазон дипропионат',
                  childClass: 'D1'
               },
               {
                  childTitle: 'Бетаметазон валерат',
                  childClass: 'D1'
               },
               {
                  childTitle: 'Клобетазон-17-бутират',
                  childClass: 'D1'
               },
               {
                  childTitle: 'Клобетазол-17-пропионат',
                  childClass: 'D1'
               },
               {
                  childTitle: 'Мометазон',
                  childClass: 'D1'
               }
            ]
         },
         {
            title: 'Клобетазон-17-бутират',
            id: 23,
            children: [
               {
                  childTitle: 'Беклометазон дипропионат',
                  childClass: 'D1'
               },
               {
                  childTitle: 'Бетаметазон валерат',
                  childClass: 'D1'
               },
               {
                  childTitle: 'Бетаметазон дипропионат',
                  childClass: 'D1'
               },
               {
                  childTitle: 'Клобетазол-17-пропионат',
                  childClass: 'D1'
               },
               {
                  childTitle: 'Мометазон',
                  childClass: 'D1'
               }
            ]
         },
         {
            title: 'Клобетазол-17-пропионат',
            id: 24,
            children: [
               {
                  childTitle: 'Беклометазон дипропионат',
                  childClass: 'D1'
               },
               {
                  childTitle: 'Бетаметазон валерат',
                  childClass: 'D1'
               },
               {
                  childTitle: 'Бетаметазон дипропионат',
                  childClass: 'D1'
               },
               {
                  childTitle: 'Клобетазон-17-бутират',
                  childClass: 'D1'
               },
               {
                  childTitle: 'Мометазон',
                  childClass: 'D1'
               }
            ]
         },
         {
            title: 'Мометазон',
            id: 25,
            children: [
               {
                  childTitle: 'Беклометазон дипропионат',
                  childClass: 'D1'
               },
               {
                  childTitle: 'Бетаметазон валерат',
                  childClass: 'D1'
               },
               {
                  childTitle: 'Бетаметазон дипропионат',
                  childClass: 'D1'
               },
               {
                  childTitle: 'Клобетазон-17-бутират',
                  childClass: 'D1'
               },
               {
                  childTitle: 'Клобетазол-17-пропионат',
                  childClass: 'D1'
               }
            ]
         },

      ]
   },
   {
      class: 'Группа D2 (тип гидрокортизон-17-бутирата)',
      children: [
         {
            title: 'Флутиказон и предникарбат',
            id: 26,
            children: [
               {
                  childTitle: 'Гидрокортизон-17-бутират',
                  childClass: 'D2'
               },
               {
                  childTitle: 'Гидрокортизон-17-пропионат',
                  childClass: 'D2'
               },
               {
                  childTitle: 'Метилпреднизолон ацепонат',
                  childClass: 'D2'
               },
               {
                  childTitle: 'Метилпреднизолон ацетат (ацетат, сукцинат, фосфат)',
                  childClass: 'A'
               },
               {
                  childTitle: 'Преднизолон',
                  childClass: 'A'
               },
               {
                  childTitle: 'Преднизолон ацетат',
                  childClass: 'A'
               },
               {
                  childTitle: 'Тиксокортол пивалат',
                  childClass: 'A'
               },
               {
                  childTitle: 'Гидрокортизон (ацетат, сукцинат, фосфат)',
                  childClass: 'A'
               },
               {
                  childTitle: 'Амцинонид',
                  childClass: 'B'
               },
               {
                  childTitle: 'Будесонид',
                  childClass: 'B'
               },
               {
                  childTitle: 'Десонид',
                  childClass: 'B'
               },
               {
                  childTitle: 'Флунизолид',
                  childClass: 'B'
               },
               {
                  childTitle: 'Флуоцинолон ацетонид',
                  childClass: 'B'
               },
               {
                  childTitle: 'Флуоцинонид',
                  childClass: 'B'
               },
               {
                  childTitle: 'Галцинонид',
                  childClass: 'B'
               },
               {
                  childTitle: 'Триамцинолон',
                  childClass: 'B'
               },
               {
                  childTitle: 'Триамцинолон ацетонид',
                  childClass: 'B'
               },
            ]
         },
         {
            title: 'Гидрокортизон-17-бутират',
            id: 27,
            children: [
               {
                  childTitle: 'Флутиказон и предникарбат',
                  childClass: 'D2'
               },
               {
                  childTitle: 'Гидрокортизон-17-пропионат',
                  childClass: 'D2'
               },
               {
                  childTitle: 'Метилпреднизолон ацепонат',
                  childClass: 'D2'
               },
               {
                  childTitle: 'Метилпреднизолон ацетат (ацетат, сукцинат, фосфат)',
                  childClass: 'A'
               },
               {
                  childTitle: 'Преднизолон',
                  childClass: 'A'
               },
               {
                  childTitle: 'Преднизолон ацетат',
                  childClass: 'A'
               },
               {
                  childTitle: 'Тиксокортол пивалат',
                  childClass: 'A'
               },
               {
                  childTitle: 'Гидрокортизон (ацетат, сукцинат, фосфат)',
                  childClass: 'A'
               },
               {
                  childTitle: 'Амцинонид',
                  childClass: 'B'
               },
               {
                  childTitle: 'Будесонид',
                  childClass: 'B'
               },
               {
                  childTitle: 'Десонид',
                  childClass: 'B'
               },
               {
                  childTitle: 'Флунизолид',
                  childClass: 'B'
               },
               {
                  childTitle: 'Флуоцинолон ацетонид',
                  childClass: 'B'
               },
               {
                  childTitle: 'Флуоцинонид',
                  childClass: 'B'
               },
               {
                  childTitle: 'Галцинонид',
                  childClass: 'B'
               },
               {
                  childTitle: 'Триамцинолон',
                  childClass: 'B'
               },
               {
                  childTitle: 'Триамцинолон ацетонид',
                  childClass: 'B'
               },
            ]
         },
         {
            title: 'Гидрокортизон-17-пропионат',
            id: 28,
            children: [
               {
                  childTitle: 'Флутиказон и предникарбат',
                  childClass: 'D2'
               },
               {
                  childTitle: 'Гидрокортизон-17-бутират',
                  childClass: 'D2'
               },
               {
                  childTitle: 'Метилпреднизолон ацепонат',
                  childClass: 'D2'
               },
               {
                  childTitle: 'Метилпреднизолон ацетат (ацетат, сукцинат, фосфат)',
                  childClass: 'A'
               },
               {
                  childTitle: 'Преднизолон',
                  childClass: 'A'
               },
               {
                  childTitle: 'Преднизолон ацетат',
                  childClass: 'A'
               },
               {
                  childTitle: 'Тиксокортол пивалат',
                  childClass: 'A'
               },
               {
                  childTitle: 'Гидрокортизон (ацетат, сукцинат, фосфат)',
                  childClass: 'A'
               },
               {
                  childTitle: 'Амцинонид',
                  childClass: 'B'
               },
               {
                  childTitle: 'Будесонид',
                  childClass: 'B'
               },
               {
                  childTitle: 'Десонид',
                  childClass: 'B'
               },
               {
                  childTitle: 'Флунизолид',
                  childClass: 'B'
               },
               {
                  childTitle: 'Флуоцинолон ацетонид',
                  childClass: 'B'
               },
               {
                  childTitle: 'Флуоцинонид',
                  childClass: 'B'
               },
               {
                  childTitle: 'Галцинонид',
                  childClass: 'B'
               },
               {
                  childTitle: 'Триамцинолон',
                  childClass: 'B'
               },
               {
                  childTitle: 'Триамцинолон ацетонид',
                  childClass: 'B'
               },
            ]
         },
         {
            title: 'Метилпреднизолон ацепонат',
            id: 29,
            children: [
               {
                  childTitle: 'Флутиказон и предникарбат',
                  childClass: 'D2'
               },
               {
                  childTitle: 'Гидрокортизон-17-бутират',
                  childClass: 'D2'
               },
               {
                  childTitle: 'Гидрокортизон-17-пропионат',
                  childClass: 'D2'
               },
               {
                  childTitle: 'Метилпреднизолон ацетат (ацетат, сукцинат, фосфат)',
                  childClass: 'A'
               },
               {
                  childTitle: 'Преднизолон',
                  childClass: 'A'
               },
               {
                  childTitle: 'Преднизолон ацетат',
                  childClass: 'A'
               },
               {
                  childTitle: 'Тиксокортол пивалат',
                  childClass: 'A'
               },
               {
                  childTitle: 'Гидрокортизон (ацетат, сукцинат, фосфат)',
                  childClass: 'A'
               },
               {
                  childTitle: 'Амцинонид',
                  childClass: 'B'
               },
               {
                  childTitle: 'Будесонид',
                  childClass: 'B'
               },
               {
                  childTitle: 'Десонид',
                  childClass: 'B'
               },
               {
                  childTitle: 'Флунизолид',
                  childClass: 'B'
               },
               {
                  childTitle: 'Флуоцинолон ацетонид',
                  childClass: 'B'
               },
               {
                  childTitle: 'Флуоцинонид',
                  childClass: 'B'
               },
               {
                  childTitle: 'Галцинонид',
                  childClass: 'B'
               },
               {
                  childTitle: 'Триамцинолон',
                  childClass: 'B'
               },
               {
                  childTitle: 'Триамцинолон ацетонид',
                  childClass: 'B'
               },
            ]
         }
      ]
   },
]