import axiosInstance from "@/src/redux/api";

export const fetchUseQuery = async <T,>(
   method: 'get' | 'post',
   path: string,
   jsonString?: string,
): Promise<T> => {
   const response = method === 'get'
      ? await axiosInstance.get<T>(path)
      : await axiosInstance.post<T>(path, jsonString ? jsonString : null);

   return response.data;
};