export const asthmaPIScore = (
   wheez: string,
   par: string,
   ecz: string,
   rhin: string,
   disp: string,
   eos: string
) => {
   const cwheez = wheez === '1' ? 1 : 0;

   const cpar = par === '1' ? 1 : 0;
   const cecz = ecz === '1' ? 1 : 0;
   const major = cpar + cecz;

   const crhin = rhin === '1' ? 1 : 0;
   const cdisp = disp === '1' ? 1 : 0;
   const ceos = eos === '1' ? 1 : 0;
   const minor = crhin + cdisp + ceos;

   let criteria;

   if (cwheez === 1) {
      if (major >= 1 || minor >= 2) {
         criteria = 'high'
      } else {
         criteria = 'hless'
      }
   } else if (cwheez === 0) {
      if (major >= 1 || minor >= 2) {
         criteria = 'low'
      } else {
         criteria = 'lless'
      }
   }

   return criteria;
}


export const statinDoseScore = (
   statin: string,
   hdlchol: string,
   ldlchol: string,
   triglyc: string,
   statinList: {
      statin: string;
      statinEn: string;
      data: {
         dose: string;
         hdl: string;
         ldl: string;
         tg: string;
      }[];
   }[]
) => {
   const statinArr = statin.split(' ');
   const [statinName, statinDose] = statinArr;

   if (statinName && statinDose) {
      const findedStatin = statinList.find((stat) => stat.statinEn === statinName);

      if (!findedStatin) return;

      const findedDose = findedStatin.data.find((dose) => dose.dose === statinDose);

      if (!findedDose) return;


      let resLdlchol: string | undefined;
   
      if (ldlchol !== '') {
         const cldlchol = +ldlchol * +findedDose.ldl / 100;
         resLdlchol = (+ldlchol - cldlchol).toFixed(2)
      }


      let resHdlchol: string | undefined;

      if (hdlchol !== '') {
         if (findedDose.hdl.includes('-')) {
            const hdlcholArr = findedDose.hdl.split('-');
            const [min, max] = hdlcholArr;

            const cmin = +min * +hdlchol / 100;
            const cmax = +max * +hdlchol / 100;
            const resMin = (+hdlchol + cmin).toFixed(2);
            const resMax = (+hdlchol + cmax).toFixed(2);

            resHdlchol = `${resMin} - ${resMax}`;
         } else {
            let chdlchol = +hdlchol * +findedDose.hdl / 100;
            resHdlchol = (chdlchol + +hdlchol).toFixed(2)
         }
      }

      let resTg: string | undefined;

      if (triglyc !== '') {
         if (findedDose.tg.includes('-')) {
            const tgArr = findedDose.tg.split('-');
            const [min, max] = tgArr;

            const cmin = +min * +triglyc / 100;
            const cmax = +max * +triglyc / 100;
            const resMin = (+triglyc - cmin).toFixed(2);
            const resMax = (+triglyc - cmax).toFixed(2);

            resTg = `${resMin} - ${resMax}`
         } else {
            let ctg = +triglyc * +findedDose.tg / 100;
            resTg = (+triglyc - ctg).toFixed(2);
         }
      }

      const resStatin = `${findedStatin.statin} ${statinDose} мг`;

      return {
         resLdlchol: !resLdlchol || !/\d/.test(resLdlchol) ? (
            undefined
         ) : (
            `${ldlchol} → ${resLdlchol}`
         ),
         resHdlchol: !resHdlchol || !/\d/.test(resHdlchol) ? (
            undefined
         ) : (
            `${hdlchol} → ${resHdlchol}`
         ),
         resTg: !resTg || !/\d/.test(resTg) ? (
            undefined
         ) : (
            `${triglyc} → ${resTg}`
         ),
         resStatin
      }
   }

   return;
}


export const garfieldCalc = (
   gender: number,
   heartfail: number,
   vasc: number,
   stroke: number,
   bleed: number,
   carotid: number,
   diab: number,
   ckd: number,
   dementia: number,
   smoker: number,
   antiplatelet: number,
   oac: number,
   ethnicity: number,
   age: number,
   weight: number,
   pulse: number,
   diastolic: number
) => {
   const mortalityCoefficients = {
      gender: gender === 1 ? -0.306202287 : 0,
      heartfail: heartfail === 1 ? 0.693789082 : 0,
      vasc: vasc === 1 ? 0.306120964 : 0,
      stroke: stroke === 1 ? 0.26585298 : 0,
      bleed: bleed === 1 ? 0.385407386 : 0,
      diab: diab === 1 ? 0.280133213 : 0,
      ckd: ckd === 1 ? 0.377903886 : 0,
      dementia: dementia === 1 ? 0.489453313 : 0,
      smoker: smoker === 1 ? 0.345481149 : 0,
      oac: oac === 1 ? -0.414591263 : oac === 2 ? -0.18593561 : 0,
      ethnicity: ethnicity === 1 ? 0.157023564 : ethnicity === 2 ? -0.609609055 : ethnicity === 3 ? 0.375675102 : 0,
      age: age <= 65 ? 0.031050027 * (age - 65) : 0.064594824 * (age - 65),
      weight: weight <= 75 ? -0.021535182 * (weight - 75) : 0,
      pulse: pulse <= 120 ? 0.007678035 * (pulse - 120) : 0,
      diastolic: diastolic <= 80 ? -0.019304333 * (diastolic - 80) : 0,
   };

   const strokeCoefficients = {
      heartfail: heartfail === 1 ? 0.233182644 : 0,
      vasc: vasc === 1 ? 0.197919709 : 0,
      stroke: stroke === 1 ? 0.800863063 : 0,
      bleed: bleed === 1 ? 0.29883967 : 0,
      diab: diab === 1 ? 0.211995445 : 0,
      ckd: ckd === 1 ? 0.349516938 : 0,
      dementia: dementia === 1 ? 0.513221391 : 0,
      smoker: smoker === 1 ? 0.478831506 : 0,
      oac: oac === 1 ? -0.572199357 : oac === 2 ? -0.352373263 : 0,
      age: 0.039138147 * (age - 65),
      diastolic: diastolic > 80 ? 0.01590016 * (diastolic - 80) : 0,
   };

   const bleedingCoefficients = {
      vasc: vasc === 1 ? 0.168950627 : 0,
      bleed: bleed === 1 ? 0.782237771 : 0,
      carotid: carotid === 1 ? 0.316245771 : 0,
      ckd: ckd === 1 ? 0.498686574 : 0,
      oac: oac === 1 ? 0.24232543 : oac === 2 ? 0.609713354 : 0,
      antiplatelet: antiplatelet === 1 ? 0.236620846 : 0,
      diab: diab === 1 ? 0.176898047 : 0,
      age: 0.043476276 * (age - 65),
      pulse: 0.004167103 * (pulse - 120),
   };

   const mortalityX = Object.values(mortalityCoefficients).reduce((a: number, b: number) => a + b, 0);
   const strokeX = Object.values(strokeCoefficients).reduce((a: number, b: number) => a + b, 0);
   const bleedingX = Object.values(bleedingCoefficients).reduce((a: number, b: number) => a + b, 0);


   const baselineSurvival = {
      mortality: { sixMonths: 0.9879, oneYear: 0.9791, twoYears: 0.9625 },
      stroke: { sixMonths: 0.9956, oneYear: 0.9925, twoYears: 0.9876 },
      bleeding: { sixMonths: 0.9969, oneYear: 0.9947, twoYears: 0.9917 },
   };

   function calculateRisk(baseline: { sixMonths: number; oneYear: number; twoYears: number }, x: number) {
      return {
         sixMonths: ((1 - Math.pow(baseline.sixMonths, Math.exp(x))) * 100).toFixed(2) + '%',
         oneYear: ((1 - Math.pow(baseline.oneYear, Math.exp(x))) * 100).toFixed(2) + '%',
         twoYears: ((1 - Math.pow(baseline.twoYears, Math.exp(x))) * 100).toFixed(2) + '%',
      };
   }

   const mortalityRisk = calculateRisk(baselineSurvival.mortality, mortalityX);
   const strokeRisk = calculateRisk(baselineSurvival.stroke, strokeX);
   const bleedingRisk = calculateRisk(baselineSurvival.bleeding, bleedingX);

   return {
      mortality: mortalityRisk,
      stroke: strokeRisk,
      bleeding: bleedingRisk,
   };
};

export const meldScoreCalc = (
   dialysis: number,
   creatinine: number,
   bilirubin: number,
   inr: number
) => {
   const ccreatinine = (dialysis === 1 || creatinine > 4) ? 4 : creatinine;

   const creatinineFix = Math.max(ccreatinine, 1);
   const bilirubinFix = Math.max(bilirubin, 1);
   const inrFix = Math.max(inr, 1);

   const meldScore = 10 * (0.957 * Math.log(creatinineFix) +
      0.378 * Math.log(bilirubinFix) +
      1.120 * Math.log(inrFix)) + 6.43;

   return Math.round(meldScore);
}

export const meldNaScoreCalc = (
   creatinine: number,
   bilirubin: number,
   inr: number,
   sodium: number,
   dialysis: number
) => {
   creatinine = Math.max(creatinine, 1.0);
   bilirubin = Math.max(bilirubin, 1.0);
   inr = Math.max(inr, 1.0);

   if (creatinine > 4.0 || dialysis === 1) {
      creatinine = 4.0;
   }

   sodium = Math.min(Math.max(sodium, 125), 137);

   let meldI = 0.957 * Math.log(creatinine) + 0.378 * Math.log(bilirubin) + 1.120 * Math.log(inr) + 0.643;

   meldI = Math.round(meldI * 10);

   let meldScore = meldI;
   if (meldI > 11) {
      meldScore = meldI + 1.32 * (137 - sodium) - (0.033 * meldI * (137 - sodium));
   }

   return Math.min(Math.round(meldScore), 40);
};

export const meld3ScoreCalc = (
   gender: number,
   bilirubin: number,
   sodium: number,
   inr: number,
   creatinine: number,
   albumin: number,
   dialysis: number,
   age: number
) => {
   bilirubin = Math.max(bilirubin, 1.0);
   creatinine = dialysis === 1 || creatinine > 3.0 ? 3.0 : Math.max(creatinine, 1.0);
   sodium = Math.max(Math.min(sodium, 137), 125);
   albumin = Math.max(Math.min(albumin, 3.5), 1.5);

   const sodiumFactor = 0.82 * (137 - sodium) - 0.24 * (137 - sodium) * Math.log(bilirubin);
   const femaleFactor = gender === 0 && age === 1 ? 1.33 : 0;

   const meldScore = femaleFactor
      + 4.56 * Math.log(bilirubin)
      + sodiumFactor
      + 9.09 * Math.log(inr)
      + 11.14 * Math.log(creatinine)
      + 1.85 * (3.5 - albumin)
      - 1.83 * (3.5 - albumin) * Math.log(creatinine);

   const ageFactor = age === 1 ? 6 : 7.33;

   return Math.round(meldScore + ageFactor);
};

export function dentTAMaxFunc (locan: string, weight: number) {
   let res, carp;
   if (locan === 'Убистезин 1,7 мл' || locan === 'Септанест 1:200,000 1,7 мл') {
      let maxDose = weight * 7
      if (maxDose < 501) {
         carp = maxDose / 68
         res = maxDose
      } else {
         res = 500
         carp = 7.3
      }
   } else if (locan === 'Убистезин Форте 1,7 мл' || locan === 'Септанест 1:100,000 1,7 мл') {
      let maxDose = weight * 7
      if (maxDose < 501) {
         carp = maxDose / 68
         res = maxDose
      } else {
         res = 500
         carp = 7.3
      }
   } else if (locan ==='Ораблок 1,8 мл' || locan ==='Артинибса 1,8 мл') {
      let maxDose = weight * 7
      if (maxDose < 501) {
         carp = maxDose / 72
         res = maxDose
      } else {
         res = 500
         carp = 6.9
      }
   } else if (locan === 'Лигноспан 1,8 мл') {
      let maxDose = weight * 4.4
      if (maxDose < 500) {
         carp = maxDose / 36
         res = maxDose
      } else {
         res = 500
         carp = 13.8
      }
   } else if (locan === 'Ксилестезин-А 1,7 мл' || locan === 'Лигноспан стандарт 1,7 мл') {
      let maxDose = weight * 4.4
      if (maxDose < 500) {
         carp = maxDose / 34
         res = maxDose
      } else {
         res = 500
         carp = 11
      }
   } else if (locan === 'Лидокаин') {
      let maxDose = weight * 4.4
      if (maxDose < 300) {
         carp = maxDose / 40
         res = maxDose
      } else {
         res = 300
         carp = 7.5
      }
   } else if (locan === 'Скандонест 1,8 мл' || locan === 'Мепивастезин 1,8 мл') {
      let maxDose = weight * 4.4
      if (maxDose < 400) {
         carp = maxDose / 54
         res = maxDose
      } else {
         res = 400
         carp = 7.4
      }
   }
   return { res, carp, locan, weight }
}

export const H2FPEFFunc = (age: number, bmi: number, ee: number, ps: number, af: number): string => {

   const coef = -9.1917 + 0.0451 * age + 0.1307 * bmi + 0.0859 * ee + 0.0520 * ps + 1.6997 * af;
   const res = (Math.exp(coef) / (1 + Math.exp(coef))) * 100
   const resToStr = res.toFixed(2);

   return resToStr
}

export const suncreenBody = (weight: number, height: number, day: number, hour: number, packageFl: number) => {

   const aream = Math.pow((weight * height / 3600), 0.5);
   

   const sunscrQuant = Math.round(aream * 10 * 2);
   const sunscrQuantSp = sunscrQuant / 4.929;

   let sunscrPack: number;

   if (hour <= 3) {
      sunscrPack = sunscrQuant / packageFl
   } else if (hour % 2 === 0) {
      let evNum = hour / 2
      sunscrPack = sunscrQuant / packageFl * evNum
   } else {
      let evNum = (hour - 1) / 2
      sunscrPack = sunscrQuant / packageFl * evNum
   }

   sunscrPack = sunscrPack * day

   return { sunscrQuant, sunscrQuantSp, sunscrPack }
}


export const suncreenFace = (flength: number, fwidth: number, day: number, hour: number, packageFl: number) => {

   const sunscrQuant = (flength/2 * fwidth/2) * Math.PI * 2 / 1000;
   const sunscrQuantSp = sunscrQuant / 4.929;

   let sunscrPack: number;

   if (hour <= 3) {
      sunscrPack = sunscrQuant / packageFl
   } else if (hour % 2 === 0) {
      let evNum = hour / 2
      sunscrPack = sunscrQuant / packageFl * evNum
   } else {
      let evNum = (hour - 1) / 2
      sunscrPack = sunscrQuant / packageFl * evNum
   }

   sunscrPack = sunscrPack * day

   return { sunscrQuant, sunscrQuantSp, sunscrPack }
}

function scoreRiskFunc(age: number, riskEstimationCalibrated: number): string {
   let scoreRisk: string = '';
   if (age < 50) {
      if (riskEstimationCalibrated < 2.5) {
         scoreRisk = 'Низкий'
      } else if (riskEstimationCalibrated >= 2.5 && riskEstimationCalibrated < 7.5) {
         scoreRisk = 'Средний'
      } else {
         scoreRisk = 'Высокий'
      }
   }
   if (age >= 50 && age < 69) {
      if (riskEstimationCalibrated < 5) {
         scoreRisk = 'Низкий'
      } else if (riskEstimationCalibrated >= 5 && riskEstimationCalibrated < 10) {
         scoreRisk = 'Средний'
      } else {
         scoreRisk = 'Высокий'
      }
   }
   if (age >= 70) {
      if (riskEstimationCalibrated < 7.5) {
         scoreRisk = 'Низкий'
      } else if (riskEstimationCalibrated >= 7.5 && riskEstimationCalibrated < 15) {
         scoreRisk = 'Средний'
      } else {
         scoreRisk = 'Высокий'
      }
   }
   return scoreRisk;
}
 

 export const Score2Func = (gender: string, age: number, smoking: number, sbp: number, diabetes: number, tchol: number, hdlchol: number, riskRegion: string, isMmol: boolean) => {
   if (!isMmol) {
      tchol = tchol * 0.02586
      hdlchol = hdlchol * 0.02586
   }
   const cage = (age - 60) / 5;
   const csbp = (sbp - 120) / 20
   const ctchol = (tchol - 6) / 1
   const chdlchol = (hdlchol - 1.3) / 0.5
   const smokingage = cage * smoking;
   const sbpage = cage * csbp;
   const tcholage = cage * ctchol;
   const hdlcholage = cage * chdlchol;
   const diabetesage = cage * diabetes;
   let ageLog: number, smokingLog: number, sbpLog: number, diabetLog: number, tcholLog: number, hdlcholLog: number, smokingageLog: number, sbpageLog: number, cholageLog: number, hdlageLog: number, diabetesageLog: number, scale1: number | undefined, scale2: number | undefined;
   if (gender == 'male') {
      ageLog = 0.3742
      smokingLog = 0.6012
      sbpLog = 0.2777
      diabetLog = 0.6457
      tcholLog = 0.1458
      hdlcholLog = -0.2698
      smokingageLog = -0.0755
      sbpageLog = -0.0255
      cholageLog = -0.0281
      hdlageLog = 0.0426
      diabetesageLog = -0.0983
      if (riskRegion == 'low') {
         scale1 = -0.5699
         scale2 = 0.7476
      } else if (riskRegion == 'moderate') {
         scale1 = -0.1565
         scale2 = 0.8009
      } else if (riskRegion == 'high') {
         scale1 = 0.3207
         scale2 = 0.9360
      } else if (riskRegion == 'very high') {
         scale1 = 0.5836
         scale2 = 0.8294
      }
   } else {
      ageLog = 0.4648
      smokingLog = 0.7744
      sbpLog = 0.3131
      diabetLog = 0.8096
      tcholLog = 0.1002
      hdlcholLog = -0.2606
      smokingageLog = -0.1088
      sbpageLog = -0.0277
      cholageLog = -0.0226
      hdlageLog = 0.0613
      diabetesageLog = -0.1272
      if (riskRegion == 'low') {
         scale1 = -0.7380
         scale2 = 0.7019
      } else if (riskRegion == 'moderate') {
         scale1 = -0.3143
         scale2 = 0.7701
      } else if (riskRegion == 'high') {
         scale1 = 0.5710
         scale2 = 0.9369
      } else if (riskRegion == 'very high') {
         scale1 = 0.9412
         scale2 = 0.8329
      }
   }
   const baselineSurvival = gender == 'male' ? 0.9605 : 0.9776
   const linearPredictor = (cage * ageLog) + (smoking * smokingLog) + (csbp * sbpLog) + (diabetes * diabetLog) + (ctchol * tcholLog) + (chdlchol * hdlcholLog) + (smokingage * smokingageLog) + (sbpage * sbpageLog) + (tcholage * cholageLog) + (hdlcholage * hdlageLog) + (diabetesage * diabetesageLog);
   const riskEstimationUncalibrated = 1 - Math.pow(baselineSurvival, Math.exp(linearPredictor));
   const riskEstimationCalibrated = (1 - Math.exp(-Math.exp(scale1! + scale2! * Math.log(-Math.log(1 - riskEstimationUncalibrated))))) * 100
   const riskEstimationCalibratedFix = riskEstimationCalibrated.toFixed(2);

   const scoreRisk = scoreRiskFunc(age, riskEstimationCalibrated);
   
   return {riskEstimationCalibratedFix, scoreRisk};
}


export const Score2OPFunc = (gender: string, age: number, smoking: number, sbp: number, diabetes: number, tchol: number, hdlchol: number, riskRegion: string, isMmol: boolean) => {
   if (!isMmol) {
      tchol = tchol * 0.02586
      hdlchol = hdlchol * 0.02586
   }
   const cage = 73;
   const csbp = 150;
   const ctchol = 6;
   const chdlchol = 1.4;
   let ageLog: number, smokingLog: number, sbpLog: number, diabetLog: number, tcholLog: number, hdlcholLog: number, smokingageLog: number, sbpageLog: number, cholageLog: number, hdlageLog: number, diabetesageLog: number, scale1: number | undefined, scale2: number | undefined;
   if (gender == 'male') {
         ageLog = 0.0634
         smokingLog = 0.3524
         sbpLog = 0.0094
         diabetLog = 0.4245
         tcholLog = 0.0850
         hdlcholLog = -0.3564
         smokingageLog = -0.0247
         sbpageLog = -0.0005
         cholageLog = 0.0073
         hdlageLog = 0.0091
         diabetesageLog = -0.0174
      if (riskRegion == 'low') {
         scale1 = -0.34
         scale2 = 1.19
      } else if (riskRegion == 'moderate') {
         scale1 = 0.01
         scale2 = 1.25
      } else if (riskRegion == 'high') {
         scale1 = 0.08
         scale2 = 1.15
      } else if (riskRegion == 'very high') {
         scale1 = 0.05
         scale2 = 0.7
      }
   } else {
      ageLog = 0.0789
      smokingLog = 0.4921
      sbpLog = 0.0102
      diabetLog = 0.6010
      tcholLog = 0.0605
      hdlcholLog = -0.3040
      smokingageLog = -0.0255
      sbpageLog = -0.0004
      cholageLog = -0.0009
      hdlageLog = 0.0154
      diabetesageLog = -0.0107
      if (riskRegion == 'low') {
         scale1 = -0.52
         scale2 = 1.01
      } else if (riskRegion == 'moderate') {
         scale1 = -0.1
         scale2 = 1.1
      } else if (riskRegion == 'high') {
         scale1 = 0.38
         scale2 = 1.09
      } else if (riskRegion == 'very high') {
         scale1 = 0.38
         scale2 = 0.69
      }
   }
   const baselineSurvival = gender == 'male' ? 0.758 : 0.808
   const meanLP = gender == 'male' ? 0.093 : 0.229;
   const linearPredictor = (ageLog * (age - cage)) + (smokingLog * smoking) + (sbpLog * (sbp - csbp)) + (diabetLog * diabetes) + (tcholLog * (tchol - ctchol)) + (hdlcholLog * (hdlchol - chdlchol)) + (smokingageLog * (age - cage)) + (sbpageLog * (age - cage) * (sbp - csbp)) + (cholageLog * (tchol - ctchol) * (age - cage)) + (hdlageLog * (hdlchol - chdlchol) * (age - cage)) + (diabetesageLog * (age - cage) * diabetes);
   const riskEstimationUncalibrated = 1 - Math.pow(baselineSurvival, Math.exp(linearPredictor - meanLP));
   const riskEstimationCalibrated = (1 - Math.exp(-Math.exp(scale1! + scale2! * Math.log(-Math.log(1 - riskEstimationUncalibrated))))) * 100;
   const riskEstimationCalibratedFix = riskEstimationCalibrated.toFixed(2);

   const scoreRisk = scoreRiskFunc(age, riskEstimationCalibrated);
   
   return {riskEstimationCalibratedFix, scoreRisk};
}

export const Score2FuncDiab = (gender: string, age: number, smoking: number, sbp: number, diabetes: number, tchol: number, hdlchol: number, riskRegion: string, isMmol: boolean, agediab: number, a1c: number, egfr: number) => {
   if (!isMmol) {
      tchol = tchol * 0.02586
      hdlchol = hdlchol * 0.02586
   }

   const cage = (age - 60) / 5;
   const csbp = (sbp - 120) / 20;
   const ctchol = tchol - 6;
   const chdlchol = (hdlchol - 1.3) / 0.5;

   const smokingage = cage * smoking;
   const sbpage = cage * csbp;
   const tcholage = cage * ctchol;
   const hdlcholage = cage * chdlchol;
   const diabetesage = cage * diabetes;

   const ageLog = gender === 'male' ? 0.5368 : 0.6624;
   const smokingLog = gender === 'male' ? 0.4774 : 0.6139;
   const sbpLog = gender === 'male' ? 0.1322 : 0.1421;
   const diabetLog = gender === 'male' ? 0.6457 : 0.8096;
   const tcholLog = gender === 'male' ? 0.1102 : 0.1127;
   const hdlcholLog = gender === 'male' ? -0.1087 : -0.1568;
   const smokingageLog = gender === 'male' ? -0.0672 : -0.1122;
   const sbpageLog = gender === 'male' ? -0.0268 : -0.0167;
   const diabetesageLog = gender === 'male' ? -0.0983 : -0.1272;
   const cholageLog = gender === 'male' ? -0.0181 : -0.0200;
   const hdlageLog = gender === 'male' ? 0.0095 : 0.0186;

   const cagediab = diabetes * (agediab - 50) / 5;
   const ca1c = (a1c - 31) / 9.34;
   const cegfr = (Math.log(egfr) - 4.5) / 0.15;
   const cegfr2 = cegfr * cegfr;
   const a1cAge = ca1c * cage;
   const egfrAge = cegfr * cage;

   const cagediabLog = gender === 'male' ? -0.0998 : -0.1180;
   const ca1cLog = gender === 'male' ? 0.0955 : 0.1173;
   const cegfrLog = gender === 'male' ? -0.0591 : -0.0640;
   const cegfr2Log = gender === 'male' ? 0.0058 : 0.0062;
   const a1cAgeLog = gender === 'male' ? -0.0134 : -0.0196;
   const egfrAgeLog = gender === 'male' ?
      0.0115 : 0.0169;

   const baselineSurvival = gender === 'male' ? 0.9605 : 0.9776;

   const linearPredictor =
      (cage * ageLog) +
      (smoking * smokingLog) +
      (csbp * sbpLog) +
      (diabetes * diabetLog) +
      (ctchol * tcholLog) +
      (chdlchol * hdlcholLog) +
      (smokingage * smokingageLog) +
      (sbpage * sbpageLog) +
      (tcholage * cholageLog) +
      (hdlcholage * hdlageLog) +
      (diabetesage * diabetesageLog) +
      (cagediab * cagediabLog) +
      (ca1c * ca1cLog) +
      (cegfr * cegfrLog) +
      (cegfr2 * cegfr2Log) +
      (a1cAge * a1cAgeLog) +
      (egfrAge * egfrAgeLog);

   let scale1: number, scale2: number;

   if (gender == 'male') {
      if (riskRegion == 'low') {
         scale1 = -0.5699
         scale2 = 0.7476
      } else if (riskRegion == 'moderate') {
         scale1 = -0.1565
         scale2 = 0.8009
      } else if (riskRegion == 'high') {
         scale1 = 0.3207
         scale2 = 0.9360
      } else if (riskRegion == 'very high') {
         scale1 = 0.5836
         scale2 = 0.8294
      }
   } else {
      if (riskRegion == 'low') {
         scale1 = -0.7380
         scale2 = 0.7019
      } else if (riskRegion == 'moderate') {
         scale1 = -0.3143
         scale2 = 0.7701
      } else if (riskRegion == 'high') {
         scale1 = 0.5710
         scale2 = 0.9369
      } else if (riskRegion == 'very high') {
         scale1 = 0.9412
         scale2 = 0.8329
      }
   }

   const riskEstimationUncalibrated = 1 - Math.pow(baselineSurvival, Math.exp(linearPredictor));
   const riskEstimationCalibrated = (1 - Math.exp(-Math.exp(scale1! + scale2! * Math.log(-Math.log(1 - riskEstimationUncalibrated))))) * 100;
   const riskEstimationCalibratedFix = riskEstimationCalibrated.toFixed(2);

   const scoreRisk = scoreRiskFunc(age, riskEstimationCalibrated);

   return { riskEstimationCalibratedFix, scoreRisk };
}


interface QTScanParameters {
   age: string;
   gender: string;
   heartfail: boolean;
   myoinf: boolean;
   hypokal: boolean;
   sepsis: boolean;
   qtc: boolean;
}


export const QTScanFunc = ({ age, gender, heartfail, myoinf, qtc, hypokal, sepsis }: QTScanParameters): number => {
   const cage = +age >= 68 ? 1 : 0;
   const cgender = +gender;
   const chf = heartfail ? 3 : 0;
   const cmyoinf = myoinf ? 2 : 0;
   const cqtc = qtc ? 2 : 0;
   const chypokal = hypokal ? 2 : 0;
   const csepsis = sepsis ? 3 : 0;

   const result = cage + cgender + chf + cmyoinf + cqtc + chypokal + csepsis;

   return result
}

interface QTScanNonIcuParameters {
   age: string,
   gender: string,
   atrialfib: boolean,
   lqts: boolean,
   heartfail: boolean,
   valve: boolean,
   hypertension: boolean,
   myoinf: boolean,
   myocinfprior: boolean,
   qtc: boolean,
   qtc500: boolean,
   hypocalc: boolean,
   hypokal: boolean,
   hypomag: boolean
}

export const QTScanNonIcuFunc = ({ age, gender, atrialfib, lqts, heartfail, valve, hypertension, myoinf, myocinfprior, qtc, qtc500, hypocalc, hypokal, hypomag }: QTScanNonIcuParameters): number => {
   const cage = +age >= 68 ? 1 : 0;
   const cgender = +gender;
   const catrialfib = atrialfib ? 3 : 0;
   const clqts = lqts ? 8 : 0;
   const chf = heartfail ? 3 : 0;
   const cvalve = valve ? 2 : 0;
   const chypertension = hypertension ? 2 : 0;
   const cmyoinf = myoinf ? 3 : 0;
   const cmyocinfprior = myocinfprior ? 2 : 0;
   const cqtc = qtc ? 3 : 0;
   const cqtc500 = qtc500 ? 8 : 0;
   const chypocalc = hypocalc ? 1 : 0;
   const chypokal = hypokal ? 3 : 0;
   const chypomag = hypomag ? 2 : 0;

   const result = cage + cgender + catrialfib + clqts + chf + cvalve + chypertension + cmyoinf + cmyocinfprior + cqtc + cqtc500 + chypocalc + chypokal + chypomag;

   return result
}


function ccrclearance(cc: number):number {
   let ncc = 0;
   if (cc >= 0 && cc <= 2) ncc = 25;
   if (cc >= 3 && cc <= 6) ncc = 24;
   if (cc >= 7 && cc <= 10) ncc = 23;
   if (cc >= 11 && cc <= 14) ncc = 22;
   if (cc >= 15 && cc <= 18) ncc = 21;
   if (cc >= 19 && cc <= 22) ncc = 20;
   if (cc >= 23 && cc <= 26) ncc = 19;
   if (cc >= 27 && cc <= 30) ncc = 18;
   if (cc >= 31 && cc <= 34) ncc = 17;
   if (cc >= 35 && cc <= 38) ncc = 16;
   if (cc >= 39 && cc <= 42) ncc = 15;
   if (cc >= 43 && cc <= 48) ncc = 14;
   if (cc >= 49 && cc <= 50) ncc = 13;
   if (cc >= 51 && cc <= 54) ncc = 12;
   if (cc >= 55 && cc <= 58) ncc = 11;
   if (cc >= 59 && cc <= 62) ncc = 10;
   if (cc >= 63 && cc <= 66) ncc = 9;
   if (cc >= 67 && cc <= 70) ncc = 8;
   if (cc >= 71 && cc <= 74) ncc = 7;
   if (cc >= 75 && cc <= 78) ncc = 6;
   if (cc >= 79 && cc <= 82) ncc = 5;
   if (cc >= 83 && cc <= 86) ncc = 4;
   if (cc >= 87 && cc <= 90) ncc = 3;
   if (cc >= 91 && cc <= 94) ncc = 2;
   if (cc >= 95 && cc <= 98) ncc = 1;
   return ncc;
}

function cage(age: number): number {
   let nage = 19;
   if (age < 52) nage = 0;
   if (age == 52 || age == 53) nage = 1;
   if (age == 54 || age == 55) nage = 2;
   if (age == 56 || age == 57) nage = 3;
   if (age == 58 || age == 59) nage = 4;
   if (age == 60 || age == 61) nage = 5;
   if (age == 62 || age == 63) nage = 6;
   if (age == 64 || age == 65) nage = 7;
   if (age == 66 || age == 67) nage = 8;
   if (age == 68 || age == 69) nage = 9;
   if (age == 70 || age == 71 || age == 72) nage = 10;
   if (age == 73 || age == 74) nage = 11;
   if (age == 75 || age == 76) nage = 12;
   if (age == 77 || age == 78) nage = 13;
   if (age == 79 || age == 80) nage = 14;
   if (age == 81 || age == 82) nage = 15;
   if (age == 83 || age == 84) nage = 16;
   if (age == 85 || age == 86) nage = 17;
   if (age == 87 || age == 88) nage = 18;
   return nage;
}

function cwbc(wbc: number): number {
   let nwbc = 15;
   if (wbc < 6) nwbc = 0;
   if (wbc >= 6 && wbc <= 7.3) nwbc = 1;
   if (wbc >= 7.4 && wbc < 8.5) nwbc = 2;
   if (wbc >= 8.5 && wbc < 9.5) nwbc = 3;
   if (wbc >= 9.5 && wbc < 10.3) nwbc = 4;
   if (wbc >= 10.3 && wbc < 11.2) nwbc = 5;
   if (wbc >= 11.2 && wbc < 12.1) nwbc = 6;
   if (wbc >= 12.1 && wbc < 13) nwbc = 7;
   if (wbc >= 13 && wbc < 14) nwbc = 8;
   if (wbc >= 14 && wbc < 14.9) nwbc = 9;
   if (wbc >= 14.9 && wbc < 15.8) nwbc = 10;
   if (wbc >= 15.8 && wbc < 16.7) nwbc = 11;
   if (wbc >= 16.7 && wbc < 17.6) nwbc = 12;
   if (wbc >= 17.6 && wbc < 18.4) nwbc = 13;
   if (wbc >= 18.5 && wbc < 19.5) nwbc = 14;
   return nwbc;
}

function chb(hb: number): number {
   let nchb = 0;
   if (hb < 10.1) nchb = 14;
   if (hb >= 10.1 && hb < 10.2) nchb = 13;
   if (hb >= 10.2 && hb < 10.4) nchb = 12;
   if (hb >= 10.4 && hb < 10.5) nchb = 11;
   if (hb >= 10.5 && hb < 10.6) nchb = 10;
   if (hb >= 10.6 && hb < 10.7) nchb = 9;
   if (hb >= 10.7 && hb < 10.9) nchb = 8;
   if (hb >= 10.9 && hb < 11) nchb = 7;
   if (hb >= 11 && hb < 11.1) nchb = 6;
   if (hb >= 11.1 && hb < 11.3) nchb = 5;
   if (hb >= 11.3 && hb < 11.5) nchb = 4;
   if (hb >= 11.5 && hb < 11.6) nchb = 3;
   if (hb >= 11.6 && hb < 11.8) nchb = 2;
   if (hb >= 11.8 && hb < 12) nchb = 1;
   return nchb;
}

export const totalPreciseDapt = (hb: number, wbc: number, age: number, cc: number, blood: number): number => {
   let answer = chb(hb) + cwbc(wbc) + cage(age) + ccrclearance(cc) + blood;
   return answer;
}


export function mdrdFunc (age: number, gender: number, creatinine: number, ismgdl: boolean, race: number) {
   const ccreatinine = ismgdl === true ? creatinine : creatinine / 88.4016973126
   const cgender = gender === 1 ? 1 : 0.742;
   const crace = race === 0 ? 1 : 1.212;
   const gfr = 175 * (1/Math.pow(ccreatinine, 1.154)) * (1/Math.pow(age, 0.203)) * crace * cgender
   const cgfr = Math.round(gfr);
   return cgfr;
}


export function cockcroft (age: number, weight: number, gender: number, creatinine: number, ismgdl: boolean, height: number) {
   const ccreatinine = ismgdl === true ? creatinine : creatinine / 88.4016973126
   const cgender = gender === 1 ? 1 : 0.85;
   const gfr = (140 - age) * weight * cgender / (72 * ccreatinine)
   const cgfr = Math.round(gfr);

   let ibw;
   if (gender === 1) {
      ibw = 50 + (2.3 * ((height / 2.54) - 60))
   } else {
      ibw = 45.5 + (2.3 * ((height / 2.54) - 60))
   }

   const abw = ibw + 0.4 * (weight - ibw)
   const cbw = weight < 69 ? ibw : abw
   const egfr = ((140 - age) * cbw / (72 * ccreatinine)) * cgender
   const cegfr = Math.round(egfr);
   const heightM = height / 100;
   const bmi = weight / (heightM * heightM)
   return {cgfr, cegfr, bmi}
}


export function ckdEpiFunc (age: number, gender: number, creatinine: number, ismgdl: boolean) {
   const ccreatinine = ismgdl === true ? creatinine : creatinine / 88.4016973126
   const cgender = gender === 1 ? 1 : 1.012;
   const k = gender === 1 ? 0.9 : 0.7;
   const a = gender === 1 ? -0.302 : -0.241;
   const ccreatininek = ccreatinine/k;
   const min = ccreatininek < 1 ? ccreatininek : 1;
   const max = ccreatininek > 1 ? ccreatininek : 1;
   const gfr = 142 * Math.pow(min, a) * (1/Math.pow(max, 1.200)) * Math.pow(0.9938, age) * cgender
   const cgfr = Math.round(gfr);
   return cgfr
}