import * as SecureStore from 'expo-secure-store';


export function textTranslit(text: string) {
   let arreng = ['A', 'a', 'B', 'b', 'V', 'v', 'G', 'g', 'D', 'd', 'E', 'e', 'Z', 'z', 'I', 'i', 'J', 'j', 'K', 'k', 'L', 'l', 'M', 'm', 'N', 'n', 'O', 'o', 'P', 'p', 'R', 'r', 'S', 's', 'T', 't', 'U', 'u', 'F', 'f', 'H', 'h', 'C', 'c', 'Y', 'y', 'Q', 'q', 'W', 'w', 'X', 'x'];
   let arrarm = ['а', 'а', 'б', 'б', 'в', 'в', 'г', 'г', 'д', 'д', 'е', 'е', 'з', 'з', 'и', 'и', 'дж', 'дж', 'к', 'к', 'л', 'л', 'м', 'м', 'н', 'н', 'о', 'о', 'п', 'п', 'р', 'р', 'с', 'с', 'т', 'т', 'у', 'у', 'ф', 'ф', 'х', 'х', 'ж', 'ж', 'й', 'й', 'к', 'к', 'в', 'в', 'х', 'х']

   for (let i = 0; i < arreng.length; i++) {
      let reg = new RegExp(arreng[i], "g");
      text = text.replace(reg, arrarm[i]);
   }

   const regRep1 = /йу/gi;

   text = text.replaceAll(regRep1, 'ю')

   return text;
}

export const saveInSecureStore = async (value: string, storage: string) => {
   try {
      await SecureStore.setItemAsync(storage, value);
   } catch (error) {
      return;
   }
};

export const getFromSecureStore = async (storage: string): Promise<string | undefined> => {
   try {
      const storedHistory = await SecureStore.getItemAsync(storage);
      return storedHistory ? storedHistory : undefined;
   } catch (error) {
      return undefined;
   }
};

export const deleteFromSecureStore = async (storage: string) => {
   try {
      await SecureStore.deleteItemAsync(storage);
   } catch (error) {
      return;
   }
};

export function normalizeCommaToDot<T extends Record<string, any>>(data: T): T {
   const normalizedData = {} as T;

   for (const key in data) {
      const value = data[key];
      normalizedData[key] =
         typeof value === 'string' && value.includes(',')
            ? (value.replace(/,/g, '.') as any)
            : value;
   }

   return normalizedData;
}

export function getBallWord(count: number) {
   const lastDigit = count % 10;
   const lastTwoDigits = count % 100;

   if (lastTwoDigits >= 11 && lastTwoDigits <= 14) {
      return 'баллов';
   }

   if (lastDigit === 1) {
      return 'балл';
   } else if (lastDigit >= 2 && lastDigit <= 4) {
      return 'балла';
   } else {
      return 'баллов';
   }
}

export function getPackWord(count: number) {
   const lastDigit = count % 10;
   const lastTwoDigits = count % 100;

   if (lastTwoDigits >= 11 && lastTwoDigits <= 14) {
      return 'пачек';
   }

   if (lastDigit === 1) {
      return 'пачка';
   } else if (lastDigit >= 2 && lastDigit <= 4) {
      return 'пачки';
   } else {
      return 'пачек';
   }
}

export function getTeaspoonWord(count: number) {
   const lastDigit = count % 10;
   const lastTwoDigits = count % 100;

   if (lastTwoDigits >= 11 && lastTwoDigits <= 14) {
      return 'чайных ложек';
   }

   if (lastDigit === 1) {
      return 'чайная ложка';
   } else if (lastDigit >= 2 && lastDigit <= 4) {
      return 'чайные ложки';
   } else {
      return 'чайных ложек';
   }
}