import { FontAwesomeIcon } from '@fortawesome/react-native-fontawesome';
import { IconProp } from '@fortawesome/fontawesome-svg-core';
import { useAppSelector } from '@/src/redux/hooks';
import { ComponentProps } from 'react';

interface CustomIconProps extends Omit<ComponentProps<typeof FontAwesomeIcon>, 'icon'> {
   icon: IconProp;
}

export default function CustomIcon({ icon, ...props }: CustomIconProps) {
   const { titleSize } = useAppSelector(state => state.fontSizeStore);

   return (
      <FontAwesomeIcon
         size={titleSize}
         icon={icon}
         {...props}
      />
   );
}