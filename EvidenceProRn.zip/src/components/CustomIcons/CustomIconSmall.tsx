import { FontAwesomeIcon } from '@fortawesome/react-native-fontawesome';
import { IconProp } from '@fortawesome/fontawesome-svg-core';
import { useAppSelector } from '@/src/redux/hooks';
import { ComponentProps } from 'react';

interface CustomIconProps extends Omit<ComponentProps<typeof FontAwesomeIcon>, 'icon'> {
   icon: IconProp;
}

export default function CustomIconSmall({ icon, ...props }: CustomIconProps) {
   const { textSize } = useAppSelector(state => state.fontSizeStore);

   return (
      <FontAwesomeIcon
         size={textSize}
         icon={icon}
         {...props}
      />
   );
}