import React from 'react'
import { View } from 'react-native'
import CustomTextBold from '@/src/components/CustomTexts/CustomTextBold'
import { useTheme } from '@/src/hooks/useTheme'

export default function ToastModal({
   opacity,
   text
}: {
   opacity: 0 | 1,
   text: string
}) {
   const { colors } = useTheme()

   return (
      <View style={{
         position: 'absolute',
         width: 300,
         maxHeight: 150,
         zIndex: 2,
         backgroundColor: colors.modalToastBg,
         top: 20,
         left: '50%',
         transform: [{ translateX: '-50%' }],
         alignItems: 'center',
         justifyContent: 'center',
         paddingVertical: 15,
         paddingHorizontal: 10,
         borderRadius: 10,
         opacity
      }}>
         <CustomTextBold style={{ color: colors.primary }}>
            {text}
         </CustomTextBold>
      </View>
   )
}
