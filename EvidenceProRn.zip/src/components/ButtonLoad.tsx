import React from 'react'
import { ActivityIndicator, Platform, StyleSheet, TouchableOpacity } from 'react-native'
import { LoaderStatusType } from '@/src/types/types'
import CustomText from '@/src/components/CustomTexts/CustomText'
import { useTheme } from '@/src/hooks/useTheme'


interface IButtonLoad {
   title: string,
   status: LoaderStatusType | boolean,
   marginTop?: number,
   onPress: () => void,
}

const ButtonLoad: React.FC<IButtonLoad> = ({
   title,
   status,
   marginTop,
   onPress,
}) => {
   const { colors } = useTheme()

   return (
      <TouchableOpacity
         style={[
            styles.btn,
            {
               marginTop: marginTop,
               backgroundColor: colors.formBtn,
            }
         ]}
         onPress={onPress}
         accessibilityLabel="Press Me Btn"
         disabled={status === 'loading' ? true : false}
      >
         {status === 'loading' || status === true ? (
            <ActivityIndicator
               size={Platform.OS === 'ios' ? "small" : "large"}
               color={colors.indicator}
            />
         ) : (
            <CustomText style={{ color: colors.primaryReverse }}>
               {title}
            </CustomText>
         )}
      </TouchableOpacity>
   )
}

const styles = StyleSheet.create({
   btn: {
      height: 50,
      borderRadius: 2,
      flexDirection: 'row',
      alignItems: 'center',
      justifyContent: 'center',
   },
})

export default ButtonLoad
