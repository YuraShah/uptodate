import { faCaretDown } from '@fortawesome/free-solid-svg-icons';
import { FontAwesomeIcon } from '@fortawesome/react-native-fontawesome';
import React, { useState } from 'react'
import { Path, PathValue } from 'react-hook-form';
import { FlatList, Pressable } from 'react-native';
import { Modal, StyleSheet, TouchableOpacity, View } from 'react-native';
import CustomText from '@/src/components/CustomTexts/CustomText';
import { useTheme } from '@/src/hooks/useTheme';

interface ISelectPicker {
   onChange: (...event: any[]) => void,
   items: any[],
   value: PathValue<any, Path<any>>,
   placeholder?: string
}

const SelectPicker = ({
   onChange,
   items,
   value,
   placeholder
}: ISelectPicker) => {
   const [modalVisible, setModalVisible] = useState(false);
   const { colors } = useTheme()

   return (
      <>
         <Pressable
            onPress={() => setModalVisible(true)}
            style={[styles.formSelectTouch, { 
               backgroundColor: !modalVisible ? colors.inputBackground : colors.pickerBg 
            }]}
         >
            <CustomText
               style={{
                  flex: 1,
                  color: items.find(item => item.value === value) ? colors.pickerText : colors.pickerTextReverse,
               }}
               numberOfLines={1}
               ellipsizeMode="tail"
            >
               {items.find(item => item.value === value)?.label || placeholder || 'Выбрать'}
            </CustomText>
            <FontAwesomeIcon
               icon={faCaretDown}
            />
         </Pressable>

         <Modal
            transparent={true}
            visible={modalVisible}
            onRequestClose={() => setModalVisible(false)}
            supportedOrientations={['portrait', 'landscape']}
         >
            <TouchableOpacity
               style={styles.formModalContainer}
               activeOpacity={1}
               onPress={() => setModalVisible(false)}
            >
               <View style={[styles.formModalContent, , { backgroundColor: colors.pickerBg }]}>
                  <FlatList
                     contentContainerStyle={{ paddingVertical: 5 }}
                     data={items}
                     keyExtractor={(item) => item.value.toString()}
                     renderItem={({ item }) => (
                        <TouchableOpacity
                           style={styles.formModalItem}
                           onPress={() => {
                              onChange(item.value);
                              setModalVisible(false);
                           }}
                        >
                           <CustomText>
                              {item.label}
                           </CustomText>
                        </TouchableOpacity>
                     )}
                  />
               </View>
            </TouchableOpacity>
         </Modal>
      </>
   )
}

const styles = StyleSheet.create({
   formSelectTouch: {
      minHeight: 48,
      flexDirection: 'row',
      alignItems: 'center',
      justifyContent: 'space-between',
      columnGap: 15,
      paddingHorizontal: 15,
      borderRadius: 2
   },
   formModalContainer: {
      flex: 1,
      justifyContent: 'center',
      alignItems: 'center',
      backgroundColor: 'rgba(0, 0, 0, 0.5)',
   },
   formModalContent: {
      width: '80%',
      borderRadius: 4,
      maxHeight: 310
   },
   formModalItem: {
      padding: 15,
      width: '100%',
   },
})

export default SelectPicker
