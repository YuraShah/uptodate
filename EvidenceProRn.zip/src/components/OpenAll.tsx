import React from 'react'
import { TouchableOpacity } from 'react-native';
import CustomIcon from '@/src/components/CustomIcons/CustomIcon';
import { faMaximize, faMinimize } from '@fortawesome/free-solid-svg-icons';
import { useTheme } from '@/src/hooks/useTheme';

interface IOpenAll {
   openStates: boolean[],
   toggleAll: (open: boolean) => void
}

export default function OpenAll({
   openStates,
   toggleAll,
}: IOpenAll) {
   const { colors } = useTheme()

   return (
      <TouchableOpacity
         onPress={() => {
            const allOpen = openStates.every(Boolean);
            toggleAll(!allOpen);
         }}
         style={{
            position: 'absolute',
            bottom: 15,
            left: 15,
            backgroundColor: colors.primaryReverse,
            padding: 10,
            justifyContent: 'center',
            alignItems: 'center',
            borderRadius: 5,
            zIndex: 1
         }}
      >
         <CustomIcon
            icon={openStates.every(Boolean) ? faMinimize : faMaximize}
            color={colors.black}
         />
      </TouchableOpacity>
   )
}
