import React from 'react'
import CustomTextNoFontBold from './CustomTexts/CustomTextNoFontBold'
import { TouchableOpacity, View, Linking } from 'react-native'
import { useTheme } from '@/src/hooks/useTheme'
import CustomTextNoFont from '@/src/components/CustomTexts/CustomTextNoFont'
import { useSafeAreaInsets } from 'react-native-safe-area-context'


interface IAppUpdate {
   setIsAppCloseVersion: Function,
   isAppCloseLink: string
}

const AppUpdate = ({
   setIsAppCloseVersion,
   isAppCloseLink
}: IAppUpdate) => {
   const { colors } = useTheme()
   const insets = useSafeAreaInsets();

   return (
      <View
         style={{
            position: 'absolute',
            bottom: insets.bottom + 10,
            backgroundColor: colors.mainBg,
            width: '100%',
            zIndex: 10
         }}
      >
         <CustomTextNoFont
            style={{
               textAlign: 'center',
               marginVertical: 10,
               color: colors.mainBgText,
               fontSize: 17
            }}
         >
            Доступна обновленная версия
         </CustomTextNoFont>
         <View
            style={{
               flexDirection: 'row',
               justifyContent: 'space-evenly',
               gap: 10,
               marginVertical: 10
            }}
         >
            <TouchableOpacity
               accessibilityLabel='Press Close'
               onPress={() => setIsAppCloseVersion(false)}
               style={{
                  backgroundColor: colors.updateCloseBg,
                  paddingVertical: 5,
                  paddingHorizontal: 10,
                  borderRadius: 4,
                  alignItems: 'center',
                  justifyContent: 'center',
                  minWidth: 130,
                  height: 45,
               }}
            >
               <CustomTextNoFontBold
                  style={{
                     fontSize: 17,
                     color: colors.black
                  }}
               >
                  Закрыть
               </CustomTextNoFontBold>
            </TouchableOpacity>
            <TouchableOpacity
               onPress={() => Linking.openURL(isAppCloseLink!)}
               accessibilityLabel='Press Open'
               style={{
                  backgroundColor: colors.updateOpenBg,
                  paddingVertical: 5,
                  paddingHorizontal: 10,
                  borderRadius: 4,
                  alignItems: 'center',
                  justifyContent: 'center',
                  minWidth: 130,
                  height: 45
               }}
            >
               <CustomTextNoFontBold
                  style={{
                     fontSize: 17,
                     color: colors.black
                  }}
               >
                  Обновить
               </CustomTextNoFontBold>
            </TouchableOpacity>
         </View>
      </View>
   )
}

export default AppUpdate