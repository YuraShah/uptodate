import React from 'react'
import { Platform, StyleSheet, Text, View } from 'react-native'
import CustomText from '@/src/components/CustomTexts/CustomText'
import CustomTextBold from '@/src/components/CustomTexts/CustomTextBold'

interface IUlLi {
   marginVertical?: number,
   ulText?: string,
   liArray: (string | string[])[],
   isNumeric?: boolean
}

const UlLi = ({
   marginVertical = 20,
   ulText,
   liArray,
   isNumeric
}: IUlLi) => {
   return (
      <View style={{ marginVertical: marginVertical }}>
         {ulText ? (
            <CustomTextBold style={styles.ulTitle}>
               {ulText}
            </CustomTextBold>
         ) : null}
         {liArray.map((li, index) => (
            <React.Fragment key={index}>
               <CustomText
                  style={styles.liText}
               >
                  {isNumeric && typeof li === 'string' ? (
                     <><Text style={{ fontSize: Platform.OS === 'ios' ? 7 : 10 }}>{index + 1 + '. '}</Text> {li}</>
                  ) : typeof li === 'string' ? (
                     <><Text style={{ fontSize: Platform.OS === 'ios' ? 7 : 10 }}>{"\u2B24" + " "}</Text> {li}</>
                  ) : null}
               </CustomText>
               {Array.isArray(li) && (
                  <View style={styles.subLiContainer}>
                     {li.map((subLi, subIndex) => (
                        <CustomText key={subIndex} style={styles.subLiText}>
                           <Text style={{ fontSize: Platform.OS === 'ios' ? 6 : 8 }}>{"\u25EF" + " "}</Text> {subLi}
                        </CustomText>
                     ))}
                  </View>
               )}
            </React.Fragment>
         ))}
      </View>
   )
}

const styles = StyleSheet.create({
   ulTitle: {
      marginBottom: 3,
   },
   liText: {
      marginVertical: 3,
      paddingLeft: 10
   },
   subLiContainer: {
      marginTop: -30
   },
   subLiText: {
      marginVertical: 3,
      paddingLeft: 15,
   },
})

export default UlLi
