import React from 'react'
import { StyleSheet, TouchableOpacity } from 'react-native'
import CustomText from '@/src/components/CustomTexts/CustomText'
import { useTheme } from '@/src/hooks/useTheme'

interface ICalcButton {
   onPress: () => void,
}

const CalcButton: React.FC<ICalcButton> = ({ onPress }) => {
   const { colors } = useTheme()

   return (
      <TouchableOpacity
         style={[styles.btn, { backgroundColor: colors.calcBtnBg }]}
         onPress={onPress}
         accessibilityLabel='Press Save'
      >
         <CustomText>
            Результат
         </CustomText>
      </TouchableOpacity>
   )
}

const styles = StyleSheet.create({
   btn: {
      height: 50,
      borderRadius: 2,
      flexDirection: 'row',
      alignItems: 'center',
      justifyContent: 'center',
      marginTop: 20,
      marginBottom: 70
   },
})

export default CalcButton
