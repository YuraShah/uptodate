import React, { useMemo } from 'react'
import CalcSections from '@/src/components/Calcs/CalcSections'
import CustomText from '@/src/components/CustomTexts/CustomText'
import { Pressable, RefreshControl, ScrollView, StyleSheet, useWindowDimensions, View } from 'react-native'
import { useTheme } from '@/src/hooks/useTheme'
import CalcTitleShare from '@/src/components/Calcs/CalcTitleShare'
import { Control, FieldValues, Path, UseFormHandleSubmit } from 'react-hook-form'
import UlLi from '@/src/components/UlLi'
import CustomLink from '@/src/components/CustomTexts/CustomLink'
import { useNavigation } from '@react-navigation/native'
import { CustomTable } from '@/src/components/CustomTable'
import { findMatchingScreen } from '@/src/navigation/findMatchingScreen'
import CustomTextBoldItalic from '@/src/components/CustomTexts/CustomTextBoldItalic'
import CalcInput from '@/src/components/Calcs/CalcInput'
import CalcSelect from '@/src/components/Calcs/CalcSelect'
import CalcCheck from '@/src/components/Calcs/CalcCheck'
import CalcRadio from '@/src/components/Calcs/CalcRadio'
import CalcButton from '@/src/components/Calcs/CalcButton'
import CalcRefs from '@/src/components/Calcs/CalcRefs'
import { MainStackParamList } from '@/src/types/navigationTypes'
import { NativeStackNavigationProp } from '@react-navigation/native-stack'
import ZoomableImage from '@/src/components/ZoomableImage '
import { useAppSelector } from '@/src/redux/hooks'

interface IFormSelect<T extends FieldValues> {
   type: 'select',
   label: string,
   inputId: Path<T>,
   required: 'yes' | 'no',
   items: {
      value: string, label: string
   }[],
   selected?: boolean
}
interface IFormRadio<T extends FieldValues> {
   type: "radio",
   label: string,
   inputId: Path<T>,
   required: 'yes' | 'no',
   numeric: string,
   smallText?: string
   radioButtons: {
      id: string
      label: string
      value: string,
      color?: string
   }[]
}
interface IFormCheckbox<T extends FieldValues> {
   type: 'checkbox',
   inputId: Path<T>,
   label: string,
}
interface IFormInput<T extends FieldValues> {
   type: 'input',
   label: string,
   inputId: Path<T>,
   placeholder: string,
   placeholder1?: string,
   error: string,
   error1?: string,
   span: string,
   span1?: string,
   min?: number,
   min1?: number,
   max?: number,
   max1?: number,
   required: 'yes' | 'no',
   pattern: "nodot" | 'dot',
   ext?: 0 | 1,
   spanWidth?: number,
   extIndex?: number
}
interface IFormTitle {
   type: 'title',
   formTitle: string,
   link?: string,
}
interface IFormCustom {
   type: 'custom',
   text?: string,
   img?: any,
   height?: number,
   heightL?: number
}

type IForm<T extends FieldValues> = (IFormSelect<T> | IFormRadio<T> | IFormCheckbox<T> | IFormInput<T> | IFormTitle | IFormCustom)[]

export interface ICalcData<T extends FieldValues> {
   id: string,
   link: string,
   title: string,
   text: string,
   description: {
      descriptionMain: (string | (string | string[]))[],
      descriptionLink?: {
         name: string,
         link: string,
      }[],
      descriptionTable?: {
         headData?: string[],
         headWidthNums?: number[],
         bodyData: string[][],
         flexNums?: number[],
         widthNums?: number[]
      }[],
      descriptionImage?: {
         image: any,
         imageSub?: string,
         imageSup?: string,
         height?: number,
         heightL?: number
      }[]

   }
   form: IForm<T>,
   refers: string[]
}

interface ICalcComponent<T extends FieldValues> {
   data: ICalcData<T>,
   save: (data: T) => void
   handleSubmit: UseFormHandleSubmit<T>,
   result?: string | number,
   onRefresh: () => void,
   refreshing: boolean,
   control: Control<T>,
   isMarginStart?: boolean,
   spanVar?: boolean,
   spanBoolean?: boolean | boolean[],
   spanFunction?: Function | Function[],
   onChange?: (value: boolean) => void,
   ResultComponent?: JSX.Element
}

export default function CalcComponent<T extends FieldValues>({
   data,
   save,
   handleSubmit,
   result,
   onRefresh,
   refreshing,
   control,
   isMarginStart,
   spanVar,
   spanBoolean,
   spanFunction,
   onChange,
   ResultComponent
}: ICalcComponent<T>) {
   const { colors } = useTheme()
   const { width } = useWindowDimensions();
   const navigation = useNavigation<NativeStackNavigationProp<MainStackParamList>>()
   let newIndex = -1;
   const { user } = useAppSelector(state => state.authStore)
   const { paymentData } = useAppSelector(state => state.paymentStore)

   const navigationToLink = (link: string) => {
      const matchingScreen = findMatchingScreen(link);

      if (!matchingScreen) return;

      // if (typeof matchingScreen === 'string') {
      //    navigation.navigate('WebViewAuth', { url: matchingScreen });
      //    return;
      // }

      if (matchingScreen && Object.keys(matchingScreen.params).length > 0) {
         navigation.push(matchingScreen.screen as any, matchingScreen.params as any);
      } else {
         navigation.push(matchingScreen.screen as any);
      }
   }

   const renderRadioForm = (elem: IFormRadio<T>, index: number) => {

      const radioButtons = useMemo(() =>
         elem.radioButtons.map((rb) => ({
            ...rb,
         })),
         [index]
      );

      return (
         <CalcRadio<T>
            control={control}
            labelTitle={elem.label}
            inputId={elem.inputId}
            required={elem.required === 'yes' ? true : false}
            isNumeric={elem.numeric === 'yes' ? index + 1 : undefined}
            radioButtons={radioButtons}
            smallText={elem.smallText ? elem.smallText : undefined}
            isMarginStart={isMarginStart}
         />
      )
   }

   return (
      <CalcSections
         calc={(
            <>
               {ResultComponent ? ResultComponent : null}
               <ScrollView
                  refreshControl={
                     <RefreshControl
                        refreshing={refreshing}
                        onRefresh={onRefresh}
                        colors={[colors.mainBg]}
                        progressBackgroundColor={colors.refreshProgressBarBg}
                     />
                  }
                  style={styles.container}
               >
                  <CalcTitleShare
                     titleText={data.title}
                     calcId={data.id}
                     link={data.link}
                     lock={!user || paymentData.length === 0 || paymentData[0] !== 1 ? true : false}
                  />
                  <View style={styles.form}>
                     {data.form.map((elem, index) => {
                        const isInputOrSelect = elem.type === 'input' || elem.type === 'select';
                        newIndex = elem.type === 'title' || elem.type === 'custom' ? newIndex : newIndex + 1;
                        const inputSpanBoolean = elem.type === 'input' && Array.isArray(spanBoolean) && elem.extIndex != undefined ? spanBoolean[elem.extIndex] : !Array.isArray(spanBoolean) && spanBoolean;
                        const inputSpanFunction = elem.type === 'input' && Array.isArray(spanFunction) && elem.extIndex != undefined ? spanFunction[elem.extIndex] : !Array.isArray(spanFunction) ? spanFunction : undefined;

                        return (
                           <React.Fragment key={index}>
                              {elem.type === 'input' && elem.ext === 1 ? (
                                 <View
                                    style={[
                                       isInputOrSelect && width != undefined && width >= 780 && { width: '70%' }
                                    ]}
                                 >
                                    <CalcInput<T>
                                       control={control}
                                       labelTitle={elem.label}
                                       inputId={elem.inputId}
                                       inputPlaceholder={inputSpanBoolean ? (elem.placeholder1 || elem.placeholder) : elem.placeholder}
                                       errorText={inputSpanBoolean ? (elem.error1 || elem.error) : elem.error}
                                       inputSpan={inputSpanBoolean ? (elem.span1 || elem.span) : elem.span}
                                       min={inputSpanBoolean && elem.min ? elem.min1 : elem.min ? elem.min : undefined}
                                       max={inputSpanBoolean && elem.max ? elem.max1 : elem.max ? elem.max : undefined}
                                       required={elem.required === 'yes' ? true : false}
                                       pattern={elem.pattern === 'dot' ? /(^\d+$)|(^\d+[.,]\d+$)/ : /^\d+$/}
                                       spanVar={spanVar}
                                       spanBoolean={inputSpanBoolean}
                                       spanFunction={inputSpanFunction}
                                       spanWidth={elem.spanWidth}
                                    />
                                 </View>
                              ) : elem.type === 'input' ? (
                                 <View
                                    style={[
                                       isInputOrSelect && width != undefined && width >= 780 && { width: '70%' }
                                    ]}
                                 >
                                    <CalcInput<T>
                                       control={control}
                                       labelTitle={elem.label}
                                       inputId={elem.inputId}
                                       inputPlaceholder={elem.placeholder}
                                       errorText={elem.error}
                                       inputSpan={elem.span}
                                       min={elem.min ? elem.min : undefined}
                                       max={elem.max ? elem.max : undefined}
                                       required={elem.required === 'yes' ? true : false}
                                       pattern={elem.pattern === 'dot' ? /(^\d+$)|(^\d+[.,]\d+$)/ : /^\d+$/}
                                       spanWidth={elem.spanWidth}
                                    />
                                 </View>
                              ) : elem.type === 'radio' ? (
                                 renderRadioForm(elem, newIndex)
                              ) : elem.type === 'select' ? (
                                 <View
                                    style={[
                                       isInputOrSelect && width != undefined && width >= 780 && { width: '70%' }
                                    ]}
                                 >
                                    <CalcSelect<T>
                                       control={control}
                                       labelTitle={elem.label}
                                       inputId={elem.inputId}
                                       required={elem.required === 'yes' ? true : false}
                                       items={elem.items}
                                    />
                                 </View>
                              ) : elem.type === 'checkbox' ? (
                                 <CalcCheck<T>
                                    control={control}
                                    inputId={elem.inputId}
                                    labelTitle={elem.label}
                                    onChange={onChange ? onChange : undefined}
                                 />
                              ) : elem.type === 'title' ? (
                                 elem.link ? (
                                    <Pressable
                                       style={styles.pressable}
                                       onPress={() => navigationToLink(elem.link!)}
                                       disabled={elem.link ? false : true}
                                    >
                                       <CustomText style={styles.formTitle}>
                                          <CustomLink>{elem.formTitle}</CustomLink>
                                       </CustomText>
                                    </Pressable>
                                 ) : (
                                    <CustomTextBoldItalic style={styles.formTitle}>
                                       {elem.formTitle}
                                    </CustomTextBoldItalic>
                                 )
                              ) : elem.type === 'custom' ? (
                                 <>
                                    {elem.text ? (
                                       <CustomText>
                                          {elem.text}
                                       </CustomText>
                                    ) : null}
                                    {elem.img ? (
                                       <View
                                          style={{ marginVertical: 10 }}
                                       >
                                          <ZoomableImage
                                             img={elem.img}
                                             height={width < 780 && elem.height ? (
                                                elem.height
                                             ) : width >= 780 && elem.heightL ? (
                                                elem.heightL
                                             ) : undefined
                                             }
                                             resizeMode='contain'
                                          />
                                       </View>
                                    ) : null}
                                 </>
                              ) : null}
                           </React.Fragment>
                        )
                     })}
                     <View
                        style={[
                           width != undefined && width >= 780 && { width: '70%' },
                           { ...result != undefined && { marginBottom: 90 } }
                        ]}
                     >
                        <CalcButton
                           onPress={handleSubmit(save)}
                        />
                     </View>
                  </View>
               </ScrollView>
            </>
         )}
         what={<>
            {data.description.descriptionMain.map((description, descriptionIndex) => (
               <React.Fragment key={descriptionIndex}>
                  {typeof description === 'string' ? (
                     <CustomText>
                        {description}
                     </CustomText>
                  ) : (
                     <UlLi
                        ulText={description[0] !== '' ? description[0] : undefined}
                        liArray={description.slice(1)}
                        marginVertical={0}
                     />
                  )}
               </React.Fragment>
            ))}
            {data.description.descriptionTable && data.description.descriptionTable.map((table, index) => (
               <CustomTable
                  headData={table.headData}
                  headWidthNums={table.headWidthNums}
                  bodyData={table.bodyData}
                  flexNums={table.flexNums}
                  widthNums={table.widthNums}
                  key={index}
               />
            ))}
            {data.description.descriptionImage && data.description.descriptionImage.map((img, index) => (
               <React.Fragment key={index}>
                  {img.imageSup ? (
                     <CustomText style={styles.imageText}>
                        {img.imageSup}
                     </CustomText>
                  ) : null}
                  <View>
                     <ZoomableImage
                        img={img.image}
                        height={width < 780 && img.height ? (
                           img.height
                        ) : width >= 780 && img.heightL ? (
                           img.heightL
                        ) : undefined
                        }
                        resizeMode='contain'
                        isFlex
                     />
                  </View>
                  {img.imageSub ? (
                     <CustomText style={styles.imageText}>
                        {img.imageSub}
                     </CustomText>
                  ) : null}
               </React.Fragment>
            ))}
            {data.description.descriptionLink && navigation && (
               <View style={{ rowGap: 7 }}>
                  {data.description.descriptionLink.map((descLink) => (
                     <Pressable
                        key={descLink.name}
                        style={styles.pressable}
                        onPress={() => navigationToLink(descLink.link!)}>
                        <CustomText>
                           <CustomLink>
                              {descLink.name}
                           </CustomLink>
                        </CustomText>
                     </Pressable>
                  ))}
               </View>
            )}
         </>}
         calcRef={<CalcRefs
            refs={data.refers}
         />}
      />
   )
}

const styles = StyleSheet.create({
   container: {
      padding: 15,
   },
   form: {
      marginTop: 10,
      marginBottom: 20,
      padding: 5
   },
   pressable: {
      minHeight: 30,
      justifyContent: 'center',
   },
   formTitle: {
      marginTop: 20,
      marginBottom: -2
   },
   image: {
      flex: 1,
      resizeMode: 'contain',
      width: '100%',
   },
   imageText: {
      marginVertical: 10,
   },
})