import React from 'react'
import { FieldValues, Path, Control, Controller } from 'react-hook-form'
import { Platform, StyleSheet, View } from 'react-native'
import { RadioGroup, RadioButtonProps } from 'react-native-radio-buttons-group';
import CustomText from '@/src/components/CustomTexts/CustomText';
import { useAppSelector } from '@/src/redux/hooks';
import CustomTextNoFont from '@/src/components/CustomTexts/CustomTextNoFont';
import { useTheme } from '@/src/hooks/useTheme';
import CustomTextBold from '@/src/components/CustomTexts/CustomTextBold';


interface ICalcRadio<T extends FieldValues> {
   control: Control<T>,
   labelTitle: string,
   inputId: Path<T>,
   required: boolean,
   isNumeric?: number,
   smallText?: string,
   radioButtons: RadioButtonProps[],
   isMarginStart?: boolean
}

const CalcRadio = <T extends FieldValues>({
   control,
   labelTitle,
   inputId,
   required,
   isNumeric,
   smallText,
   radioButtons,
   isMarginStart
}: ICalcRadio<T>) => {
   const { textSize } = useAppSelector(state => state.fontSizeStore);
   const { colors } = useTheme()

   return (
      <View style={styles.formRow}>
         <CustomTextBold style={[isMarginStart && { marginLeft: -5 }]}>
            {isNumeric && isNumeric + '. '}{labelTitle}
         </CustomTextBold>
         {smallText && (
            <CustomTextNoFont style={{ fontSize: 15, marginTop: 5, marginBottom: 7, lineHeight: 24 }}>
               {smallText}
            </CustomTextNoFont>
         )}
         <Controller
            control={control}
            rules={{
               required: required,
            }}
            render={({ field: { onChange, value }, fieldState: { error } }) => (
               <>
                  {error && (
                     <CustomText style={[
                        styles.errorText, {
                           color: colors.formError
                        }]}
                     >
                        Выберите одно из полей
                     </CustomText>
                  )}
                  <RadioGroup
                     radioButtons={radioButtons.map((button, index) => ({
                        ...button,
                        containerStyle: {
                           borderBottomWidth: index !== radioButtons.length - 1 ? 1 : 0,
                           borderBottomColor: colors.calcRadioSeparator,
                           paddingBottom: index !== radioButtons.length - 1 ? 7 : 0,
                           paddingTop: 7,
                           marginVertical: 0
                        },
                        labelStyle: {
                           fontSize: textSize,
                           lineHeight: 28,
                           flex: 1,
                           color: colors.primary,
                           ...Platform.OS === 'ios' && { fontFamily: 'Roboto-Regular' }
                        },
                        color: colors.radioColor
                     }))}
                     onPress={onChange}
                     selectedId={value}
                     containerStyle={{
                        alignItems: 'flex-start',
                        marginTop: 5,
                        marginLeft: isMarginStart ? -12 : 0,
                     }}
                  />
               </>
            )}
            name={inputId}
         />
      </View>
   )
}

const styles = StyleSheet.create({
   formRow: {
      marginTop: 10,
      marginBottom: 15
   },
   errorText: {
      marginTop: 5,
   },
})

export default CalcRadio
