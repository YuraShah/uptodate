import React, { useState } from 'react'
import { useForm } from 'react-hook-form';
import benzList from '@/src/constants/calcs/data/benz-convert.json'
import CalcComponent, { ICalcData } from '@/src/components/Calcs/CalcComponent';
import { benzConvertCalc } from '@/src/constants/calcs/form/benz-convert-calc';
import CustomBold from '@/src/components/CustomTexts/CustomBold';
import CustomText from '@/src/components/CustomTexts/CustomText';
import CalcResult from '@/src/components/Calcs/CalcResult';
import { View } from 'react-native';
import { normalizeCommaToDot } from '@/src/functions/functions';

type IBenzConvert = {
   firstBenz: string,
   dose: string,
   secondBenz: string
}

const BenzConvert = () => {
   const { control, handleSubmit, reset } = useForm<IBenzConvert>({});
   const [benzResult, setBenzResult] = useState<string>();
   const [refreshing, setRefreshing] = React.useState(false);

   const save = (data: IBenzConvert): void => {
      const cleanedData = normalizeCommaToDot(data);
      if (cleanedData.firstBenz === cleanedData.secondBenz) {
         setBenzResult(`${cleanedData.firstBenz} ${cleanedData.dose} мг = ${cleanedData.secondBenz} ${cleanedData.dose} мг`)
      } else {
         const findBenz = benzList.find((benz) => benz.from === cleanedData.firstBenz);

         if (!findBenz) return;

         const convertBenz = findBenz.to.find((conv) => conv.title === cleanedData.secondBenz)

         if (!convertBenz) return;

         const total = convertBenz.multiple ? +cleanedData.dose * convertBenz.dose : +cleanedData.dose / convertBenz.dose
         const upRange = convertBenz.multiple ? +cleanedData.dose * convertBenz.rangeUp : +cleanedData.dose / convertBenz.rangeUp
         const lowRange = convertBenz.multiple ? +cleanedData.dose * convertBenz.rangeLow : +cleanedData.dose / convertBenz.rangeLow
         const range = convertBenz.multiple ? `${parseFloat(lowRange.toFixed(2))} - ${parseFloat(upRange.toFixed(2))} мг` : `${parseFloat(upRange.toFixed(2))} - ${parseFloat(lowRange.toFixed(2))} мг`
         const result = `${cleanedData.firstBenz} ${cleanedData.dose} мг ≈ ${cleanedData.secondBenz} ${parseFloat(total.toFixed(2))} мг. Диапазон: ${range}`

         setBenzResult(result)
      }
   }

   const onRefresh = React.useCallback(() => {
      setRefreshing(true);
      setBenzResult(undefined)
      reset()
      setTimeout(() => {
         setRefreshing(false);
      }, 300);
   }, []);


   return (
      <CalcComponent<IBenzConvert>
         data={benzConvertCalc as ICalcData<IBenzConvert>}
         save={save}
         handleSubmit={handleSubmit}
         result={benzResult}
         onRefresh={onRefresh}
         refreshing={refreshing}
         control={control}
         ResultComponent={benzResult != undefined ? (
            <CalcResult
               closeFunction={() => setBenzResult(undefined)}
            >
               <View style={{ paddingRight: 40, rowGap: 15 }}>
                  <CustomText>
                     <CustomBold>{benzResult}.</CustomBold>
                  </CustomText>
               </View>
            </CalcResult>
         ) : undefined}
      />
   )
}

export default BenzConvert
