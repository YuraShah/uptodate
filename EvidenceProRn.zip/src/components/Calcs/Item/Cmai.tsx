import React, { useState } from 'react'
import { useForm } from 'react-hook-form';
import CalcResult from '@/src/components/Calcs/CalcResult';
import { cmaiCalc } from '@/src/constants/calcs/form/cmai-calc';
import CustomText from '@/src/components/CustomTexts/CustomText';
import CustomBold from '@/src/components/CustomTexts/CustomBold';
import CalcComponent, { ICalcData } from '@/src/components/Calcs/CalcComponent';
import { getBallWord, normalizeCommaToDot } from '@/src/functions/functions';

type ICmaiForm = {
  hit: string,
  kick: string,
  grab: string,
  push: string,
  throw: string,
  bit: string,
  scratch: string,
  split: string,
  hurt: string,
  tear: string,
  sexual: string,
  pace: string,
  dress: string,
  place: string,
  falling: string,
  eating: string,
  handling: string,
  hiding: string,
  hoarding: string,
  performing: string,
  restless: string,
  scream: string,
  verbalsex: string,
  verbagress: string,
  sent: string,
  noise: string,
  complain: string,
  negativ: string,
  attent: string,
}

const Cmai = () => {
  const { control, handleSubmit, reset } = useForm<ICmaiForm>({});
  const [cmaiResult, setCmaiResult] = useState<number>();
  const [refreshing, setRefreshing] = React.useState(false);

  const save = (data: ICmaiForm): void => {
    const cleanedData = normalizeCommaToDot(data);
    const total = Object.values(cleanedData).reduce((a: number, b: string) => a + +b, 0);
    setCmaiResult(total)
    reset()
  }

  const onRefresh = React.useCallback(() => {
    setRefreshing(true);
    setCmaiResult(undefined)
    reset()
    setTimeout(() => {
      setRefreshing(false);
    }, 300);
  }, []);


  return (
    <CalcComponent<ICmaiForm>
      data={cmaiCalc as ICalcData<ICmaiForm>}
      save={save}
      handleSubmit={handleSubmit}
      result={cmaiResult}
      onRefresh={onRefresh}
      refreshing={refreshing}
      control={control}
      ResultComponent={cmaiResult != undefined ? (
        <CalcResult
          closeFunction={() => setCmaiResult(undefined)}
        >
          <CustomText>
            <CustomBold>{cmaiResult} {getBallWord(cmaiResult)}.</CustomBold> {cmaiResult >= 29 && (
              `${cmaiResult >= 29 && cmaiResult <= 47 ? "Низкий" : cmaiResult > 47 && cmaiResult < 88 ? "Средний" : "Высокий"} уровень агитации`
            )}
          </CustomText>
        </CalcResult>
      ) : undefined}
    />
  )
}

export default Cmai
