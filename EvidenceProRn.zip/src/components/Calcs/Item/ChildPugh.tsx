import React, { useState } from 'react'
import { useForm } from 'react-hook-form';
import CalcResult from '@/src/components/Calcs/CalcResult';
import { childPughCalc } from '@/src/constants/calcs/form/child-calc';
import CustomText from '@/src/components/CustomTexts/CustomText';
import CustomBold from '@/src/components/CustomTexts/CustomBold';
import CalcComponent, { ICalcData } from '@/src/components/Calcs/CalcComponent';
import { getBallWord, normalizeCommaToDot } from '@/src/functions/functions';
import CustomTextBold from '@/src/components/CustomTexts/CustomTextBold';

type IChildPughForm = {
   bilirubin: string,
   albumin: string,
   inr: string,
   ascites: string,
   enceph: string,
}

const ChildPugh = () => {
   const { control, handleSubmit, reset } = useForm<IChildPughForm>({});
   const [childPughResult, setChildPughResult] = useState<number>();
   const [refreshing, setRefreshing] = React.useState(false);

   const save = (data: IChildPughForm): void => {
      const cleanedData = normalizeCommaToDot(data);
      const total = Object.values(cleanedData).reduce((a: number, b: string) => a + +b, 0);
      setChildPughResult(total)
      reset()
   }

   const onRefresh = React.useCallback(() => {
      setRefreshing(true);
      setChildPughResult(undefined)
      reset()
      setTimeout(() => {
         setRefreshing(false);
      }, 300);
   }, []);


   return (
      <CalcComponent<IChildPughForm>
         data={childPughCalc as ICalcData<IChildPughForm>}
         save={save}
         handleSubmit={handleSubmit}
         result={childPughResult}
         onRefresh={onRefresh}
         refreshing={refreshing}
         control={control}
         ResultComponent={childPughResult != undefined ? (
            <CalcResult
               closeFunction={() => setChildPughResult(undefined)}
            >
               <CustomText>
                  <CustomBold>{childPughResult} {getBallWord(childPughResult)}.</CustomBold>
               </CustomText>
               <CustomTextBold>
                  {childPughResult > 6 && childPughResult < 10
                     ? "Child класс B"
                     : childPughResult >= 10
                        ? "Child класс C"
                        : "Child класс A"
                  }
               </CustomTextBold>
               <CustomText>
                  {childPughResult > 6 && childPughResult < 10
                     ? "«Показание для оценки трансплантации"
                     : childPughResult >= 10
                        ? "Ожидаемая продолжительность жизни: 1-3 лет"
                        : "Ожидаемая продолжительность жизни: 15-20 лет"
                  }
               </CustomText>
               <CustomText>
                  {childPughResult > 6 && childPughResult < 10
                     ? "Периоперационная смертность при абдоминальной операции: 30%"
                     : childPughResult >= 10
                        ? "Периоперационная смертность при абдоминальной операции: 82%"
                        : "Периоперационная смертность при абдоминальной операции: 10%"
                  }
               </CustomText>
            </CalcResult>
         ) : undefined}
      />
   )
}

export default ChildPugh
