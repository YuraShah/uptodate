import React, { useState } from 'react'
import { useForm } from 'react-hook-form';
import CalcResult from '@/src/components/Calcs/CalcResult';
import CustomText from '@/src/components/CustomTexts/CustomText';
import CustomBold from '@/src/components/CustomTexts/CustomBold';
import { ckdEpiFunc } from '@/src/functions/calc-functions';
import CalcComponent, { ICalcData } from '@/src/components/Calcs/CalcComponent';
import { ckdepiCalc } from '@/src/constants/calcs/form/ckdepi-calc';
import { normalizeCommaToDot } from '@/src/functions/functions';

type CKDEPIForm = {
   age: string,
   gender: string,
   creatinine: string,
}

const CKDEPI = () => {
   const { control, handleSubmit, reset } = useForm<CKDEPIForm>({});
   const [ckdepiResult, setCkdepiResult] = useState<number>();
   const [isMgdl, setIsMgdl] = useState<boolean>(false)
   const [refreshing, setRefreshing] = React.useState(false);

   const save = (data: CKDEPIForm): void => {
      const cleanedData = normalizeCommaToDot(data);
      const result = ckdEpiFunc(+cleanedData.age, +cleanedData.gender, +cleanedData.creatinine, isMgdl)
      setCkdepiResult(result)
      setIsMgdl(false)
      reset()
   }

   const onRefresh = React.useCallback(() => {
      setRefreshing(true);
      setCkdepiResult(undefined)
      setIsMgdl(false)
      reset()
      setTimeout(() => {
         setRefreshing(false);
      }, 300);
   }, []);


   return (
      <CalcComponent<CKDEPIForm>
         data={ckdepiCalc as ICalcData<CKDEPIForm>}
         save={save}
         handleSubmit={handleSubmit}
         result={ckdepiResult}
         onRefresh={onRefresh}
         refreshing={refreshing}
         control={control}
         isMarginStart
         spanVar={true}
         spanBoolean={isMgdl}
         spanFunction={setIsMgdl}
         ResultComponent={ckdepiResult != undefined ? (
            <CalcResult
               closeFunction={() => setCkdepiResult(undefined)}
            >
               <CustomText>СКФ: <CustomBold>{ckdepiResult} мл/мин/1,73 м²</CustomBold> (хроническая болезнь почек, {ckdepiResult > 90 ? '1' : ckdepiResult <= 89 && ckdepiResult >= 60 ? '2' : ckdepiResult <= 59 && ckdepiResult >= 45 ? '3А' : ckdepiResult <= 44 && ckdepiResult >= 30 ? '3Б' : ckdepiResult <= 29 && ckdepiResult >= 15 ? '4' : '5'} степени).</CustomText>
            </CalcResult>
         ) : undefined}
      />
   )
}

export default CKDEPI
