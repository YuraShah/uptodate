import React, { useState } from 'react';
import { useForm } from 'react-hook-form';
import CalcResult from '@/src/components/Calcs/CalcResult';
import CustomText from '@/src/components/CustomTexts/CustomText';
import CustomBold from '@/src/components/CustomTexts/CustomBold';
import { hemorr2hagesCalc } from '@/src/constants/calcs/form/hemorr2hages-calc';
import CalcComponent, { ICalcData } from '@/src/components/Calcs/CalcComponent';
import { getBallWord, normalizeCommaToDot } from '@/src/functions/functions';

type Hemorr2hagesForm = {
   age: boolean
   alcohol: boolean,
   anemia: boolean,
   blood: boolean,
   fall: boolean,
   genetic: boolean,
   hypert: boolean,
   kidliv: boolean,
   oncol: boolean,
   stroke: boolean,
   thromboc: boolean
}

function hemorr2hagesTotal({ kidliv, alcohol, oncol, age, thromboc, blood, hypert, anemia, genetic, fall, stroke }: any) {
   let total = 0;
   if (kidliv) { total = total + 1 };
   if (alcohol) { total = total + 1 };
   if (oncol) { total = total + 1 };
   if (age) { total = total + 1 };
   if (thromboc) { total = total + 1 };
   if (blood) { total = total + 2 };
   if (hypert) { total = total + 1 };
   if (anemia) { total = total + 1 };
   if (genetic) { total = total + 1 };
   if (fall) { total = total + 1 };
   if (stroke) { total = total + 1 };
   return total;
}

const HEMORR2HAGES = () => {
   const { control, handleSubmit, reset } = useForm<Hemorr2hagesForm>({});
   const [hemorr2hagesResult, setHemorr2hagesResult] = useState<number>();
   const [refreshing, setRefreshing] = React.useState(false);

   const save = (data: Hemorr2hagesForm): void => {
      const cleanedData = normalizeCommaToDot(data);
      const total = hemorr2hagesTotal(cleanedData);
      setHemorr2hagesResult(total)
      reset();
   }

   const onRefresh = React.useCallback(() => {
      setRefreshing(true);
      setHemorr2hagesResult(undefined)
      reset()
      setTimeout(() => {
         setRefreshing(false);
      }, 300);
   }, []);

   
   return (
      <CalcComponent<Hemorr2hagesForm>
         data={hemorr2hagesCalc as ICalcData<Hemorr2hagesForm>}
         save={save}
         handleSubmit={handleSubmit}
         result={hemorr2hagesResult}
         onRefresh={onRefresh}
         refreshing={refreshing}
         control={control}
         ResultComponent={hemorr2hagesResult != undefined ? (
            <CalcResult
               closeFunction={() => setHemorr2hagesResult(undefined)}
            >
               <CustomText><CustomBold>{hemorr2hagesResult} {getBallWord(hemorr2hagesResult)}.</CustomBold></CustomText>
               <CustomText>{hemorr2hagesResult == 0 ? 'Низкий риск кровотечения, частота: 1.9 (0.6 - 4.4)' : hemorr2hagesResult == 1 ? 'Низкий риск кровотечения, частота: 2.5 (1.3 - 4.3)' : hemorr2hagesResult == 2 ? 'Средний риск кровотечения, частота: 5.3 (3.4 - 8.1)' : hemorr2hagesResult == 3 ? 'Средний риск кровотечения, частота: 8.4 (4.9 - 13.6)' : hemorr2hagesResult == 4 ? 'Высокий риск кровотечения, частота: 10.4 (5.1 - 18.9)' : 'Высокий риск кровотечения, частота: 12.3 (5.8 - 23.1)'} (100 человеко-лет [95% доверительный интервал]): {hemorr2hagesResult >= 4 ? "Применение любых антитромботических препаратов требует особой осторожности." : ''}</CustomText>
            </CalcResult>
         ) : undefined}
      />
   )
}

export default HEMORR2HAGES
