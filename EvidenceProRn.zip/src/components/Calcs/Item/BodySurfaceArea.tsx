import React, { useState } from 'react'
import { useForm } from 'react-hook-form';
import CalcComponent, { ICalcData } from '@/src/components/Calcs/CalcComponent';
import { bodySurfaceAreaCalc } from '@/src/constants/calcs/form/body-surface-area-calc';
import CustomBold from '@/src/components/CustomTexts/CustomBold';
import CustomText from '@/src/components/CustomTexts/CustomText';
import CalcResult from '@/src/components/Calcs/CalcResult';
import { normalizeCommaToDot } from '@/src/functions/functions';

type BodySurfaceAreaForm = {
   height: string,
   weight: string
}

const BodySurfaceArea = () => {
   const [bodySurfaceAreaResult, setBodySurfaceAreaResult] = useState<number>();
   const { control, handleSubmit, reset } = useForm<BodySurfaceAreaForm>({});
   const [refreshing, setRefreshing] = React.useState(false);

   const save = (data: BodySurfaceAreaForm): void => {
      const cleanedData = normalizeCommaToDot(data);
      const res = Math.pow((+cleanedData.height * +cleanedData.weight) / 3600, 0.5)
      setBodySurfaceAreaResult(res)
      reset();
   }

   const onRefresh = React.useCallback(() => {
      setRefreshing(true);
      setBodySurfaceAreaResult(undefined)
      reset()
      setTimeout(() => {
         setRefreshing(false);
      }, 300);
   }, []);

   
   return (
      <CalcComponent<BodySurfaceAreaForm>
         data={bodySurfaceAreaCalc as ICalcData<BodySurfaceAreaForm>}
         save={save}
         handleSubmit={handleSubmit}
         result={bodySurfaceAreaResult}
         onRefresh={onRefresh}
         refreshing={refreshing}
         control={control}
         ResultComponent={bodySurfaceAreaResult != undefined ? (
            <CalcResult
               closeFunction={() => setBodySurfaceAreaResult(undefined)}
            >
               <CustomText>Площадь поверхности тела: <CustomBold>{bodySurfaceAreaResult.toFixed(1)} м²</CustomBold></CustomText>
            </CalcResult>
         ) : undefined}
      />
   )
}

export default BodySurfaceArea
