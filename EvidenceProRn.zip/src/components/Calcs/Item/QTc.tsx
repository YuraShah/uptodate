import React, { useState } from 'react'
import { useForm } from 'react-hook-form';
import CalcResult from '@/src/components/Calcs/CalcResult';
import CustomText from '@/src/components/CustomTexts/CustomText';
import CustomBold from '@/src/components/CustomTexts/CustomBold';
import CalcComponent, { ICalcData } from '@/src/components/Calcs/CalcComponent';
import { qtcCalc } from '@/src/constants/calcs/form/qtc-calc';
import { normalizeCommaToDot } from '@/src/functions/functions';

type IQTcForm = {
   formula: string,
   rate: string,
   speed: string,
   qt: string,
}

const QTc = () => {
   const { control, handleSubmit, reset } = useForm<IQTcForm>({});
   const [qtcResult, setQtcResult] = useState<number>();
   const [isMsec, setIsMsec] = useState(false)
   const [refreshing, setRefreshing] = React.useState(false);

   const save = (data: IQTcForm): void => {
      const cleanedData = normalizeCommaToDot(data);
      const { formula, rate, qt, speed } = cleanedData;

      const hr = parseFloat(rate);
      const qtInterval = parseFloat(qt);

      let cQtInterval: number;

      if (+speed === 25) {
         cQtInterval = isMsec ? qtInterval : qtInterval * 40;
      } else {
         cQtInterval = isMsec ? qtInterval : qtInterval * 20;
      }

      const rrInterval = 60 / hr;

      let qtc: number;

      switch (formula) {
         case 'bazett':
            qtc = cQtInterval / Math.sqrt(rrInterval);
            break;
         case 'fridericia':
            qtc = cQtInterval / Math.cbrt(rrInterval);
            break;
         case 'framingham':
            qtc = cQtInterval + 154 * (1 - rrInterval);
            break;
         case 'hodges':
            qtc = cQtInterval + 1.75 * ((60 / rrInterval) - 60);
            break;
         case 'rautaharju':
            qtc = cQtInterval * (120 + hr) / 180;
            break;
         default:
            throw new Error("Unknown formula selected");
      }

      setQtcResult(Math.round(qtc))
      reset({
         formula: ''
      })
   }

   const onRefresh = React.useCallback(() => {
      setRefreshing(true);
      setQtcResult(undefined)
      setIsMsec(false)
      reset({
         formula: ''
      })
      setTimeout(() => {
         setRefreshing(false);
      }, 300);
   }, []);


   return (
      <CalcComponent<IQTcForm>
         data={qtcCalc as ICalcData<IQTcForm>}
         save={save}
         handleSubmit={handleSubmit}
         result={qtcResult}
         onRefresh={onRefresh}
         refreshing={refreshing}
         control={control}
         isMarginStart
         spanVar={true}
         spanBoolean={isMsec}
         spanFunction={setIsMsec}
         ResultComponent={qtcResult != undefined ? (
            <CalcResult
               closeFunction={() => setQtcResult(undefined)}
            >
               <CustomText>
                  Скорректированный интервал QT: <CustomBold>{qtcResult}</CustomBold> мсек։
               </CustomText>
            </CalcResult>
         ) : undefined}
      />
   )
}

export default QTc
