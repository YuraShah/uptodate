import React, { useState } from 'react';
import { useForm } from 'react-hook-form';
import CalcResult from '@/src/components/Calcs/CalcResult';
import CustomText from '@/src/components/CustomTexts/CustomText';
import CustomBold from '@/src/components/CustomTexts/CustomBold';
import { crusadeCalc } from '@/src/constants/calcs/form/crusade-calc';
import CalcComponent, { ICalcData } from '@/src/components/Calcs/CalcComponent';
import { getBallWord, normalizeCommaToDot } from '@/src/functions/functions';

type CRUSADEForm = {
   hct: string,
   creatinine: string,
   heartbeat: string,
   gender: string,
   heartD: string,
   vascularD: string,
   diabetes: string,
   syst: string
}

const CRUSADE = () => {
   const { control, handleSubmit, reset } = useForm<CRUSADEForm>({});
   const [crusadeResult, setCrusadeResult] = useState<number>();
   const [refreshing, setRefreshing] = React.useState(false);

   const save = (data: CRUSADEForm): void => {
      const cleanedData = normalizeCommaToDot(data);
      const nicotineDependenceIndex = Object.values(cleanedData).reduce((a: number, b: string) => a + +b, 0)

      if (cleanedData.syst === '50') {
         const newIndex = nicotineDependenceIndex - 45
         setCrusadeResult(newIndex)
      } else {
         setCrusadeResult(nicotineDependenceIndex)
      }
      reset();
   }

   const onRefresh = React.useCallback(() => {
      setRefreshing(true);
      setCrusadeResult(undefined)
      reset()
      setTimeout(() => {
         setRefreshing(false);
      }, 300);
   }, []);


   return (
      <CalcComponent<CRUSADEForm>
         data={crusadeCalc as ICalcData<CRUSADEForm>}
         save={save}
         handleSubmit={handleSubmit}
         result={crusadeResult}
         onRefresh={onRefresh}
         refreshing={refreshing}
         control={control}
         ResultComponent={crusadeResult != undefined ? (
            <CalcResult
               closeFunction={() => setCrusadeResult(undefined)}
            >
               <CustomText><CustomBold>{crusadeResult} {getBallWord(crusadeResult)}.</CustomBold> Риск сильного кровотечения в больнице {crusadeResult <= 20 ? 'очень низкий (3.1' : crusadeResult >= 21 && crusadeResult <= 30 ? 'низкий (5.5' : crusadeResult <= 31 && crusadeResult <= 40 ? 'умеренный (8.6' : crusadeResult <= 41 && crusadeResult <= 50 ? 'высокий (11.9' : 'очень высокий (19.5'}%{')'}.</CustomText>
            </CalcResult>
         ) : undefined}
      />
   )
}

export default CRUSADE
