import React, { useState } from 'react'
import { useForm } from 'react-hook-form';
import { meldScoreCalc } from '@/src/functions/calc-functions';
import CalcResult from '@/src/components/Calcs/CalcResult';
import CustomText from '@/src/components/CustomTexts/CustomText';
import CustomBold from '@/src/components/CustomTexts/CustomBold';
import CalcComponent, { ICalcData } from '@/src/components/Calcs/CalcComponent';
import { meldOriginalCalc } from '@/src/constants/calcs/form/meldoriginal-calc';
import { getBallWord, normalizeCommaToDot } from '@/src/functions/functions';

type IMeldForm = {
   dialysis: string,
   creatinine: string,
   bilirubin: string,
   inr: string,
}

const MeldOriginal = () => {
   const { control, handleSubmit, reset } = useForm<IMeldForm>({});
   const [meldResult, setMeldResult] = useState<number>();
   const [isMmol, setIsMmol] = useState<boolean>(true)
   const [refreshing, setRefreshing] = React.useState(false);

   const save = (data: IMeldForm): void => {
      const cleanedData = normalizeCommaToDot(data);
      const creatinine = isMmol ? +cleanedData.creatinine * 0.0113 : +cleanedData.creatinine;
      const bilirubin = isMmol ? +cleanedData.bilirubin * 0.06 : +cleanedData.bilirubin;
      const total = meldScoreCalc(+cleanedData.dialysis, creatinine, bilirubin, +cleanedData.inr);
      setMeldResult(total)
   }

   const onRefresh = React.useCallback(() => {
      setRefreshing(true);
      setMeldResult(undefined)
      setIsMmol(true)
      reset()
      setTimeout(() => {
         setRefreshing(false);
      }, 300);
   }, []);


   return (
      <CalcComponent<IMeldForm>
         data={meldOriginalCalc as ICalcData<IMeldForm>}
         save={save}
         handleSubmit={handleSubmit}
         result={meldResult}
         onRefresh={onRefresh}
         refreshing={refreshing}
         control={control}
         isMarginStart
         spanVar={true}
         spanBoolean={isMmol}
         spanFunction={setIsMmol}
         ResultComponent={meldResult != undefined ? (
            <CalcResult
               closeFunction={() => setMeldResult(undefined)}
            >
               <CustomText><CustomBold>{meldResult} {getBallWord(meldResult)}.</CustomBold></CustomText>
               <CustomText>{
                  meldResult <= 9
                     ? "Расчетная смертность за 3 месяца: 1.9%"
                     : meldResult > 9 && meldResult < 20
                        ? "Расчетная смертность за 3 месяца: 6.0%"
                        : meldResult >= 20 && meldResult < 30
                           ? "Расчетная смертность за 3 месяца: 19.6%"
                           : meldResult >= 30 && meldResult < 40
                              ? "Расчетная смертность за 3 месяца: 52.6%"
                              : meldResult >= 40 && "Расчетная смертность за 3 месяца: 71.6%"
               }</CustomText>
            </CalcResult>
         ) : undefined}
      />
   )
}

export default MeldOriginal
