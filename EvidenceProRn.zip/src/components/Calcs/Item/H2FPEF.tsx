import React, { useState } from 'react'
import { useForm } from 'react-hook-form';
import CalcResult from '@/src/components/Calcs/CalcResult';
import CustomText from '@/src/components/CustomTexts/CustomText';
import CustomBold from '@/src/components/CustomTexts/CustomBold';
import { H2FPEFFunc } from '@/src/functions/calc-functions';
import CalcComponent, { ICalcData } from '@/src/components/Calcs/CalcComponent';
import { h2fpefCalc } from '@/src/constants/calcs/form/h2fpef-calc';
import { normalizeCommaToDot } from '@/src/functions/functions';

type H2FPEFForm = {
   age: string,
   bmi: string,
   ee: string,
   ps: string,
   af: string
}

const H2FPEF = () => {
   const { control, handleSubmit, reset } = useForm<H2FPEFForm>({});
   const [h2fpefResult, setH2fpefResult] = useState<string>();
   const [refreshing, setRefreshing] = React.useState(false);

   const save = (data: H2FPEFForm) => {
      const cleanedData = normalizeCommaToDot(data);
      const result = H2FPEFFunc(+cleanedData.age, +cleanedData.bmi, +cleanedData.ee, +cleanedData.ps, +cleanedData.af);
      setH2fpefResult(result)
      reset()
   }

   const onRefresh = React.useCallback(() => {
      setRefreshing(true);
      setH2fpefResult(undefined)
      reset()
      setTimeout(() => {
         setRefreshing(false);
      }, 300);
   }, []);


   return (
      <CalcComponent<H2FPEFForm>
         data={h2fpefCalc as ICalcData<H2FPEFForm>}
         save={save}
         handleSubmit={handleSubmit}
         result={h2fpefResult}
         onRefresh={onRefresh}
         refreshing={refreshing}
         control={control}
         isMarginStart
         ResultComponent={h2fpefResult != undefined ? (
            <CalcResult
               closeFunction={() => setH2fpefResult(undefined)}
            >
               <CustomText><CustomBold>{h2fpefResult}%</CustomBold> вероятность сердечной недостаточности с сохраненной фракцией выброса</CustomText>
            </CalcResult>
         ) : undefined}
      />
   )
}

export default H2FPEF
