import React, { useState } from 'react'
import { useForm } from 'react-hook-form';
import CalcResult from '@/src/components/Calcs/CalcResult';
import CustomText from '@/src/components/CustomTexts/CustomText';
import CustomBold from '@/src/components/CustomTexts/CustomBold';
import { dentTAMaxFunc } from '@/src/functions/calc-functions';
import CalcComponent, { ICalcData } from '@/src/components/Calcs/CalcComponent';
import { dentTAMaxCalc } from '@/src/constants/calcs/form/denttamax-calc';
import { normalizeCommaToDot } from '@/src/functions/functions';

type DentTAMaxForm = {
   locan: string,
   weight: string
}

type DentTAMaxResult = {
   res: string | undefined,
   carp: string | undefined,
   locan: string,
   weight: number
}

const DentTAMax = () => {
   const { control, handleSubmit, reset } = useForm<DentTAMaxForm>({});
   const [denttamaxResult, setDenttamaxResult] = useState<DentTAMaxResult>({ res: '', carp: '', locan: '', weight: 0 });
   const [refreshing, setRefreshing] = React.useState(false);

   const save = (data: DentTAMaxForm): void => {
      const dataWeight = parseFloat(data.weight.replace(',', '.'));
      const { res, carp, locan, weight } = dentTAMaxFunc(data.locan, dataWeight)
      setDenttamaxResult({ ...denttamaxResult, res: res?.toFixed(1), carp: carp?.toFixed(1), locan: locan, weight: weight })
      reset({
         locan: ''
      })
   }

   const onRefresh = React.useCallback(() => {
      setRefreshing(true);
      setDenttamaxResult({ res: '', carp: '', locan: '', weight: 0 })
      reset({
         locan: ''
      })
      setTimeout(() => {
         setRefreshing(false);
      }, 300);
   }, []);

   return (
      <CalcComponent<DentTAMaxForm>
         data={dentTAMaxCalc as ICalcData<DentTAMaxForm>}
         save={save}
         handleSubmit={handleSubmit}
         result={denttamaxResult.locan !== '' ? undefined : ''}
         onRefresh={onRefresh}
         refreshing={refreshing}
         control={control}
         ResultComponent={denttamaxResult.locan != '' ? (
            <CalcResult
               closeFunction={() => setDenttamaxResult({ res: '', carp: '', locan: '', weight: 0 })}
            >
               <CustomText>Для человека весом {denttamaxResult.weight} кг максимальная доза анестетика:  {denttamaxResult.locan} <CustomBold>{denttamaxResult?.res} мг</CustomBold> и максимальное количество карпул: <CustomBold>{denttamaxResult?.carp}</CustomBold>.</CustomText>
            </CalcResult>
         ) : undefined}
      />
   )
}

export default DentTAMax