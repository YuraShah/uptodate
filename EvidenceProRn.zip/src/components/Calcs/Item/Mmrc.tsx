import React, { useState } from 'react'
import { useForm } from 'react-hook-form';
import CalcComponent, { ICalcData } from '@/src/components/Calcs/CalcComponent';
import { mmrcCalc } from '@/src/constants/calcs/form/mmrc-calc';
import CustomBold from '@/src/components/CustomTexts/CustomBold';
import CalcResult from '@/src/components/Calcs/CalcResult';
import CustomText from '@/src/components/CustomTexts/CustomText';
import { getBallWord, normalizeCommaToDot } from '@/src/functions/functions';

type IMmrcForm = {
   symptomSeverity: string
}

export default function Mmrc() {
   const { control, handleSubmit, reset } = useForm<IMmrcForm>({});
   const [result, setResult] = useState<number>();
   const [refreshing, setRefreshing] = React.useState(false);

   const save = (data: IMmrcForm): void => {
      const cleanedData = normalizeCommaToDot(data);
      setResult(+cleanedData.symptomSeverity)
      reset()
   }

   const onRefresh = React.useCallback(() => {
      setRefreshing(true);
      setResult(undefined)
      reset()
      setTimeout(() => {
         setRefreshing(false);
      }, 300);
   }, []);


   return (
      <CalcComponent<IMmrcForm>
         data={mmrcCalc as ICalcData<IMmrcForm>}
         save={save}
         handleSubmit={handleSubmit}
         result={result}
         onRefresh={onRefresh}
         refreshing={refreshing}
         control={control}
         ResultComponent={result != undefined ? (
            <CalcResult
               closeFunction={() => setResult(undefined)}
            >
               <CustomText>
                  <CustomBold>{result} {getBallWord(result)}.</CustomBold>
               </CustomText>
               <CustomText>
                  Более высокий балл указывает на более высокую степень тяжести.
               </CustomText>
            </CalcResult>
         ) : undefined}
      />
   )
}
