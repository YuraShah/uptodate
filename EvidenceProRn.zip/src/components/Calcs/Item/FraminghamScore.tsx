import React, { useState } from 'react';
import { useForm } from 'react-hook-form';
import CalcResult from '@/src/components/Calcs/CalcResult';
import CustomText from '@/src/components/CustomTexts/CustomText';
import CustomBold from '@/src/components/CustomTexts/CustomBold';
import CalcComponent, { ICalcData } from '@/src/components/Calcs/CalcComponent';
import { framinghamScoreCalc } from '@/src/constants/calcs/form/framingham-score-calc';
import { getBallWord, normalizeCommaToDot } from '@/src/functions/functions';

const framinghamResults: Record<string, string> = {
   1: '2.6',
   2: '3.0',
   3: '3.5',
   4: '4.0',
   5: '4.7',
   6: '5.4',
   7: '6.3',
   8: '7.3',
   9: '8.4',
   10: '9.7',
   11: '11.2',
   12: '12.9',
   13: '14.8',
   14: '17.0',
   15: '19.5',
   16: '22.4',
   17: '25.5',
   18: '29.0',
   19: '32.9',
   20: '37.1',
   21: '41.7',
   22: '46.6',
   23: '51.8',
   24: '57.3',
   25: '62.8',
   26: '68.4',
   27: '73.8',
   28: '79.0',
   29: '83.7',
   30: '30'
}

type FraminghamScoreForm = {
   age: string,
   syst: string,
   hypTr: string,
   diabetes: string,
   smoking: string,
   anamnesis: string,
   arythm: string,
   hypertr: string
}

function framinghamScoreTotal({
   age,
   syst,
   hypTr,
   diabetes,
   smoking,
   anamnesis,
   arythm,
   hypertr
}: FraminghamScoreForm) {
   let ageN = +age, systN = +syst, hypTrN = +hypTr, diabetesN = +diabetes, smokingN = +smoking, anamnesisN = +anamnesis, arythmN = +arythm, hypertrN = +hypertr;
   let cage = ageN >= 54 && ageN <= 56 ? 0 : ageN >= 57 && ageN <= 59 ? 1 : ageN >= 60 && ageN <= 62 ? 2 : ageN >= 63 && ageN <= 65 ? 3 : ageN >= 66 && ageN <= 68 ? 4 : ageN >= 69 && ageN <= 71 ? 5 : ageN >= 72 && ageN <= 74 ? 6 : ageN >= 75 && ageN <= 77 ? 7 : ageN >= 78 && ageN <= 80 ? 8 : ageN >= 81 && ageN <= 83 ? 9 : 10;
   let csyst = systN >= 95 && systN <= 105 ? 0 : systN >= 106 && systN <= 116 ? 1 : systN >= 117 && systN <= 126 ? 2 : systN >= 127 && systN <= 137 ? 3 : systN >= 138 && systN <= 148 ? 4 : systN >= 149 && systN <= 159 ? 5 : systN >= 160 && systN <= 170 ? 6 : systN >= 171 && systN <= 181 ? 7 : systN >= 182 && systN <= 191 ? 8 : systN >= 192 && systN <= 202 ? 9 : 10;
   const total = cage + csyst + hypTrN + diabetesN + smokingN + anamnesisN + arythmN + hypertrN;
   return total;
}


const FraminghamScore = () => {
   const { control, handleSubmit, reset } = useForm<FraminghamScoreForm>({});
   const [framinghamScoreResult, setFraminghamScoreResult] = useState<number>()
   const [refreshing, setRefreshing] = React.useState(false);

   const save = (data: FraminghamScoreForm): void => {
      const cleanedData = normalizeCommaToDot(data);
      const total = framinghamScoreTotal(cleanedData);
      setFraminghamScoreResult(total);
      reset({
         hypertr: '',
         anamnesis: '',
         arythm: '',
         diabetes: '',
         hypTr: '',
         smoking: '',
      })
   }

   const onRefresh = React.useCallback(() => {
      setRefreshing(true);
      setFraminghamScoreResult(undefined)
      reset({
         hypertr: '',
         anamnesis: '',
         arythm: '',
         diabetes: '',
         hypTr: '',
         smoking: '',
      })
      setTimeout(() => {
         setRefreshing(false);
      }, 300);
   }, []);


   return (
      <CalcComponent<FraminghamScoreForm>
         data={framinghamScoreCalc as ICalcData<FraminghamScoreForm>}
         save={save}
         handleSubmit={handleSubmit}
         result={framinghamScoreResult}
         onRefresh={onRefresh}
         refreshing={refreshing}
         control={control}
         ResultComponent={framinghamScoreResult != undefined ? (
            <CalcResult
               closeFunction={() => setFraminghamScoreResult(undefined)}
            >
               <CustomText><CustomBold>{framinghamScoreResult} {getBallWord(framinghamScoreResult)}.</CustomBold></CustomText>
               <CustomText>Риск инсульта за 10 лет: {framinghamResults[framinghamScoreResult] || framinghamResults[30]}%:</CustomText>
            </CalcResult>
         ) : undefined}
      />
   )
}


export default FraminghamScore
