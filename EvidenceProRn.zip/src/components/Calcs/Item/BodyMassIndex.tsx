import React, { useState } from 'react';
import { useForm } from 'react-hook-form';
import CalcResult from '@/src/components/Calcs/CalcResult';
import CustomText from '@/src/components/CustomTexts/CustomText';
import CustomBold from '@/src/components/CustomTexts/CustomBold';
import CalcComponent, { ICalcData } from '@/src/components/Calcs/CalcComponent';
import { bodyMassIndexCalc } from '@/src/constants/calcs/form/body-mass-index-calc';
import { normalizeCommaToDot } from '@/src/functions/functions';

type BodyMassIndexForm = {
   weight: string,
   height: string,
   targetbmi?: string
}

const BodyMassIndex = () => {
   const [bodyMassIndexResult, setBodyMassIndexResult] = useState<number>();
   const [targetBodyMassIndexResult, setTargetBodyMassIndexResult] = useState<number>();
   const [targetNum, setTargetNum] = useState<string>();
   const { control, handleSubmit, reset } = useForm<BodyMassIndexForm>({});
   const [refreshing, setRefreshing] = React.useState(false);

   const save = (data: BodyMassIndexForm): void => {
      const cleanedData = normalizeCommaToDot(data);
      const heightM = +cleanedData.height / 100
      const bmiRes = +cleanedData.weight / (heightM * heightM)
      setBodyMassIndexResult(bmiRes)
      if (cleanedData.targetbmi && cleanedData.targetbmi != '') {
         const targetBmiRes = Math.round(heightM * heightM * +cleanedData.targetbmi)
         setTargetBodyMassIndexResult(targetBmiRes)
         setTargetNum(cleanedData.targetbmi)
      } else {
         setTargetBodyMassIndexResult(undefined)
      }
      reset();
   }

   const onRefresh = React.useCallback(() => {
      setRefreshing(true);
      setBodyMassIndexResult(undefined)
      setTargetBodyMassIndexResult(undefined)
      setTargetNum(undefined)
      reset();
      setTimeout(() => {
         setRefreshing(false);
      }, 300);
   }, []);


   return (
      <CalcComponent<BodyMassIndexForm>
         data={bodyMassIndexCalc as ICalcData<BodyMassIndexForm>}
         save={save}
         handleSubmit={handleSubmit}
         result={bodyMassIndexResult}
         onRefresh={onRefresh}
         refreshing={refreshing}
         control={control}
         ResultComponent={bodyMassIndexResult != undefined ? (
            <CalcResult
               closeFunction={() => setBodyMassIndexResult(undefined)}
            >
               <CustomText><CustomBold>{bodyMassIndexResult.toFixed(1)} кг/м²</CustomBold></CustomText>
               <CustomText>{bodyMassIndexResult < 18.5 ? 'Вес ниже нормы (недостаточный вес)' : bodyMassIndexResult >= 18.5 && bodyMassIndexResult <= 24.9 ? 'Нормальный вес' : bodyMassIndexResult >= 25 && bodyMassIndexResult <= 29.9 ? 'Избыточный вес' : bodyMassIndexResult >= 30 && bodyMassIndexResult <= 34.9 ? 'Ожирение I степени' : bodyMassIndexResult >= 35 && bodyMassIndexResult <= 39.9 ? 'Ожирение II степени' : 'Ожирение III степени'}</CustomText>
               {targetBodyMassIndexResult && (
                  <CustomText><CustomBold>{targetBodyMassIndexResult} кг </CustomBold>вес необходим, для достижения целевого {targetNum} кг/м² индекса массы тела</CustomText>
               )}
            </CalcResult>
         ) : undefined}
      />
   )
}

export default BodyMassIndex
