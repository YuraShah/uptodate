import React, { useState } from 'react'
import { useForm } from 'react-hook-form';
import CalcResult from '@/src/components/Calcs/CalcResult';
import { ostCalc } from '@/src/constants/calcs/form/ost-calc';
import CustomText from '@/src/components/CustomTexts/CustomText';
import CustomTextBold from '@/src/components/CustomTexts/CustomTextBold';
import CustomBold from '@/src/components/CustomTexts/CustomBold';
import CalcComponent, { ICalcData } from '@/src/components/Calcs/CalcComponent';
import { getBallWord, normalizeCommaToDot } from '@/src/functions/functions';

type IOst = {
   age: string,
   gender: string,
   weight: string
}

const OST = () => {
   const { control, handleSubmit, reset } = useForm<IOst>({});
   const [ostResult, setOstResult] = useState<number>();
   const [ostRisk, setOstRisk] = useState('')
   const [refreshing, setRefreshing] = React.useState(false);

   const save = (data: IOst): void => {
      const cleanedData = normalizeCommaToDot(data);
      const total = Math.round((+cleanedData.weight - +cleanedData.age) * 0.2);
      setOstResult(total)

      let risk;

      if (cleanedData.gender === '0') {
         if (total < -1) {
            risk = 'Высокий'
         } else if (total >= -1 && total <= 3) {
            risk = 'Средний'
         } else {
            risk = 'Низкий'
         }
      } else {
         if (total < -3) {
            risk = 'Высокий'
         } else if (total >= -3 && total <= 1) {
            risk = 'Средний'
         } else {
            risk = 'Низкий'
         }
      }

      setOstRisk(risk)
      reset()
   }

   const onRefresh = React.useCallback(() => {
      setRefreshing(true);
      setOstResult(undefined)
      setOstRisk('')
      reset()
      setTimeout(() => {
         setRefreshing(false);
      }, 300);
   }, []);


   return (
      <CalcComponent<IOst>
         data={ostCalc as ICalcData<IOst>}
         save={save}
         handleSubmit={handleSubmit}
         result={ostResult}
         onRefresh={onRefresh}
         refreshing={refreshing}
         control={control}
         isMarginStart
         ResultComponent={ostResult != undefined ? (
            <CalcResult
               closeFunction={() => setOstResult(undefined)}
            >
               <CustomText>
                  <CustomTextBold>{ostResult} {getBallWord(ostResult)}.</CustomTextBold>
               </CustomText>
               {ostRisk !== '' && (
                  <CustomText>
                     <CustomBold>{ostRisk}</CustomBold> риск остеопороза.
                  </CustomText>
               )}
            </CalcResult>
         ) : undefined}
      />
   )
}

export default OST
