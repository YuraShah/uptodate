import React, { useState } from 'react'
import { useForm } from 'react-hook-form';
import { meldNaScoreCalc } from '@/src/functions/calc-functions';
import CalcResult from '@/src/components/Calcs/CalcResult';
import CustomText from '@/src/components/CustomTexts/CustomText';
import CustomBold from '@/src/components/CustomTexts/CustomBold';
import { meldNaCalc } from '@/src/constants/calcs/form/meldna-calc';
import CalcComponent, { ICalcData } from '@/src/components/Calcs/CalcComponent';
import { getBallWord, normalizeCommaToDot } from '@/src/functions/functions';

type IMeldNaForm = {
   dialysis: string,
   creatinine: string,
   bilirubin: string,
   inr: string,
   sodium: string
}

const MeldNa = () => {
   const { control, handleSubmit, reset } = useForm<IMeldNaForm>({});
   const [meldNaResult, setMeldNaResult] = useState<number>();
   const [isMmol, setIsMmol] = useState<boolean>(true)
   const [isNaMmol, setIsNaMmol] = useState<boolean>(false)
   const [refreshing, setRefreshing] = React.useState(false);

   const save = (data: IMeldNaForm): void => {
      const cleanedData = normalizeCommaToDot(data);
      const creatinine = isMmol ? +cleanedData.creatinine * 0.0113 : +cleanedData.creatinine;
      const bilirubin = isMmol ? +cleanedData.bilirubin * 0.06 : +cleanedData.bilirubin;
      const total = meldNaScoreCalc(creatinine, bilirubin, +cleanedData.inr, +cleanedData.sodium, +cleanedData.dialysis);
      setMeldNaResult(total)
      reset()
   }

   const onRefresh = React.useCallback(() => {
      setRefreshing(true);
      setMeldNaResult(undefined)
      setIsMmol(true)
      setIsNaMmol(false)
      reset()
      setTimeout(() => {
         setRefreshing(false);
      }, 300);
   }, []);


   return (
      <CalcComponent<IMeldNaForm>
         data={meldNaCalc as ICalcData<IMeldNaForm>}
         save={save}
         handleSubmit={handleSubmit}
         result={meldNaResult}
         onRefresh={onRefresh}
         refreshing={refreshing}
         control={control}
         isMarginStart
         spanVar
         spanBoolean={[isMmol, isNaMmol]}
         spanFunction={[setIsMmol, setIsNaMmol]}
         ResultComponent={meldNaResult != undefined ? (
            <CalcResult
               closeFunction={() => setMeldNaResult(undefined)}
            >
               <CustomText><CustomBold>{meldNaResult} {getBallWord(meldNaResult)}.</CustomBold></CustomText>
               {meldNaResult <= 9 ? (
                  <CustomText>Расчетная смертность за 3 месяца: 1.9%</CustomText>
               ) : meldNaResult > 9 && meldNaResult < 20 ? (
                  <CustomText>Расчетная смертность за 3 месяца: 6.0%</CustomText>
               ) : meldNaResult >= 20 && meldNaResult < 30 ? (
                  <CustomText>Расчетная смертность за 3 месяца: 19.6%</CustomText>
               ) : meldNaResult >= 30 && meldNaResult < 40 ? (
                  <CustomText>Расчетная смертность за 3 месяца: 52.6%</CustomText>
               ) : meldNaResult >= 40 && (
                  <CustomText>Расчетная смертность за 3 месяца: 71.6%</CustomText>
               )}
            </CalcResult>
         ) : undefined}
      />
   )
}

export default MeldNa
