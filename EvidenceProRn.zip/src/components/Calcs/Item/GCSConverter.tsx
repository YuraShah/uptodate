import React, { useState } from 'react';
import { useForm } from 'react-hook-form';
import { View } from 'react-native';
import { gcs } from '@/src/constants/calcs/data/gcs-list';
import CalcResult from '@/src/components/Calcs/CalcResult';
import CustomText from '@/src/components/CustomTexts/CustomText';
import CustomBold from '@/src/components/CustomTexts/CustomBold';
import CalcComponent, { ICalcData } from '@/src/components/Calcs/CalcComponent';
import { gcsGlucCalc } from '@/src/constants/calcs/form/gcs-gluc-calc';
import { normalizeCommaToDot } from '@/src/functions/functions';


export type GCSForm = {
   firstGcs: string,
   dose: string,
   secondGcs: string
}
export type GCSResult = {
   result: number,
   fromGcs: string,
   fromMaxDur: number,
   dosage: string,
   toGcs: string,
   toMaxDur: number
}


const GCSConverter = () => {
   const [gcsConverterResult, setGcsConverterResult] = useState<GCSResult>({ result: 0, fromGcs: '', fromMaxDur: 0, dosage: '', toGcs: '', toMaxDur: 0 })
   const { control, handleSubmit, reset } = useForm<GCSForm>({})
   const [refreshing, setRefreshing] = React.useState(false);

   const save = (data: GCSForm): void => {
      const cleanedData = normalizeCommaToDot(data);
      const gcsEquivalentDose = gcsEquivalentDoseCalc(cleanedData.firstGcs, +cleanedData.dose, cleanedData.secondGcs);
      const equiFirstName = gcs.find((a) => a.gcsNameEng == cleanedData.firstGcs);
      const equiSecondName = gcs.find((a) => a.gcsNameEng == cleanedData.secondGcs);

      if (!equiFirstName || !equiSecondName) return

      setGcsConverterResult({ ...gcsConverterResult, result: gcsEquivalentDose!, fromGcs: equiFirstName?.gcsName, fromMaxDur: equiFirstName?.maxDuration, dosage: cleanedData.dose, toGcs: equiSecondName?.gcsName, toMaxDur: equiSecondName?.maxDuration })
      reset({
         firstGcs: '',
         secondGcs: ''
      })
   }


   function gcsEquivalentDoseCalc(first: string, dose: number, second: string) {
      const gcsRatio = gcsRatios[first]?.[second];

      if (gcsRatio) {
         const gcsEquivalent = gcsRatio * dose;
         return +gcsEquivalent.toFixed(2)
      }
   }

   const closeResultBox = (): void => {
      setGcsConverterResult({ result: 0, fromGcs: '', fromMaxDur: 0, dosage: '', toGcs: '', toMaxDur: 0 });
      reset({
         firstGcs: '',
         secondGcs: ''
      })
   }

   const onRefresh = React.useCallback(() => {
      setRefreshing(true);
      setGcsConverterResult({ result: 0, fromGcs: '', fromMaxDur: 0, dosage: '', toGcs: '', toMaxDur: 0 });
      reset({
         firstGcs: '',
         secondGcs: ''
      })
      setTimeout(() => {
         setRefreshing(false);
      }, 300);
   }, []);

   
   return (
      <CalcComponent<GCSForm>
         data={gcsGlucCalc as ICalcData<GCSForm>}
         save={save}
         handleSubmit={handleSubmit}
         result={gcsConverterResult.fromGcs === '' ? undefined : ''}
         onRefresh={onRefresh}
         refreshing={refreshing}
         control={control}
         ResultComponent={gcsConverterResult.fromGcs != '' ? (
            <CalcResult
               closeFunction={() => closeResultBox()}
            >
               <View>
                  <CustomText><CustomBold>{gcsConverterResult.dosage} мг {gcsConverterResult.fromGcs.toLowerCase()} ≈ {gcsConverterResult.result} мг {gcsConverterResult.toGcs.toLowerCase()}</CustomBold></CustomText>
                  <CustomText>{gcsConverterResult.toMaxDur > gcsConverterResult.fromMaxDur ? `${gcsConverterResult.toGcs} имеет более длительный период полураспада. Возможно, придется принимать препарат реже.` : ''}</CustomText>
               </View>
            </CalcResult>
         ) : undefined}
      />
   )
}

export default GCSConverter


const gcsRatios: Record<string, Record<string, number>> = {
   'cortisone': {
      'cortisone': 1,
      'hydrocortisone': 0.8,
      'dexamethasone': 0.03,
      'bethamethasone': 0.024,
      'prednisone': 0.2,
      'prednisolone': 0.2,
      'methylprednisolone': 0.16,
      'triamcinolone': 0.16
   },
   'hydrocortisone': {
      'cortisone': 1.25,
      'hydrocortisone': 1,
      'dexamethasone': 0.0375,
      'bethamethasone': 0.03,
      'prednisone': 0.25,
      'prednisolone': 0.25,
      'methylprednisolone': 0.2,
      'triamcinolone': 0.2
   },
   'dexamethasone': {
      'cortisone': 33.33,
      'hydrocortisone': 26.67,
      'dexamethasone': 1,
      'bethamethasone': 0.8,
      'prednisone': 6.67,
      'prednisolone': 6.67,
      'methylprednisolone': 5.33,
      'triamcinolone': 5.33
   },
   'bethamethasone': {
      'cortisone': 41.7,
      'hydrocortisone': 33.3,
      'dexamethasone': 1.25,
      'bethamethasone': 1,
      'prednisone': 8.33,
      'prednisolone': 8.33,
      'methylprednisolone': 6.67,
      'triamcinolone': 6.67
   },
   'prednisone': {
      'cortisone': 5,
      'hydrocortisone': 4,
      'dexamethasone': 0.15,
      'bethamethasone': 0.12,
      'prednisone': 1,
      'prednisolone': 1,
      'methylprednisolone': 0.8,
      'triamcinolone': 0.8
   },
   'prednisolone': {
      'cortisone': 5,
      'hydrocortisone': 4,
      'dexamethasone': 0.15,
      'bethamethasone': 0.12,
      'prednisone': 1,
      'prednisolone': 1,
      'methylprednisolone': 0.8,
      'triamcinolone': 0.8
   },
   'methylprednisolone': {
      'cortisone': 6.25,
      'hydrocortisone': 5,
      'dexamethasone': 0.1875,
      'bethamethasone': 0.15,
      'prednisone': 1.25,
      'prednisolone': 1.25,
      'methylprednisolone': 1,
      'triamcinolone': 1
   },
   'triamcinolone': {
      'cortisone': 6.25,
      'hydrocortisone': 5,
      'dexamethasone': 0.1875,
      'bethamethasone': 0.15,
      'prednisone': 1.25,
      'prednisolone': 1.25,
      'methylprednisolone': 1,
      'triamcinolone': 1
   }
}
