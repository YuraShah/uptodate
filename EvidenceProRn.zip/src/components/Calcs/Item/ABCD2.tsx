import React, { useState } from 'react';
import { useForm } from 'react-hook-form';
import CalcComponent, { ICalcData } from '@/src/components/Calcs/CalcComponent';
import { abcd2Calc } from '@/src/constants/calcs/form/abcd2-calc';
import CalcResult from '@/src/components/Calcs/CalcResult';
import CustomText from '@/src/components/CustomTexts/CustomText';
import CustomBold from '@/src/components/CustomTexts/CustomBold';
import { normalizeCommaToDot } from '@/src/functions/functions';

type ABCD2Form = {
   age: string,
   hypertension: string,
   clinic: string,
   duration: string,
   diabetes: string
}

const ABCD2 = () => {
   const { control, handleSubmit, reset } = useForm<ABCD2Form>({});
   const [abcd2Result, setAbcd2Result] = useState<number>();
   const [refreshing, setRefreshing] = React.useState(false);

   const save = (data: ABCD2Form): void => {
      const cleanedData = normalizeCommaToDot(data);
      const total = Object.values(cleanedData).reduce((a: number, b: string) => a + +b, 0);
      setAbcd2Result(total)
      reset()
   }

   const onRefresh = React.useCallback(() => {
      setRefreshing(true);
      setAbcd2Result(undefined)
      reset()
      setTimeout(() => {
         setRefreshing(false);
      }, 300);
   }, []);

   
   return (
      <CalcComponent<ABCD2Form>
         data={abcd2Calc as ICalcData<ABCD2Form>}
         save={save}
         handleSubmit={handleSubmit}
         result={abcd2Result}
         onRefresh={onRefresh}
         refreshing={refreshing}
         control={control}
         ResultComponent={abcd2Result != undefined ? (
            <CalcResult
               closeFunction={() => setAbcd2Result(undefined)}
            >
               <CustomText><CustomBold>{abcd2Result} баллов.</CustomBold> {abcd2Result < 4 ? 'Низкий риск' : abcd2Result >= 4 && abcd2Result <= 5 ? 'Средний риск' : 'Высокий риск'} инсульта.</CustomText>
               <CustomText>Риск инсульта в первые 2 дня: {abcd2Result < 4 ? '1.0' : abcd2Result >= 4 && abcd2Result <= 5 ? '4.1' : '8.1'}%, в течение первой недели: {abcd2Result < 4 ? '1.2' : abcd2Result >= 4 && abcd2Result <= 5 ? '5.9' : '11.7'}%, в течение 3 месяцев: {abcd2Result < 4 ? '3.1' : abcd2Result >= 4 && abcd2Result <= 5 ? '9.8' : '17.8'}%</CustomText>
            </CalcResult>
         ) : undefined}
      />
   )
}

export default ABCD2