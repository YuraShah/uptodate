import React, { useState } from 'react';
import { useForm } from 'react-hook-form';
import CalcResult from '@/src/components/Calcs/CalcResult';
import CustomText from '@/src/components/CustomTexts/CustomText';
import CustomBold from '@/src/components/CustomTexts/CustomBold';
import CalcComponent, { ICalcData } from '@/src/components/Calcs/CalcComponent';
import { percentageGramCalc } from '@/src/constants/calcs/form/percentage-gram-calc';
import { normalizeCommaToDot } from '@/src/functions/functions';

type IPercentageGramSolution = {
   percent: string,
   volume: string
}

const PercentageGramSolution = () => {
   const { control, handleSubmit, reset } = useForm<IPercentageGramSolution>({})
   const [solutionResult, setSolutionResult] = useState<number>(0);
   const [refreshing, setRefreshing] = React.useState(false);

   const save = (data: IPercentageGramSolution): void => {
      const cleanedData = normalizeCommaToDot(data);
      const c = (+cleanedData.percent * +cleanedData.volume) / 100;
      setSolutionResult(c);
      reset()
   }

   const onRefresh = React.useCallback(() => {
      setRefreshing(true);
      setSolutionResult(0)
      reset()
      setTimeout(() => {
         setRefreshing(false);
      }, 300);
   }, []);


   return (
      <CalcComponent<IPercentageGramSolution>
         data={percentageGramCalc as ICalcData<IPercentageGramSolution>}
         save={save}
         handleSubmit={handleSubmit}
         result={solutionResult}
         onRefresh={onRefresh}
         refreshing={refreshing}
         control={control}
         ResultComponent={solutionResult !== 0 ? (
            <CalcResult
               closeFunction={() => setSolutionResult(0)}
            >
               <CustomText>Содержание вещества: <CustomBold>{solutionResult * 1000} мг ({solutionResult} г)</CustomBold></CustomText>
            </CalcResult>
         ) : undefined}
      />
   )
}

export default PercentageGramSolution
