import React, { useState } from 'react';
import { useForm } from 'react-hook-form';
import { View } from 'react-native';
import { gcs } from '@/src/constants/calcs/data/gcs-list';
import CalcResult from '@/src/components/Calcs/CalcResult';
import CustomText from '@/src/components/CustomTexts/CustomText';
import CustomBold from '@/src/components/CustomTexts/CustomBold';
import CalcComponent, { ICalcData } from '@/src/components/Calcs/CalcComponent';
import { gcsMineralCalc } from '@/src/constants/calcs/form/gcs-mineral-calc';
import { normalizeCommaToDot } from '@/src/functions/functions';
import { GCSForm, GCSResult } from './GCSConverter';


const GcsConverterMineral = () => {
   const [gcsConverterResult, setGcsConverterResult] = useState<GCSResult>({ result: 0, fromGcs: '', fromMaxDur: 0, dosage: '', toGcs: '', toMaxDur: 0 })
   const { control, handleSubmit, reset } = useForm<GCSForm>({})
   const [refreshing, setRefreshing] = React.useState(false);

   const save = (data: GCSForm): void => {
      const cleanedData = normalizeCommaToDot(data);
      const gcsEquivalentDose = gcsEquivalentDoseCalc(cleanedData.firstGcs, +cleanedData.dose, cleanedData.secondGcs);
      const equiFirstName = gcs.find((a) => a.gcsNameEng == cleanedData.firstGcs);
      const equiSecondName = gcs.find((a) => a.gcsNameEng == cleanedData.secondGcs);

      if (!equiFirstName || !equiSecondName) return

      setGcsConverterResult({ ...gcsConverterResult, result: gcsEquivalentDose, fromGcs: equiFirstName?.gcsName, fromMaxDur: equiFirstName?.maxDuration, dosage: cleanedData.dose, toGcs: equiSecondName?.gcsName, toMaxDur: equiSecondName?.maxDuration })
      reset({
         firstGcs: '',
         secondGcs: ''
      })
   }


   function gcsEquivalentDoseCalc(first: string, dose: number, second: string) {
      let gcsRatio: number;
      if (first == 'hydrocortisone') {
         gcsRatio = second === 'hydrocortisone' ? 1 : 2.5
      } else {
         gcsRatio = (second === 'prednisolone' || second === 'prednisone') ? 1 : 0.4
      }
      let gcsEquivalent = gcsRatio * dose;
      return +gcsEquivalent.toFixed(2)
   }

   const closeResultBox = (): void => {
      setGcsConverterResult({ result: 0, fromGcs: '', fromMaxDur: 0, dosage: '', toGcs: '', toMaxDur: 0 });
      reset({
         firstGcs: '',
         secondGcs: ''
      })
   }

   const onRefresh = React.useCallback(() => {
      setRefreshing(true);
      setGcsConverterResult({ result: 0, fromGcs: '', fromMaxDur: 0, dosage: '', toGcs: '', toMaxDur: 0 });
      reset({
         firstGcs: '',
         secondGcs: ''
      })
      setTimeout(() => {
         setRefreshing(false);
      }, 300);
   }, []);


   return (
      <CalcComponent<GCSForm>
         data={gcsMineralCalc as ICalcData<GCSForm>}
         save={save}
         handleSubmit={handleSubmit}
         result={gcsConverterResult.fromGcs === '' ? undefined : ''}
         onRefresh={onRefresh}
         refreshing={refreshing}
         control={control}
         ResultComponent={gcsConverterResult.fromGcs != '' ? (
            <CalcResult
               closeFunction={() => closeResultBox()}
            >
               <View>
                  <CustomText><CustomBold>{gcsConverterResult.dosage} мг {gcsConverterResult.fromGcs.toLowerCase()} ≈ {gcsConverterResult.result} мг {gcsConverterResult.toGcs.toLowerCase()}</CustomBold></CustomText>
                  <CustomText>{gcsConverterResult.toMaxDur > gcsConverterResult.fromMaxDur ? `${gcsConverterResult.toGcs} имеет более длительный период полураспада. Возможно, придется принимать препарат реже.` : ''}</CustomText>
               </View>
            </CalcResult>
         ) : undefined}
      />
   )
}

export default GcsConverterMineral
