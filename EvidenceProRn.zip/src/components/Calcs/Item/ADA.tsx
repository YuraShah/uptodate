import React, { useState } from 'react'
import { useForm } from 'react-hook-form';
import { adaCalc } from '@/src/constants/calcs/form/ada-calc';
import CalcComponent, { ICalcData } from '@/src/components/Calcs/CalcComponent';
import CustomBold from '@/src/components/CustomTexts/CustomBold';
import CustomText from '@/src/components/CustomTexts/CustomText';
import CalcResult from '@/src/components/Calcs/CalcResult';
import { getBallWord, normalizeCommaToDot } from '@/src/functions/functions';

type IAda = {
   age: string,
   gender: string,
   degree: string,
   hypert: string,
   phys: string,
   bmi: string,
   gest: string,
}

const Ada = () => {
   const { control, handleSubmit, reset } = useForm<IAda>({});
   const [adaResult, setAdaResult] = useState<number>();
   const [refreshing, setRefreshing] = React.useState(false);

   const save = (data: IAda): void => {
      const cleanedData = normalizeCommaToDot(data);
      const cgender = +cleanedData.gender;
      const cage = +cleanedData.age;
      const cbmi = +cleanedData.bmi;
      const cdegree = +cleanedData.degree;
      const chypert = +cleanedData.hypert;
      const cphys = +cleanedData.phys;

      let cgest: number;

      if (cgender === 1) {
         cgest = 0;
      } else {
         cgest = +cleanedData.gest;
      }

      const total = cgender + cage + cbmi + cdegree + chypert + cphys + cgest;
      setAdaResult(total)
      reset()
   }

   const onRefresh = React.useCallback(() => {
      setRefreshing(true);
      setAdaResult(undefined)
      reset()
      setTimeout(() => {
         setRefreshing(false);
      }, 300);
   }, []);

   return (
      <CalcComponent<IAda>
         data={adaCalc as ICalcData<IAda>}
         save={save}
         handleSubmit={handleSubmit}
         result={adaResult}
         onRefresh={onRefresh}
         refreshing={refreshing}
         control={control}
         ResultComponent={adaResult != undefined ? (
            <CalcResult
               closeFunction={() => setAdaResult(undefined)}
            >
               <CustomText>
                  <CustomBold>{adaResult} {getBallWord(adaResult)}.</CustomBold>
               </CustomText>
               <CustomText>
                  <CustomBold>{adaResult < 5
                     ? 'Небольшой риск.'
                     : 'Большой риск.'}
                  </CustomBold> {adaResult < 5
                     ? 'Скрининг на диабет 2 типа не рекомендуется рекомендациями ADA (Американской диабетической ассоциации).'
                     : 'Пациентам с баллами ≥5 следует пройти тест на сахарный диабет в соответствии с рекомендациями ADA (Американской диабетической ассоциации).'
                  }
               </CustomText>
            </CalcResult>
         ) : undefined}
      />
   )
}

export default Ada