import React, { useState } from 'react'
import { useForm } from 'react-hook-form';
import { asthmaPIScore } from '@/src/functions/calc-functions';
import CalcResult from '@/src/components/Calcs/CalcResult';
import { asthmapiCalc } from '@/src/constants/calcs/form/asthmapi-calc';
import CustomText from '@/src/components/CustomTexts/CustomText';
import CustomBold from '@/src/components/CustomTexts/CustomBold';
import CalcComponent, { ICalcData } from '@/src/components/Calcs/CalcComponent';
import { normalizeCommaToDot } from '@/src/functions/functions';

type IAsthmaPI = {
   wheezing: string,
   parent: string,
   eczema: string,
   rhinit: string,
   cold: string,
   eosin: string
}

const asthmaResults: Record<string, string> = {
   'hless': "Строгими критериями; меньше вероятность развития детской астмы.",
   'high': "Строгими критериями; >95% специфичность для дальнейшей диагностики детской астмы.",
   'low': "«Свободными» критериями; 80% специфичность для дальнейшей диагностики детской астмы.",
   'default': "«Свободными» критериями; меньше вероятность развития детской астмы."
};

const AsthmaPI = () => {
   const { control, handleSubmit, reset } = useForm<IAsthmaPI>({});
   const [asthmaResult, setAsthmaResult] = useState<string>();
   const [refreshing, setRefreshing] = React.useState(false);

   const save = (data: IAsthmaPI): void => {
      const cleanedData = normalizeCommaToDot(data);
      const result = asthmaPIScore(cleanedData.wheezing, cleanedData.parent, cleanedData.eczema, cleanedData.rhinit, cleanedData.cold, cleanedData.eosin);
      setAsthmaResult(result)
      reset()
   }

   const onRefresh = React.useCallback(() => {
      setRefreshing(true);
      setAsthmaResult(undefined)
      reset()
      setTimeout(() => {
         setRefreshing(false);
      }, 300);
   }, []);


   return (
      <CalcComponent<IAsthmaPI>
         data={asthmapiCalc as ICalcData<IAsthmaPI>}
         save={save}
         handleSubmit={handleSubmit}
         result={asthmaResult}
         onRefresh={onRefresh}
         refreshing={refreshing}
         control={control}
         ResultComponent={asthmaResult != undefined ? (
            <CalcResult
               closeFunction={() => setAsthmaResult(undefined)}
            >
               <CustomText>
                  <CustomBold>{(asthmaResult === 'lless' || asthmaResult === 'hless') ? (
                     'Отрицательный'
                  ) : (
                     'Положительный'
                  )}</CustomBold>
               </CustomText>
               <CustomText>
                  {asthmaResults[asthmaResult] || asthmaResults.default}
               </CustomText>
            </CalcResult>
         ) : undefined}
      />
   )
}

export default AsthmaPI
