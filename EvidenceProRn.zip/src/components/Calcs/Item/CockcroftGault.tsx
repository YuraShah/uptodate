import React, { useState } from 'react'
import { useForm } from 'react-hook-form';
import CalcResult from '@/src/components/Calcs/CalcResult';
import CustomText from '@/src/components/CustomTexts/CustomText';
import CustomBold from '@/src/components/CustomTexts/CustomBold';
import { cockcroft } from '@/src/functions/calc-functions';
import CalcComponent, { ICalcData } from '@/src/components/Calcs/CalcComponent';
import { cockcroftGaultCalc } from '@/src/constants/calcs/form/cockcroft-gault-calc';
import { normalizeCommaToDot } from '@/src/functions/functions';

type CockcroftGaultForm = {
   age: string,
   weight: string,
   gender: string,
   creatinine: string,
   height: string
}

const CockcroftGault = () => {
   const { control, handleSubmit, reset } = useForm<CockcroftGaultForm>({});
   const [cockcroftGaultResult, setCockcroftGaultResult] = useState<number>();
   const [cockcroftGaultEResult, setCockcroftGaultEResult] = useState<number>();
   const [isMgdl, setIsMgdl] = useState<boolean>(false)
   const [refreshing, setRefreshing] = React.useState(false);

   const save = (data: CockcroftGaultForm): void => {
      const cleanedData = normalizeCommaToDot(data);
      const { cgfr, cegfr, bmi } = cockcroft(+cleanedData.age, +cleanedData.weight, +cleanedData.gender, +cleanedData.creatinine, isMgdl, +cleanedData.height)
      setCockcroftGaultResult(cgfr)
      if (bmi <= 18.3) {
         setCockcroftGaultEResult(undefined)
      } else {
         setCockcroftGaultEResult(cegfr)
      }
      setIsMgdl(false)
      reset()
   }

   const onRefresh = React.useCallback(() => {
      setRefreshing(true);
      setCockcroftGaultResult(undefined)
      setCockcroftGaultEResult(undefined)
      setIsMgdl(false)
      reset()
      setTimeout(() => {
         setRefreshing(false);
      }, 300);
   }, []);

   return (
      <CalcComponent<CockcroftGaultForm>
         data={cockcroftGaultCalc as ICalcData<CockcroftGaultForm>}
         save={save}
         handleSubmit={handleSubmit}
         result={cockcroftGaultResult}
         onRefresh={onRefresh}
         refreshing={refreshing}
         control={control}
         isMarginStart
         spanVar={true}
         spanBoolean={isMgdl}
         spanFunction={setIsMgdl}
         ResultComponent={cockcroftGaultResult != undefined ? (
            <CalcResult
               closeFunction={() => setCockcroftGaultResult(undefined)}
            >
               <CustomText>СКФ:  <CustomBold>{cockcroftGaultResult} мл/мин</CustomBold> (хроническая болезнь почек, {cockcroftGaultResult > 90 ? '1' : cockcroftGaultResult <= 89 && cockcroftGaultResult >= 60 ? '2' : cockcroftGaultResult <= 59 && cockcroftGaultResult >= 45 ? '3А' : cockcroftGaultResult <= 44 && cockcroftGaultResult >= 30 ? '3Б' : cockcroftGaultResult <= 29 && cockcroftGaultResult >= 15 ? '4' : '5'} степени)</CustomText>
               {cockcroftGaultEResult != undefined && <CustomText>СКФ: <CustomBold>{cockcroftGaultEResult} мл/мин</CustomBold> [идеальная и скорректированная масса тела] (хроническая болезнь почек, {cockcroftGaultResult > 90 ? '1' : cockcroftGaultResult <= 89 && cockcroftGaultResult >= 60 ? '2' : cockcroftGaultResult <= 59 && cockcroftGaultResult >= 45 ? '3А' : cockcroftGaultResult <= 44 && cockcroftGaultResult >= 30 ? '3Б' : cockcroftGaultResult <= 29 && cockcroftGaultResult >= 15 ? '4' : '5'} степени)</CustomText>}
            </CalcResult>
         ) : undefined}
      />
   )
}

export default CockcroftGault
