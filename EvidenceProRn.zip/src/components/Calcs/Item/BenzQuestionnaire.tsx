import React, { useState } from 'react'
import { useForm } from 'react-hook-form';
import { benzQuestCalc } from '@/src/constants/calcs/form/benz-calc';
import CalcComponent, { ICalcData } from '@/src/components/Calcs/CalcComponent';
import CustomBold from '@/src/components/CustomTexts/CustomBold';
import CustomText from '@/src/components/CustomTexts/CustomText';
import CalcResult from '@/src/components/Calcs/CalcResult';
import { getBallWord, normalizeCommaToDot } from '@/src/functions/functions';

type IBenzQuestion = {
  unreal: string,
  noise: string,
  light: string,
  smell: string,
  touch: string,
  mouth: string,
  pain: string,
  twitch: string,
  pins: string,
  dizz: string,
  faint: string,
  sick: string,
  depr: string,
  sore: string,
  feel: string,
  seein: string,
  unable: string,
  memory: string,
  appetite: string
}

const BenzQuestionnaire = () => {
  const { control, handleSubmit, reset } = useForm<IBenzQuestion>({});
  const [benzResult, setBenzResult] = useState<number>();
  const [refreshing, setRefreshing] = React.useState(false);

  const save = (data: IBenzQuestion): void => {
    const cleanedData = normalizeCommaToDot(data);
    const total = Object.values(cleanedData).reduce((a: number, b: string) => a + +b, 0);
    setBenzResult(total)
    reset()
  }

  const onRefresh = React.useCallback(() => {
    setRefreshing(true);
    setBenzResult(undefined)
    reset()
    setTimeout(() => {
      setRefreshing(false);
    }, 300);
  }, []);


  return (
    <CalcComponent<IBenzQuestion>
      data={benzQuestCalc as ICalcData<IBenzQuestion>}
      save={save}
      handleSubmit={handleSubmit}
      result={benzResult}
      onRefresh={onRefresh}
      refreshing={refreshing}
      control={control}
      ResultComponent={benzResult != undefined ? (
        <CalcResult
          closeFunction={() => setBenzResult(undefined)}
        >
          <CustomText>
            <CustomBold>{benzResult} {getBallWord(benzResult)}</CustomBold>
          </CustomText>
        </CalcResult>
      ) :  undefined}
    />
  )
}

export default BenzQuestionnaire
