import React, { useState } from 'react';
import { useForm } from 'react-hook-form'
import CalcResult from '@/src/components/Calcs/CalcResult';
import CustomText from '@/src/components/CustomTexts/CustomText';
import CustomBold from '@/src/components/CustomTexts/CustomBold';
import CalcComponent, { ICalcData } from '@/src/components/Calcs/CalcComponent';
import { chadvascCalc } from '@/src/constants/calcs/form/chadvas-calc';
import { getBallWord, normalizeCommaToDot } from '@/src/functions/functions';

type CHADSVASC2Type = {
   heartFailure: boolean,
   hypertension: boolean,
   age1: string,
   diabetes: boolean,
   stroke: boolean,
   vascular: boolean,
   gender: boolean
}

const CHADSVASC2 = () => {
   const { control, handleSubmit, reset } = useForm<CHADSVASC2Type>({})
   const [chadsvasc2Result, setChadsvasc2Result] = useState<number>();
   const [refreshing, setRefreshing] = React.useState(false);

   const save = (data: CHADSVASC2Type): void => {
      const cleanedData = normalizeCommaToDot(data);
      const answer = chadsvasc2Total(cleanedData);
      setChadsvasc2Result(answer);
      reset()
   }

   function chadsvasc2Total({ heartFailure, hypertension, age1, diabetes, stroke, vascular, gender }: any) {
      const cHeartFailure = heartFailure ? 1 : 0;
      const cHypertension = hypertension ? 1 : 0;
      const cAge1 = age1 ? +age1 : 0
      const cDiabetes = diabetes ? 1 : 0;
      const cStroke = stroke ? 2 : 0;
      const cVascular = vascular ? 1 : 0;
      const cGender = gender ? 1 : 0;
      const total = cHeartFailure + cHypertension + cAge1 + cDiabetes + cStroke + cVascular + cGender;
      return total;
   }

   const onRefresh = React.useCallback(() => {
      setRefreshing(true);
      setChadsvasc2Result(undefined)
      reset()
      setTimeout(() => {
         setRefreshing(false);
      }, 300);
   }, []);


   return (
      <CalcComponent<CHADSVASC2Type>
         data={chadvascCalc as ICalcData<CHADSVASC2Type>}
         save={save}
         handleSubmit={handleSubmit}
         result={chadsvasc2Result}
         onRefresh={onRefresh}
         refreshing={refreshing}
         control={control}
         isMarginStart
         ResultComponent={chadsvasc2Result != undefined ? (
            <CalcResult
               closeFunction={() => setChadsvasc2Result(undefined)}
            >
               <CustomText><CustomBold>{chadsvasc2Result} {getBallWord(chadsvasc2Result)}.</CustomBold> Ожидаемая ежегодная заболеваемость инсультом: {chadsvasc2Result == 0 ? 0 : chadsvasc2Result == 1 ? 1.3 : chadsvasc2Result == 2 ? 2.2 : chadsvasc2Result == 3 ? 3.2 : chadsvasc2Result == 4 ? 4.0 : chadsvasc2Result == 5 ? 6.7 : chadsvasc2Result == 6 ? 9.8 : chadsvasc2Result == 7 ? 9.6 : chadsvasc2Result == 8 ? 6.7 : 15.2}%.</CustomText>
            </CalcResult>
         ) : undefined}
      />
   )
}

export default CHADSVASC2