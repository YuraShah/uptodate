import React, { useState } from 'react'
import { useForm } from 'react-hook-form';
import CalcResult from '@/src/components/Calcs/CalcResult';
import { ciwaCalc } from '@/src/constants/calcs/form/ciwa-calc';
import CustomText from '@/src/components/CustomTexts/CustomText';
import CustomBold from '@/src/components/CustomTexts/CustomBold';
import CalcComponent, { ICalcData } from '@/src/components/Calcs/CalcComponent';
import { getBallWord, normalizeCommaToDot } from '@/src/functions/functions';

type ICiwaForm = {
  irrit: string,
  fatig: string,
  tense: string,
  concen: string,
  appet: string,
  burn: string,
  racing: string,
  head: string,
  muscle: string,
  anxious: string,
  upset: string,
  sleep: string,
  weak: string,
  sleep2: string,
  visual: string,
  fearful: string,
  worry: string,
  agit: string,
  tremor: string,
  palms: string,
}

const Ciwa = () => {
  const { control, handleSubmit, reset } = useForm<ICiwaForm>({});
  const [ciwaResult, setCiwaResult] = useState<number>();
  const [refreshing, setRefreshing] = React.useState(false);

  const save = (data: ICiwaForm): void => {
    const cleanedData = normalizeCommaToDot(data);
    const total = Object.values(cleanedData).reduce((a: number, b: string) => a + +b, 0);
    setCiwaResult(total)
    reset()
  }

  const onRefresh = React.useCallback(() => {
    setRefreshing(true);
    setCiwaResult(undefined)
    reset()
    setTimeout(() => {
      setRefreshing(false);
    }, 300);
  }, []);


  return (
    <CalcComponent<ICiwaForm>
      data={ciwaCalc as ICalcData<ICiwaForm>}
      save={save}
      handleSubmit={handleSubmit}
      result={ciwaResult}
      onRefresh={onRefresh}
      refreshing={refreshing}
      control={control}
      ResultComponent={ciwaResult != undefined ? (
        <CalcResult
          closeFunction={() => setCiwaResult(undefined)}
        >
          <CustomText>
            <CustomBold>{ciwaResult} {getBallWord(ciwaResult)}.</CustomBold>
          </CustomText>
          <CustomText>
            {ciwaResult > 0 && ciwaResult <= 20
              ? "Легкий абстинентный синдром"
              : ciwaResult > 0 && ciwaResult <= 20
                ? "Средний абстинентный синдром"
                : ciwaResult > 40 && ciwaResult <= 60
                  ? "Тяжелый абстинентный синдром"
                  : ciwaResult > 60 && "Очень тяжелый абстинентный синдром"
            }
          </CustomText>
        </CalcResult>
      ) : undefined}
    />
  )
}

export default Ciwa
