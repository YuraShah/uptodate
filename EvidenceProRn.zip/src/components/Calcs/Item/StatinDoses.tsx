import React, { useState } from 'react'
import { useForm } from 'react-hook-form';
import { statinDoseScore } from '@/src/functions/calc-functions';
import { statinList } from '@/src/constants/calcs/data/statins-list'
import CalcResult from '@/src/components/Calcs/CalcResult';
import CustomText from '@/src/components/CustomTexts/CustomText';
import CustomBold from '@/src/components/CustomTexts/CustomBold';
import CalcComponent, { ICalcData } from '@/src/components/Calcs/CalcComponent';
import { statinDosesCalc } from '@/src/constants/calcs/form/statin-doses-calc';
import { normalizeCommaToDot } from '@/src/functions/functions';

type IStatinDosesForm = {
   statin: string,
   hdlchol: string,
   ldlchol: string,
   triglyc: string,
}

const StatinDoses = () => {
   const { control, handleSubmit, reset } = useForm<IStatinDosesForm>({});
   const [isMmol, setIsMmol] = useState<boolean>(false)
   const [hdl, setHdl] = useState('');
   const [ldl, setLdl] = useState('');
   const [tg, setTg] = useState('');
   const [mmol, setMmol] = useState('');
   const [statin, setStatin] = useState('');
   const [refreshing, setRefreshing] = React.useState(false);

   const save = (data: IStatinDosesForm): void => {
      const cleanedData = normalizeCommaToDot(data);
      const { statin, hdlchol, ldlchol, triglyc } = cleanedData;
      const result = statinDoseScore(statin, hdlchol, ldlchol, triglyc, statinList)

      if (result?.resHdlchol) setHdl(result.resHdlchol)
      if (result?.resLdlchol) setLdl(result.resLdlchol)
      if (result?.resTg) setTg(result.resTg)
      if (result?.resStatin) setStatin(result.resStatin)

      if (!isMmol) {
         setMmol('ммоль/л')
      } else {
         setMmol('мг/дл')
      }

      reset({
         statin: ''
      })
   }

   const handleResult = () => {
      setHdl('')
      setLdl('')
      setTg('')
   }

   const onRefresh = React.useCallback(() => {
      setRefreshing(true);
      setMmol('')
      setStatin('')
      reset({
         statin: ''
      })
      handleResult()
      setIsMmol(false)
      setTimeout(() => {
         setRefreshing(false);
      }, 300);
   }, []);

   
   return (
      <CalcComponent<IStatinDosesForm>
         data={statinDosesCalc as ICalcData<IStatinDosesForm>}
         save={save}
         handleSubmit={handleSubmit}
         result={(hdl !== '' || ldl !== '' || tg !== '') ? undefined : ''}
         onRefresh={onRefresh}
         refreshing={refreshing}
         control={control}
         spanVar={true}
         spanBoolean={isMmol}
         spanFunction={setIsMmol}
         ResultComponent={(hdl !== '' || ldl !== '' || tg !== '') ? (
            <CalcResult
               closeFunction={() => handleResult()}
            >
               <CustomText>
                  <CustomBold>{statin}</CustomBold>
               </CustomText>
               {ldl !== '' && (
                  <CustomText>
                     Липопротеины низкой плотности: <CustomBold>{ldl} {mmol}</CustomBold>:
                  </CustomText>
               )}
               {hdl !== '' && (
                  <CustomText>
                     Липопротеины высокой плотности: <CustomBold>{hdl} {mmol}</CustomBold>:
                  </CustomText>
               )}
               {tg !== '' && (
                  <CustomText>
                     Триглицериды: <CustomBold>{tg} {mmol}</CustomBold>:
                  </CustomText>
               )}
            </CalcResult>
         ) : undefined}
      />
   )
}

export default StatinDoses
