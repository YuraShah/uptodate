import React, { useState } from 'react';
import { useForm } from 'react-hook-form';
import CalcResult from '@/src/components/Calcs/CalcResult';
import CustomText from '@/src/components/CustomTexts/CustomText';
import CustomBold from '@/src/components/CustomTexts/CustomBold';
import CalcComponent, { ICalcData } from '@/src/components/Calcs/CalcComponent';
import { smokingIndexCalc } from '@/src/constants/calcs/form/smokingindex-calc';
import { normalizeCommaToDot } from '@/src/functions/functions';

type ISmokingIndex = {
   quantity: string,
   years: string
}

const SmokingIndex = () => {
   const [smokingIndexResult, setSmokingIndexResult] = useState<number>()
   const { control, handleSubmit, reset } = useForm<ISmokingIndex>({});
   const [refreshing, setRefreshing] = React.useState(false);

   const save = (data: ISmokingIndex): void => {
      const cleanedData = normalizeCommaToDot(data);
      const smokingIndex = (+cleanedData.quantity * +cleanedData.years) / 20;
      setSmokingIndexResult(smokingIndex)
      reset();
   }

   const onRefresh = React.useCallback(() => {
      setRefreshing(true);
      setSmokingIndexResult(undefined)
      reset()
      setTimeout(() => {
         setRefreshing(false);
      }, 300);
   }, []);


   return (
      <CalcComponent<ISmokingIndex>
         data={smokingIndexCalc as ICalcData<ISmokingIndex>}
         save={save}
         handleSubmit={handleSubmit}
         result={smokingIndexResult}
         onRefresh={onRefresh}
         refreshing={refreshing}
         control={control}
         ResultComponent={smokingIndexResult != undefined ? (
            <CalcResult
               closeFunction={() => setSmokingIndexResult(undefined)}
            >
               <CustomText>Индекс курения: <CustomBold>{smokingIndexResult}</CustomBold></CustomText>
            </CalcResult>
         ) : undefined}
      />
   )
}

export default SmokingIndex
