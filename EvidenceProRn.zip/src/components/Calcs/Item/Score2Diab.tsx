import React, { useState } from 'react';
import { useForm } from 'react-hook-form';
import CalcResult from '@/src/components/Calcs/CalcResult';
import CustomText from '@/src/components/CustomTexts/CustomText';
import CustomBold from '@/src/components/CustomTexts/CustomBold';
import { Score2FuncDiab } from '@/src/functions/calc-functions';
import { score2DiabCalc } from '@/src/constants/calcs/form/score2diab-calc';
import CalcComponent, { ICalcData } from '@/src/components/Calcs/CalcComponent';
import { normalizeCommaToDot } from '@/src/functions/functions';

type IScore2Diab = {
   age: string,
   gender: string,
   hdlchol: string,
   riskRegion: string,
   sbp: string,
   smoking: string,
   tchol: string,
   agediab: string,
   hba1c: string,
   egfr: string
}

const Score2Diab = () => {
   const { control, handleSubmit, reset, setValue } = useForm<IScore2Diab>()
   const [isMmol, setIsMmol] = useState<boolean>(true)
   const [scoreRisk, setScoreRisk] = useState<string>('')
   const [scoreResult, setScoreResult] = useState<string>('')
   const [refreshing, setRefreshing] = React.useState(false);

   const save = (data: IScore2Diab): void => {
      const cleanedData = normalizeCommaToDot(data);
      const gender = cleanedData.gender === '1' ? 'male' : 'female'
      const hba1cMol = (+cleanedData.hba1c - 2.15) / 0.0915

      const { riskEstimationCalibratedFix, scoreRisk } = Score2FuncDiab(gender, +cleanedData.age, +cleanedData.smoking, +cleanedData.sbp, 1, +cleanedData.tchol, +cleanedData.hdlchol, cleanedData.riskRegion, isMmol, +cleanedData.agediab, hba1cMol, +cleanedData.egfr);
      setScoreResult(riskEstimationCalibratedFix)
      setScoreRisk(scoreRisk)

      reset()
      setValue('riskRegion', '')
   }

   const onRefresh = React.useCallback(() => {
      setRefreshing(true);
      setIsMmol(true)
      setScoreRisk('')
      setScoreResult('')
      reset()
      setValue('riskRegion', '')
      setTimeout(() => {
         setRefreshing(false);
      }, 300);
   }, []);


   return (
      <CalcComponent<IScore2Diab>
         data={score2DiabCalc as ICalcData<IScore2Diab>}
         save={save}
         handleSubmit={handleSubmit}
         result={scoreResult !== '' ? '' : undefined}
         onRefresh={onRefresh}
         refreshing={refreshing}
         control={control}
         isMarginStart
         spanVar
         spanBoolean={isMmol}
         spanFunction={setIsMmol}
         ResultComponent={scoreResult != '' ? (
            <CalcResult
               closeFunction={() => setScoreResult('')}
            >
               <CustomText><CustomBold>{scoreResult}%</CustomBold> 10-летний риск сердечно-сосудистых событий</CustomText>
               <CustomText>Риск: {scoreRisk}</CustomText>
            </CalcResult>
         ) : undefined}
      />
   )
}

export default Score2Diab
