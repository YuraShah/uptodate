import React, { useState } from 'react'
import { useForm } from 'react-hook-form';
import CalcResult from '@/src/components/Calcs/CalcResult';
import { karnovskyCalc } from '@/src/constants/calcs/form/karnofsky-calc';
import CustomText from '@/src/components/CustomTexts/CustomText';
import CustomBold from '@/src/components/CustomTexts/CustomBold';
import CalcComponent, { ICalcData } from '@/src/components/Calcs/CalcComponent';
import { getBallWord, normalizeCommaToDot } from '@/src/functions/functions';

type IKarnovskyForm = {
   desc: string,
}

const Karnofsky = () => {
   const { control, handleSubmit, reset } = useForm<IKarnovskyForm>({});
   const [karnResult, setKarnResult] = useState<number>();
   const [refreshing, setRefreshing] = React.useState(false);

   const save = (data: IKarnovskyForm): void => {
      const cleanedData = normalizeCommaToDot(data);
      const total = +cleanedData.desc;
      setKarnResult(total)
      reset()
   }

   const onRefresh = React.useCallback(() => {
      setRefreshing(true);
      setKarnResult(undefined)
      reset()
      setTimeout(() => {
         setRefreshing(false);
      }, 300);
   }, []);


   return (
      <CalcComponent<IKarnovskyForm>
         data={karnovskyCalc as ICalcData<IKarnovskyForm>}
         save={save}
         handleSubmit={handleSubmit}
         result={karnResult}
         onRefresh={onRefresh}
         refreshing={refreshing}
         control={control}
         ResultComponent={karnResult != undefined ? (
            <CalcResult
               closeFunction={() => setKarnResult(undefined)}
            >
               <CustomText>
                  <CustomBold>{karnResult} {getBallWord(karnResult)}</CustomBold> из 100 баллов.
               </CustomText>
            </CalcResult>
         ) : undefined}
      />
   )
}

export default Karnofsky
