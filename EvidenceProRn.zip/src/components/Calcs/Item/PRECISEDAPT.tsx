import React, { useState } from 'react';
import { useForm } from 'react-hook-form';
import CalcResult from '@/src/components/Calcs/CalcResult';
import CustomText from '@/src/components/CustomTexts/CustomText';
import CustomBold from '@/src/components/CustomTexts/CustomBold';
import { totalPreciseDapt } from '@/src/functions/calc-functions';
import { preciseDaptCalc } from '@/src/constants/calcs/form/precisedapt-calc';
import CalcComponent, { ICalcData } from '@/src/components/Calcs/CalcComponent';
import { getBallWord, normalizeCommaToDot } from '@/src/functions/functions';

type PRECISEDAPTForm = {
   hgb: string,
   wbc: string,
   age: string,
   creat: string,
   blood: string
}

const PRECISEDAPT = () => {
   const { control, handleSubmit, reset } = useForm<PRECISEDAPTForm>();
   const [preciseDaptResult, setPreciseDaptResult] = useState<number>();
   const [isgL, setIsgL] = useState<boolean>(true)
   const [refreshing, setRefreshing] = React.useState(false);

   const save = (data: PRECISEDAPTForm): void => {
      const cleanedData = normalizeCommaToDot(data);
      const hgb = isgL ? +cleanedData.hgb / 10 : +cleanedData.hgb;
      const total = totalPreciseDapt(hgb, +cleanedData.wbc, +cleanedData.age, +cleanedData.creat, +cleanedData.blood)
      setPreciseDaptResult(total)
      reset()
   }

   const onRefresh = React.useCallback(() => {
      setRefreshing(true);
      setPreciseDaptResult(undefined)
      setIsgL(true)
      reset()
      setTimeout(() => {
         setRefreshing(false);
      }, 300);
   }, []);


   return (
      <CalcComponent<PRECISEDAPTForm>
         data={preciseDaptCalc as ICalcData<PRECISEDAPTForm>}
         save={save}
         handleSubmit={handleSubmit}
         result={preciseDaptResult}
         onRefresh={onRefresh}
         refreshing={refreshing}
         control={control}
         spanVar={true}
         spanBoolean={isgL}
         spanFunction={setIsgL}
         ResultComponent={preciseDaptResult != undefined ? (
            <CalcResult
               closeFunction={() => setPreciseDaptResult(undefined)}
            >
               <CustomText><CustomBold>{preciseDaptResult} {getBallWord(preciseDaptResult)}.</CustomBold></CustomText>
               <CustomText>Нужна {preciseDaptResult <= 25 ? 'стандартная' : 'краткосрочная'} двойная антиагрегантная терапия ({preciseDaptResult <= 25 ? '12 - 24' : '3-6'} месяцев):</CustomText>
            </CalcResult>
         ) : undefined}
      />
   )
}

export default PRECISEDAPT
