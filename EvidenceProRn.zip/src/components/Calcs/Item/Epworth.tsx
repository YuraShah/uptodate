import React, { useState } from 'react';
import { useForm } from 'react-hook-form';
import CalcResult from '@/src/components/Calcs/CalcResult';
import CustomText from '@/src/components/CustomTexts/CustomText';
import CustomBold from '@/src/components/CustomTexts/CustomBold';
import CalcComponent, { ICalcData } from '@/src/components/Calcs/CalcComponent';
import { epworthCalc } from '@/src/constants/calcs/form/epworth-calc';
import { getBallWord, normalizeCommaToDot } from '@/src/functions/functions';

type EpworthForm = {
   read: string,
   tv: string,
   soc: string,
   aut: string,
   bed: string,
   talk: string,
   lan: string,
   stop: string
}

const Epworth = () => {
   const { control, handleSubmit, reset } = useForm<EpworthForm>({});
   const [epworthResult, setEpworthResult] = useState<number>();
   const [refreshing, setRefreshing] = React.useState(false);

   const save = (data: EpworthForm): void => {
      const cleanedData = normalizeCommaToDot(data);
      const total = Object.values(cleanedData).reduce((a: number, b: string) => a + +b, 0);
      setEpworthResult(total)
      reset()
   }

   const onRefresh = React.useCallback(() => {
      setRefreshing(true);
      setEpworthResult(undefined)
      reset()
      setTimeout(() => {
         setRefreshing(false);
      }, 300);
   }, []);


   return (
      <CalcComponent<EpworthForm>
         data={epworthCalc as ICalcData<EpworthForm>}
         save={save}
         handleSubmit={handleSubmit}
         result={epworthResult}
         onRefresh={onRefresh}
         refreshing={refreshing}
         control={control}
         ResultComponent={epworthResult != undefined ? (
            <CalcResult
               closeFunction={() => setEpworthResult(undefined)}
            >
               <CustomText><CustomBold>{epworthResult} {getBallWord(epworthResult)}</CustomBold>. {epworthResult >= 1 && epworthResult <= 6 ? (
                  'Нормальный сон'
               ) : epworthResult > 6 && epworthResult <= 8 ? (
                  'Умеренная сонливость'
               ) : epworthResult > 8 && (
                  'Аномальная (возможно патологическая) сонливость'
               )}</CustomText>
            </CalcResult>
         ) : undefined}
      />
   )
}

export default Epworth
