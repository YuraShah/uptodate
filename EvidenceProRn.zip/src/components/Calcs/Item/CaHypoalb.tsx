import React, { useState } from 'react'
import { useForm } from 'react-hook-form';
import CalcResult from '@/src/components/Calcs/CalcResult';
import CustomText from '@/src/components/CustomTexts/CustomText';
import CustomBold from '@/src/components/CustomTexts/CustomBold';
import CalcComponent, { ICalcData } from '@/src/components/Calcs/CalcComponent';
import { caHypoalbCalc } from '@/src/constants/calcs/form/ca-hypoalb-calc';
import { normalizeCommaToDot } from '@/src/functions/functions';

type CaHypoalbForm = {
   ca: string,
   alb: string
}

const CaHypoalb = () => {
   const { control, handleSubmit, reset } = useForm<CaHypoalbForm>({});
   const [caHypoalbResult, setCaHypoalbResult] = useState<number>();
   const [ismmol, setIsmmol] = useState<boolean>(true)
   const [isgL, setIsgL] = useState<boolean>(true)
   const [refreshing, setRefreshing] = React.useState(false);

   const save = (data: CaHypoalbForm): void => {
      const cleanedData = normalizeCommaToDot(data);
      const mmolca = ismmol ? +cleanedData.ca * 4 : +cleanedData.ca
      const glalb = isgL ? +cleanedData.alb / 10 : +cleanedData.alb
      const total = mmolca + (0.8 * (4 - glalb))
      setCaHypoalbResult(total)
      reset()
   }

   const onRefresh = React.useCallback(() => {
      setRefreshing(true);
      setCaHypoalbResult(undefined)
      setIsmmol(true)
      setIsgL(true)
      reset()
      setTimeout(() => {
         setRefreshing(false);
      }, 300);
   }, []);

   return (
      <CalcComponent<CaHypoalbForm>
         data={caHypoalbCalc as ICalcData<CaHypoalbForm>}
         save={save}
         result={caHypoalbResult}
         handleSubmit={handleSubmit}
         onRefresh={onRefresh}
         refreshing={refreshing}
         control={control}
         spanVar
         spanBoolean={[ismmol, isgL]}
         spanFunction={[setIsmmol, setIsgL]}
         ResultComponent={caHypoalbResult != undefined ? (
            <CalcResult
               closeFunction={() => setCaHypoalbResult(undefined)}
            >
               <CustomText>Скорректированный кальций: <CustomBold>{(caHypoalbResult * 0.2495).toFixed(1)} ммоль/л ({caHypoalbResult.toFixed(1)} мг/дл)</CustomBold>:</CustomText>
            </CalcResult>
         ) : undefined}
      />
   )
}

export default CaHypoalb
