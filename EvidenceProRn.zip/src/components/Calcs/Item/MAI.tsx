import React, { useState } from 'react';
import { useForm } from 'react-hook-form';
import { StyleSheet } from 'react-native';
import CalcResult from '@/src/components/Calcs/CalcResult';
import CustomText from '@/src/components/CustomTexts/CustomText';
import CustomBold from '@/src/components/CustomTexts/CustomBold';
import { maiCalc } from '@/src/constants/calcs/form/mai-calc';
import CalcComponent, { ICalcData } from '@/src/components/Calcs/CalcComponent';
import { getBallWord, normalizeCommaToDot } from '@/src/functions/functions';

type MAIForm = {
   indic: string,
   effect: string,
   dose: string,
   know: string,
   do: string,
   inter: string,
   side: string,
   bro: string,
   dur: string,
   better: string
}

const MAI = () => {
   const { control, handleSubmit, reset } = useForm<MAIForm>({});
   const [maiResult, setMaiResult] = useState<number>();
   const [refreshing, setRefreshing] = React.useState(false);

   const save = (data: MAIForm): void => {
      const cleanedData = normalizeCommaToDot(data);
      const total = Object.values(cleanedData).reduce((a: number, b: string) => a + +b, 0);
      setMaiResult(total)
      reset()
   }

   const onRefresh = React.useCallback(() => {
      setRefreshing(true);
      setMaiResult(undefined)
      reset()
      setTimeout(() => {
         setRefreshing(false);
      }, 300);
   }, []);


   return (
      <CalcComponent<MAIForm>
         data={maiCalc as ICalcData<MAIForm>}
         save={save}
         handleSubmit={handleSubmit}
         result={maiResult}
         onRefresh={onRefresh}
         refreshing={refreshing}
         control={control}
         ResultComponent={maiResult != undefined ? (
            <CalcResult
               closeFunction={() => setMaiResult(undefined)}
            >
               <CustomText style={styles.resultText}><CustomBold>{maiResult} {getBallWord(maiResult)}</CustomBold></CustomText>
            </CalcResult>
         ) : undefined}
      />
   )
}

const styles = StyleSheet.create({
   container: {
      padding: 15,
   },
   form: {
      marginTop: 10,
      marginBottom: 20,
      padding: 5
   },
   resultText: {
      marginBottom: 5,
      marginRight: 15,
   },
   resultTextOth: {
      marginRight: 16,
   },
})

export default MAI
