import React, { useState } from 'react'
import { ScrollView, View } from 'react-native'
import { useForm } from 'react-hook-form';
import CalcResult from '@/src/components/Calcs/CalcResult';
import CustomText from '@/src/components/CustomTexts/CustomText';
import CustomBold from '@/src/components/CustomTexts/CustomBold';
import CalcComponent, { ICalcData } from '@/src/components/Calcs/CalcComponent';
import { garfieldCalculator } from '@/src/constants/calcs/form/garfield-calc';
import { garfieldCalc } from '@/src/functions/calc-functions';
import { normalizeCommaToDot } from '@/src/functions/functions';

type IGarfieldForm = {
   gender: string,
   age: string,
   weight: string,
   heartfail: string,
   vasc: string,
   stroke: string,
   bleed: string,
   carotid: string,
   diab: string,
   ckd: string,
   dementia: string,
   smoker: string,
   antiplatelet: string,
   ethnicity: string,
   pulse: string,
   diastolic: string,
   oac: string
}

const Garfield = () => {
   const { control, handleSubmit, reset } = useForm<IGarfieldForm>({});
   const [garfMortResult, setGarfMortResult] = useState<{ sixMonths: string, oneYear: string, twoYears: string }>();
   const [garfStrokeResult, setGarfStrokeResult] = useState<{ sixMonths: string, oneYear: string, twoYears: string }>();
   const [garfBleedResult, setGarfBleedResult] = useState<{ sixMonths: string, oneYear: string, twoYears: string }>();
   const [refreshing, setRefreshing] = React.useState(false);

   const save = (data: IGarfieldForm): void => {
      const cleanedData = normalizeCommaToDot(data);
      const { mortality, stroke, bleeding } = garfieldCalc(+cleanedData.gender, +cleanedData.heartfail, +cleanedData.vasc, +cleanedData.stroke, +cleanedData.bleed, +cleanedData.carotid, +cleanedData.diab, +cleanedData.ckd, +cleanedData.dementia, +cleanedData.smoker, +cleanedData.antiplatelet, +cleanedData.oac, +cleanedData.ethnicity, +cleanedData.age, +cleanedData.weight, +cleanedData.pulse, +cleanedData.diastolic);
      setGarfMortResult(mortality)
      setGarfStrokeResult(stroke)
      setGarfBleedResult(bleeding)
   }

   const resetResult = () => {
      setGarfMortResult(undefined)
      setGarfStrokeResult(undefined)
      setGarfBleedResult(undefined)
   }

   const onRefresh = React.useCallback(() => {
      setRefreshing(true);
      resetResult()
      reset()
      setTimeout(() => {
         setRefreshing(false);
      }, 200);
   }, []);


   return (
      <CalcComponent<IGarfieldForm>
         data={garfieldCalculator as ICalcData<IGarfieldForm>}
         save={save}
         handleSubmit={handleSubmit}
         result={garfMortResult && garfStrokeResult && garfBleedResult ? '' : undefined}
         onRefresh={onRefresh}
         refreshing={refreshing}
         control={control}
         isMarginStart
         ResultComponent={garfMortResult && garfStrokeResult && garfBleedResult ? (
            <CalcResult
               closeFunction={() => resetResult()}
               heightLimiter
            >
               <ScrollView>
                  <View style={{ marginVertical: 30, rowGap: 50, paddingRight: 40}}>
                     <View style={{ rowGap: 7}}>
                        <CustomText><CustomBold>Смертность от всех причин</CustomBold></CustomText>
                        <CustomText><CustomBold>6 месяцев:</CustomBold> {garfMortResult.sixMonths}</CustomText>
                        <CustomText><CustomBold>1 год:</CustomBold> {garfMortResult.oneYear}</CustomText>
                        <CustomText><CustomBold>2 года:</CustomBold> {garfMortResult.twoYears}</CustomText>
                     </View>
                     <View style={{ rowGap: 7}}>
                        <CustomText><CustomBold>Ишемический инсульт/Системная эмболия</CustomBold></CustomText>
                        <CustomText><CustomBold>6 месяцев:</CustomBold> {garfStrokeResult.sixMonths}</CustomText>
                        <CustomText><CustomBold>1 год:</CustomBold> {garfStrokeResult.oneYear}</CustomText>
                        <CustomText><CustomBold>2 года:</CustomBold> {garfStrokeResult.twoYears}</CustomText>
                     </View>
                     <View style={{ rowGap: 7}}>
                        <CustomText><CustomBold>Сильное кровотечение (включая ишемический инсульт)</CustomBold></CustomText>
                        <CustomText><CustomBold>6 месяцев:</CustomBold> {garfBleedResult.sixMonths}</CustomText>
                        <CustomText><CustomBold>1 год:</CustomBold> {garfBleedResult.oneYear}</CustomText>
                        <CustomText><CustomBold>2 года:</CustomBold> {garfBleedResult.twoYears}</CustomText>
                     </View>
                  </View>
               </ScrollView>
            </CalcResult>
         ) : undefined}
      />
   )
}

export default Garfield
