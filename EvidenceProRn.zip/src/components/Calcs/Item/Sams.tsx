import React, { useState } from 'react'
import { useForm } from 'react-hook-form';
import CalcResult from '@/src/components/Calcs/CalcResult';
import { samsCalc } from '@/src/constants/calcs/form/sams-calc';
import CustomText from '@/src/components/CustomTexts/CustomText';
import CustomBold from '@/src/components/CustomTexts/CustomBold';
import CalcComponent, { ICalcData } from '@/src/components/Calcs/CalcComponent';
import { getBallWord, normalizeCommaToDot } from '@/src/functions/functions';

type ISamsForm = {
   symp: string,
   time: string,
   end: string,
   rest: string,
}

const Sams = () => {
   const { control, handleSubmit, reset } = useForm<ISamsForm>({});
   const [samsResult, setSamsResult] = useState<number>();
   const [refreshing, setRefreshing] = React.useState(false);

   const save = (data: ISamsForm): void => {
      const cleanedData = normalizeCommaToDot(data);
      const symp = +cleanedData.symp === 4 ? 2 : +cleanedData.symp;
      const total = +cleanedData.end + +cleanedData.rest + +cleanedData.time + symp;
      setSamsResult(total)
      reset()
   }

   const onRefresh = React.useCallback(() => {
      setRefreshing(true);
      setSamsResult(undefined)
      reset()
      setTimeout(() => {
         setRefreshing(false);
      }, 300);
   }, []);

   return (
      <CalcComponent<ISamsForm>
         data={samsCalc as ICalcData<ISamsForm>}
         save={save}
         handleSubmit={handleSubmit}
         result={samsResult}
         onRefresh={onRefresh}
         refreshing={refreshing}
         control={control}
         ResultComponent={samsResult != undefined ? (
            <CalcResult
               closeFunction={() => setSamsResult(undefined)}
            >
               <CustomText>
                  <CustomBold>{samsResult} {getBallWord(samsResult)}.</CustomBold>
               </CustomText>
               <CustomText>
                  {
                     samsResult < 7
                        ? "Статиновая миопатия маловероятна."
                        : samsResult === 7 || samsResult === 8
                           ? "Возможная статиновая миопатия."
                           : "С большой вероятностью это статиновая миопатия."
                  }
               </CustomText>
            </CalcResult>
         ) : undefined}
      />
   )
}

export default Sams
