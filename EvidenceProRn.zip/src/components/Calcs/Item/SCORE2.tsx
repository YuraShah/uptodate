import React, { useState } from 'react';
import { useForm } from 'react-hook-form';
import CalcResult from '@/src/components/Calcs/CalcResult';
import CustomText from '@/src/components/CustomTexts/CustomText';
import CustomBold from '@/src/components/CustomTexts/CustomBold';
import { Score2Func, Score2OPFunc } from '@/src/functions/calc-functions';
import { score2Calc } from '@/src/constants/calcs/form/score2-calc';
import CalcComponent, { ICalcData } from '@/src/components/Calcs/CalcComponent';
import { normalizeCommaToDot } from '@/src/functions/functions';

type IScore2 = {
   age: string,
   gender: string,
   hdlchol: string,
   riskRegion: string,
   sbp: string,
   smoking: string,
   tchol: string
}

const SCORE2 = () => {
   const { control, handleSubmit, reset, setValue } = useForm<IScore2>()
   const [isMmol, setIsMmol] = useState<boolean>(true)
   const [scoreRisk, setScoreRisk] = useState<string>('')
   const [scoreResult, setScoreResult] = useState<string>('')
   const [refreshing, setRefreshing] = React.useState(false);

   const save = (data: IScore2): void => {
      const cleanedData = normalizeCommaToDot(data);
      const gender = cleanedData.gender === '1' ? 'male' : 'female'
      if (+cleanedData.age < 70) {
         const { riskEstimationCalibratedFix, scoreRisk } = Score2Func(gender, +cleanedData.age, +cleanedData.smoking, +cleanedData.sbp, 0, +cleanedData.tchol, +cleanedData.hdlchol, cleanedData.riskRegion, isMmol);
         setScoreResult(riskEstimationCalibratedFix)
         setScoreRisk(scoreRisk)
      } else {
         const { riskEstimationCalibratedFix, scoreRisk } = Score2OPFunc(gender, +cleanedData.age, +cleanedData.smoking, +cleanedData.sbp, 0, +cleanedData.tchol, +cleanedData.hdlchol, cleanedData.riskRegion, isMmol);
         setScoreResult(riskEstimationCalibratedFix)
         setScoreRisk(scoreRisk)
      }
      reset()
      setValue('riskRegion', '')
   }

   const onRefresh = React.useCallback(() => {
      setRefreshing(true);
      setIsMmol(true)
      setScoreRisk('')
      setScoreResult('')
      reset()
      setValue('riskRegion', '')
      setTimeout(() => {
         setRefreshing(false);
      }, 300);
   }, []);


   return (
      <CalcComponent<IScore2>
         data={score2Calc as ICalcData<IScore2>}
         save={save}
         handleSubmit={handleSubmit}
         result={scoreResult !== '' ? '' : undefined}
         onRefresh={onRefresh}
         refreshing={refreshing}
         control={control}
         isMarginStart
         spanVar
         spanBoolean={isMmol}
         spanFunction={setIsMmol}
         ResultComponent={scoreResult != '' ? (
            <CalcResult
               closeFunction={() => setScoreResult('')}
            >
               <CustomText><CustomBold>{scoreResult}%</CustomBold></CustomText>
               <CustomText>Риск: {scoreRisk}</CustomText>
            </CalcResult>
         ) : undefined}
      />
   )
}

export default SCORE2
