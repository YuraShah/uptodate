import React, { useState } from 'react'
import { useForm } from 'react-hook-form';
import { apgarCalc } from '@/src/constants/calcs/form/apgar-calc';
import CalcComponent, { ICalcData } from '@/src/components/Calcs/CalcComponent';
import CalcResult from '@/src/components/Calcs/CalcResult';
import CustomText from '@/src/components/CustomTexts/CustomText';
import CustomBold from '@/src/components/CustomTexts/CustomBold';
import { getBallWord, normalizeCommaToDot } from '@/src/functions/functions';

type IApgarForm = {
   activity: string,
   pulse: string,
   grimace: string,
   appearance: string,
   respirations: string
}

const Apgar = () => {
   const { control, handleSubmit, reset } = useForm<IApgarForm>({});
   const [apgarResult, setApgarResult] = useState<number>();
   const [refreshing, setRefreshing] = React.useState(false);

   const save = (data: IApgarForm): void => {
      const cleanedData = normalizeCommaToDot(data);
      const total = Object.values(cleanedData).reduce((a: number, b: string) => a + +b, 0);
      setApgarResult(total)
      reset()
   }

   const onRefresh = React.useCallback(() => {
      setRefreshing(true);
      setApgarResult(undefined)
      reset()
      setTimeout(() => {
         setRefreshing(false);
      }, 300);
   }, []);


   return (
      <CalcComponent<IApgarForm>
         data={apgarCalc as ICalcData<IApgarForm>}
         save={save}
         handleSubmit={handleSubmit}
         result={apgarResult}
         onRefresh={onRefresh}
         refreshing={refreshing}
         control={control}
         ResultComponent={apgarResult != undefined ? (
            <CalcResult
               closeFunction={() => setApgarResult(undefined)}
            >
               <CustomText>
                  <CustomBold>{apgarResult} {getBallWord(apgarResult)}.</CustomBold>
               </CustomText>
               <CustomText>
                  {apgarResult >= 7
                     ? "Баллы ≥7 считаются «нормальными» для новорожденных."
                     : "Баллы <7 указывают на возможную необходимость медицинского вмешательства, такого как отсасывание, высушивание, согревание и стимуляция младенца. Также может быть показан дополнительный кислород."
                  }
               </CustomText>
            </CalcResult>
         ) : undefined}
      />
   )
}

export default Apgar
