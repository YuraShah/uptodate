import React, { useState } from 'react'
import { useForm } from 'react-hook-form';
import { meld3ScoreCalc } from '@/src/functions/calc-functions';
import CalcResult from '@/src/components/Calcs/CalcResult';
import CustomText from '@/src/components/CustomTexts/CustomText';
import CustomBold from '@/src/components/CustomTexts/CustomBold';
import CalcComponent, { ICalcData } from '@/src/components/Calcs/CalcComponent';
import { meldThreeCalc } from '@/src/constants/calcs/form/meldthree-calc';
import { getBallWord, normalizeCommaToDot } from '@/src/functions/functions';

type IMeld3Form = {
   dialysis: string,
   creatinine: string,
   bilirubin: string,
   inr: string,
   sodium: string,
   albumin: string,
   age: string,
   gender: string
}

const MeldThree = () => {
   const { control, handleSubmit, reset } = useForm<IMeld3Form>({});
   const [meld3Result, setMeld3Result] = useState<number>();
   const [isMmol, setIsMmol] = useState<boolean>(true)
   const [isNaMmol, setIsNaMmol] = useState<boolean>(false)
   const [isAlbDl, setIsAlbDl] = useState<boolean>(true)
   const [refreshing, setRefreshing] = React.useState(false);

   const save = (data: IMeld3Form): void => {
      const cleanedData = normalizeCommaToDot(data);
      const creatinine = isMmol ? +cleanedData.creatinine * 0.0113 : +cleanedData.creatinine;
      const bilirubin = isMmol ? +cleanedData.bilirubin * 0.06 : +cleanedData.bilirubin;
      const albumine = isAlbDl ? +cleanedData.albumin : +cleanedData.albumin * 10;
      const total = meld3ScoreCalc(+cleanedData.gender, bilirubin, +cleanedData.sodium, +cleanedData.inr, creatinine, albumine, +cleanedData.dialysis, +cleanedData.age);
      setMeld3Result(total)
      reset()
   }

   const onRefresh = React.useCallback(() => {
      setRefreshing(true);
      setMeld3Result(undefined)
      setIsMmol(true)
      setIsNaMmol(false)
      setIsAlbDl(true)
      reset()
      setTimeout(() => {
         setRefreshing(false);
      }, 300);
   }, []);


   return (
      <CalcComponent<IMeld3Form>
         data={meldThreeCalc as ICalcData<IMeld3Form>}
         save={save}
         handleSubmit={handleSubmit}
         result={meld3Result}
         onRefresh={onRefresh}
         refreshing={refreshing}
         control={control}
         isMarginStart
         spanVar={true}
         spanBoolean={[isMmol, isNaMmol, isAlbDl]}
         spanFunction={[setIsMmol, setIsNaMmol, setIsAlbDl]}
         ResultComponent={meld3Result != undefined ? (
            <CalcResult
               closeFunction={() => setMeld3Result(undefined)}
            >
               <CustomText><CustomBold>{meld3Result} {getBallWord(meld3Result)}.</CustomBold></CustomText>
               <CustomText>
                  Расчетная 90-дневная выживаемость: {(Math.pow(0.946, Math.exp((0.17698 * meld3Result - 3.56))) * 100).toFixed(1)}%
               </CustomText>
            </CalcResult>
         ) : undefined}
      />
   )
}

export default MeldThree
