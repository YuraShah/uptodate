import React, { useState } from 'react'
import { useForm } from 'react-hook-form';
import CalcResult from '@/src/components/Calcs/CalcResult';
import CustomText from '@/src/components/CustomTexts/CustomText';
import CustomBold from '@/src/components/CustomTexts/CustomBold';
import { hasbledCalc } from '@/src/constants/calcs/form/hasbled-calc';
import CalcComponent, { ICalcData } from '@/src/components/Calcs/CalcComponent';
import { getBallWord, normalizeCommaToDot } from '@/src/functions/functions';

type IHasBledForm = {
   hyper: string,
   renal: string,
   liver: string,
   stroke: string,
   mbleed: string,
   inr: string,
   age: string,
   medic: string,
   alco: string
}

const Hasbled = () => {
   const { control, handleSubmit, reset } = useForm<IHasBledForm>({});
   const [hasResult, setHasResult] = useState<number>();
   const [refreshing, setRefreshing] = React.useState(false);

   const save = (data: IHasBledForm): void => {
      const cleanedData = normalizeCommaToDot(data);
      const total = Object.values(cleanedData).reduce((a: number, b: string) => a + +b, 0);
      setHasResult(total)
      reset()
   }

   const onRefresh = React.useCallback(() => {
      setRefreshing(true);
      setHasResult(undefined)
      reset()
      setTimeout(() => {
         setRefreshing(false);
      }, 300);
   }, []);


   return (
      <CalcComponent<IHasBledForm>
         data={hasbledCalc as ICalcData<IHasBledForm>}
         save={save}
         handleSubmit={handleSubmit}
         result={hasResult}
         onRefresh={onRefresh}
         refreshing={refreshing}
         control={control}
         ResultComponent={hasResult != undefined ? (
            <CalcResult
               closeFunction={() => setHasResult(undefined)}
            >
               <CustomText>
                  <CustomBold>{hasResult} {getBallWord(hasResult)}.</CustomBold>
               </CustomText>
               {hasResult <= 5 ? (
                  <CustomText>
                     В одном валидационном исследовании риск был{' '}
                     <CustomBold>{
                        hasResult === 0
                           ? "0,9%"
                           : hasResult === 1
                              ? "3,4%"
                              : hasResult === 2
                                 ? "4,1%"
                                 : hasResult === 3
                                    ? "5,8%"
                                    : hasResult === 4
                                       ? "8,9%"
                                       : hasResult === 5
                                          ? "9,1%"
                                          : ''
                     }</CustomBold>{' '}
                     (Lip 2011) и в другом валидационном исследовании кровотечение на 100 пациенто-лет был{' '}
                     <CustomBold>
                        {hasResult === 0
                           ? "1,13"
                           : hasResult === 1
                              ? "1,02"
                              : hasResult === 2
                                 ? "1,88"
                                 : hasResult === 3
                                    ? "3,72"
                                    : hasResult === 4
                                       ? "8,70"
                                       : hasResult === 5
                                          ? "12,5"
                                          : ""
                        }
                     </CustomBold>{' '}
                     (Pisters 2010):
                  </CustomText>
               ) : (
                  <CustomText>
                     Баллы выше 5 были слишком редки для определения риска, но, вероятно, <CustomBold>более 10%</CustomBold>.
                  </CustomText>
               )}
               {hasResult < 2 ? (
                  <CustomText>Следует рассмотреть возможность применения антикоагулянтов. У пациента относительно низкий риск возникновения массивного кровотечения (~1/100 пациенто-лет).</CustomText>
               ) : hasResult === 2 ? (
                  <CustomText>Можно рассмотреть возможность применения антикоагулянтов, но у пациента имеется умеренный риск возникновения массивного кровотечения (~2/100 пациенто-лет).</CustomText>
               ) : hasResult >= 3 && (
                  <CustomText>Следует рассмотреть альтернативы антикоагуляции. У пациента высок риск сильного кровотечения.</CustomText>
               )}
            </CalcResult>
         ) : undefined}
      />
   )
}

export default Hasbled
