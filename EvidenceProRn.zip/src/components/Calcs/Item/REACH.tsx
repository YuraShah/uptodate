import React, { useState } from 'react';
import { useForm } from 'react-hook-form';
import CalcResult from '@/src/components/Calcs/CalcResult';
import CustomText from '@/src/components/CustomTexts/CustomText';
import CustomBold from '@/src/components/CustomTexts/CustomBold';
import { reachCalc } from '@/src/constants/calcs/form/reach-calc';
import CalcComponent, { ICalcData } from '@/src/components/Calcs/CalcComponent';
import { getBallWord, normalizeCommaToDot } from '@/src/functions/functions';

type IREACH = {
   age: string,
   anticoag: string,
   antithromb: string,
   atherosclerosis: string,
   chol: string,
   diabetes: string,
   heart: string,
   hypertension: string,
   smoke: string
}

const REACH = () => {
   const { control, handleSubmit, reset } = useForm<IREACH>({});
   const [reachResult, setReachResult] = useState<number>();
   const [refreshing, setRefreshing] = React.useState(false);

   const save = (data: IREACH): void => {
      const cleanedData = normalizeCommaToDot(data);
      const total = Object.values(cleanedData).reduce((a: number, b: string) => a + +b, 0);
      setReachResult(total)
      reset()
   }

   const onRefresh = React.useCallback(() => {
      setRefreshing(true);
      setReachResult(undefined)
      reset()
      setTimeout(() => {
         setRefreshing(false);
      }, 300);
   }, []);


   return (
      <CalcComponent<IREACH>
         data={reachCalc as ICalcData<IREACH>}
         save={save}
         handleSubmit={handleSubmit}
         result={reachResult}
         onRefresh={onRefresh}
         refreshing={refreshing}
         control={control}
         ResultComponent={reachResult != undefined ? (
            <CalcResult
               closeFunction={() => setReachResult(undefined)}
            >
               <CustomText><CustomBold>{reachResult} {getBallWord(reachResult)}.</CustomBold> Уровень риска: {reachResult <= 6 ? '0.46' : reachResult == 7 || reachResult == 8 ? '0.95' : reachResult == 9 || reachResult == 10 ? '1.25' : '2.76'}%</CustomText>
            </CalcResult>
         ) : undefined}
      />
   )
}

export default REACH
