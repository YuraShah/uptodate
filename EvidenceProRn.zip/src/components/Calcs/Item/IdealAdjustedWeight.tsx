import React, { useState } from 'react';
import { useForm } from 'react-hook-form';
import CalcResult from '@/src/components/Calcs/CalcResult';
import CustomText from '@/src/components/CustomTexts/CustomText';
import CustomBold from '@/src/components/CustomTexts/CustomBold';
import { idealAdjustedWeightCalc } from '@/src/constants/calcs/form/ideal-adjusted-weight-calc';
import CalcComponent, { ICalcData } from '@/src/components/Calcs/CalcComponent';
import { normalizeCommaToDot } from '@/src/functions/functions';

type IdealAdjustedWeightForm = {
   gender: string,
   height: string,
   weight?: string
} 

const IdealAdjustedWeight = () => {
   const [idealBodyWeightResult, setIdealBodyWeightResult] = useState<number>();
   const [adjustedBodyWeightResult, setAdjustedBodyWeightResult] = useState<number>();
   const [actualBodyWeightResult, setActualBodyWeightResult] = useState<number>(0);
   const { control, handleSubmit, reset } = useForm<IdealAdjustedWeightForm>({});
   const [refreshing, setRefreshing] = React.useState(false);

   const save = (data: IdealAdjustedWeightForm): void => {
      const cleanedData = normalizeCommaToDot(data);
      const gend = cleanedData.gender == '1' ? 'male' : 'female'
      const heightInches = +cleanedData.height / 2.54
      const cgend = gend === 'male' ? 50 : 45.5
      if (cleanedData.weight) setActualBodyWeightResult(+cleanedData.weight)
      if (+cleanedData.height >= 152) {
         const idealRes = cgend + 2.3 * (heightInches - 60)
         setIdealBodyWeightResult(idealRes)
         if (cleanedData.weight && cleanedData.weight != '') {
            const adjRes = idealRes + 0.4 * (+cleanedData.weight - idealRes)
            setAdjustedBodyWeightResult(adjRes)
         } else {
            setAdjustedBodyWeightResult(undefined)
         }
      } else {
         const idealRes = cgend - 2.3 * (60 - heightInches)
         setIdealBodyWeightResult(idealRes)
         if (cleanedData.weight && cleanedData.weight != '') {
            const adjRes = idealRes + 0.4 * (+cleanedData.weight - idealRes)
            setAdjustedBodyWeightResult(adjRes)
         } else {
            setAdjustedBodyWeightResult(undefined)
         }
      }
      reset()
   }

   const onRefresh = React.useCallback(() => {
      setRefreshing(true);
      setIdealBodyWeightResult(undefined)
      setAdjustedBodyWeightResult(undefined)
      setActualBodyWeightResult(0)
      setTimeout(() => {
         setRefreshing(false);
      }, 300);
   }, []);


   return (
      <CalcComponent<IdealAdjustedWeightForm>
         data={idealAdjustedWeightCalc as ICalcData<IdealAdjustedWeightForm>}
         save={save}
         handleSubmit={handleSubmit}
         result={idealBodyWeightResult}
         onRefresh={onRefresh}
         refreshing={refreshing}
         control={control}
         isMarginStart
         ResultComponent={idealBodyWeightResult != undefined ? (
            <CalcResult
               closeFunction={() => setIdealBodyWeightResult(undefined)}
            >
               <CustomText>Идеальный вес тела: <CustomBold>{idealBodyWeightResult.toFixed(1)} кг</CustomBold></CustomText>
               {adjustedBodyWeightResult && <CustomText>{actualBodyWeightResult > idealBodyWeightResult ? <>Скорректированная масса тела: <CustomBold>{adjustedBodyWeightResult.toFixed(1)} кг</CustomBold></> : 'Скорректированная масса тела применима только в том случае, если фактическая масса тела превышает идеальную массу тела.'}</CustomText>}
            </CalcResult>
         ) : undefined}
      />
   )
}


export default IdealAdjustedWeight
