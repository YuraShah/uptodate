import React, { useState } from 'react'
import { useForm } from 'react-hook-form';
import CalcResult from '@/src/components/Calcs/CalcResult';
import CustomText from '@/src/components/CustomTexts/CustomText';
import CustomBold from '@/src/components/CustomTexts/CustomBold';
import { serumOsmolalityCalc } from '@/src/constants/calcs/form/serumosmolality-calc';
import CalcComponent, { ICalcData } from '@/src/components/Calcs/CalcComponent';
import { normalizeCommaToDot } from '@/src/functions/functions';

type SerumOsmolalityForm = {
   na: string,
   bun: string,
   glucose: string,
   alcohol?: string,
   measser?: string
}

const SerumOsmolality: React.FC = () => {
   const { control, handleSubmit, reset } = useForm<SerumOsmolalityForm>({});
   const [isNaMol, setIsNaMol] = useState<boolean>(true)
   const [isBunMol, setIsBunMol] = useState<boolean>(true)
   const [isGlMol, setIsGlMol] = useState<boolean>(true)
   const [isMeasMol, setIsMeasMol] = useState<boolean>(false)
   const [serumOsmolalityResult, setSerumOsmolalityResult] = useState<number>();
   const [osmGapResult, setOsmGapResult] = useState<number>();
   const [refreshing, setRefreshing] = React.useState(false);

   const save = (data: SerumOsmolalityForm): void => {
      const cleanedData = normalizeCommaToDot(data);
      const cna = +cleanedData.na
      const cbun = isBunMol ? +cleanedData.bun * 2.8011 : +cleanedData.bun
      const cgluc = isGlMol ? +cleanedData.glucose * 18.018 : +cleanedData.glucose
      const res = (2 * cna + (cbun / 2.8) + (cgluc / 18)).toFixed(1)
      const resNum = Math.round(+res)
      setSerumOsmolalityResult(resNum)

      if (cleanedData.measser && cleanedData.measser !== '') {
         const osmGap = +cleanedData.measser - resNum
         const osmGapNum = Math.round(osmGap)
         setOsmGapResult(osmGapNum)
      } else {
         setOsmGapResult(undefined)
      }
      reset()
   }

   const onRefresh = React.useCallback(() => {
      setRefreshing(true);
      setSerumOsmolalityResult(undefined)
      setOsmGapResult(undefined)
      setIsNaMol(true)
      setIsBunMol(true)
      setIsGlMol(true)
      setIsMeasMol(false)
      reset()
      setTimeout(() => {
         setRefreshing(false);
      }, 300);
   }, []);


   return (
      <CalcComponent<SerumOsmolalityForm>
         data={serumOsmolalityCalc as ICalcData<SerumOsmolalityForm>}
         save={save}
         result={serumOsmolalityResult}
         handleSubmit={handleSubmit}
         onRefresh={onRefresh}
         refreshing={refreshing}
         control={control}
         spanVar
         spanBoolean={[isNaMol, isBunMol, isGlMol, isMeasMol]}
         spanFunction={[setIsNaMol, setIsBunMol, setIsGlMol, setIsMeasMol]}
         ResultComponent={serumOsmolalityResult != undefined ? (
            <CalcResult
               closeFunction={() => setSerumOsmolalityResult(undefined)}
            >
               <CustomText>Расчетная осмолярность плазмы: <CustomBold>{serumOsmolalityResult} мосм/кг</CustomBold> (нормальная осмолярность плазмы: 285 - 295 мосм/кг).</CustomText>
               {osmGapResult && (
                  <CustomText>Осмолярная разница: <CustomBold>{osmGapResult} мосм/кг</CustomBold> (норма осмолярной разницы [измеренной - расчетной]՝ -14 - +10).</CustomText>
               )}
            </CalcResult>
         ) : undefined}
      />
   )
}

export default SerumOsmolality
