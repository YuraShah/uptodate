import React, { useState } from 'react'
import { useForm } from 'react-hook-form';
import CalcResult from '@/src/components/Calcs/CalcResult';
import { dripCalc } from '@/src/constants/calcs/form/drip-calc';
import CustomText from '@/src/components/CustomTexts/CustomText';
import CustomBold from '@/src/components/CustomTexts/CustomBold';
import CalcComponent, { ICalcData } from '@/src/components/Calcs/CalcComponent';
import { getBallWord, normalizeCommaToDot } from '@/src/functions/functions';

type IDripForm = {
   antib: string,
   term: string,
   tube: string,
   prior: string,
   hosp: string,
   dis: string,
   funct: string,
   h2: string,
   wound: string,
   mrsa: string
}

const Drip = () => {
   const { control, handleSubmit, reset } = useForm<IDripForm>({});
   const [dripResult, setDripResult] = useState<number>();
   const [refreshing, setRefreshing] = React.useState(false);

   const save = (data: IDripForm): void => {
      const cleanedData = normalizeCommaToDot(data);
      const total = Object.values(cleanedData).reduce((a: number, b: string) => a + +b, 0);
      setDripResult(total)
      reset()
   }

   const onRefresh = React.useCallback(() => {
      setRefreshing(true);
      setDripResult(undefined)
      reset()
      setTimeout(() => {
         setRefreshing(false);
      }, 300);
   }, []);


   return (
      <CalcComponent<IDripForm>
         data={dripCalc as ICalcData<IDripForm>}
         save={save}
         handleSubmit={handleSubmit}
         result={dripResult}
         onRefresh={onRefresh}
         refreshing={refreshing}
         control={control}
         ResultComponent={dripResult != undefined ? (
            <CalcResult
               closeFunction={() => setDripResult(undefined)}
            >
               <CustomText>
                  <CustomBold>{dripResult} {getBallWord(dripResult)}.</CustomBold>
               </CustomText>
               {dripResult >= 4 ? (
                  <CustomText>
                     <CustomBold>Высокий</CustomBold> риск развития лекарственно-устойчивой пневмонии. Вероятно, потребуются антибиотики широкого спектра действия.
                  </CustomText>
               ) : (
                  <CustomText>
                    <CustomBold>Низкий</CustomBold> риск развития лекарственно-устойчивой пневмонии. Рассмотрите вариант лечения без антибиотиков широкого спектра действия.
                  </CustomText>
               )}
            </CalcResult>
         ) : undefined}
      />
   )
}

export default Drip
