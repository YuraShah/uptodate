import React, { useState } from 'react'
import { useForm } from 'react-hook-form';
import CalcComponent, { ICalcData } from '@/src/components/Calcs/CalcComponent';
import { copdAssessmentForm } from '@/src/constants/calcs/form/copd-asessment-calc';
import CustomText from '@/src/components/CustomTexts/CustomText';
import CustomBold from '@/src/components/CustomTexts/CustomBold';
import CalcResult from '@/src/components/Calcs/CalcResult';
import { getBallWord, normalizeCommaToDot } from '@/src/functions/functions';

type ICopdAssessmentForm = {
   cough: string,
   phlegm: string,
   chestTightness: string,
   breathlessness: string,
   activity: string,
   confidence: string,
   sleep: string,
   energy: string
}

export default function CopdAssessment() {
   const { control, handleSubmit, reset } = useForm<ICopdAssessmentForm>({});
   const [result, setResult] = useState<number>();
   const [refreshing, setRefreshing] = React.useState(false);

   const save = (data: ICopdAssessmentForm): void => {
      const cleanedData = normalizeCommaToDot(data);
      const total = Object.values(cleanedData).reduce((a: number, b: string) => a + +b, 0);
      setResult(total)
      reset()
   }

   const onRefresh = React.useCallback(() => {
      setRefreshing(true);
      setResult(undefined)
      reset()
      setTimeout(() => {
         setRefreshing(false);
      }, 300);
   }, []);

   
   return (
      <CalcComponent<ICopdAssessmentForm>
         data={copdAssessmentForm as ICalcData<ICopdAssessmentForm>}
         save={save}
         handleSubmit={handleSubmit}
         result={result}
         onRefresh={onRefresh}
         refreshing={refreshing}
         control={control}
         ResultComponent={result != undefined ? (
            <CalcResult
               closeFunction={() => setResult(undefined)}
            >
               <CustomText>
                  <CustomBold>{result} {getBallWord(result)}.</CustomBold>
               </CustomText>
               {result >= 0 && result <= 10 ? (
                  <CustomText>
                     Низкое воздействие на здоровье.
                  </CustomText>
               ) : result >= 11 && result >= 20 ? (
                  <CustomText>
                     Умеренное воздействие на здоровье.
                  </CustomText>
               ) : result > 21 && (
                  <CustomText>
                     Высокое воздействие на здоровье.
                  </CustomText>
               )}
            </CalcResult>
         ) : undefined}
      />
   )
}
