import React, { useState } from 'react'
import { useForm } from 'react-hook-form';
import CalcResult from '@/src/components/Calcs/CalcResult';
import CustomText from '@/src/components/CustomTexts/CustomText';
import CustomBold from '@/src/components/CustomTexts/CustomBold';
import { mdrdFunc } from '@/src/functions/calc-functions';
import { mdrdCalc } from '@/src/constants/calcs/form/mdrd-calc';
import CalcComponent, { ICalcData } from '@/src/components/Calcs/CalcComponent';
import { normalizeCommaToDot } from '@/src/functions/functions';

type MDRDForm = {
   age: string,
   gender: string,
   creatinine: string,
   race: string
}

const MDRD = () => {
   const { control, handleSubmit, reset } = useForm<MDRDForm>({});
   const [mdrdResult, setMdrdResult] = useState<number>();
   const [isMgdl, setIsMgdl] = useState<boolean>(false)
   const [refreshing, setRefreshing] = React.useState(false);

   const save = (data: MDRDForm): void => {
      const cleanedData = normalizeCommaToDot(data);
      const result = mdrdFunc(+cleanedData.age, +cleanedData.gender, +cleanedData.creatinine, isMgdl, +cleanedData.race)
      setMdrdResult(result)
      setIsMgdl(false)
      reset()
   }

   const onRefresh = React.useCallback(() => {
      setRefreshing(true);
      setMdrdResult(undefined)
      setIsMgdl(false)
      reset()
      setTimeout(() => {
         setRefreshing(false);
      }, 300);
   }, []);


   return (
      <CalcComponent<MDRDForm>
         data={mdrdCalc as ICalcData<MDRDForm>}
         save={save}
         handleSubmit={handleSubmit}
         result={mdrdResult}
         onRefresh={onRefresh}
         refreshing={refreshing}
         control={control}
         isMarginStart
         spanVar={true}
         spanBoolean={isMgdl}
         spanFunction={setIsMgdl}
         ResultComponent={mdrdResult != undefined ? (
            <CalcResult
               closeFunction={() => setMdrdResult(undefined)}
            >
               <CustomText>СКФ:  <CustomBold>{mdrdResult} мл/мин/1,73 м²</CustomBold> (хроническая болезнь почек, {mdrdResult > 90 ? '1' : mdrdResult <= 89 && mdrdResult >= 60 ? '2' : mdrdResult <= 59 && mdrdResult >= 45 ? '3А' : mdrdResult <= 44 && mdrdResult >= 30 ? '3Б' : mdrdResult <= 29 && mdrdResult >= 15 ? '4' : '5'} степени):</CustomText>
            </CalcResult>
         ) : undefined}
      />
   )
}

export default MDRD
