import React, { useState } from 'react';
import { useForm } from 'react-hook-form';
import CalcResult from '@/src/components/Calcs/CalcResult';
import CustomText from '@/src/components/CustomTexts/CustomText';
import CustomBold from '@/src/components/CustomTexts/CustomBold';
import CalcComponent, { ICalcData } from '@/src/components/Calcs/CalcComponent';
import { nicotineDependenceCalc } from '@/src/constants/calcs/form/nicotine-dependence-calc';
import { getBallWord, normalizeCommaToDot } from '@/src/functions/functions';

type INicotineDependence = {
   first: string,
   second: string,
   third: string,
   fourth: string,
   fifth: string,
   sixth: string
}

const NicotineDependence = () => {
   const { control, handleSubmit, reset } = useForm<INicotineDependence>({});
   const [nicotineDependenceResult, setNicotineDependenceResult] = useState<number>();
   const [refreshing, setRefreshing] = React.useState(false);

   const save = (data: INicotineDependence): void => {
      const cleanedData = normalizeCommaToDot(data);
      const nicotineDependenceIndex = Object.values(cleanedData).reduce((a: number, b: string) => a + +b, 0)
      setNicotineDependenceResult(nicotineDependenceIndex)
      reset();
   }

   const onRefresh = React.useCallback(() => {
      setRefreshing(true);
      setNicotineDependenceResult(undefined)
      reset()
      setTimeout(() => {
         setRefreshing(false);
      }, 300);
   }, []);


   return (
      <CalcComponent<INicotineDependence>
         data={nicotineDependenceCalc as ICalcData<INicotineDependence>}
         save={save}
         handleSubmit={handleSubmit}
         result={nicotineDependenceResult}
         onRefresh={onRefresh}
         refreshing={refreshing}
         control={control}
         ResultComponent={nicotineDependenceResult != undefined ? (
            <CalcResult
               closeFunction={() => setNicotineDependenceResult(undefined)}
            >
               <CustomText><CustomBold>{nicotineDependenceResult} {getBallWord(nicotineDependenceResult)}.</CustomBold> <CustomText>{nicotineDependenceResult <= 2 ? 'Очень легкая зависимость. Приняв решение бросить курить, сосредоточьтесь на психологических факторах.' : nicotineDependenceResult > 2 && nicotineDependenceResult < 4 ? 'Легкая зависимость. Приняв решение бросить курить, сосредоточьтесь на психологических факторах.' : nicotineDependenceResult == 4 ? 'Слабая зависимость. После принятия решения бросить курить целесообразно использовать никотинзаместительные препараты.' : nicotineDependenceResult == 5 ? 'Умеренная степень зависимости. После принятия решения бросить курить целесообразно использовать никотинзаместительные препараты.' : nicotineDependenceResult > 5 && nicotineDependenceResult <= 7 ? 'Высокий уровень зависимости. После принятия решения бросить курить резкий отказ от этой привычки может вызвать неприятные ощущения в организме. Рекомендуется использовать никотинзаместительные препараты.' : 'Очень высокий уровень зависимости. После принятия решения бросить курить резкий отказ от этой привычки может вызвать неприятные ощущения в организме. Рекомендуется использовать никотинзаместительные препараты.'}</CustomText></CustomText>
            </CalcResult>
         ) : undefined}
      />
   )
}

export default NicotineDependence
