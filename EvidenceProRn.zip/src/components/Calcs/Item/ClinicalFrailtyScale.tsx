import React, { useState } from 'react'
import { useForm } from 'react-hook-form';
import { ScrollView, View } from 'react-native';
import CalcResult from '@/src/components/Calcs/CalcResult';
import { cfsCalc } from '@/src/constants/calcs/form/cfs-calc';
import CustomText from '@/src/components/CustomTexts/CustomText';
import CustomBold from '@/src/components/CustomTexts/CustomBold';
import CalcComponent, { ICalcData } from '@/src/components/Calcs/CalcComponent';
import { getBallWord, normalizeCommaToDot } from '@/src/functions/functions';

type ICFSForm = {
   cfs: string
}

const ClinicalFrailtyScale = () => {
   const { control, handleSubmit, reset } = useForm<ICFSForm>({});
   const [cfsResult, setCfsResult] = useState<number>();
   const [refreshing, setRefreshing] = React.useState(false);

   const save = (data: ICFSForm): void => {
      const cleanedData = normalizeCommaToDot(data);
      const total = +cleanedData.cfs;
      setCfsResult(total)
      reset()
   }

   const onRefresh = React.useCallback(() => {
      setRefreshing(true);
      setCfsResult(undefined)
      reset()
      setTimeout(() => {
         setRefreshing(false);
      }, 300);
   }, []);


   return (
      <CalcComponent<ICFSForm>
         data={cfsCalc as ICalcData<ICFSForm>}
         save={save}
         handleSubmit={handleSubmit}
         result={cfsResult}
         onRefresh={onRefresh}
         refreshing={refreshing}
         control={control}
         ResultComponent={cfsResult != undefined ? (
            <CalcResult
               closeFunction={() => setCfsResult(undefined)}
               heightLimiter
            >
               <ScrollView>
                  <View style={{
                     paddingRight: 40,
                     marginVertical: 30,
                     rowGap: 5
                  }}>
                     <CustomText>
                        <CustomBold>{cfsResult} {getBallWord(cfsResult)}.</CustomBold>
                     </CustomText>
                     {(cfsResult === 1 || cfsResult === 2 || cfsResult === 3) ? (
                        <>
                           <CustomText>
                              {cfsResult === 1 ? (
                                 "Очень хорошо"
                              ) : cfsResult === 2 ? (
                                 "Хорошо"
                              ) : (
                                 "Хорошо с излеченным коморбидным заболеванием"
                              )}
                           </CustomText>
                           <CustomText style={{ marginTop: 20 }}>Приблизительная вероятность избежания стационарного лечения (госпитализации) в течение 30 месяцев: <CustomBold>93%</CustomBold> </CustomText>
                           <CustomText>Расчетная вероятность смерти в течение 70 месяцев: <CustomBold>88%</CustomBold></CustomText>
                           <CustomText style={{ marginTop: 20 }}>Приблизительная вероятность выживания через 30 месяцев: <CustomBold>89%</CustomBold></CustomText>
                           <CustomText>Приблизительная вероятность выживания через 70 месяцев: <CustomBold>75%</CustomBold></CustomText>
                        </>
                     ) : cfsResult === 4 ? (
                        <>
                           <CustomText>Очевидно уязвимый</CustomText>
                           <CustomText style={{ marginTop: 20 }}>Приблизительная вероятность избежания стационарного лечения (госпитализации) в течение 30 месяцев: <CustomBold>85%</CustomBold></CustomText>
                           <CustomText>Расчетная вероятность смерти в течение 70 месяцев: <CustomBold>75%</CustomBold></CustomText>
                           <CustomText style={{ marginTop: 20 }}>Приблизительная вероятность выживания через 30 месяцев: <CustomBold>77%</CustomBold></CustomText>
                           <CustomText>Приблизительная вероятность выживания через 70 месяцев: <CustomBold>55%</CustomBold></CustomText>
                        </>
                     ) : cfsResult === 5 ? (
                        <>
                           <CustomText>Слегка ослабленный</CustomText>
                           <CustomText style={{ marginTop: 20 }}>Приблизительная вероятность избежания стационарного лечения (госпитализации) в течение 30 месяцев: <CustomBold>72%</CustomBold></CustomText>
                           <CustomText>Расчетная вероятность смерти в течение 70 месяцев: <CustomBold>58%</CustomBold></CustomText>
                           <CustomText style={{ marginTop: 20 }}>Приблизительная вероятность выживания через 30 месяцев: <CustomBold>68%</CustomBold></CustomText>
                           <CustomText>Приблизительная вероятность выживания через 70 месяцев: <CustomBold>42%</CustomBold></CustomText>
                        </>
                     ) : (cfsResult === 6 || cfsResult === 7) ? (
                        <>
                           <CustomText>
                              {cfsResult === 6 ? (
                                 "Умеренно слабый"
                              ) : (
                                 "Тяжелый слабый"
                              )}
                           </CustomText>
                           <CustomText style={{ marginTop: 20 }}>Приблизительная вероятность избежания стационарного лечения (госпитализации) в течение 30 месяцев: <CustomBold>66%</CustomBold></CustomText>
                           <CustomText>Расчетная вероятность смерти в течение 70 месяцев: <CustomBold>50%</CustomBold></CustomText>
                           <CustomText style={{ marginTop: 20 }}>Приблизительная вероятность выживания через 30 месяцев: <CustomBold>60%</CustomBold></CustomText>
                           <CustomText>Приблизительная вероятность выживания через 70 месяцев: <CustomBold>38%</CustomBold></CustomText>
                        </>
                     ) : (
                        <CustomText>
                           {cfsResult === 8 ? (
                              "Очень тяжело слабый"
                           ) : (
                              "Терминальная стадия заболевания"
                           )}
                        </CustomText>
                     )}
                  </View>
               </ScrollView>
            </CalcResult>
         ) : undefined}
      />
   )
}

export default ClinicalFrailtyScale
