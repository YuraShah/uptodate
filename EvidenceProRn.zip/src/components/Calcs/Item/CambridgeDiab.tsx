import React, { useState } from 'react'
import { useForm } from 'react-hook-form';
import CalcResult from '@/src/components/Calcs/CalcResult';
import { cambridgeDiabCalc } from '@/src/constants/calcs/form/cambdiab-calc';
import CustomText from '@/src/components/CustomTexts/CustomText';
import CustomBold from '@/src/components/CustomTexts/CustomBold';
import CalcComponent, { ICalcData } from '@/src/components/Calcs/CalcComponent';
import { normalizeCommaToDot } from '@/src/functions/functions';

type ICambridgeDiab = {
   gender: string,
   hypert: string,
   ster: string,
   age: string,
   bmi: string,
   famil: string,
   smoking: string
}

const CambridgeDiab = () => {
   const { control, handleSubmit, reset } = useForm<ICambridgeDiab>({});
   const [diabResult, setDiabResult] = useState<number>();
   const [refreshing, setRefreshing] = React.useState(false);

   const save = (data: ICambridgeDiab): void => {
      const cleanedData = normalizeCommaToDot(data);
      const alpha = -6.322;

      const genderCoeff = +cleanedData.gender * -0.879;
      const hypertCoeff = +cleanedData.hypert * 1.222;
      const sterCoeff = +cleanedData.ster * 2.191;
      const ageCoeff = parseFloat(cleanedData.age) * 0.063;
      const bmiCoeff = parseFloat(cleanedData.bmi);
      const familCoeff = parseFloat(cleanedData.famil);
      const smokingCoeff = parseFloat(cleanedData.smoking);

      const total = alpha + genderCoeff + hypertCoeff + sterCoeff + ageCoeff + bmiCoeff + familCoeff + smokingCoeff;
      const probability = 1 / (1 + Math.exp(-total));
      const probabilityPercentage = probability * 100;

      setDiabResult(probabilityPercentage)
      reset()
   }

   const onRefresh = React.useCallback(() => {
      setRefreshing(true);
      setDiabResult(undefined)
      reset()
      setTimeout(() => {
         setRefreshing(false);
      }, 300);
   }, []);


   return (
      <CalcComponent<ICambridgeDiab>
         data={cambridgeDiabCalc as ICalcData<ICambridgeDiab>}
         save={save}
         handleSubmit={handleSubmit}
         result={diabResult}
         onRefresh={onRefresh}
         refreshing={refreshing}
         control={control}
         isMarginStart
         ResultComponent={diabResult != undefined ? (
            <CalcResult
               closeFunction={() => setDiabResult(undefined)}
            >
               <CustomText>
                  <CustomBold>{parseFloat(diabResult.toFixed(2))}%</CustomBold> вероятность диабета 2 типа у ранее недиагностированного пациента.
               </CustomText>
               <CustomText>
                  {'>'}11% баллы риска имеют 85%-ную чувствительность для выявления сахарного диабета (HgbA1c ≥7,0%).
               </CustomText>
            </CalcResult>
         ) : undefined}
      />
   )
}

export default CambridgeDiab
