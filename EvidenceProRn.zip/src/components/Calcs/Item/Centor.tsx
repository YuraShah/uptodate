import React, { useState } from 'react'
import { useForm } from 'react-hook-form';
import CalcResult from '@/src/components/Calcs/CalcResult';
import CustomText from '@/src/components/CustomTexts/CustomText';
import CustomBold from '@/src/components/CustomTexts/CustomBold';
import CalcComponent, { ICalcData } from '@/src/components/Calcs/CalcComponent';
import { centorCalc } from '@/src/constants/calcs/form/centor-calc';
import { getBallWord, normalizeCommaToDot } from '@/src/functions/functions';

type CentorForm = {
   age: string,
   tonsil: string,
   lymph: string,
   temp: string,
   cough: string
}

const Centor = () => {
   const { control, handleSubmit, reset } = useForm<CentorForm>({});
   const [centorResult, setCentorResult] = useState<number>();
   const [refreshing, setRefreshing] = React.useState(false);

   const save = (data: CentorForm): void => {
      const cleanedData = normalizeCommaToDot(data);
      const cage = cleanedData.age === '-1' ? -1 : +cleanedData.age
      const total = cage + +cleanedData.tonsil + +cleanedData.lymph + +cleanedData.temp + +cleanedData.cough;
      setCentorResult(total)
      reset()
   }

   const onRefresh = React.useCallback(() => {
      setRefreshing(true);
      setCentorResult(undefined)
      reset()
      setTimeout(() => {
         setRefreshing(false);
      }, 300);
   }, []);


   return (
      <CalcComponent<CentorForm>
         data={centorCalc as ICalcData<CentorForm>}
         save={save}
         handleSubmit={handleSubmit}
         result={centorResult}
         onRefresh={onRefresh}
         refreshing={refreshing}
         control={control}
         ResultComponent={centorResult != undefined ? (
            <CalcResult
               closeFunction={() => setCentorResult(undefined)}
            >
               <CustomText><CustomBold>{centorResult} {getBallWord(centorResult)}</CustomBold></CustomText>
               <CustomText>{centorResult === -1 || centorResult === 0 ? 'Вероятность стрептококкового фарингита: 1-2.5%' : centorResult === 1 ? 'Вероятность стрептококкового фарингита: 5-10%' : centorResult === 2 ? 'Вероятность стрептококкового фарингита: 11-17%' : centorResult === 3 ? 'Вероятность стрептококкового фарингита: 28-35%' : 'Вероятность стрептококкового фарингита: 51-53%'}</CustomText>
               <CustomText>{centorResult === -1 || centorResult === 0 ? 'Никаких дополнительных анализов или антибиотиков не требуется.' : centorResult === 1 ? 'Никаких дополнительных анализов или антибиотиков не требуется.' : centorResult === 2 ? 'Селективное экспресс-тестирование и/или посев на стрептококки' : centorResult === 3 ? 'Рассмотрите возможность экспресс-тестирования и/или посева' : 'Рассмотрите возможность экспресс-тестирования и/или посева. В зависимости от конкретного случая может быть целесообразной эмпирическая антибактериальная терапия.'}</CustomText>
            </CalcResult>
         ) : undefined}
      />
   )
}

export default Centor
