import React, { useState } from 'react'
import { useForm } from 'react-hook-form';
import CalcResult from '@/src/components/Calcs/CalcResult';
import CustomText from '@/src/components/CustomTexts/CustomText';
import CustomBold from '@/src/components/CustomTexts/CustomBold';
import { acetamToxCalc } from '@/src/constants/calcs/form/acetamtox-calc';
import CalcComponent, { ICalcData } from '@/src/components/Calcs/CalcComponent';
import { normalizeCommaToDot } from '@/src/functions/functions';

type AcetamToxForm = {
   hour: string,
   point: string,
}

const AcetamTox = () => {
   const { control, handleSubmit, reset } = useForm<AcetamToxForm>({});
   const [acetamToxResult, setAcetamToxResult] = useState<number>();
   const [perTimeResult, setPerTimeResult] = useState<number>(0);
   const [bordResult, setBordResult] = useState<number>(0);
   const [isHigh, setIsHigh] = useState<boolean>(false)
   const [refreshing, setRefreshing] = React.useState(false);
   const [isMgl, setIsMgl] = useState<boolean>(false)

   const save = (data: AcetamToxForm): void => {
      const cleanedData = normalizeCommaToDot(data);
      const toxLevel = Math.exp(5.298317 - ((+cleanedData.hour - 4) * 0.1732868))
      const rxLevel = toxLevel - (0.25 * toxLevel)
      const point = !isMgl ? +cleanedData.point / 6.62 : +cleanedData.point
      setPerTimeResult(+cleanedData.hour)
      setAcetamToxResult(rxLevel)
      setBordResult(toxLevel)
      if (point < rxLevel) {
         setIsHigh(false)
      } else {
         setIsHigh(true)
      }
      reset()
   }

   const onRefresh = React.useCallback(() => {
      setRefreshing(true);
      setAcetamToxResult(undefined)
      setPerTimeResult(0)
      setBordResult(0)
      setIsHigh(false)
      setIsMgl(false)
      reset()
      setTimeout(() => {
         setRefreshing(false);
      }, 300);
   }, []);


   return (
      <CalcComponent<AcetamToxForm>
         data={acetamToxCalc as ICalcData<AcetamToxForm>}
         save={save}
         handleSubmit={handleSubmit}
         result={acetamToxResult}
         onRefresh={onRefresh}
         refreshing={refreshing}
         control={control}
         spanVar
         spanBoolean={isMgl}
         spanFunction={setIsMgl}
         ResultComponent={acetamToxResult != undefined ? (
            <CalcResult
               closeFunction={() => setAcetamToxResult(undefined)}
            >
               <CustomText>{perTimeResult} часов после приема парацетамола его уровень {isHigh ? <><CustomBold>ВЫШЕ</CustomBold></> :
                  <><CustomBold>НИЖЕ</CustomBold></>}, чем {acetamToxResult.toFixed(2)} мкг/мл [{(acetamToxResult * 6.62).toFixed(2)} мкмоль/л] пороговое значение лечения. {'\n'}{'\n'}{!isHigh ? <>Пороговое значение токсичности для данного времени равно {bordResult.toFixed(2)} мкг/мл [{(bordResult * 6.62).toFixed(2)} мкмоль/л], что указывает на <CustomBold>НИЗКИЙ РИСК</CustomBold> развития.</> : <>{bordResult.toFixed(2)} мкг/мл [{(bordResult * 6.62).toFixed(2)} мкмоль/л] пороговом значении существует <CustomBold>ВЫСОКИЙ РИСК</CustomBold>, поэтому эту передозировку следует лечить.</>}</CustomText>
            </CalcResult>
         ) : undefined}
      />
   )
}

export default AcetamTox
