import React, { useState } from 'react';
import { useForm } from 'react-hook-form';
import { View } from 'react-native';
import CalcResult from '@/src/components/Calcs/CalcResult';
import CustomText from '@/src/components/CustomTexts/CustomText';
import CustomBold from '@/src/components/CustomTexts/CustomBold';
import CalcComponent, { ICalcData } from '@/src/components/Calcs/CalcComponent';
import { intravenousCalc } from '@/src/constants/calcs/form/intravenous-calc';
import { normalizeCommaToDot } from '@/src/functions/functions';

type IIntraVenousSpeed = {
   volume: string,
   time: string
}

const IntraVenousSpeed = () => {
   const [intraVenousSpeedResult, setIntraVenousSpeedResult] = useState<number>();
   const [isTimeInMinute, setIsTimeInMinute] = useState<boolean>(false);
   const { control, handleSubmit, reset } = useForm<IIntraVenousSpeed>({});
   const [refreshing, setRefreshing] = React.useState(false);

   const save = (data: IIntraVenousSpeed): void => {
      const cleanedData = normalizeCommaToDot(data);
      let v = !isTimeInMinute ? (+cleanedData.volume * 20) / +cleanedData.time : (+cleanedData.volume * 20) / (+cleanedData.time * 60);
      setIntraVenousSpeedResult(v);
      reset();
   }

   const onRefresh = React.useCallback(() => {
      setRefreshing(true);
      setIntraVenousSpeedResult(undefined)
      setIsTimeInMinute(false)
      reset();
      setTimeout(() => {
         setRefreshing(false);
      }, 300);
   }, []);


   return (
      <CalcComponent<IIntraVenousSpeed>
         data={intravenousCalc as ICalcData<IIntraVenousSpeed>}
         save={save}
         handleSubmit={handleSubmit}
         result={intraVenousSpeedResult}
         onRefresh={onRefresh}
         refreshing={refreshing}
         control={control}
         spanVar={true}
         spanBoolean={isTimeInMinute}
         spanFunction={setIsTimeInMinute}
         ResultComponent={intraVenousSpeedResult != undefined ? (
            <CalcResult
               closeFunction={() => setIntraVenousSpeedResult(undefined)}
            >
               <View>
                  <CustomText>Количество капель в минуту: <CustomBold>{Math.round(intraVenousSpeedResult)}</CustomBold></CustomText>
                  <CustomText>Количество капель в секунду: <CustomBold>{(intraVenousSpeedResult / 60).toFixed(2)}</CustomBold></CustomText>
               </View>
            </CalcResult>
         ) : undefined}
         />
   )
}

export default IntraVenousSpeed
