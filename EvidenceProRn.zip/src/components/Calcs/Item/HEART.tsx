import React, { useState } from 'react';
import { useForm } from 'react-hook-form';
import CalcResult from '@/src/components/Calcs/CalcResult';
import CustomText from '@/src/components/CustomTexts/CustomText';
import CustomBold from '@/src/components/CustomTexts/CustomBold';
import { heartCalc } from '@/src/constants/calcs/form/heart-calc';
import CalcComponent, { ICalcData } from '@/src/components/Calcs/CalcComponent';
import { getBallWord, normalizeCommaToDot } from '@/src/functions/functions';

type IHeart = {
   age: string,
   anamnesis: string,
   ecg: string,
   risks: string,
   troponin: string
}

const HEART = () => {
   const { control, handleSubmit, reset } = useForm<IHeart>({});
   const [heartResult, setHeartResult] = useState<number>();
   const [refreshing, setRefreshing] = React.useState(false);

   const save = (data: IHeart): void => {
      const cleanedData = normalizeCommaToDot(data);
      const total = Object.values(cleanedData).reduce((a: number, b: any) => a + +b, 0);
      setHeartResult(total)
      reset()
   }

   const onRefresh = React.useCallback(() => {
      setRefreshing(true);
      setHeartResult(undefined)
      reset()
      setTimeout(() => {
         setRefreshing(false);
      }, 300);
   }, []);


   return (
      <CalcComponent<IHeart>
         data={heartCalc as ICalcData<IHeart>}
         save={save}
         handleSubmit={handleSubmit}
         result={heartResult}
         onRefresh={onRefresh}
         refreshing={refreshing}
         control={control}
         ResultComponent={heartResult != undefined ? (
            <CalcResult
               closeFunction={() => setHeartResult(undefined)}
            >
               <CustomText><CustomBold>{heartResult} {getBallWord(heartResult)}.</CustomBold> Риск неблагоприятного сердечного события составляет {heartResult <= 3 ? '0.9 - 1.7' : heartResult >= 4 && heartResult <= 6 ? '12 - 16.6' : '50 - 65'}%. В исследовании результата HEART эти пациенты {heartResult <= 3 ? 'были выписаны (0.99% в ретроспективном исследовании, 1.7% в проспективном исследовании)' : heartResult >= 4 && heartResult <= 6 ? 'были госпитализированы (11.6% ретроспективно, 16.6% проспективно)' : 'претендовали на ранние инвазивные вмешательства (65.2% ретроспективно, 50.1% проспективно)'}:</CustomText>
            </CalcResult>
         ) : undefined}
      />
   )
}

export default HEART
