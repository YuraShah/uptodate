import React, { useEffect, useMemo, useState } from 'react'
import { FlatList, RefreshControl, ScrollView, StyleSheet, TouchableOpacity, useWindowDimensions, View } from 'react-native';
import { useForm } from 'react-hook-form';
import { RadioButtonProps } from 'react-native-radio-buttons-group';
import { faTrashCan } from '@fortawesome/free-solid-svg-icons';
import CalcResult from '@/src/components/Calcs/CalcResult';
import CustomText from '@/src/components/CustomTexts/CustomText';
import CustomTextItalic from '@/src/components/CustomTexts/CustomTextItalic';
import CustomTextBold from '@/src/components/CustomTexts/CustomTextBold';
import CustomBold from '@/src/components/CustomTexts/CustomBold';
import { useQuery } from '@tanstack/react-query';
import { fetchUseQuery } from '@/src/functions/fetchUseQuery';
import { IResponseData, LINKS } from '@/src/types/types';
import { QTScanNonIcuFunc } from '@/src/functions/calc-functions';
import { useTheme } from '@/src/hooks/useTheme';
import CustomIconSmall from '@/src/components/CustomIcons/CustomIconSmall';
import { SafeAreaView } from 'react-native';
import { getBallWord, normalizeCommaToDot } from '@/src/functions/functions';
import { Toast } from 'toastify-react-native';
import CalcTitleShare from '@/src/components/Calcs/CalcTitleShare';
import CalcInput from '@/src/components/Calcs/CalcInput';
import CalcRadio from '@/src/components/Calcs/CalcRadio';
import CalcCheck from '@/src/components/Calcs/CalcCheck';
import CalcButton from '@/src/components/Calcs/CalcButton';
import CalcRefs from '@/src/components/Calcs/CalcRefs';
import Separator from '@/src/components/Separator';
import MenuList from '@/src/components/MenuList';
import { useDebounce } from '@/src/hooks/useDebounce';
import SelectAsyncComponent from '@/src/components/SelectComponent/SelectAsyncComponent';
import { CustomTable } from '@/src/components/CustomTable';
import Loader from '@/src/components/Loader/Loader';
import ErrorNet from '@/src/components/ErrorNet';

const riskValues: { [key: string]: number } = {
  KR: 3,
  CR: 0,
  PR: 1,
  SR: 0
};

type IQTRiskNonIcu = {
  age: string,
  gender: string,
  atrialfib: boolean,
  lqts: boolean,
  heartfailure: boolean,
  valve: boolean,
  hypertension: boolean,
  myocinf: boolean,
  myocinfprior: boolean,
  qtc: boolean,
  qtc500: boolean,
  hypocalc: boolean,
  hypokal: boolean,
  hypomag: boolean,
  liverfail: boolean,
  renalfail: boolean,
  diab: boolean
}

type IQtDrugs = {
  id: string,
  label: string,
  qt_category: string,
  qt_ecg: string
}

const QTScanNonIcu = () => {
  const [inpValue, setInpValue] = useState<string>('');
  const debouncedValue = useDebounce(inpValue, 500)
  const [isSearchListOpen, setIsSearchListOpen] = useState<boolean>(false)
  const [refreshing, setRefreshing] = React.useState(false);
  const { colors } = useTheme()
  const [qtScanResult, setQtScanResult] = useState<number>();
  const [drugs, setDrugs] = useState<IQtDrugs[]>([])
  const [krRiskDrugs, setKrRiskDrugs] = useState<IQtDrugs[]>([])
  const [isHypokal, setIsHypokal] = useState(false)
  const [isHypocalc, setIsHypocalc] = useState(false)
  const [isHypomag, setIsHypomag] = useState(false)
  const { width } = useWindowDimensions()

  const onHandleChange = (label: string) => {
    const findedDrug = data?.data.find((drug) => drug.label === label)

    if (!findedDrug) return

    if (drugs.length < 30) {
      const findDrug = drugs.find((a) => a.label === label)

      if (findDrug) {
        Toast.success("Уже добавлено", "top")
        return
      }

      setDrugs([...drugs, findedDrug])
      setIsSearchListOpen(false)
      setInpValue('')
    }
  }

  const deleteDrug = (index: number) => {
    const filteredDrugs = drugs.filter((_, i) => i !== index);
    setDrugs(filteredDrugs)
    setKrRiskDrugs([])
    setQtScanResult(undefined)
  }

  const { isError, data, refetch, isSuccess, isLoading } = useQuery({
    queryKey: ['drugQtOptions', debouncedValue],
    queryFn: async () => {
      return fetchUseQuery<IResponseData<IQtDrugs>>(
        'post',
        LINKS.DRUGQTSEARCHCALC,
        debouncedValue.toLowerCase()
      )
    },
    enabled: debouncedValue.length >= 3,
    gcTime: 2000
  })

  useEffect(() => {
    if (data && data.data && isSuccess) {
      setIsSearchListOpen(true)
    }
  }, [data, isSuccess])

  const { control, handleSubmit, reset, setValue } = useForm<IQTRiskNonIcu>();

  const handleCheckboxChange = (value: boolean, id: keyof IQTRiskNonIcu) => {
    if (value) {
      if (id === 'qtc500') {
        setValue('qtc500', true);
        setValue('qtc', false);
        setValue('lqts', false);
      } else if (id === 'qtc') {
        setValue('qtc', true);
        setValue('qtc500', false);
        setValue('lqts', false);
      } else if (id === 'lqts') {
        setValue('lqts', true);
        setValue('qtc500', false);
        setValue('qtc', false);
      } else if (id === 'myocinf') {
        setValue('myocinf', true);
        setValue('myocinfprior', false);
      } else if (id === 'myocinfprior') {
        setValue('myocinfprior', true);
        setValue('myocinf', false);
      }
    } else {
      setValue(id, false);
    }
  };

  const save = (data: IQTRiskNonIcu) => {
    const cleanedData = normalizeCommaToDot(data);
    const result = QTScanNonIcuFunc({
      age: cleanedData.age,
      gender: cleanedData.gender,
      atrialfib: cleanedData.atrialfib,
      lqts: cleanedData.lqts,
      heartfail: cleanedData.heartfailure,
      valve: cleanedData.valve,
      hypertension: cleanedData.hypertension,
      myoinf: cleanedData.myocinf,
      myocinfprior: cleanedData.myocinfprior,
      qtc: cleanedData.qtc,
      qtc500: cleanedData.qtc500,
      hypocalc: cleanedData.hypocalc,
      hypokal: cleanedData.hypokal,
      hypomag: cleanedData.hypomag
    })

    setIsHypokal(cleanedData.hypokal)
    setIsHypocalc(cleanedData.hypocalc)
    setIsHypomag(cleanedData.hypomag)
    setKrRiskDrugs([])

    if (drugs.length > 0) {
      const filteredRisk = drugs.filter((a) => a.qt_category === 'KR');
      const posRisk = drugs.find((a) => a.qt_category === 'PR');

      let riskScore = 0;

      if (filteredRisk.length > 0) {
        setKrRiskDrugs(filteredRisk)

        if (posRisk) {
          riskScore = 1;
        }
      }


      const sumRisk = drugs.reduce((sum, item) => {
        return sum + (riskValues[item.qt_category!] || 0);
      }, 0);

      const endResult = result + sumRisk + riskScore;

      setQtScanResult(endResult);
      reset()
      setDrugs([])
      return
    }

    setQtScanResult(result);
    reset()
    setDrugs([])
  }

  const onRefresh = React.useCallback(() => {
    setRefreshing(true);
    setDrugs([])
    reset()
    refetch()
    setTimeout(() => {
      setRefreshing(false);
    }, 2000);
  }, []);

  const radioButtons1: RadioButtonProps[] = useMemo(() => ([
    {
      id: '0',
      label: 'Мужской',
      value: '20',
      color: colors.checkboxColor,
    },
    {
      id: '1',
      label: 'Женский',
      value: '1',
      color: colors.checkboxColor,
    }
  ]), []);

  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: colors.background }}>
      {qtScanResult != undefined && (
        <CalcResult
          closeFunction={() => setQtScanResult(undefined)}
          heightLimiter
        >
          <ScrollView>
            <CustomText style={styles.resultText}><CustomBold>{qtScanResult} {getBallWord(qtScanResult)}.</CustomBold></CustomText>
            {krRiskDrugs.length > 0 && (
              <View style={styles.resultOthContainer}>
                <CustomText style={styles.resultOth}>Очень высокий риск TdP. Выполните ЭКГ, чтобы проверить QTc и следить за тем, чтобы он не превышал 500 мс. Рассмотрите возможность замены {krRiskDrugs.map((elem, index) => (<CustomBold key={index}>{elem.label}а{index !== krRiskDrugs.length - 1 && ', '}</CustomBold>))} на альтернативные препараты без известного риска TdP, если это возможно.</CustomText>
                {isHypokal && (
                  <CustomText style={styles.resultOth}>Рекомендовать ЭКГ для проверки QTc и коррекции гипокалиемии перед использованием {krRiskDrugs.map((elem, index) => (<CustomBold key={index}>{elem.label}а{index !== krRiskDrugs.length - 1 && ', '}</CustomBold>))} из-за известного риска TdP.</CustomText>
                )}
                {isHypomag && (
                  <CustomText style={styles.resultOth}>Рекомендовать ЭКГ для проверки QTc и коррекции гипомагниемии перед использованием {krRiskDrugs.map((elem, index) => (<CustomBold key={index}>{elem.label}а{index !== krRiskDrugs.length - 1 && ', '}</CustomBold>))} из-за известного риска TdP.</CustomText>
                )}
                {isHypocalc && (
                  <CustomText style={styles.resultOth}>Рекомендовать ЭКГ для проверки QTc и коррекции гипокальциемии перед использованием {krRiskDrugs.map((elem, index) => (<CustomBold key={index}>{elem.label}а{index !== krRiskDrugs.length - 1 && ', '}</CustomBold>))} из-за известного риска TdP.</CustomText>
                )}
                {krRiskDrugs.map((elem, index) => {
                  if (elem.qt_ecg) {
                    return (
                      <CustomText
                        style={styles.resultOth}
                        key={index}
                      >
                        Листок-вкладыш <CustomBold>{elem.label}а</CustomBold>: {elem.qt_ecg}
                      </CustomText>
                    )
                  }
                })}
              </View>
            )}
          </ScrollView>
        </CalcResult>
      )}
      <FlatList
        style={styles.container}
        refreshControl={
          <RefreshControl
            refreshing={refreshing}
            onRefresh={onRefresh}
            colors={[colors.mainBg]}
            progressBackgroundColor={colors.refreshProgressBarBg}
          />
        }
        ListHeaderComponent={
          <>
            <CalcTitleShare
              titleText={'Калькулятор риска QT (пациент, не находящийся в отделении интенсивной терапии)'}
              calcId={'EV-CALC-29'}
              link='qt-risk-non-icu'
            />
            <View style={styles.form}>
              <View style={[
                width >= 780 && { width: '70%' }
              ]}>
                <CalcInput<IQTRiskNonIcu>
                  control={control}
                  labelTitle={'Возраст'}
                  inputId={'age'}
                  inputPlaceholder={'1 - 120'}
                  errorText={'Возраст должен быть в диапазоне 1 - 120'}
                  inputSpan={'лет'}
                  min={1}
                  max={120}
                  required={true}
                  pattern={/^\d+$/}
                  spanWidth={115}
                />
              </View>
              <CalcRadio<IQTRiskNonIcu>
                control={control}
                labelTitle={'Пол'}
                inputId={'gender'}
                required={true}
                radioButtons={radioButtons1}
                isMarginStart
              />
              <View style={styles.subcontainer}>
                <CustomText style={styles.subtitle}>Кардиологические диагнозы</CustomText>
                <CalcCheck<IQTRiskNonIcu>
                  control={control}
                  inputId={'atrialfib'}
                  labelTitle={'Фибрилляция предсердий'}
                />
                <CalcCheck<IQTRiskNonIcu>
                  control={control}
                  inputId={'lqts'}
                  labelTitle={'Врожденный синдром удлиненного интервала QT'}
                  onChange={(value: boolean) => handleCheckboxChange(value, 'lqts')}
                />
                <CalcCheck<IQTRiskNonIcu>
                  control={control}
                  inputId={'heartfailure'}
                  labelTitle={'Сердечная недостаточность'}
                />
                <CalcCheck<IQTRiskNonIcu>
                  control={control}
                  inputId={'valve'}
                  labelTitle={'Болезнь сердечного клапана'}
                />
                <CalcCheck<IQTRiskNonIcu>
                  control={control}
                  inputId={'hypertension'}
                  labelTitle={'Гипертензия'}
                />
                <CalcCheck<IQTRiskNonIcu>
                  control={control}
                  inputId={'myocinf'}
                  labelTitle={'Инфаркт миокарда (острый)'}
                  onChange={(value: boolean) => handleCheckboxChange(value, 'myocinf')}
                />
                <CalcCheck<IQTRiskNonIcu>
                  control={control}
                  inputId={'myocinfprior'}
                  labelTitle={'Инфаркт миокарда (в анамнезе)'}
                  onChange={(value: boolean) => handleCheckboxChange(value, 'myocinfprior')}
                />
              </View>
              <View style={styles.subcontainer}>
                <CustomText style={styles.subtitle}>ЭКГ</CustomText>
                <CalcCheck<IQTRiskNonIcu>
                  control={control}
                  inputId={'qtc'}
                  labelTitle={'QTc ≥450 և <500 мсек'}
                  onChange={(value: boolean) => handleCheckboxChange(value, 'qtc')}
                />
                <CalcCheck<IQTRiskNonIcu>
                  control={control}
                  inputId={'qtc500'}
                  labelTitle={'QTc ≥500 мсек'}
                  onChange={(value: boolean) => handleCheckboxChange(value, 'qtc500')}
                />
              </View>
              <View style={styles.subcontainer}>
                <CustomText style={styles.subtitle}>Электролиты</CustomText>
                <CalcCheck<IQTRiskNonIcu>
                  control={control}
                  inputId={'hypocalc'}
                  labelTitle={'Гипокальцемия ≤ 8.5 мг/дл'}
                />
                <CalcCheck<IQTRiskNonIcu>
                  control={control}
                  inputId={'hypokal'}
                  labelTitle={'Гипокалемия ≤3.5 мэкв/л'}
                />
                <CalcCheck<IQTRiskNonIcu>
                  control={control}
                  inputId={'hypomag'}
                  labelTitle={'Гипомагнемия ≤1.5 мэкв/л'}
                />
              </View>
              <View style={{ marginTop: 10 }}>
                <CustomText style={styles.subtitle}>Специфические риски</CustomText>
                <CalcCheck<IQTRiskNonIcu>
                  control={control}
                  inputId={'diab'}
                  labelTitle={'Сахарный диабет'}
                />
                <CalcCheck<IQTRiskNonIcu>
                  control={control}
                  inputId={'liverfail'}
                  labelTitle={'Печеночная недостаточность'}
                />
                <CalcCheck<IQTRiskNonIcu>
                  control={control}
                  inputId={'renalfail'}
                  labelTitle={'Почечная недостаточность'}
                />
                <View style={{ marginTop: 20, marginBottom: -10 }}>
                  <CustomTextBold>Добавить лекарство</CustomTextBold>
                  <SelectAsyncComponent
                    inpValue={inpValue}
                    setInpValue={setInpValue}
                    windowWidth={width}
                    placeholder={`Напишите препарат (≥3 буквы)`}
                  />
                </View>
              </View>
              {isLoading ? <Loader /> : isError ? <ErrorNet /> : null}
            </View>
          </>
        }
        data={data?.data ?? []}
        renderItem={({ item }) => (
          <MenuList
            onPress={() => onHandleChange(item.label)}
            title={item.label}
          />
        )}
        ItemSeparatorComponent={() => <Separator />}
        ListEmptyComponent={isSuccess && isSearchListOpen ? <CustomText style={{ paddingHorizontal: 15, marginTop: 5, marginBottom: 15 }}>Не найдено совпадений</CustomText> : null}
        keyExtractor={item => item.id}
        ListFooterComponent={
          <>
            {drugs.length > 0 && (
              <View style={styles.drugsContainer}>
                {drugs.map((drug, index) => (
                  <View
                    key={index}
                    style={[styles.drugContainer, { borderColor: colors.tableBorder }]}
                  >
                    <View style={styles.drugContent}>
                      <CustomText style={styles.drugText}>
                        {drug.label}
                      </CustomText>
                      <CustomTextItalic style={styles.drugText}>
                        {drug.qt_category === 'KR' ? (
                          'Известный риск TdP'
                        ) : drug.qt_category === 'PR' ? (
                          'Возможный риск TdP'
                        ) : drug.qt_category === 'CR' ? (
                          'Условный риск TdP'
                        ) : (
                          'Специфический риск TdP'
                        )}
                      </CustomTextItalic>
                    </View>
                    <TouchableOpacity
                      onPress={() => deleteDrug(index)}
                      style={[styles.drugTouch, { backgroundColor: colors.tableBorder }]}
                    >
                      <CustomIconSmall
                        icon={faTrashCan}
                        color={colors.iconWhite}
                      />
                    </TouchableOpacity>
                  </View>
                )
                )}
              </View>
            )}
            <View style={[{ marginTop: -10 }, width >= 780 && { width: '70%' }]}>
              <CalcButton
                onPress={handleSubmit(save)}
              />
            </View>
            <View
              style={{
                marginBottom: 40,
                marginTop: -40
              }}
            >
              <CustomTable
                headData={['Баллы', 'Риск']}
                bodyData={[
                  ['8.5-11.5', 'Низкий риск'],
                  ['11.6-15.5', 'Средний риск'],
                  ['>15.5', 'Высокий риск']
                ]}
                flexNums={[1, 1]}
              />
            </View>
            <CalcRefs
              refs={[
                "Hohnloser SH, Woosley RL. Sotalol. N Engl J Med 1994; 331:31-38",
                "Schwartz PJ, Woosley RL. Predicting the Unpredictable: Drug-Induced QT Prolongation and Torsades de Pointes. J Am Coll Cardiol 2016;67:1639-50.",
                "Zareba W, Moss AJ, Le Cessie S, Locati EH, Robinson JL, Hall WJ et al. Risk of cardiac events in family members of patients with Long QT syndrome. J Am. College Cardiol 1995; 26(7):1685-1691.",
                "Schwartz PJ, Moss AJ, Vincent GM, Crampton RS. Diagnostic criteria for the long QT syndrome: An update. Circ 1993; 88:782-784.",
                "Moss AJ, Schwartz PJ, Crampton RS, Tzivoni D, Locati EH, MacCluer J et al. The long QT syndrome. Prospective longitudinal study of 328 families. Circ 1991; 84(3):1136-1144.",
              ]}
              isRefTitle
            />
          </>
        }
      />
    </SafeAreaView>
  )
}

const styles = StyleSheet.create({
  container: {
    padding: 15,
  },
  resultText: {
    marginBottom: 40,
    marginRight: 40,
    marginTop: 30,
    paddingRight: 15
  },
  resultOthContainer: {
    paddingRight: 25,
    paddingBottom: 40
  },
  resultOth: {
    marginVertical: 10,
  },
  form: {
    marginTop: 10,
    padding: 5
  },
  headTab: {
    padding: 5,
    fontWeight: 'bold',
    lineHeight: 28
  },
  textTab: {
    padding: 5,
    lineHeight: 28
  },
  subcontainer: {
    marginVertical: 10,
  },
  subtitle: {
    fontWeight: 'bold',
    marginBottom: 10
  },
  drugsContainer: {
    marginBottom: 10,
  },
  drugContainer: {
    marginVertical: 5,
    flexDirection: 'row',
    borderWidth: 1,
    borderRadius: 2,
    overflow: 'hidden'
  },
  drugContent: {
    flex: 1
  },
  drugText: {
    padding: 5
  },
  drugTouch: {
    width: 50,
    alignItems: 'center',
    justifyContent: 'center'
  },
})

export default QTScanNonIcu
