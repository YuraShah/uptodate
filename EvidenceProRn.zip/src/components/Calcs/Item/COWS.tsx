import React, { useState } from 'react';
import { useForm } from 'react-hook-form';
import CalcResult from '@/src/components/Calcs/CalcResult';
import CustomText from '@/src/components/CustomTexts/CustomText';
import CustomBold from '@/src/components/CustomTexts/CustomBold';
import CalcComponent, { ICalcData } from '@/src/components/Calcs/CalcComponent';
import { cowsCalc } from '@/src/constants/calcs/form/cows-calc';
import { getBallWord, normalizeCommaToDot } from '@/src/functions/functions';

type COWSForm = {
   pulse: string,
   sweating: string,
   restless: string,
   pupil: string,
   bone: string,
   nose: string,
   gi: string,
   tremor: string,
   yawning: string,
   anxiety: string,
   skin: string,
}

const COWS = () => {
   const { control, handleSubmit, reset } = useForm<COWSForm>({});
   const [cowsResult, setCowsResult] = useState<number>();
   const [refreshing, setRefreshing] = React.useState(false);

   const save = (data: COWSForm): void => {
      const cleanedData = normalizeCommaToDot(data);
      const total = Object.values(cleanedData).reduce((a: number, b: string) => a + +b, 0);
      setCowsResult(total)
      reset()
   }

   const onRefresh = React.useCallback(() => {
      setRefreshing(true);
      setCowsResult(undefined)
      reset()
      setTimeout(() => {
         setRefreshing(false);
      }, 300);
   }, []);


   return (
      <CalcComponent<COWSForm>
         data={cowsCalc as ICalcData<COWSForm>}
         save={save}
         handleSubmit={handleSubmit}
         result={cowsResult}
         onRefresh={onRefresh}
         refreshing={refreshing}
         control={control}
         ResultComponent={cowsResult != undefined ? (
            <CalcResult
               closeFunction={() => setCowsResult(undefined)}
            >
               <CustomText><CustomBold>{cowsResult} {getBallWord(cowsResult)}</CustomBold></CustomText>
            </CalcResult>
         ) : undefined}
      />
   )
}

export default COWS
