import React, { useState } from 'react'
import { useForm } from 'react-hook-form';
import { ScrollView, View } from 'react-native';
import CalcResult from '@/src/components/Calcs/CalcResult';
import CustomText from '@/src/components/CustomTexts/CustomText';
import CustomBold from '@/src/components/CustomTexts/CustomBold';
import { nacDoseCalc } from '@/src/constants/calcs/form/nacdose-calc';
import CalcComponent, { ICalcData } from '@/src/components/Calcs/CalcComponent';
import { normalizeCommaToDot } from '@/src/functions/functions';

type NACDoseForm = {
   weight: string,
   route: string
}

const NACDose = () => {
   const { control, handleSubmit, reset } = useForm<NACDoseForm>({});
   const [nacDoseResult, setNacDoseResult] = useState<number>();
   const [isPerOs, setIsPerOs] = useState<boolean>(false)
   const [refreshing, setRefreshing] = React.useState(false);


   const save = (data: NACDoseForm): void => {
      const cleanedData = normalizeCommaToDot(data);
      setIsPerOs(cleanedData.route === '0' ? false : true)
      setNacDoseResult(+cleanedData.weight)
      reset()
   }

   const onRefresh = React.useCallback(() => {
      setRefreshing(true);
      setNacDoseResult(undefined)
      setIsPerOs(false)
      reset()
      setTimeout(() => {
         setRefreshing(false);
      }, 300);
   }, []);


   return (
      <CalcComponent<NACDoseForm>
         data={nacDoseCalc as ICalcData<NACDoseForm>}
         save={save}
         handleSubmit={handleSubmit}
         result={nacDoseResult}
         onRefresh={onRefresh}
         refreshing={refreshing}
         control={control}
         ResultComponent={nacDoseResult != undefined ? (
            <CalcResult
               closeFunction={() => setNacDoseResult(undefined)}
               heightLimiter
            >
               <ScrollView>
                  <View style={{ marginVertical: 30, paddingRight: 40 }}>
                     {!isPerOs ? (
                        <CustomText>Внутривенное введение: 21-часовой график, «дозирование 3-мя пакетами» {'\n'}{'\n'}Ударная доза: <CustomBold>{nacDoseResult * 150} мг</CustomBold> внутривенно {nacDoseResult >= 1 && nacDoseResult <= 20 ? `${nacDoseResult * 3} мл (3 мл/кг)` : nacDoseResult > 20 && nacDoseResult <= 40 ? 'в 100 мл' : 'в 200 мл'} растворителе в течение 60 минут, затем {'\n'}<CustomBold>{nacDoseResult * 50} мг</CustomBold> внутривенно {nacDoseResult >= 1 && nacDoseResult <= 20 ? `${nacDoseResult * 7} мл (7 мл/кг)` : nacDoseResult > 20 && nacDoseResult <= 40 ? 'в 250 мл' : 'в 500 мл'} растворителе в течение 4 часов, затем {'\n'}<CustomBold>{nacDoseResult * 100} мг</CustomBold> внутривенно {nacDoseResult >= 1 && nacDoseResult <= 20 ? `${nacDoseResult * 14} мл (14 мл/кг)` : nacDoseResult > 20 && nacDoseResult <= 40 ? 'в 500 мл' : 'в 1000 мл'} растворителе в течение 16 часов {'\n'}
                        </CustomText>
                     ) : (
                        <CustomText>Пероральное дозирование: 72-часовой график, всего 18 доз {'\n'}Всего <CustomBold>1330 мг/кг</CustomBold> должно быть введено: {'\n'}{'\n'}Ударная доза: <CustomBold>{nacDoseResult * 140} мг</CustomBold> перорально, затем {'\n'}Поддерживающая доза: <CustomBold>{nacDoseResult * 70} мг</CustomBold> перорально каждые 4 часа в течение 72 часов. {'\n'}{'\n'}<CustomBold>Примечание:</CustomBold> если у пациента возникла рвота в течение 1 часа после приема препарата, дозу следует повторить.
                        </CustomText>
                     )}
                  </View>
               </ScrollView>
            </CalcResult>
         ) : undefined}
      />
   )
}

export default NACDose
