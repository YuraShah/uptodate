import React, { useState } from 'react'
import { useForm } from 'react-hook-form';
import CalcResult from '@/src/components/Calcs/CalcResult';
import { wtohCalc } from '@/src/constants/calcs/form/wtoh-calc';
import CustomText from '@/src/components/CustomTexts/CustomText';
import CustomBold from '@/src/components/CustomTexts/CustomBold';
import CalcComponent, { ICalcData } from '@/src/components/Calcs/CalcComponent';
import { normalizeCommaToDot } from '@/src/functions/functions';

type IWtohForm = {
   waist: string,
   height: string,
   gend_cat: string,
}

const Wtoh = () => {
   const { control, handleSubmit, reset } = useForm<IWtohForm>({});
   const [wtohResult, setWtohResult] = useState<number>()
   const [cat, setCat] = useState('');
   const [refreshing, setRefreshing] = React.useState(false);

   const save = (data: IWtohForm): void => {
      const cleanedData = normalizeCommaToDot(data);
      const result = +cleanedData.waist / +cleanedData.height;
      const resultCuted = parseFloat(result.toFixed(2));
      setWtohResult(resultCuted);
      setCat(cleanedData.gend_cat);

      reset({
         gend_cat: '',
      });
   }

   const onRefresh = React.useCallback(() => {
      setRefreshing(true);
      setWtohResult(undefined)
      setCat('')
      setTimeout(() => {
         setRefreshing(false);
      }, 300);
   }, []);


   return (
      <CalcComponent<IWtohForm>
         data={wtohCalc as ICalcData<IWtohForm>}
         save={save}
         handleSubmit={handleSubmit}
         result={wtohResult}
         onRefresh={onRefresh}
         refreshing={refreshing}
         control={control}
         ResultComponent={wtohResult != undefined ? (
            <CalcResult
               closeFunction={() => setWtohResult(undefined)}
            >
               <CustomText>
                  <CustomBold>{parseFloat(wtohResult.toFixed(2))}</CustomBold>
               </CustomText>
               <CustomText>
                  {cat === '2' && (
                     wtohResult <= 0.34 ? (
                        "Очень худой"
                     ) : wtohResult > 0.34 && wtohResult <= 0.42 ? (
                        "Худой"
                     ) : wtohResult > 0.42 && wtohResult <= 0.52 ? (
                        "Здоровый"
                     ) : wtohResult > 0.52 && wtohResult <= 0.57 ? (
                        "Избыточный вес"
                     ) : wtohResult > 0.57 && wtohResult <= 0.62 ? (
                        "Большой избыточный вес"
                     ) : wtohResult > 0.62 && (
                        "Ожирение"
                     )
                  )}
                  {cat === '1' && (
                     wtohResult <= 0.34 ? (
                        "Очень худой"
                     ) : wtohResult > 0.34 && wtohResult <= 0.41 ? (
                        "Худой"
                     ) : wtohResult > 0.41 && wtohResult <= 0.48 ? (
                        "Здоровый"
                     ) : wtohResult > 0.48 && wtohResult <= 0.53 ? (
                        "Избыточный вес"
                     ) : wtohResult > 0.53 && wtohResult <= 0.57 ? (
                        "Большой избыточный вес"
                     ) : wtohResult > 0.57 && (
                        "Ожирение"
                     )
                  )}
                  {cat === '0' && (
                     wtohResult <= 0.34 ? (
                        "Очень худой"
                     ) : wtohResult > 0.34 && wtohResult <= 0.45 ? (
                        "Худой"
                     ) : wtohResult > 0.45 && wtohResult <= 0.51 ? (
                        "Здоровый"
                     ) : wtohResult > 0.51 && wtohResult <= 0.63 ? (
                        "Избыточный вес"
                     ) : wtohResult > 0.63 && (
                        "Ожирение"
                     )
                  )}
               </CustomText>
            </CalcResult>
         ) : undefined}
      />
   )
}

export default Wtoh
