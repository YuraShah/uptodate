import React, { useState } from 'react';
import { useForm } from 'react-hook-form';
import { ScrollView, View } from 'react-native';
import CalcResult from '@/src/components/Calcs/CalcResult';
import CustomText from '@/src/components/CustomTexts/CustomText';
import CustomBold from '@/src/components/CustomTexts/CustomBold';
import CalcComponent, { ICalcData } from '@/src/components/Calcs/CalcComponent';
import { graceCalc } from '@/src/constants/calcs/form/grace-calc';
import { getBallWord, normalizeCommaToDot } from '@/src/functions/functions';

type IGrace = {
   age: string,
   cardiacarrest: boolean,
   creatinine: string,
   heartClass: string,
   heartbeat: string
   necrosisMarker: boolean,
   stt: boolean,
   syst: string
}

const GRACE = () => {
   const { control, handleSubmit, reset } = useForm<IGrace>({});
   const [isMol, setIsMol] = useState<boolean>(true);
   const [graceResult, setGraceResult] = useState<number>();
   const [refreshing, setRefreshing] = React.useState(false);

   const save = (data: IGrace): void => {
      const cleanedData = normalizeCommaToDot(data);
      const total = graceTotal(cleanedData)
      setGraceResult(total)
      reset({
         heartClass: ''
      })
   }

   function graceTotal({ age, heartbeat, syst, creatinine, cardiacarrest, stt, necrosisMarker, heartClass }: any) {
      let ageN = +age, heartbeatN = +heartbeat, systN = +syst, creatinineN = +creatinine, ccardiacarrest = 0, cstt = 0, cnecrosisMarker = 0, cheartClass = +heartClass;
      let cage = ageN < 30 ? 0 : ageN >= 30 && ageN <= 39 ? 8 : ageN >= 40 && ageN <= 49 ? 25 : ageN >= 50 && ageN <= 59 ? 41 : ageN >= 60 && ageN <= 69 ? 58 : ageN >= 70 && ageN <= 79 ? 75 : ageN >= 80 && ageN <= 89 ? 91 : 100;
      let cheartbeat = heartbeatN < 50 ? 0 : heartbeatN >= 50 && heartbeatN <= 69 ? 3 : heartbeatN >= 70 && heartbeatN <= 89 ? 9 : heartbeatN >= 90 && heartbeatN <= 109 ? 15 : heartbeatN >= 110 && heartbeatN <= 149 ? 24 : heartbeatN >= 150 && heartbeatN <= 199 ? 38 : 46;
      let csyst = systN < 80 ? 58 : systN >= 80 && systN <= 99 ? 53 : systN >= 100 && systN <= 119 ? 43 : systN >= 120 && systN <= 139 ? 34 : systN >= 140 && systN <= 159 ? 24 : systN >= 160 && systN <= 199 ? 10 : 0;
      if (!isMol) {
         creatinineN = creatinineN * 88.4
      }
      let ccreatinine = creatinineN < 35.36 ? 1 : creatinineN >= 35.36 && creatinineN <= 70.71 ? 4 : creatinineN >= 70.72 && creatinineN <= 106.07 ? 7 : creatinineN >= 106.08 && creatinineN <= 141.43 ? 10 : creatinineN >= 141.44 && creatinineN <= 176.7 ? 13 : creatinineN >= 176.8 && creatinineN <= 353 ? 21 : 28;
      if (cardiacarrest) { ccardiacarrest = 39 };
      if (stt) { cstt = 28 };
      if (necrosisMarker) { cnecrosisMarker += 14 };
      const total = cage + cheartbeat + csyst + ccreatinine + ccardiacarrest + cstt + cnecrosisMarker + cheartClass;
      return total;
   }

   const onRefresh = React.useCallback(() => {
      setRefreshing(true);
      setIsMol(true)
      setGraceResult(undefined)
      reset({
         heartClass: ''
      })
      setTimeout(() => {
         setRefreshing(false);
      }, 300);
   }, []);


   return (
      <CalcComponent<IGrace>
         data={graceCalc as ICalcData<IGrace>}
         save={save}
         handleSubmit={handleSubmit}
         result={graceResult}
         onRefresh={onRefresh}
         refreshing={refreshing}
         control={control}
         spanVar={true}
         spanBoolean={isMol}
         spanFunction={setIsMol}
         ResultComponent={graceResult != undefined ? (
            <CalcResult
               closeFunction={() => setGraceResult(undefined)}
               heightLimiter
            >
               <ScrollView>
                  <View style={{ marginVertical: 30, paddingRight: 40, rowGap: 30 }}>
                     <CustomText><CustomBold>{graceResult} {getBallWord(graceResult)}</CustomBold></CustomText>
                     <CustomText><CustomBold>Острый коронарный синдром с подъемом сегмента ST</CustomBold> {'\n'}Внутрибольничная смертность: {graceResult < 126 ? 'меньше 2%' : graceResult >= 126 && graceResult <= 154 ? '2-5%' : 'больше 5%'}, риск летального исхода: {graceResult < 126 ? 'низкий' : graceResult >= 126 && graceResult <= 154 ? 'умеренный' : 'высокий'} {'\n'}Смертность в течение 6 месяцев: {graceResult < 100 ? 'меньше 4.5' : graceResult >= 100 && graceResult <= 127 ? '4.5-11' : 'больше 11'}%, риск летального исхода: {graceResult < 100 ? 'низкий' : graceResult >= 100 && graceResult <= 127 ? 'умеренный' : 'высокий'}</CustomText>
                     <CustomText><CustomBold>Острый коронарный синдром без подъема сегмента ST</CustomBold> {'\n'}Внутрибольничная смертность: {graceResult < 109 ? 'меньше 1%' : graceResult >= 109 && graceResult <= 140 ? '1-3%' : 'больше 3%'}%, риск летального исхода: {graceResult < 109 ? 'низкий' : graceResult >= 109 && graceResult <= 140 ? 'умеренный' : 'высокий'} {'\n'}Смертность в течение 6 месяцев: {graceResult < 89 ? 'меньше 3' : graceResult >= 89 && graceResult <= 118 ? '3-8' : 'больше 8'}%, риск летального исхода: {graceResult < 89 ? 'низкий' : graceResult >= 89 && graceResult <= 118 ? 'умеренный' : 'высокий'}</CustomText>
                  </View>
               </ScrollView>
            </CalcResult>
         ) : undefined}
      />
   )
}

export default GRACE
