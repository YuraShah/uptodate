import React, { useState } from 'react'
import { useForm } from 'react-hook-form'
import { Platform, ScrollView, Text, View } from 'react-native';
import CalcResult from '@/src/components/Calcs/CalcResult';
import CustomText from '@/src/components/CustomTexts/CustomText';
import CustomBold from '@/src/components/CustomTexts/CustomBold';
import { suncreenBody } from '@/src/functions/calc-functions';
import CalcComponent, { ICalcData } from '@/src/components/Calcs/CalcComponent';
import { sunscreenBody } from '@/src/constants/calcs/form/sunscreen-calc';
import { getPackWord, getTeaspoonWord } from '@/src/functions/functions';

type SunscreenCalcBForm = {
   weight: string,
   height: string,
   day: string,
   hour: string,
   packageFl: string
}

const SunscreenBody = () => {
   const { control, handleSubmit, reset } = useForm<SunscreenCalcBForm>({});
   const [sunscreenBCalc, setSunscreenBCalc] = useState<number>();
   const [sunscreenBCalcSp, setSunscreenBCalcSp] = useState<number>(0);
   const [sunscreenBPack, setSunscreenBPack] = useState<number>(0);
   const [refreshing, setRefreshing] = React.useState(false);

   const save = (data: SunscreenCalcBForm): void => {
      const { sunscrQuant, sunscrQuantSp, sunscrPack } = suncreenBody(+data.weight, +data.height, +data.day, +data.hour, +data.packageFl)
      setSunscreenBCalc(sunscrQuant)
      setSunscreenBCalcSp(sunscrQuantSp)
      setSunscreenBPack(sunscrPack)
   }

   const onRefresh = React.useCallback(() => {
      setRefreshing(true);
      setSunscreenBCalc(undefined)
      setSunscreenBCalcSp(0)
      setSunscreenBPack(0)
      reset({
         packageFl: ''
      })
      setTimeout(() => {
         setRefreshing(false);
      }, 300);
   }, []);


   return (
      <CalcComponent<SunscreenCalcBForm>
         data={sunscreenBody as ICalcData<SunscreenCalcBForm>}
         save={save}
         handleSubmit={handleSubmit}
         result={sunscreenBCalc}
         onRefresh={onRefresh}
         refreshing={refreshing}
         control={control}
         ResultComponent={sunscreenBCalc != undefined ? (
            <CalcResult
               closeFunction={() => setSunscreenBCalc(undefined)}
               heightLimiter
            >
               <ScrollView>
                  <View style={{ marginVertical: 30, paddingRight: 40, rowGap: 20 }}>
                     <CustomText>Вы будете использовать {sunscreenBPack.toFixed(2)} {getPackWord(sunscreenBPack)} солнцезащитного крема, возмите с собой <CustomBold>{Math.ceil(sunscreenBPack)} {getPackWord(sunscreenBPack)}.</CustomBold></CustomText>
                     <View style={{ rowGap: 3 }}>
                        <CustomText>Для одного использования вам понадобится <CustomBold>{sunscreenBCalc} мл ({sunscreenBCalcSp.toFixed(1)} {getTeaspoonWord(sunscreenBCalcSp)}) солнцезащитного крема,</CustomBold> включая:</CustomText>
                        <CustomText><Text style={{ fontSize: Platform.OS === 'ios' ? 7 : 12 }}>{"\u2B24" + " "}</Text><CustomBold>{(9 * sunscreenBCalc / 100).toFixed(1)} мл ({(9 * sunscreenBCalcSp / 100).toFixed(1)} {getTeaspoonWord(9 * sunscreenBCalcSp / 100)})</CustomBold> для каждой руки</CustomText>
                        <CustomText><Text style={{ fontSize: Platform.OS === 'ios' ? 7 : 12 }}>{"\u2B24" + " "}</Text><CustomBold>{(18 * sunscreenBCalc / 100).toFixed(1)} мл ({(18 * sunscreenBCalcSp / 100).toFixed(1)} {getTeaspoonWord(18 * sunscreenBCalcSp / 100)})</CustomBold> для каждой ноги</CustomText>
                        <CustomText><Text style={{ fontSize: Platform.OS === 'ios' ? 7 : 12 }}>{"\u2B24" + " "}</Text><CustomBold>{(36 * sunscreenBCalc / 100).toFixed(1)} мл ({(36 * sunscreenBCalcSp / 100).toFixed(1)} {getTeaspoonWord(36 * sunscreenBCalcSp / 100)})</CustomBold> для туловища</CustomText>
                     </View>
                     <CustomText><CustomBold>Важно:</CustomBold> повторно наносите солнцезащитный крем после купания, сильного потоотделения или каждые 2 часа. Только частое нанесение в необходимом количестве (2 мг/см² кожи) гарантирует защиту от солнца.</CustomText>
                  </View>
               </ScrollView>
            </CalcResult>
         ) : undefined}
      />
   )
}

export default SunscreenBody
