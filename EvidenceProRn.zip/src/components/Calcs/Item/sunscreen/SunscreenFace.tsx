import React, { useState } from 'react'
import { useForm } from 'react-hook-form';
import { ScrollView, View } from 'react-native';
import CalcResult from '@/src/components/Calcs/CalcResult';
import CustomText from '@/src/components/CustomTexts/CustomText';
import CustomBold from '@/src/components/CustomTexts/CustomBold';
import { suncreenFace } from '@/src/functions/calc-functions';
import { sunscreenFace } from '@/src/constants/calcs/form/sunscreen-calc';
import CalcComponent, { ICalcData } from '@/src/components/Calcs/CalcComponent';
import { getPackWord, getTeaspoonWord } from '@/src/functions/functions';

type SunscreenCalcFForm = {
   flength: string,
   fwidth: string,
   day: string,
   hour: string,
   packageFl: string
}

const SunscreenFace = () => {
   const { control, handleSubmit, reset } = useForm<SunscreenCalcFForm>({});
   const [sunscreenFCalc, setSunscreenFCalc] = useState<number>();
   const [sunscreenFCalcSp, setSunscreenFCalcSp] = useState<number>(0);
   const [sunscreenFPack, setSunscreenFPack] = useState<number>(0);
   const [refreshing, setRefreshing] = React.useState(false);

   const save = (data: SunscreenCalcFForm): void => {
      const { sunscrQuant, sunscrQuantSp, sunscrPack } = suncreenFace(+data.flength, +data.fwidth, +data.day, +data.hour, +data.packageFl)
      setSunscreenFCalc(sunscrQuant)
      setSunscreenFCalcSp(sunscrQuantSp)
      setSunscreenFPack(sunscrPack)
   }

   const onRefresh = React.useCallback(() => {
      setRefreshing(true);
      setSunscreenFCalc(undefined)
      setSunscreenFCalcSp(0)
      setSunscreenFPack(0)
      reset({
         packageFl: ''
      })
      setTimeout(() => {
         setRefreshing(false);
      }, 300);
   }, []);


   return (
      <CalcComponent<SunscreenCalcFForm>
         data={sunscreenFace as ICalcData<SunscreenCalcFForm>}
         save={save}
         handleSubmit={handleSubmit}
         result={sunscreenFCalc}
         onRefresh={onRefresh}
         refreshing={refreshing}
         control={control}
         ResultComponent={sunscreenFCalc != undefined ? (
            <CalcResult
               closeFunction={() => setSunscreenFCalc(undefined)}
               heightLimiter
            >
               <ScrollView>
                  <View style={{ marginVertical: 30, paddingRight: 40, rowGap: 20 }}>
                     <CustomText>Вы будете использовать {sunscreenFPack.toFixed(4)} {getPackWord(sunscreenFPack)} солнцезащитного крема, возмите с собой <CustomBold>{Math.ceil(sunscreenFPack)} {getPackWord(sunscreenFPack)}.</CustomBold></CustomText>
                     <CustomText>Для одного применения на лице вам понадобится <CustomBold>{sunscreenFCalc.toFixed(2)} мл ({sunscreenFCalcSp.toFixed(2)} {getTeaspoonWord(sunscreenFCalcSp)}) солнцезащитного крема.</CustomBold></CustomText>
                     <CustomText><CustomBold>Важно:</CustomBold> повторно наносите солнцезащитный крем после купания, сильного потоотделения или каждые 2 часа. Только частое нанесение в необходимом количестве (2 мг/см² кожи) гарантирует защиту от солнца.</CustomText>
                  </View>
               </ScrollView>
            </CalcResult>
         ) : undefined}
      />
   )
}

export default SunscreenFace
