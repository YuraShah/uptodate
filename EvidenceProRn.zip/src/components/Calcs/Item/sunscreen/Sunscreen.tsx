import React from 'react'
import { SafeAreaView, ScrollView, View } from 'react-native'
import TitleShare from '@/src/components/TitleShare'
import { useTheme } from '@/src/hooks/useTheme'
import { useNavigation } from '@react-navigation/native'
import { NativeStackNavigationProp } from '@react-navigation/native-stack'
import { MainStackParamList } from '@/src/types/navigationTypes'
import MenuList from '@/src/components/MenuList'
import Separator from '@/src/components/Separator'

const Sunscreen = () => {
   const navigation = useNavigation<NativeStackNavigationProp<MainStackParamList>>()
   const { colors } = useTheme()

   return (
      <SafeAreaView style={{ flex: 1, backgroundColor: colors.background }}>
         <ScrollView
            contentContainerStyle={{ paddingVertical: 15 }}
         >
            <View style={{ paddingHorizontal: 15 }}>
               <TitleShare
                  titleText={'Калькулятор количества солнцезащитного крема (SPF)'}
               />
            </View>
            <View style={{ rowGap: 2, marginTop: 15 }}>
               <View>
                  <MenuList
                     title='Тело'
                     onPress={() => navigation.push('CalcsItem', { param: 'sunscreen/body' })}
                  />
               </View>
               <Separator />
               <View>
                  <MenuList
                     title='Лицо'
                     onPress={() => navigation.push('CalcsItem', { param: 'sunscreen/face' })}
                  />
               </View>
            </View>
         </ScrollView>
      </SafeAreaView>
   )
}

export default Sunscreen
