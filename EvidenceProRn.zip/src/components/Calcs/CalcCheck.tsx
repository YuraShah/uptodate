import React from 'react'
import { FieldValues, Path, Control, Controller } from 'react-hook-form'
import { StyleSheet, TouchableOpacity, View } from 'react-native'
import Checkbox from 'expo-checkbox';
import CustomText from '@/src/components/CustomTexts/CustomText';
import { useTheme } from '@/src/hooks/useTheme';

interface ICalcCheck<T extends FieldValues> {
   control: Control<T>,
   inputId: Path<T>,
   labelTitle: string,
   onChange?: (value: boolean) => void
}

const CalcCheck = <T extends FieldValues>({
   control,
   inputId,
   labelTitle,
   onChange
}: ICalcCheck<T>) => {
   const { colors } = useTheme()

   return (
      <View style={styles.formRow}>
         <Controller
            control={control}
            render={({ field: { onChange: fieldOnChange, onBlur, value } }) => (
               <TouchableOpacity
                  onPress={() => {
                     const newValue = !value;
                     fieldOnChange(newValue);
                     if (onChange) {
                        onChange(newValue);
                     }
                  }}
                  style={styles.formTouch}
                  accessibilityLabel={`Press Check ${inputId}`}
               >
                  <Checkbox
                     color={colors.checkboxColor}
                     value={value}
                     onValueChange={fieldOnChange}
                  />
                  <CustomText style={styles.formRowText}>
                     {labelTitle}
                  </CustomText>
               </TouchableOpacity>
            )}
            name={inputId}
         />
      </View>
   )
}

const styles = StyleSheet.create({
   formRow: {
      marginVertical: 5,
   },
   formTouch: {
      flexDirection: 'row',
      alignItems: 'center',
      gap: 10
   },
   formRowText: {
      flex: 1
   },
})

export default CalcCheck
