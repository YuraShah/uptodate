import { faX } from '@fortawesome/free-solid-svg-icons'
import { FontAwesomeIcon } from '@fortawesome/react-native-fontawesome'
import React, { ReactNode } from 'react'
import { StyleSheet, TouchableOpacity, View } from 'react-native'
import { useUpdateOrientation } from '@/src/hooks/useUpdateOrientation'
import { useTheme } from '@/src/hooks/useTheme'

interface ICalcResult {
   children: ReactNode,
   closeFunction: () => void,
   heightLimiter?: boolean
}

const CalcResult = ({ children, closeFunction, heightLimiter }: ICalcResult) => {
   const resultHeight = useUpdateOrientation();
   const { colors } = useTheme()

   return (
      <View style={[
         styles.resultBox,
         { backgroundColor: colors.calcResultBg, rowGap: 10 },
         heightLimiter && {
            height: resultHeight ? 500 : 270,
            paddingVertical: 0,
            paddingEnd: 0
         }
      ]}>
         {heightLimiter ? (
            children
         ) : (
            <View style={{ paddingRight: 5, rowGap: 7 }}>
               {children}
            </View>
         )}
         <TouchableOpacity
            onPress={closeFunction}
            style={styles.resultIcon}
            accessibilityLabel='Press Res'
         >
            <FontAwesomeIcon
               icon={faX}
               size={20}
               color={colors.calcResultIcon}
            />
         </TouchableOpacity>
      </View>
   )
}

const styles = StyleSheet.create({
   resultBox: {
      paddingVertical: 30,
      paddingStart: 20,
      paddingEnd: 20,
      position: 'absolute',
      bottom: -1,
      left: 0,
      width: '100%',
      zIndex: 100,
      minHeight: 150
   },
   resultIcon: {
      position: 'absolute',
      top: 10,
      right: 8,
      marginLeft: 7,
      width: 48,
      height: 48,
      alignItems: 'flex-end',
      paddingRight: 5,
      paddingTop: 2,
      zIndex: 101
   },
})

export default CalcResult
