import React, { useEffect, useState } from 'react'
import { faArrowUpFromBracket, faStar as faStarSolid } from '@fortawesome/free-solid-svg-icons'
import { FontAwesomeIcon } from '@fortawesome/react-native-fontawesome'
import { StyleSheet, TouchableOpacity, View, useWindowDimensions } from 'react-native'
import CustomTextLargeBold from '@/src/components/CustomTexts/CustomTextLargeBold'
import { useAppDispatch, useAppSelector } from '@/src/redux/hooks'
import { faStar } from '@fortawesome/free-regular-svg-icons'
import { IResponseData } from '@/src/types/types'
import useShareLink from '@/src/hooks/useShareLink'
import { useTheme } from '@/src/hooks/useTheme'
import { Toast } from 'toastify-react-native';
import { addUserFavorites, deleteUserFavorites, getUserCalcs } from '@/src/redux/features/user/userAPI'


interface ITitleShare {
   titleText: string,
   calcId: string,
   link: string,
   lock: boolean
}

const CalcTitleShare = ({
   titleText,
   calcId,
   link,
   lock
}: ITitleShare) => {
   const [isStar, setIsStar] = useState(false)
   const { width } = useWindowDimensions();
   const { userCalcsData } = useAppSelector(state => state.userStore)
   const { user } = useAppSelector(state => state.authStore)
   const dispatch = useAppDispatch()
   const shareLink = useShareLink()
   const { colors } = useTheme()

   useEffect(() => {
      if (lock) return;

      setIsStar(userCalcsData!.includes(calcId));
   }, [userCalcsData, calcId, lock]);

   const toggleCalc = async () => {
      if (lock) {
         Toast.info("Нужна подписка для добавления в избранное", "top")
         return;
      }

      if (!isStar && userCalcsData!.length >= 20) {
         Toast.warn("Максимальное количество моих калькуляторов: 20", "top")
         return;
      }

      const action = isStar ? deleteUserFavorites : addUserFavorites;
      const request = isStar ? calcId : {
         uid: user!.id,
         category: 'calc',
         favorites_id: calcId,
         title: titleText,
         link: link
      }
      await dispatch(action(JSON.stringify(request)));

      const response = await dispatch(getUserCalcs());
      if (response?.meta?.requestStatus === 'fulfilled' && response.payload) {
         const payload = response.payload as IResponseData<string>;
         setIsStar(payload.data.includes(calcId));
         Toast.success(isStar ? 'Удалён из избранного' : 'Добавлен в избранное', "top")
      }
   };

   return (
      <View style={styles.titleShareContainer}>
         <CustomTextLargeBold
            style={[
               styles.title,
               {
                  color: colors.title,
               },
            ]}
         >
            {titleText}
         </CustomTextLargeBold>
         {shareLink && (
            <View style={[
               styles.linksContainer, {
                  paddingRight: width >= 650 ? 17 : 3,
                  columnGap: width >= 650 ? 5 : 3,
               }
            ]}>
               <TouchableOpacity
                  style={styles.starLinkTouch}
                  onPress={toggleCalc}
                  accessibilityLabel={isStar ? 'Delete Star' : 'Add Star'}
               >
                  <FontAwesomeIcon
                     icon={isStar ? faStarSolid : faStar}
                     size={25}
                     color={colors.othTitle}
                  />
               </TouchableOpacity>
               <TouchableOpacity
                  onPress={() => shareLink()}
                  accessibilityLabel='Press Share'
                  style={styles.shareLinkTouch}
               >
                  <FontAwesomeIcon
                     icon={faArrowUpFromBracket}
                     size={18}
                     color={colors.title}
                  />
               </TouchableOpacity>
            </View>
         )}
      </View>
   )
}

const styles = StyleSheet.create({
   titleShareContainer: {
      flexDirection: 'row',
      columnGap: 7,
   },
   title: {
      flex: 1
   },
   linksContainer: {
      flexDirection: 'row',
   },
   starLinkTouch: {
      flexDirection: 'row',
      padding: 5,
   },
   shareLinkTouch: {
      flexDirection: 'row',
      paddingHorizontal: 5,
      paddingBottom: 5,
      paddingTop: 9
   }
})

export default CalcTitleShare