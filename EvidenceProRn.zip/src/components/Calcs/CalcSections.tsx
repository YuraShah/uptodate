import { useTheme } from '@/src/hooks/useTheme';
import React, { useState } from 'react'
import { ScrollView, StyleSheet, useWindowDimensions, View } from 'react-native';
import { TabView, TabBar } from 'react-native-tab-view';
import CustomTextNoFontBold from '@/src/components/CustomTexts/CustomTextNoFontBold';

interface ICalcSections {
   calc: React.ReactNode,
   what?: React.ReactNode,
   calcRef?: React.ReactNode,
}

function CalcRoute({
   calc,
   colors
}: {
   calc: React.ReactNode,
   colors: Record<string, string>
}) {
   return (
      <View style={{
         flex: 1,
         backgroundColor: colors.background
      }}>
         {calc}
      </View>
   )
};

function WhatRoute({
   what,
   colors
}: {
   what: React.ReactNode,
   colors: Record<string, string>
}) {
   return (
      <ScrollView style={{ backgroundColor: colors.background }}>
         <View style={{
            marginBottom: 70,
            rowGap: 20,
            padding: 15
         }}>
            {what}
         </View>
      </ScrollView>
   )
};

function RefRoute({
   calcRef,
   colors
}: {
   calcRef: React.ReactNode,
   colors: Record<string, string>
}) {
   return (
      <ScrollView style={{ backgroundColor: colors.background }}>
         <View style={{
            padding: 15,
         }}>
            {calcRef}
         </View>
      </ScrollView>
   )
}

const routes = [
   { key: 'calc', title: 'Калькулятор' },
   { key: 'what', title: 'Инфо' },
   { key: 'ref', title: 'Ссылки' },
];

const CalcSections = ({
   calc,
   what,
   calcRef
}: ICalcSections) => {
   const { colors } = useTheme();
   const layout = useWindowDimensions();
   const [index, setIndex] = useState(0);

   const renderScene = ({ route }: any) => {
      switch (route.key) {
         case 'calc':
            return <CalcRoute calc={calc} colors={colors} />;
         case 'what':
            return <WhatRoute what={what} colors={colors} />;
         case 'ref':
            return <RefRoute calcRef={calcRef} colors={colors} />;
         default:
            return null;
      }
   };

   return (
      <TabView
         navigationState={{ index, routes }}
         renderScene={renderScene}
         onIndexChange={setIndex}
         initialLayout={{ width: layout.width }}
         commonOptions={{
            label: ({ labelText }) => (
               <CustomTextNoFontBold
                  style={{
                     fontSize: 15,
                     color: colors.title,
                  }}
               >
                  {labelText}
               </CustomTextNoFontBold>
            )
         }}
         renderTabBar={props => (
            <TabBar
               {...props}
               indicatorStyle={{ backgroundColor: colors.topTabsIndicator }}
               style={{ backgroundColor: colors.topTabsBg, height: 35 }}
               tabStyle={{
                  paddingTop: 2,
                  justifyContent: 'flex-start',
               }}
            />
         )}
      />
   )
}


const styles = StyleSheet.create({
   chooseBox: {
      lineHeight: 28,
      flexDirection: 'row',
      justifyContent: 'space-between',
      columnGap: 5,
      padding: 2,
      marginHorizontal: 5,
      borderRadius: 4,
   },
   chooseTouch: {
      flexGrow: 1,
      alignItems: 'center',
      minHeight: 30,
      borderRadius: 4,
      // flexBasis: '34%'
   },
})

export default CalcSections
