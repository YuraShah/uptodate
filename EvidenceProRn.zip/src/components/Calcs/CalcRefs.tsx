import React from 'react'
import { StyleSheet, View } from 'react-native'
import CustomTextBold from '@/src/components/CustomTexts/CustomTextBold'
import CustomRefText from '@/src/components/CustomTexts/CustomRefText'

interface ICalcRefs {
   refs: string[],
   isRefTitle?: boolean
}

const CalcRefs = ({
   refs,
   isRefTitle
}: ICalcRefs) => {
   return (
      <View style={styles.referencesBox}>
         {isRefTitle ? (
            <CustomTextBold style={[styles.referencesTitle]}>Ссылки</CustomTextBold>
         ) : null}
         {refs.map((ref, index) => (
            <CustomRefText
               style={[styles.referencesList]}
               key={index}
            >
               {index + 1}. {ref}
            </CustomRefText>
         ))}
      </View >
   )
}

const styles = StyleSheet.create({
   referencesBox: {
      marginBottom: 40,
   },
   referencesTitle: {
      marginBottom: 3
   },
   referencesList: {
      marginVertical: 3,
   },
})

export default CalcRefs
