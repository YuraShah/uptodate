import { faArrowRightArrowLeft } from '@fortawesome/free-solid-svg-icons'
import React from 'react'
import { Controller, FieldValues, Path, Control } from 'react-hook-form'
import { Text, View, StyleSheet, TouchableOpacity } from 'react-native'
import CustomText from '@/src/components/CustomTexts/CustomText'
import CustomInput from '@/src/components/CustomTexts/CustomInput'
import { useTheme } from '@/src/hooks/useTheme'
import CustomBold from '@/src/components/CustomTexts/CustomBold'
import CustomIconSmall from '@/src/components/CustomIcons/CustomIconSmall'

interface ICalcInput<T extends FieldValues> {
   control: Control<T>,
   labelTitle: string,
   inputId: Path<T>,
   inputPlaceholder: string,
   inputSpan: string,
   errorText: string,
   required: boolean,
   min?: number,
   max?: number,
   pattern?: RegExp,
   spanVar?: boolean,
   spanBoolean?: boolean,
   spanFunction?: Function,
   spanWidth?: number,
   link?: boolean
}

const CalcInput = <T extends FieldValues>({
   control,
   labelTitle,
   inputId,
   inputPlaceholder,
   errorText,
   inputSpan,
   min,
   max,
   required,
   pattern,
   spanVar,
   spanBoolean,
   spanFunction,
   spanWidth = 50
}: ICalcInput<T>) => {
   const { colors } = useTheme()

   return (
      <View style={styles.formRow}>
         <CustomText style={styles.formRowText}>
            <CustomBold>{labelTitle}</CustomBold> {inputId === 'measser' && <Text style={{ fontSize: 16 }}>(необязательное поле)</Text>}
         </CustomText>
         <Controller
            control={control}
            rules={{
               required: required,
               ...(pattern && { pattern }),
               ...(min && { min: min }),
               ...(max && { max: max }),
            }}
            render={({ field: { onChange, onBlur, value }, fieldState: { error } }) => (
               <>
                  {error && (
                     <CustomText style={[
                        styles.errorText,
                        { color: colors.formError }]}
                     >
                        {errorText}
                     </CustomText>
                  )}
                  <View style={styles.inputSpan}>
                     <CustomInput
                        onBlur={onBlur}
                        onChangeText={onChange}
                        value={value}
                        style={[styles.input, {
                           backgroundColor: colors.inputBackground
                        }]}
                        keyboardType='numeric'
                        accessibilityLabel={`Input for ${labelTitle}`}
                        placeholder={inputPlaceholder}
                     />
                     {!spanVar ? (
                        <View style={[styles.span, { width: spanWidth, backgroundColor: colors.calcBtnBg }]}>
                           <CustomText>
                              {inputSpan}
                           </CustomText>
                        </View>
                     ) : spanFunction && (
                        <TouchableOpacity
                           style={[styles.span, styles.spanTouch, { minWidth: spanWidth + 60, backgroundColor: colors.calcBtnBg }]}
                           onPress={() => spanFunction(!spanBoolean)}
                           accessibilityLabel={`Press ${inputSpan}`}
                        >
                           <CustomText>
                              {inputSpan}
                           </CustomText>
                           <CustomIconSmall
                              icon={faArrowRightArrowLeft}
                              color={colors.primary}
                           />
                        </TouchableOpacity>
                     )}
                  </View>
               </>
            )}
            name={inputId}
         />
      </View>
   )
}

const styles = StyleSheet.create({
   formRow: {
      marginVertical: 10
   },
   formRowText: {
      marginBottom: 7,
   },
   errorText: {
      marginBottom: 7,
   },
   inputSpan: {
      flex: 1,
      flexDirection: 'row',
   },
   input: {
      paddingHorizontal: 20,
      borderTopRightRadius: 0,
      borderBottomRightRadius: 0,
      borderTopLeftRadius: 2,
      borderBottomLeftRadius: 2,
      flex: 1,
      height: 48,
   },
   span: {
      flexDirection: 'row',
      alignItems: 'center',
      justifyContent: 'center',
      borderTopRightRadius: 2,
      borderBottomRightRadius: 2,
      paddingHorizontal: 10
   },
   spanTouch: {
      paddingVertical: 2,
      columnGap: 3
   },
})

export default CalcInput