import React from 'react'
import { FieldValues, Path, Control, Controller } from 'react-hook-form'
import { StyleSheet, View } from 'react-native'
import SelectPicker from '@/src/components/SelectPicker';
import CustomText from '@/src/components/CustomTexts/CustomText';
import { useTheme } from '@/src/hooks/useTheme';
import CustomBold from '@/src/components/CustomTexts/CustomBold';

interface ICalcSelect<T extends FieldValues> {
   control: Control<T>,
   labelTitle: string,
   inputId: Path<T>,
   required: boolean,
   items: any[]
}

const CalcSelect = <T extends FieldValues>({
   control,
   labelTitle,
   inputId,
   required,
   items
}: ICalcSelect<T>) => {
   const { colors } = useTheme()

   return (
      <View style={styles.formRow}>
         <CustomText style={styles.formRowText}>
            <CustomBold>{labelTitle}</CustomBold>
         </CustomText>
         <Controller
            control={control}
            rules={{
               required: required,
            }}
            render={({ field: { onChange, value }, fieldState: { error } }) => (
               <>
                  {error && (
                     <CustomText style={[styles.errorText, { color: colors.formError }]}>
                        Выберите один из вариантов
                     </CustomText>
                  )}
                  <SelectPicker
                     onChange={onChange}
                     items={items}
                     value={value}
                  />
               </>
            )}
            name={inputId}
         />
      </View>
   )
}

const styles = StyleSheet.create({
   formRow: {
      marginVertical: 10
   },
   formRowText: {
      marginBottom: 7,
   },
   errorText: {
      marginBottom: 7,
   },
})

export default CalcSelect
