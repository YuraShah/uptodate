import React from 'react'
import ToastManager from 'toastify-react-native'
import { useTheme } from '@/src/hooks/useTheme'
import { useAppSelector } from '@/src/redux/hooks'

const Toast = () => {
   const { colors } = useTheme()
   const { isDarkMode } = useAppSelector(state => state.themeStore)

   return (
      <ToastManager
         width={300}
         height={150}
         backgroundColor={isDarkMode ? colors.background : 'inherit'}
         style={{
            paddingVertical: 15,
            paddingLeft: 10,
            paddingRight: 30,
            marginBottom: 70,
         }}
         textStyle={{
            fontSize: 16,
            flexWrap: 'wrap',
            lineHeight: 24,
            flex: 1,
            fontFamily: "Roboto-Regular"
         }}
      />
   )
}

export default Toast
