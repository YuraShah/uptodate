import React from 'react'
import { Platform, View } from 'react-native'
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import * as ScreenOrientation from 'expo-screen-orientation';
import { useTheme } from '@/src/hooks/useTheme';

export default function CustomStatusBar() {
   const insets = useSafeAreaInsets();
   const [orientation, setOrientation] = React.useState<number>()
   const { colors } = useTheme()

   React.useEffect(() => {
      if (Platform.OS !== 'android') return;

      const updateOrientation = async () => {
         const scrOrientation = await ScreenOrientation.getOrientationAsync();
         setOrientation(scrOrientation)
      }
      updateOrientation();

      const subscription = ScreenOrientation.addOrientationChangeListener(updateOrientation);
      return () => {
         ScreenOrientation.removeOrientationChangeListener(subscription);
      };
   }, [])

   return (
      <View
         style={{
            backgroundColor: colors.mainBg,
            paddingTop: Platform.OS === 'android' && orientation === ScreenOrientation.Orientation.PORTRAIT_UP ? insets.top : 0,
            display: Platform.OS === 'android' ? 'flex' : 'none'
         }}
      />
   )
}
