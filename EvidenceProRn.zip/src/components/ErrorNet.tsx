import React from 'react'
import { StyleSheet } from 'react-native'
import CustomText from '@/src/components/CustomTexts/CustomText'

const ErrorNet = () => {
   return (
      <CustomText style={[styles.errorText]}>Проблема с подключением. Попробуйте обновить страницу.</CustomText>
   )
}

const styles = StyleSheet.create({
   errorText: {
      marginVertical: 15
   },
})

export default ErrorNet
