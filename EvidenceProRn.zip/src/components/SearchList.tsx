import React, { useMemo, useState } from 'react'
import { IDrugLabel, IOtherList, IResponseData } from '@/src/types/types'
import { SafeAreaView, useWindowDimensions, View, RefreshControl } from 'react-native'
import { useTheme } from '@/src/hooks/useTheme'
import { QueryObserverResult, RefetchOptions } from '@tanstack/react-query'
import { FlashList } from '@shopify/flash-list'
import TitleShare from '@/src/components/TitleShare'
import SelectAsyncComponent from '@/src/components/SelectComponent/SelectAsyncComponent'
import ErrorNet from '@/src/components/ErrorNet'
import MenuList from '@/src/components/MenuList'
import Separator from '@/src/components/Separator'
import CustomText from '@/src/components/CustomTexts/CustomText'
import { useNavigation } from '@react-navigation/native'
import { MainStackParamList } from '@/src/types/navigationTypes'
import Loader from '@/src/components/Loader/Loader'


interface ISearchList {
   data: IResponseData<IDrugLabel | IOtherList> | undefined,
   refetch: (options?: RefetchOptions) => Promise<QueryObserverResult<IResponseData<IDrugLabel | IOtherList>, Error>>,
   isLoading: boolean,
   isError: boolean,
   isSuccess: boolean,
   screen: keyof MainStackParamList,
   title: string,
   placeholder: string,
   estimatedItemSize?: number
}

export default function SearchList({
   data,
   refetch,
   isLoading,
   isError,
   isSuccess,
   screen,
   title,
   placeholder,
   estimatedItemSize = 48
}: ISearchList) {
   const { colors } = useTheme()
   const { width } = useWindowDimensions()
   const [inpValue, setInpValue] = useState<string>('')
   const navigation = useNavigation()

   const filteredData = useMemo(() => {
      const list = data?.data ?? []
      if (!inpValue.trim()) return list

      return list.filter(item => {
         const value = 'label' in item ? item.label : item.name
         return value.toLowerCase().includes(inpValue.trim().toLowerCase())
      })
   }, [inpValue, data])


   const onRefresh = React.useCallback(() => {
      setInpValue('')
      refetch()
   }, [])


   if (isLoading) return <Loader />

   return (
      <SafeAreaView style={{ flex: 1, backgroundColor: colors.background }}>
         <FlashList
            refreshControl={
               <RefreshControl
                  refreshing={isLoading}
                  onRefresh={onRefresh}
                  colors={[colors.mainBg]}
                  progressBackgroundColor={colors.refreshProgressBarBg}
               />
            }
            contentContainerStyle={{ paddingVertical: 15 }}
            ListHeaderComponent={
               <View style={{ paddingHorizontal: 15 }}>
                  <TitleShare
                     titleText={title}
                  />
                  <SelectAsyncComponent
                     inpValue={inpValue}
                     setInpValue={setInpValue}
                     windowWidth={width}
                     placeholder={placeholder}
                  />
                  {isError ? <ErrorNet /> : null}
               </View>
            }
            data={filteredData}
            renderItem={({ item }) => (
               <MenuList
                  onPress={() => 'label' in item ? (
                     navigation.navigate('Home', { screen: screen as any, params: { param: `${item.link}:${item.id}` } })
                  ) : (
                     navigation.navigate('Home', { screen: screen as any, params: { param: item.id.toString() } })
                  )}
                  title={'label' in item ? item.label : item.name}
               />
            )}
            ItemSeparatorComponent={() => <Separator />}
            estimatedItemSize={estimatedItemSize}
            ListEmptyComponent={isSuccess ? <CustomText style={{ paddingHorizontal: 15 }}>Не найдено</CustomText> : null}
         />
      </SafeAreaView>
   )
}
