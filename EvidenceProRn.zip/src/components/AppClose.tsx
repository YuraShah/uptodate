import React from 'react'
import { useTheme } from '@/src/hooks/useTheme'
import CustomTextNoFont from '@/src/components/CustomTexts/CustomTextNoFont'
import { TouchableOpacity, View, Linking } from 'react-native'
import * as SplashScreen from 'expo-splash-screen';

interface IAppClose {
   isAppCloseLink: string
}

const AppClose = ({
   isAppCloseLink
}: IAppClose) => {
   SplashScreen.hideAsync();
   const { colors } = useTheme()

   return (
      <View
         style={{
            flex: 1,
            alignItems: 'center',
            justifyContent: 'center',
            backgroundColor: colors.background
         }}
      >
         <CustomTextNoFont style={{ fontSize: 20 }}>
            Для дальнейшего использования приложение необходимо обновить.
         </CustomTextNoFont>
         <TouchableOpacity
            onPress={() => Linking.openURL(isAppCloseLink)}
            style={{
               backgroundColor: colors.mainBg,
               marginVertical: 20,
               width: 150,
               padding: 10,
               borderRadius: 5
            }}
            accessibilityLabel='Press Ref'
         >
            <CustomTextNoFont
               style={{
                  fontSize: 20,
                  textAlign: 'center',
                  color: colors.mainBgText
               }}
            >
               Ссылка
            </CustomTextNoFont>
         </TouchableOpacity>
      </View>
   )
}

export default AppClose
