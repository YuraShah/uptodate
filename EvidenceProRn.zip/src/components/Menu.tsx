import React from 'react'
import Separator from '@/src/components/Separator'
import MenuList from '@/src/components/MenuList'
import { IMenuList } from '@/src/types/types'
import { FlatList, SafeAreaView } from 'react-native'
import { useTheme } from '@/src/hooks/useTheme'
import { useNavigation } from '@react-navigation/native'
import { NativeStackNavigationProp } from '@react-navigation/native-stack'
import { MainStackParamList } from '@/src/types/navigationTypes'
import CustomTitle from '@/src/components/CustomTexts/CustomTitle'
import { Toast } from 'toastify-react-native'
import { useAppSelector } from '@/src/redux/hooks'

type MenuProps = {
   data: IMenuList[],
   headerTitle?: string,
}

export default function Menu({
   data,
   headerTitle,
}: MenuProps) {
   const { colors } = useTheme()
   const navigation = useNavigation<NativeStackNavigationProp<MainStackParamList>>()
   const { user } = useAppSelector(state => state.authStore)
   const { paymentData } = useAppSelector(state => state.paymentStore);

   return (
      <SafeAreaView style={{ flex: 1, backgroundColor: colors.background }}>
         <FlatList
            contentContainerStyle={{ paddingVertical: 15 }}
            data={data}
            ListHeaderComponent={headerTitle ? (
               <CustomTitle style={{ paddingHorizontal: 15, marginBottom: 10 }}>
                  {headerTitle}
               </CustomTitle>
            ) : null}
            renderItem={({ item, index }) => (
               <MenuList
                  onPress={() => {
                     if (item.lock && !user) {
                        Toast.info('Зарегистрируйтесь для подписки', 'top');
                        navigation.navigate('SignIn');
                     } else if (
                        item.lock &&
                        user &&
                        (paymentData.length === 0 || paymentData[0] !== 1)
                     ) {
                        Toast.info('Оплатите подписку для доступа', 'top');
                        navigation.navigate('Payment');
                     } else if (item.param) {
                        navigation.navigate(item.link as any, { param: item.param });
                     } else {
                        navigation.navigate(item.link as any);
                     }
                  }}
                  title={item.name}
                  icon={item.icon}
                  lock={item.lock && (!user || (user && (paymentData.length === 0 || (paymentData.length > 0 && paymentData[0] !== 1)))) ? true : undefined}
                  isLastMargin={data.length - 1 === index ? true : false}
               />
            )}
            ItemSeparatorComponent={() => <Separator />}
            keyExtractor={item => item.name}
         />
      </SafeAreaView>
   )
}
