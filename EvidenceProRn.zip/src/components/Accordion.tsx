import { useTheme } from '@/src/hooks/useTheme'
import React, { ReactNode, useState } from 'react'
import { TouchableOpacity, View } from 'react-native'
import CustomIcon from '@/src/components/CustomIcons/CustomIcon'
import { faAngleRight } from '@fortawesome/free-solid-svg-icons'

interface IAccordion {
   header: ReactNode;
   content: ReactNode;
}

const Accordion = ({
   header,
   content,
}: IAccordion) => {
   const { colors } = useTheme();
   const [isAccordionOpen, setIsAccordionOpen] = useState(false)

   return (
      <View
         style={{ marginBottom: isAccordionOpen ? 30 : 0 }}
      >
         <TouchableOpacity
            onPress={() => setIsAccordionOpen(!isAccordionOpen)}
            style={{
               flexDirection: 'row',
               justifyContent: 'space-between',
               columnGap: 10
            }}
         >
            <View
               style={{
                  marginBottom: 5,
                  flex: 1
               }}>
               {header}
            </View>
            <View
               style={{ paddingTop: 7 }}
            >
               <CustomIcon
                  icon={faAngleRight}
                  color={colors.angleRightBlue}
                  style={{
                     ...isAccordionOpen && { transform: [{ rotate: '90deg' }] }
                  }}
               />
            </View>
         </TouchableOpacity>
         {isAccordionOpen ? content : null}
      </View>
   )
}

export default Accordion
