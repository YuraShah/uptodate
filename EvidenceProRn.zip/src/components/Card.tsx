import React from 'react'
import { View } from 'react-native'
import { useTheme } from '@/src/hooks/useTheme'

export default function Card({
   children,
   isPadding
}: {
   children: React.ReactNode,
   isPadding?: boolean
}) {
   const { colors } = useTheme();

   return (
      <View
         style={{
            borderRadius: 10,
            borderWidth: 1,
            overflow: 'hidden',
            paddingHorizontal: isPadding ? 0 : 7,
            paddingVertical: 10,
            rowGap: 5,
            borderColor: colors.borderBottomPrimary
         }}
      >
         {children}
      </View>
   )
}
