import React, { useState } from 'react'
import { FlatList, StyleSheet, TouchableOpacity, View } from 'react-native'
import CustomRefText from '@/src/components/CustomTexts/CustomRefText'
import CustomTextBold from '@/src/components/CustomTexts/CustomTextBold'
import { useTheme } from '../hooks/useTheme'
import CustomTextSmallBold from './CustomTexts/CustomTextSmallBold'

interface IReferences {
   refs: string[]
   flat?: boolean,
   isRefOpen?: boolean,
}

const References = ({
   refs,
   flat,
   isRefOpen = false,
}: IReferences) => {
   const { colors } = useTheme()
   const [isOpenRef, setIsOpenRef] = useState(false);

   return (
      <View>
         {isRefOpen ? (
            <TouchableOpacity
               onPress={() => setIsOpenRef(!isOpenRef)}
               accessibilityLabel='Press Ref'
            >
               <CustomTextSmallBold style={{ color: colors.othTitle }}>
                  Ссылки
               </CustomTextSmallBold>
            </TouchableOpacity>
         ) : (
            <CustomTextBold>Ссылки</CustomTextBold>
         )}
         {isRefOpen && !isOpenRef ? null : flat ? (
            <FlatList
               data={refs}
               renderItem={({ item, index }) => (
                  <CustomRefText style={styles.refList}>
                     {index + 1}. {item}
                  </CustomRefText>
               )}
            />
         ) : (
            refs.map((ref, index) => (
               <CustomRefText
                  style={styles.refList}
                  key={index}
               >
                  {index + 1}. {ref}
               </CustomRefText>
            ))
         )}
      </View>
   )
}

const styles = StyleSheet.create({
   refList: {
      marginVertical: 2,
      paddingLeft: 5
   },
})

export default References
