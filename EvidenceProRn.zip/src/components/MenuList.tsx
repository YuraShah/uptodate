import { IconDefinition } from '@fortawesome/fontawesome-svg-core'
import React from 'react'
import { GestureResponderEvent, StyleSheet, TouchableOpacity, View } from 'react-native'
import CustomIcon from '@/src/components/CustomIcons/CustomIcon'
import CustomText from '@/src/components/CustomTexts/CustomText'
import AngleRight from '@/src/components/AngleRight'
import CustomTextBold from '@/src/components/CustomTexts/CustomTextBold'
import { useTheme } from '@/src/hooks/useTheme'
import { faLock } from '@fortawesome/free-solid-svg-icons'
import { FontAwesomeIcon } from '@fortawesome/react-native-fontawesome'


interface MenuList {
   icon?: IconDefinition,
   onPress: ((event: GestureResponderEvent) => void) | undefined,
   title: string,
   color?: string,
   children?: React.ReactNode,
   header?: React.ReactNode,
   childrenTouch?: React.ReactNode,
   isActive?: boolean,
   isPadding?: boolean,
   angleColor?: string,
   isLastMargin?: boolean,
   lock?: boolean,
}

export default function MenuList({
   icon,
   onPress,
   title,
   color,
   children,
   header,
   childrenTouch,
   isActive = false,
   isPadding = false,
   angleColor,
   isLastMargin,
   lock
}: MenuList) {
   const { colors } = useTheme()

   return (
      <View style={{
         paddingHorizontal: isPadding ? 0 : 15,
         paddingVertical: header || children ? 10 : 0,
         marginBottom: isLastMargin ? 50 : 0
      }}>
         {header ? header : null}
         <TouchableOpacity
            onPress={onPress}
            style={[styles.menuTouch, {
               paddingVertical: header || children ? 0 : 10
            }]}
         >
            <View
               style={{
                  flexDirection: icon ? 'row' : 'column',
                  columnGap: icon ? 15 : 0,
                  flex: 1
               }}
            >
               {icon ? (
                  <View style={styles.menuIcon}>
                     <CustomIcon
                        icon={icon}
                        color={color}
                     />
                  </View>
               ) : null}
               {isActive ? (
                  <CustomTextBold
                     style={[
                        styles.menuText,
                        { color: colors.angleRightBlue }
                     ]}
                  >
                     {title}
                  </CustomTextBold>
               ) : (
                  <CustomText style={styles.menuText}>
                     {title}
                  </CustomText>
               )}
               {childrenTouch ?? null}
            </View>
            {lock ? (
               <View style={{ paddingTop: 3, marginRight: 3 }}>
                  <FontAwesomeIcon
                     icon={faLock}
                     color={colors.primary}
                  />
               </View>
            ) : null}
            <AngleRight
               isActive={isActive}
               color={angleColor}
            />
         </TouchableOpacity>
         {children ? children : null}
      </View>
   )
}

const styles = StyleSheet.create({
   menuTouch: {
      flexDirection: 'row',
      justifyContent: 'space-between',
      alignItems: 'center',
      gap: 3,
   },
   menuIcon: {
      paddingTop: 6,
   },
   menuText: {
      flex: 1
   },
})
