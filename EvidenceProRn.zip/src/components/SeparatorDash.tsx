import { useTheme } from '@/src/hooks/useTheme'
import React from 'react'
import { Platform, View } from 'react-native'

export default function SeparatorDash({
   isMarginHorizontal
}: {
   isMarginHorizontal?: boolean
}) {
   const { colors } = useTheme()

   return (
      <View style={{
         height: 1,
         borderBottomWidth: Platform.OS === 'ios' ? 0 : 1,
         borderTopWidth: 1,
         borderStyle: Platform.OS === 'ios' ? 'solid' : 'dashed',
         borderColor: colors.borderBottomPrimary,
         marginHorizontal: isMarginHorizontal ? 0 : 15,
      }} />
   )
}
