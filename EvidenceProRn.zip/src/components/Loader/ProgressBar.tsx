import React from 'react'
import { View } from 'react-native'
import { useTheme } from '@/src/hooks/useTheme'

const ProgressBar = ({ progress, width }: { progress: number, width: number }) => {
   const { colors } = useTheme()

   return (
      <View style={{
         height: 4,
         width: width ? width : '100%',
         backgroundColor: colors.progressBarBg,
         borderRadius: 2,
         marginVertical: 10
      }}
      >
         <View
            style={{
               height: '100%',
               width: `${progress * 100}%`,
               backgroundColor: colors.mainBg,
               borderRadius: 2,
            }}
         />
      </View>
   )
}

export default ProgressBar
