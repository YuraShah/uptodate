import React from 'react'
import { ActivityIndicator, View } from 'react-native'
import { useTheme } from '@/src/hooks/useTheme'

const Loader = () => {
   const { colors } = useTheme()

   return (
      <View style={{
         justifyContent: 'center',
         alignItems: 'center',
         flex: 1,
         backgroundColor: colors.background
      }}>
         <ActivityIndicator
            size="large"
            color={colors.mainBg}
         />
      </View>
   )
}

export default Loader
