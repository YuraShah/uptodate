import React from 'react'
import { StyleSheet, View } from 'react-native'
import CustomInput from '@/src/components/CustomTexts/CustomInput'
import { useTheme } from '@/src/hooks/useTheme'

interface ISelectAsyncComponent {
   inpValue: string,
   setInpValue: Function,
   windowWidth: number,
   placeholder?: string
}

const SelectAsyncComponent = ({
   windowWidth,
   inpValue,
   setInpValue,
   placeholder = ''
}: ISelectAsyncComponent) => {
   const { colors } = useTheme()

   return (
      <View
         style={[
            {
               marginTop: 20,
               marginBottom: 20,
            },
            windowWidth >= 780 && {
               width: '70%'
            }
         ]}
      >
         <CustomInput
            placeholder={placeholder}
            placeholderTextColor={colors.inputPlaceholder}
            style={[
               styles.input,
               {
                  backgroundColor: colors.inputBackground,
               },
            ]}
            onChangeText={(value) => setInpValue(value)}
            value={inpValue}
            accessibilityLabel="Search Input"
         />
      </View>
   )
}

const styles = StyleSheet.create({
   input: {
      paddingHorizontal: 15,
      borderRadius: 5,
      flex: 1,
   },
})

export default SelectAsyncComponent
