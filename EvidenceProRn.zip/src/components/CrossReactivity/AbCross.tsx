import CustomBold from '@/src/components/CustomTexts/CustomBold'
import CustomText from '@/src/components/CustomTexts/CustomText'
import CustomTextBold from '@/src/components/CustomTexts/CustomTextBold'
import CustomTextNoFont from '@/src/components/CustomTexts/CustomTextNoFont'
import CustomTextSmall from '@/src/components/CustomTexts/CustomTextSmall'
import MenuList from '@/src/components/MenuList'
import References from '@/src/components/References'
import Separator from '@/src/components/Separator'
import SeparatorDash from '@/src/components/SeparatorDash'
import TitleShare from '@/src/components/TitleShare'
import { abList } from '@/src/constants/data/ab-cr-list'
import { useTheme } from '@/src/hooks/useTheme'
import React, { useState } from 'react'
import { FlatList, SafeAreaView, View } from 'react-native'


export default function AbCross() {
   const { colors } = useTheme()
   const [openStates, setOpenStates] = useState<boolean[]>([])

   const toggleOpen = (id: number) => {
      setOpenStates(prev => {
         const updated = [...prev];
         updated[id] = !updated[id];
         return updated;
      });
   };


   return (
      <SafeAreaView style={{ flex: 1, backgroundColor: colors.background }}>
         <FlatList
            contentContainerStyle={{ paddingVertical: 15 }}
            ListHeaderComponent={
               <View style={{ paddingHorizontal: 15 }}>
                  <TitleShare
                     titleText='Перекрестная гиперчувствительность к β-лактамным антибиотикам'
                  />
                  <View style={{ marginTop: 10, marginBottom: 30, rowGap: 5 }}>
                     <CustomText>
                        <CustomBold>ВНИМАНИЕ:</CustomBold> Если есть аллергия на один пенициллин, следует избегать всех пенициллинов. Если это невозможно, оцените риск и выберите альтернативу.
                     </CustomText>
                      <CustomText>Здесь представлены β-лактамные антибиотики, среди которых наблюдается высокая перекрестная реактивность.</CustomText>
                  </View>
               </View>
            }
            data={abList}
            renderItem={({ item }) => (
               <View>
                  <CustomTextBold style={{ paddingHorizontal: 15 }}>
                     {item.class}
                  </CustomTextBold>
                  <FlatList
                     data={item.children}
                     renderItem={({ item: children }) => {
                        const isOpen = openStates[children.id]

                        return (
                           <MenuList
                              onPress={() => toggleOpen(children.id)}
                              title={children.title}
                              isActive={isOpen}
                              angleColor={colors.angleRightBlue}
                              children={isOpen ? (
                                 <View style={{ paddingHorizontal: 15, }}>
                                    <FlatList
                                       data={children.children}
                                       renderItem={({ item: creact }) => (
                                          <View style={{ paddingVertical: 10, rowGap: 5 }}>
                                             <View style={{
                                                flexDirection: 'row',
                                                justifyContent: 'space-between',
                                                columnGap: 2
                                             }}>
                                                <CustomText style={{ flex: 1 }}>
                                                   {creact.childTitle}
                                                </CustomText>
                                                <CustomTextNoFont style={{ fontSize: 14, maxWidth: 100, flex: 1 }}>
                                                   ⇆ {children.title}
                                                </CustomTextNoFont>
                                             </View>
                                             <View>
                                                <CustomTextBold>
                                                   Класс
                                                </CustomTextBold>
                                                <CustomText>
                                                   {item.class}
                                                </CustomText>
                                             </View>
                                             <View>
                                                <CustomTextBold>
                                                   Причина
                                                </CustomTextBold>
                                                <CustomText>
                                                   {risks[creact.childNumber]} <CustomText style={{ color: colors.formError }}>НЕ НАЗНАЧАТЬ</CustomText>
                                                </CustomText>
                                             </View>
                                          </View>
                                       )}
                                       keyExtractor={(creact, cindex) => creact.childTitle + cindex.toString()}
                                       ItemSeparatorComponent={() => <SeparatorDash isMarginHorizontal />}
                                       ListEmptyComponent={() => <CustomText style={{ marginTop: 5 }}>Не найдено</CustomText>}
                                    />
                                 </View>
                              ) : null}
                           />
                        )
                     }}
                     keyExtractor={(item) => item.id.toString()}
                     ItemSeparatorComponent={() => <Separator />}
                  />
               </View>
            )}
            keyExtractor={item => item.class}
            ItemSeparatorComponent={() => <View style={{ marginVertical: 15 }} />}
            ListFooterComponent={(
               <View style={{ paddingHorizontal: 15, marginTop: 30 }}>
                  <References
                     refs={['Castells M, Khan DA, Phillips EJ, Longo DL. Penicillin allergy. N Engl J Med. 2019;381(24):2338-2351. doi: 10.1056/NEJMra1807761']}
                     flat
                  />
               </View>
            )}
         />
      </SafeAreaView>
   )
}


const risks: Record<string, string> = {
   1: "Одинаковая боковая цепь — клинически подтверждённая перекрёстная реакция.",
   2: "Одинаковая боковая цепь — теоретически существует риск перекрёстной реакции, но клинические исследования отсутствуют.",
   3: "Сходная боковая цепь — существует потенциальный риск перекрёстной реакции.",
   4: "Реакция обусловлена β-лактамным кольцом. Имеются клинические доказательства перекрёстной реакции.",
   5: "Реакция обусловлена β-лактамным кольцом. Теоретически существует риск перекрёстной реакции, но клинические исследования отсутствуют."
}
