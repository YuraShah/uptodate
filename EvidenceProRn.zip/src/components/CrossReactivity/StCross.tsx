import CustomIconSmall from '@/src/components/CustomIcons/CustomIconSmall';
import CustomBold from '@/src/components/CustomTexts/CustomBold';
import CustomText from '@/src/components/CustomTexts/CustomText';
import CustomTextBold from '@/src/components/CustomTexts/CustomTextBold';
import CustomTextSmall from '@/src/components/CustomTexts/CustomTextSmall';
import MenuList from '@/src/components/MenuList';
import References from '@/src/components/References';
import Separator from '@/src/components/Separator';
import SeparatorDash from '@/src/components/SeparatorDash';
import TitleShare from '@/src/components/TitleShare';
import { sterList } from '@/src/constants/data/st-cr-list';
import { useTheme } from '@/src/hooks/useTheme';
import { faRightLeft } from '@fortawesome/free-solid-svg-icons';
import React, { useState } from 'react'
import { FlatList, SafeAreaView, View } from 'react-native';


export default function StCross() {
   const { colors } = useTheme()
   const [openStates, setOpenStates] = useState<boolean[]>([])

   const toggleOpen = (id: number) => {
      setOpenStates(prev => {
         const updated = [...prev];
         updated[id] = !updated[id];
         return updated;
      });
   };

   return (
      <SafeAreaView style={{ flex: 1, backgroundColor: colors.background }}>
         <FlatList
            contentContainerStyle={{ paddingVertical: 15 }}
            ListHeaderComponent={
               <View style={{ paddingHorizontal: 15, marginBottom: 20 }}>
                  <TitleShare
                     titleText='Перекрестная гиперчувствительность к кортикостероидам'
                  />
                  <CustomText style={{ marginVertical: 10 }}>
                     <CustomBold>ВНИМАНИЕ:</CustomBold> Если есть аллергия на один кортикостероид, следует избегать всех кортикостероидов. Если это невозможно, оцените риск и выберите альтернативу.
                  </CustomText>
                  <CustomText>Здесь представлены кортикостероиды, среди которых наблюдается высокая перекрестная реактивность. Между всеми кортикостероидами может развиться перекрестная реакция. Перекрестную реактивность к кортикостероидам трудно оценить, поскольку большинство людей получили по крайней мере один местный или системный кортикостероид, и во многих случаях пациенты не помнят, получали ли они ранее кортикостероид и его тип. Между кортикостероидами внутри каждой группы, а также между группой D2 и группами A и B наблюдается высокая перекрестная реактивность, при этом группа D1 демонстрирует относительно низкую перекрестную реактивность с другими группами. Кортикостероиды класса С имеют самый низкий уровень аллергенности. В порядке возрастания аллергенности: C → D1 → остальные.</CustomText>
               </View>
            }
            data={sterList}
            renderItem={({ item }) => (
               <View>
                  <CustomTextBold style={{ paddingHorizontal: 15 }}>
                     {item.class}
                  </CustomTextBold>
                  <FlatList
                     data={item.children}
                     renderItem={({ item: children }) => {
                        const isOpen = openStates[children.id]

                        return (
                           <MenuList
                              onPress={() => toggleOpen(children.id)}
                              title={children.title}
                              isActive={isOpen}
                              angleColor={colors.angleRightBlue}
                              children={isOpen ? (
                                 <View style={{ paddingHorizontal: 15, }}>
                                    <FlatList
                                       data={children.children}
                                       renderItem={({ item: creact }) => (
                                          <View style={{ paddingVertical: 10, rowGap: 5 }}>
                                             <View style={{
                                                rowGap: 7
                                             }}>
                                                <CustomText>
                                                   {creact.childTitle}
                                                </CustomText>
                                                <CustomIconSmall
                                                   icon={faRightLeft}
                                                   size={15}
                                                   color={colors.primary}
                                                />
                                                <CustomTextSmall style={{ fontSize: 15 }}>
                                                   {children.title}
                                                </CustomTextSmall>
                                             </View>
                                             <View>
                                                <CustomTextBold>
                                                   Группа
                                                </CustomTextBold>
                                                <CustomText>
                                                   {creact.childClass}
                                                </CustomText>
                                             </View>
                                             <CustomText style={{ color: colors.formError }}>НЕ НАЗНАЧАТЬ</CustomText>
                                          </View>
                                       )}
                                       keyExtractor={(creact, cindex) => creact.childTitle + cindex.toString()}
                                       ItemSeparatorComponent={() => <SeparatorDash isMarginHorizontal />}
                                       ListEmptyComponent={() => <CustomText style={{ marginTop: 5 }}>Не найдено</CustomText>}
                                    />
                                 </View>
                              ) : null}
                           />
                        )
                     }}
                     keyExtractor={(item) => item.id.toString()}
                     ItemSeparatorComponent={() => <Separator />}
                  />
               </View>
            )}
            keyExtractor={item => item.class}
            ItemSeparatorComponent={() => <View style={{ marginVertical: 15 }} />}
            ListFooterComponent={(
               <View style={{ paddingHorizontal: 15, marginTop: 30 }}>
                  <References
                     refs={[
                        'Torres MJ, Canto G. Hypersensitivity reactions to corticosteroids. Curr Opin Allergy Clin Immunol 2010; 10:273. Copyright © 2010 Lippincott Williams & Wilkins',
                        'Baeck, M., Chemelle, J. A., Goossens, A., Nicolas, J. F., & Terreux, R. (2011). Corticosteroid cross-reactivity: clinical and molecular modelling tools. Allergy, 66(10), 1367-1374.'
                     ]}
                     flat
                  />
               </View>
            )}
         />
      </SafeAreaView>
   )
}
