import React from 'react'
import { faArrowUpFromBracket } from '@fortawesome/free-solid-svg-icons'
import { FontAwesomeIcon } from '@fortawesome/react-native-fontawesome'
import { StyleSheet, TouchableOpacity, View, useWindowDimensions } from 'react-native'
import useShareLink from '@/src/hooks/useShareLink'
import CustomTextLargeBold from '@/src/components/CustomTexts/CustomTextLargeBold'
import { useTheme } from '@/src/hooks/useTheme'

interface ITitleShare {
   titleText: string,
   capitalize?: boolean,
   marginBottom?: number
}

const TitleShare = ({
   titleText,
   capitalize,
   marginBottom
}: ITitleShare) => {
   const windowWidth = useWindowDimensions().width;
   const shareLink = useShareLink()
   const { colors } = useTheme()

   return (
      <View style={[
         styles.titleShareContainer, {
            marginBottom: marginBottom ? marginBottom : 0
         }]}
      >
         <CustomTextLargeBold style={[
            styles.title,
            {
               color: colors.title,
               textTransform: capitalize ? 'capitalize' : 'none',
            },
         ]}>
            {titleText}
         </CustomTextLargeBold>
         {shareLink && (
            <TouchableOpacity
               style={[styles.titleShareTouch, {
                  paddingRight: windowWidth >= 650 ? 17 : 3
               }]}
               onPress={() => shareLink()}
               accessibilityLabel='Press Share'
            >
               <FontAwesomeIcon
                  icon={faArrowUpFromBracket}
                  size={18}
                  color={colors.title}
               />
            </TouchableOpacity>
         )}
      </View>
   )
}

const styles = StyleSheet.create({
   titleShareContainer: {
      flexDirection: 'row',
      columnGap: 7,
   },
   titleShareTouch: {
      paddingLeft: 7,
      paddingTop: 5
   },
   title: {
      flex: 1
   },
})

export default TitleShare
