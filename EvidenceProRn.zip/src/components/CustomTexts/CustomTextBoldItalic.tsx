import { Platform, Text, TextProps } from 'react-native';
import { useAppSelector } from '@/src/redux/hooks';
import { useTheme } from '@/src/hooks/useTheme';

export default function CustomTextBoldItalic(props: TextProps) {
   const { textSize } = useAppSelector(state => state.fontSizeStore)
   const { colors } = useTheme()

   return <Text
      {...props}
      style={[
         Platform.OS === 'ios' ? { fontFamily: 'Roboto-BoldItalic' } : null,
         {
            fontWeight: 'bold',
            fontStyle: 'italic',
            fontSize: textSize,
            lineHeight: 28,
            ...Platform.OS === 'ios' && { transform: [{ skewX: '-10deg' }] },
            color: colors.primary
         },
         props.style
      ]}
   />;
}