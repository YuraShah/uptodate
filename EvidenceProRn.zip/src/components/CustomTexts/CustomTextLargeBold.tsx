import { Platform, Text, TextProps } from 'react-native';
import { useAppSelector } from '@/src/redux/hooks';
import { useTheme } from '@/src/hooks/useTheme';

export default function CustomTextLargeBold(props: TextProps) {
   const { titleSize } = useAppSelector(state => state.fontSizeStore)
   const { colors } = useTheme()

   return <Text
      {...props}
      style={[
         Platform.OS === 'ios' ? { fontFamily: 'Roboto-Bold' } : null,
         { 
            fontSize: titleSize,
            lineHeight: 28,
            fontWeight: 'bold',
            color: colors.primary
          },
         props.style
      ]}
   />;
}