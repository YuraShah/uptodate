import { Platform, Text, TextProps } from 'react-native';
import { useAppSelector } from '@/src/redux/hooks';
import { useTheme } from '@/src/hooks/useTheme';

export default function CustomTextBold(props: TextProps) {
   const { textSize } = useAppSelector(state => state.fontSizeStore)
   const { colors } = useTheme()

   return <Text
      {...props}
      style={[
         Platform.OS === 'ios' ? { fontFamily: 'Roboto-Bold' } : null,
         {
            fontWeight: 'bold',
            fontSize: textSize,
            lineHeight: 28,
            color: colors.primary
         },
         props.style
      ]}
   />;
}