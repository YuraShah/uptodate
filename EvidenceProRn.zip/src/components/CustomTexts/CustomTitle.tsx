import { Platform, Text, TextProps } from 'react-native';
import { useAppSelector } from '@/src/redux/hooks';
import { useTheme } from '@/src/hooks/useTheme';

export default function CustomTitle(props: TextProps) {
   const { titleSize } = useAppSelector(state => state.fontSizeStore)
   const { colors } = useTheme()

   return <Text
      {...props}
      style={[
         Platform.OS === 'ios' ? { fontFamily: 'Roboto-Bold' } : null,
         {
            lineHeight: 28,
            color: colors.title,
            fontWeight: 'bold',
            fontSize: titleSize
         },
         props.style
      ]}
   />;
}