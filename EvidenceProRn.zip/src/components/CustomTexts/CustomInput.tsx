import { Platform, TextInput, TextInputProps } from 'react-native';
import { useAppSelector } from '@/src/redux/hooks';
import { useTheme } from '@/src/hooks/useTheme';

export default function CustomInput(props: TextInputProps) {
   const { textSize } = useAppSelector(state => state.fontSizeStore)
   const { colors } = useTheme()

   return <TextInput
      {...props}
      style={[
         Platform.OS === 'ios' ? { fontFamily: 'Roboto-Regular' } : null,
         {
            fontSize: textSize,
            paddingHorizontal: 15,
            backgroundColor: colors.inputBackground,
            borderRadius: 5,
            flex: 1,
            height: 48
         },
         props.style
      ]}
      selectionColor={colors.mainBg}
   />;
}