import { Text, TextProps } from 'react-native';
import { useTheme } from '@/src/hooks/useTheme';

export default function CustomLink(props: TextProps) {
   const { colors } = useTheme()

   return <Text
      {...props}
      style={[
         {
            color: colors.link,
            textDecorationLine: 'underline'
         },
         props.style
      ]}
   />;
}