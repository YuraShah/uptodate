import { Platform, Text, TextProps } from 'react-native';
import { useTheme } from '@/src/hooks/useTheme';

export default function CustomTextNoFontBold(props: TextProps) {
   const { colors } = useTheme()

   return <Text
      {...props}
      style={[
         Platform.OS === 'ios' ? { fontFamily: 'Roboto-Bold' } : null,
         {
            lineHeight: 28,
            fontWeight: 'bold',
            color: colors.primary
         },
         props.style
      ]}
   />;
}