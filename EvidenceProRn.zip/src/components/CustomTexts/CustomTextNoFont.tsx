import { Platform, Text, TextProps } from 'react-native';
import { useTheme } from '@/src/hooks/useTheme';

export default function CustomTextNoFont(props: TextProps) {
   const { colors } = useTheme()

   return <Text
      {...props}
      style={[
         Platform.OS === 'ios' ? { fontFamily: 'Roboto-Regular' } : null,
         {
            lineHeight: 28,
            color: colors.primary
         },
         props.style
      ]}
   />;
}