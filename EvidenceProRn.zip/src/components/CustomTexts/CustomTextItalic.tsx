import { Platform, Text, TextProps } from 'react-native';
import { useAppSelector } from '@/src/redux/hooks';
import { useTheme } from '@/src/hooks/useTheme';

export default function CustomTextItalic(props: TextProps) {
   const { textSize } = useAppSelector(state => state.fontSizeStore)
   const { colors } = useTheme()

   return <Text
      {...props}
      style={[
         Platform.OS === 'ios' ? { fontFamily: 'Roboto-Italic' } : null,
         { 
            fontSize: textSize,
            lineHeight: 28,
            fontStyle: 'italic',
            ...Platform.OS === 'ios' && { transform: [{ skewX: '-10deg' }] },
            color: colors.primary
          },
         props.style
      ]}
   />;
}