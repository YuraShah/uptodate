import { Platform, ScrollView, View } from 'react-native';
import { Row, Rows, Table } from 'react-native-reanimated-table';
import { useAppSelector } from '@/src/redux/hooks';
import { useTheme } from '@/src/hooks/useTheme';

interface ICustomTable {
   headData?: any[],
   headWidthNums?: number[],
   bodyData: any[][],
   flexNums?: number[],
   widthNums?: number[],
   marginVertical?: number,
   large?: boolean
}

export const CustomTable: React.FC<ICustomTable> = ({
   headData = [],
   headWidthNums,
   bodyData,
   flexNums,
   widthNums,
   marginVertical = 20,
   large,
}) => {
   const { textSize, refSize } = useAppSelector(state => state.fontSizeStore);
   const { colors } = useTheme()

   return (
      <View style={{ marginVertical: marginVertical }}>
         {widthNums && headData.length > 0 ? (
            <ScrollView
               horizontal
            >
               <Table
                  borderStyle={{
                     borderWidth: 1,
                     borderColor: colors.tableBorder
                  }}
               >
                  <Row
                     data={headData}
                     flexArr={flexNums}
                     widthArr={headWidthNums ?? widthNums}
                     textStyle={{
                        fontSize: large ? textSize : refSize,
                        padding: 5,
                        fontWeight: 'bold',
                        lineHeight: 28,
                        ...Platform.OS === 'ios' && { fontFamily: 'Roboto-Bold' },
                        color: colors.primary
                     }}
                  />
                  <Rows
                     data={bodyData}
                     flexArr={flexNums}
                     widthArr={widthNums}
                     textStyle={
                        {
                           fontSize: large ? textSize : refSize,
                           padding: 5,
                           lineHeight: 28,
                           ...Platform.OS === 'ios' && { fontFamily: 'Roboto-Regular' },
                           color: colors.primary
                        }}
                  />
               </Table>
            </ScrollView>
         ) : widthNums && headData.length === 0 ? (
            <ScrollView
               horizontal
            >
               <Table
                  borderStyle={{ borderWidth: 1, borderColor: colors.tableBorder }}
               >
                  <Rows
                     data={bodyData}
                     flexArr={flexNums}
                     widthArr={widthNums}
                     textStyle={
                        {
                           fontSize: large ? textSize : refSize,
                           padding: 5,
                           lineHeight: 28,
                           ...Platform.OS === 'ios' && { fontFamily: 'Roboto-Regular' },
                           color: colors.primary
                        }}
                  />
               </Table>
            </ScrollView>
         ) : headData.length > 0 ? (
            <Table
               borderStyle={{ borderWidth: 1, borderColor: colors.tableBorder }}
            >
               <Row
                  data={headData}
                  flexArr={flexNums}
                  widthArr={headWidthNums ?? widthNums}
                  textStyle={{
                     fontSize: large ? textSize : refSize,
                     padding: 5,
                     fontWeight: 'bold',
                     lineHeight: 28,
                     ...Platform.OS === 'ios' && { fontFamily: 'Roboto-Bold' },
                     color: colors.primary
                  }}
               />
               <Rows
                  data={bodyData}
                  flexArr={flexNums}
                  widthArr={widthNums}
                  textStyle={
                     {
                        fontSize: large ? textSize : refSize,
                        padding: 5,
                        lineHeight: 28,
                        ...Platform.OS === 'ios' && { fontFamily: 'Roboto-Regular' },
                        color: colors.primary
                     }}
               />
            </Table>
         ) : (
            <Table
               borderStyle={{ borderWidth: 1, borderColor: colors.tableBorder }}
            >
               <Rows
                  data={bodyData}
                  flexArr={flexNums}
                  widthArr={widthNums}
                  textStyle={
                     {
                        fontSize: large ? textSize : refSize,
                        padding: 5,
                        lineHeight: 28,
                        ...Platform.OS === 'ios' && { fontFamily: 'Roboto-Regular' },
                        color: colors.primary
                     }}
               />
            </Table>
         )}
      </View>
   );
}