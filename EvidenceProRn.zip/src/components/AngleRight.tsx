import React from 'react'
import { useWindowDimensions, View } from 'react-native'
import CustomIcon from '@/src/components/CustomIcons/CustomIcon'
import { faAngleRight } from '@fortawesome/free-solid-svg-icons'
import { useTheme } from '@/src/hooks/useTheme'

export default function AngleRight({
   isActive,
   color
}: {
   isActive?: boolean,
   color?: string
}) {
   const { colors } = useTheme()
   const { width } = useWindowDimensions()

   return (
      <View
         style={{
            paddingTop: 5,
            width: 20,
            paddingRight: width >= 780 ? 35 : 0
         }}
      >
         <CustomIcon
            icon={faAngleRight}
            color={color ? color : colors.angleRightPrimary}
            style={[isActive && { transform: [{ rotate: '90deg' }] }]}
         />
      </View>
   )
}
