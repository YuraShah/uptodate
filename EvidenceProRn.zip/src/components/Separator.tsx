import React from 'react'
import { useTheme } from '@/src/hooks/useTheme'
import { View } from 'react-native';

export default function Separator({
   marginVertical = 0
}: {
   marginVertical?: number
}) {
   const { colors } = useTheme();

   return (
      <View style={{ 
         height: 1, 
         backgroundColor: colors.borderBottomPrimary,
         marginVertical: marginVertical
      }} />
   )
}
