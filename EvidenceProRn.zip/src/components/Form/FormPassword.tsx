import React from 'react';
import { View, TouchableOpacity, StyleSheet, Platform } from 'react-native';
import { FieldValues, Path, Controller, Control } from 'react-hook-form';
import { faEye, faEyeSlash } from '@fortawesome/free-solid-svg-icons';
import CustomText from '@/src/components/CustomTexts/CustomText';
import { useTheme } from '@/src/hooks/useTheme';
import CustomInput from '@/src/components/CustomTexts/CustomInput';
import CustomIconSmall from '@/src/components/CustomIcons/CustomIconSmall';

interface IFormPassword<T extends FieldValues> {
   control: Control<T>;
   labelTitle: string;
   inputId: Path<T>;
   errorMessage?: string;
   required: boolean;
   requiredText?: string;
   min?: number;
   max?: number;
   pattern?: RegExp;
   showBoolean: boolean;
   showFunction: (show: boolean) => void;
   fontBold?: boolean;
   labelCenter?: boolean;
}

const FormPassword = <T extends FieldValues>({
   control,
   labelTitle,
   inputId,
   errorMessage,
   required,
   requiredText,
   min,
   max,
   pattern,
   showBoolean,
   showFunction,
   fontBold,
   labelCenter
}: IFormPassword<T>) => {
   const { colors } = useTheme()

   return (
      <View>
         <CustomText
            style={[styles.formRowText,
            {
               fontWeight: fontBold ? 'bold' : 'normal',
               textAlign: labelCenter ? 'center' : 'auto'
            },
            Platform.OS === 'ios' ? { fontFamily: fontBold ? 'Roboto-Bold' : 'Roboto-Regular' } : null,
            ]}
         >
            {labelTitle} {requiredText && <CustomText style={styles.requiredText}> {requiredText}</CustomText>}
         </CustomText>
         <Controller
            control={control}
            name={inputId}
            rules={{
               required: required,
               ...(pattern && { pattern }),
               ...(min && { minLength: min }),
               ...(max && { maxLength: max }),
            }}
            render={({ field: { onChange, onBlur, value }, fieldState: { error } }) => (
               <>
                  {error && (
                     <CustomText style={[
                        styles.errorText,
                        { color: colors.formError }
                     ]}
                     >
                        {errorMessage}
                     </CustomText>
                  )}
                  <View style={styles.inputContainer}>
                     <CustomInput
                        onBlur={onBlur}
                        onChangeText={onChange}
                        value={value}
                        style={styles.input}
                        secureTextEntry={!showBoolean}
                        accessibilityLabel={`Input for ${labelTitle}`}
                        autoCapitalize="none"
                     />
                     <TouchableOpacity
                        onPress={() => showFunction(!showBoolean)}
                        style={[
                           styles.iconContainer, {
                              backgroundColor: colors.inputBackground
                           }
                        ]}
                        accessibilityLabel={`Toggle password visibility`}
                     >
                        <CustomIconSmall
                           icon={showBoolean ? faEyeSlash : faEye}
                           color={colors.black}
                        />
                     </TouchableOpacity>
                  </View>
               </>
            )}
         />
      </View>
   );
};

const styles = StyleSheet.create({
   formRowText: {
      marginBottom: 7,
   },
   errorText: {
      marginBottom: 7,
   },
   inputContainer: {
      flexDirection: 'row',
      justifyContent: 'space-between'
   },
   input: {
      borderTopLeftRadius: 4,
      borderBottomLeftRadius: 4,
      borderTopRightRadius: 0,
      borderBottomRightRadius: 0,
   },
   iconContainer: {
      flexDirection: 'row',
      alignItems: 'center',
      justifyContent: 'flex-end',
      width: 48,
      paddingLeft: 5,
      paddingRight: 7,
      borderTopRightRadius: 4,
      borderBottomRightRadius: 4,
   },
   requiredText: {
      fontSize: 16
   }
});

export default FormPassword;