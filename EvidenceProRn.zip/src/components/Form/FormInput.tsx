import React from 'react';
import { View, StyleSheet, Platform } from 'react-native';
import { FieldValues, Path, Controller, Control } from 'react-hook-form';
import CustomText from '@/src/components/CustomTexts/CustomText';
import CustomInput from '@/src/components/CustomTexts/CustomInput';
import { useTheme } from '@/src/hooks/useTheme';

interface IFormInput<T extends FieldValues> {
   control: Control<T>;
   labelTitle: string;
   inputId: Path<T>;
   inputPlaceholder: string;
   errorMessage?: string;
   required: boolean;
   min?: number;
   max?: number;
   pattern?: RegExp;
   inputValue?: string;
   fontBold?: boolean;
   autoCapitalize?: boolean,
   labelCenter?: boolean,
}

const FormInput = <T extends FieldValues>({
   control,
   labelTitle,
   inputId,
   inputPlaceholder,
   errorMessage,
   required,
   min,
   max,
   pattern,
   inputValue,
   fontBold,
   autoCapitalize,
   labelCenter
}: IFormInput<T>) => {
   const { colors } = useTheme()

   return (
      <View>
         <CustomText style={[
            styles.formRowText,
            {
               fontWeight: fontBold ? 'bold' : 'normal',
               textAlign: labelCenter ? 'center' : 'auto'
            },
            Platform.OS === 'ios' ? { fontFamily: fontBold ? 'Roboto-Bold' : 'Roboto-Regular' } : null,
         ]}
         >
            {labelTitle}
         </CustomText>
         <Controller
            control={control}
            name={inputId}
            rules={{
               required: required,
               ...(pattern && { pattern }),
               ...(min && { minLength: min }),
               ...(max && { maxLength: max }),
            }}
            render={({ field: { onChange, onBlur, value }, fieldState: { error } }) => (
               <>
                  {error && (
                     <CustomText style={[styles.errorText, { color: colors.formError }]}>
                        {errorMessage}
                     </CustomText>
                  )}
                  <CustomInput
                     onBlur={onBlur}
                     onChangeText={onChange}
                     value={value || inputValue}
                     placeholder={inputPlaceholder}
                     autoCapitalize={autoCapitalize ? "none" : "words"}
                     accessibilityLabel={`Input for ${labelTitle}`}
                  />
               </>
            )}
         />
      </View>
   );
};

const styles = StyleSheet.create({
   formRowText: {
      marginBottom: 7,
   },
   errorText: {
      marginBottom: 7,
   },
})

export default FormInput;