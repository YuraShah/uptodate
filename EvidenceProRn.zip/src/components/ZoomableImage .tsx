import React from 'react'
import { Zoomable } from '@likashefqet/react-native-image-zoom';
import { gestureHandlerRootHOC } from 'react-native-gesture-handler';
import { Image } from 'react-native';

interface IZoomableImage {
   img: string,
   resizeMode?: 'cover' | 'contain' | 'stretch' | 'repeat' | 'center',
   height?: number,
   isFlex?: boolean
}

const ZoomableImage = gestureHandlerRootHOC(({
   img,
   resizeMode,
   height,
   isFlex
}: IZoomableImage) => {
   return (
      <Zoomable
         minScale={1}
         maxScale={3}
         doubleTapScale={3}
         isDoubleTapEnabled
         style={{ zIndex: 1 }}
      >
         <Image
            source={img as any}
            style={[
               {
                  width: '100%',
                  ...(isFlex ? { flex: 1 } : {}),
                  ...(height ? { height } : {}),
               },
            ]}
            resizeMode={resizeMode ?? 'stretch'}
         />
      </Zoomable>
   )
});

export default ZoomableImage;
