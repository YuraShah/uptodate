import { faArrowRotateRight } from '@fortawesome/free-solid-svg-icons';
import { FontAwesomeIcon } from '@fortawesome/react-native-fontawesome';
import { RouteProp, useNavigation, useRoute } from '@react-navigation/native';
import React, { useEffect, useRef, useState } from 'react';
import { ActivityIndicator, ScrollView, View, SafeAreaView, TouchableOpacity, BackHandler } from 'react-native';
import { WebView } from 'react-native-webview';
import ProgressBar from '@/src/components/Loader/ProgressBar';
import { useTheme } from '@/src/hooks/useTheme';
import CustomTextNoFont from '@/src/components/CustomTexts/CustomTextNoFont';
import { MainStackParamList } from '@/src/types/navigationTypes';
import { NativeStackNavigationProp } from '@react-navigation/native-stack';


const WebViewScreen = () => {
   const route = useRoute<RouteProp<MainStackParamList, 'WebView'>>()
   const { url } = route.params;
   const [isVisible, setIsVisible] = useState(true)
   const [scrolledToTop, setScrolledToTop] = React.useState(0)
   const webViewRef = useRef<WebView | null>(null);
   const [canGoBack, setCanGoBack] = useState(false);
   const navigation = useNavigation<NativeStackNavigationProp<MainStackParamList>>();
   const [progress, setProgress] = useState(0);
   const { colors } = useTheme()

   const hideSpinner = () => {
      setIsVisible(false)
   }

   const onRefresh = React.useCallback(() => {
      if (webViewRef.current) {
         setIsVisible(true)
         webViewRef?.current?.reload();
      }
   }, []);

   const handleBackPress = () => {
      if (canGoBack) {
         webViewRef.current?.goBack();
         return true;
      } else {
         navigation.goBack();
         return true;
      }
   };

   useEffect(() => {
      BackHandler.addEventListener("hardwareBackPress", handleBackPress);

      return () => {
         BackHandler.removeEventListener("hardwareBackPress", handleBackPress);
      };
   }, [canGoBack]);


   const spinner = () => {
      return (
         <View style={{
            position: 'absolute',
            left: 0,
            right: 0,
            top: 0,
            bottom: 0,
            alignItems: 'center',
            justifyContent: 'center'
         }}>
            <ActivityIndicator
               size="large"
               color={colors.mainBg}
            />
            <CustomTextNoFont style={{ color: colors.mainBg, marginTop: 0, fontSize: 16 }}>
               {Math.round(progress * 100)}%
            </CustomTextNoFont>
            <ProgressBar
               progress={progress}
               width={100}
            />
         </View>
      )
   }

   return (
      <SafeAreaView style={{ flex: 1, backgroundColor: colors.background }}>
         <ScrollView contentContainerStyle={{ flexGrow: 1 }}>
            <View
               style={{
                  position: 'absolute',
                  zIndex: 1,
                  backgroundColor: colors.mainBg,
                  opacity: scrolledToTop <= 65 ? 1 : 0,
                  top: 0,
                  left: '50%',
                  width: 40,
                  marginLeft: -20,
               }}
            >
               <TouchableOpacity
                  onPress={() => onRefresh()}
                  style={{ alignItems: 'center', paddingVertical: 5 }}
                  disabled={scrolledToTop <= 65 ? false : true}
               >
                  <FontAwesomeIcon
                     icon={faArrowRotateRight}
                     size={20}
                     color={colors.webViewRefresh}
                  />
               </TouchableOpacity>
            </View>
            <WebView
               source={{ uri: url }}
               style={{ flex: 1 }}
               onLoad={() => hideSpinner()}
               ref={webViewRef}
               nestedScrollEnabled={true}
               scrollEnabled={true}
               onScroll={(event) => {
                  const { contentOffset: { y } } = event.nativeEvent;
                  setScrolledToTop(y)
               }}
               onNavigationStateChange={(navState) => setCanGoBack(navState.canGoBack)}
               renderLoading={spinner}
               onLoadProgress={({ nativeEvent }) => setProgress(nativeEvent.progress)}
               injectedJavaScriptBeforeContentLoaded={`
                  (function() {
                     localStorage.clear();
                     document.cookie.split(";").forEach((cookie) => {
                        document.cookie = cookie.replace(/^ +/, "").replace(/=.*/, "=;expires=" + new Date().toUTCString() + ";path=/");
                     });
                     true;
                  })();
               `}
               injectedJavaScript={`document.body.style.scrollBehavior = 'smooth'; document.body.style.webkitOverflowScrolling = 'touch';`}
            />
            {isVisible && (
               spinner()
            )}
         </ScrollView>
      </SafeAreaView>
   );
}

export default WebViewScreen;