import React from 'react'
import AbCross from '@/src/components/CrossReactivity/AbCross'
import StCross from '@/src/components/CrossReactivity/StCross'
import { RouteProp, useNavigation, useRoute } from '@react-navigation/native'
import { MainStackParamList } from '@/src/types/navigationTypes'
import { NativeStackNavigationProp } from '@react-navigation/native-stack'
import { Toast } from 'toastify-react-native'
import { Platform, View } from 'react-native'
import { excludeIosParams } from '@/src/navigation/excludeIosRoutes'

const screens: Record<string, React.ComponentType> = {
   'antibiotics': AbCross,
   'steroids': StCross,
}

export default function CrossItem() {
   const route = useRoute<RouteProp<MainStackParamList, 'CrossItem'>>()
   const { param } = route.params
   const navigation = useNavigation<NativeStackNavigationProp<MainStackParamList>>()

   if (
      !screens[param] ||
      (Platform.OS === 'ios' && excludeIosParams.includes(param))
   ) {
      navigation.replace('MenuCross');
      Toast.error("Неверная ссылка", "top")
      return null;
   }


   const SelectedScreen = screens[param];

   return (
      <View key={param} style={{ flex: 1 }}>
         <SelectedScreen />
      </View>
   )
}
