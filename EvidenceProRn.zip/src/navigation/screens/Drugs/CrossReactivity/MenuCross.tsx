import Menu from '@/src/components/Menu'
import { IMenuList } from '@/src/types/types'
import React from 'react'

export default function MenuCross() {
   return (
      <Menu
         data={menuList}
         headerTitle='Перекрестная гиперчувствительность'
      />
   )
}

const menuList: IMenuList[] = [
   {
      name: "Перекрестная гиперчувствительность к β-лактамным антибиотикам",
      link: "CrossItem",
      param: 'antibiotics'
   },
   {
      name: "Перекрестная гиперчувствительность к кортикостероидам",
      link: "CrossItem",
      param: 'steroids'
   },
]
