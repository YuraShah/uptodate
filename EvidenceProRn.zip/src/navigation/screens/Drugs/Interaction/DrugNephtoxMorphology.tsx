import SearchList from '@/src/components/SearchList'
import { fetchUseQuery } from '@/src/functions/fetchUseQuery'
import { IOtherList, IResponseData, LINKS } from '@/src/types/types'
import { useQuery } from '@tanstack/react-query'
import React from 'react'

export default function DrugNephtoxMorphology() {
  const { isLoading, isError, data, isSuccess, refetch } = useQuery({
    queryKey: ['drugNephtoxMorphology'],
    queryFn: async () => {
      return fetchUseQuery<IResponseData<IOtherList>>(
        'post',
        LINKS.DRUGNEPHTOXMORPHOLOGY,
      )
    },
    gcTime: 2000
  })

  return (
    <SearchList
      data={data}
      refetch={refetch}
      isLoading={isLoading}
      isError={isError}
      isSuccess={isSuccess}
      screen="DrugNephtoxMorphologyItem"
      title='Морфологические болезни'
      placeholder='Напишите морфологию (≥3 буквы)'
    />
  )
}
