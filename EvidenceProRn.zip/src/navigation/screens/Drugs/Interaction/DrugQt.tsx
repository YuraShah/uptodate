import Menu from '@/src/components/Menu'
import { IMenuList } from '@/src/types/types'
import React from 'react'

export default function DrugQt() {
  return (
    <Menu
      data={qtList}
      headerTitle='Риски лекарственно-индуцированного удлинения интервала QT и желудочковой тахикардии типа «пируэт»'
    />
  )
}

const qtList: IMenuList[] = [
  {
    name: "Лекарства",
    link: "DrugQtDrugs"
  },
  {
    name: "Показания",
    link: "DrugQtIndication"
  },
  {
    name: "Клинические факторы",
    link: "DrugQtFactor"
  }
]
