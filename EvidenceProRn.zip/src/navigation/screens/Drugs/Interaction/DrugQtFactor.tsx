import AngleRight from '@/src/components/AngleRight'
import CustomIconSmall from '@/src/components/CustomIcons/CustomIconSmall'
import CustomText from '@/src/components/CustomTexts/CustomText'
import CustomTextBold from '@/src/components/CustomTexts/CustomTextBold'
import CustomTextBoldItalic from '@/src/components/CustomTexts/CustomTextBoldItalic'
import ErrorNet from '@/src/components/ErrorNet'
import Loader from '@/src/components/Loader/Loader'
import OpenAll from '@/src/components/OpenAll'
import SelectAsyncComponent from '@/src/components/SelectComponent/SelectAsyncComponent'
import SeparatorDash from '@/src/components/SeparatorDash'
import Separator from '@/src/components/Separator'
import TitleShare from '@/src/components/TitleShare'
import { fetchUseQuery } from '@/src/functions/fetchUseQuery'
import { useTheme } from '@/src/hooks/useTheme'
import { IResponseData, LINKS } from '@/src/types/types'
import { faLink } from '@fortawesome/free-solid-svg-icons'
import { useNavigation } from '@react-navigation/native'
import { useQuery } from '@tanstack/react-query'
import React, { useEffect, useMemo, useState } from 'react'
import { FlatList, RefreshControl, SafeAreaView, TouchableOpacity, useWindowDimensions, View } from 'react-native'

type IDrugQtFactor = {
  id: string
  title: string
  factors: {
    factor: string,
    qt: string,
    qt_quality: string,
    tdp: string,
    tdp_quality: string,
    link: string,
  }[]
}

const FactorItem = ({
  title,
  text,
  quality
}: {
  title: string,
  text: string,
  quality?: string,
}) => (
  <View style={{ paddingHorizontal: 15, rowGap: 5, marginBottom: 5 }}>
    <CustomTextBoldItalic>
      {title}
    </CustomTextBoldItalic>
    <CustomText>
      {text}
    </CustomText>
    {quality && (
      <CustomText>
        {evidenceList[quality]}
      </CustomText>
    )}
    <View>
      <View style={{ marginBottom: 5 }} />
      <Separator />
    </View>
  </View>
)

export default function DrugQtFactor() {
  const { colors } = useTheme()
  const { width } = useWindowDimensions()
  const [inpValue, setInpValue] = useState<string>('')
  const [openStates, setOpenStates] = useState<boolean[]>([]);
  const navigation = useNavigation()

  const toggleOpen = (index: number) => {
    const updated = [...openStates];
    updated[index] = !updated[index];
    setOpenStates(updated);
  };

  const toggleAll = (open: boolean) => {
    setOpenStates(Array(data?.data.length).fill(open));
  };

  const { isLoading, isError, data, isSuccess, refetch } = useQuery({
    queryKey: ['drugQtFactor'],
    queryFn: async () => {
      return fetchUseQuery<IResponseData<IDrugQtFactor>>(
        'post',
        LINKS.DRUGQTFACTOR,
      )
    },
    gcTime: 2000
  })

  const filteredData = useMemo(() => {
    const list = data?.data ?? []
    if (!inpValue.trim()) return list

    return list.filter(item =>
      item.factors.some(factorItem =>
        factorItem.factor.toLowerCase().includes(inpValue.trim().toLowerCase())
      )
    );
  }, [inpValue, data])

  useEffect(() => {
    if (data && isSuccess) {
      setOpenStates(Array(data.data.length).fill(false));
    }
  }, [data, isSuccess]);

  const onRefresh = React.useCallback(() => {
    setInpValue('')
    refetch()
  }, [])


  if (isLoading) return <Loader />

  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: colors.background }}>
      {data && data.data && data.data.length > 0 ? (
        <OpenAll
          openStates={openStates}
          toggleAll={toggleAll}
        />
      ) : null}
      <FlatList
        refreshControl={
          <RefreshControl
            refreshing={isLoading}
            onRefresh={onRefresh}
            colors={[colors.mainBg]}
            progressBackgroundColor={colors.refreshProgressBarBg}
          />
        }
        contentContainerStyle={{ paddingVertical: 15 }}
        ListHeaderComponent={
          <View style={{ paddingHorizontal: 15 }}>
            <TitleShare
              titleText={'Клинические факторы, связанные с удлинением интервала QTc и/или TdP'}
            />
            <SelectAsyncComponent
              inpValue={inpValue}
              setInpValue={setInpValue}
              windowWidth={width}
              placeholder={`Клинический фактор... (≥3 буквы)`}
            />
            {isError ? <ErrorNet /> : null}
          </View>
        }
        data={filteredData}
        renderItem={({ item, index }) => {
          const isOpen = openStates[index];

          return (
            <View style={{
              paddingVertical: 5
            }}>
              <TouchableOpacity
                onPress={() => toggleOpen(index)}
                style={{
                  flexDirection: 'row',
                  justifyContent: 'space-between',
                  alignItems: 'center',
                  paddingVertical: 5,
                  paddingHorizontal: 15
                }}
              >
                <CustomTextBold>
                  {item.title}
                </CustomTextBold>
                <AngleRight
                  color={colors.angleRightBlue}
                  isActive={isOpen}
                />
              </TouchableOpacity>
              {isOpen && (
                <FlatList
                  data={item.factors}
                  renderItem={({ item: factor }) => (
                    <View style={{ rowGap: 5 }}>
                      <View style={{ paddingHorizontal: 15, marginBottom: 5 }}>
                        <CustomTextBold>
                          {factor.factor}
                        </CustomTextBold>
                        <View style={{ marginBottom: 5 }} />
                        <Separator />
                      </View>
                      <FactorItem
                        title='Клиническая связь с удлинением интервала QT'
                        text={factor.qt}
                      />
                      <FactorItem
                        title='Качество доказательств клинической связи с удлинением интервала QT'
                        text={factor.qt_quality}
                        quality={factor.qt_quality}
                      />
                      <FactorItem
                        title='Клиническая связь с TdP'
                        text={factor.tdp}
                      />
                      <FactorItem
                        title='Качество доказательств клинической связи с TdP'
                        text={factor.tdp_quality}
                        quality={factor.tdp_quality}
                      />
                      <TouchableOpacity
                        onPress={() => navigation.navigate('Home', {
                          screen: 'WebView',
                          params: {
                            url: factor.link
                          }
                        })}
                        style={{
                          paddingHorizontal: 15,
                          paddingBottom: 10,
                          flexDirection: 'row',
                          alignItems: 'center',
                          columnGap: 5
                        }}
                      >
                        <CustomTextBold style={{ color: colors.angleRightBlue }}>
                          Ссылка
                        </CustomTextBold>
                        <CustomIconSmall
                          icon={faLink}
                          color={colors.angleRightBlue}
                        />
                      </TouchableOpacity>
                    </View>
                  )}
                  keyExtractor={factor => factor.factor}
                  ItemSeparatorComponent={() => <>
                    <SeparatorDash />
                    <View style={{ marginVertical: 5 }} />
                  </>}
                />
              )}
            </View>
          )
        }}
        keyExtractor={item => item.id}
        ItemSeparatorComponent={() => <Separator />}
        ListEmptyComponent={() => <CustomText style={{ paddingHorizontal: 15 }}>Не найдено совпадений</CustomText>}
      />
    </SafeAreaView>
  )
}

const evidenceList: Record<string, string> = {
  "Высокий": "Истинная связь между фактором и клиническим эффектом близка к полученным оценкам. Дальнейшие исследования вряд ли изменят уверенность в этой связи (несколько высококачественных исследований с последовательными, стабильными результатами, в особых случаях: одно крупное, высококачественное многоцентровое исследование).",
  "Средний": "Истинная связь между фактором и клиническим эффектом близка к представленным оценкам, но есть вероятность, что она будет существенно отличаться. Дальнейшие исследования, вероятно, окажут важное влияние на уверенность в предполагаемой связи (одно высококачественное исследование, несколько исследований с некоторыми ограничениями).",
  "Низкий": "Уверенность в предполагаемой связи между фактором и клиническим эффектом ограничена, и истинная связь может не соответствовать представленным оценкам. Дальнейшие исследования, вероятно, окажут важное влияние на уверенность в оценке любой возможной связи (одно или несколько исследований с серьезными ограничениями).",
  "Очень низкий": "Оценки связи между фактором и клиническим эффектом малодостоверны. Если связь существует, она, скорее всего, будет существенно отличаться от текущих оценок (экспертное мнение, нет прямых исследовательских доказательств, одно или несколько исследований с очень серьезными ограничениями).",
}
