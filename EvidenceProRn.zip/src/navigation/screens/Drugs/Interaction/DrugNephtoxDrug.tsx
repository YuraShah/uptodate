import SearchList from '@/src/components/SearchList'
import { fetchUseQuery } from '@/src/functions/fetchUseQuery'
import { IDrugLabel, IResponseData, LINKS } from '@/src/types/types'
import { useQuery } from '@tanstack/react-query'
import React from 'react'

export default function DrugNephtoxDrug() {
  const { isLoading, isError, data, isSuccess, refetch } = useQuery({
    queryKey: ['drugNephtoxDrug'],
    queryFn: async () => {
      return fetchUseQuery<IResponseData<IDrugLabel>>(
        'post',
        LINKS.DRUGNEPHTOXLIST,
      )
    },
    gcTime: 2000
  })

  return (
    <SearchList
      data={data}
      refetch={refetch}
      isLoading={isLoading}
      isError={isError}
      isSuccess={isSuccess}
      screen="DrugNephtoxItem"
      title='Лекарства'
      placeholder='Лекарство... (≥3 буквы)'
    />
  )
}
