import AngleRight from '@/src/components/AngleRight'
import CustomText from '@/src/components/CustomTexts/CustomText'
import CustomTextBold from '@/src/components/CustomTexts/CustomTextBold'
import CustomTextBoldItalic from '@/src/components/CustomTexts/CustomTextBoldItalic'
import ErrorNet from '@/src/components/ErrorNet'
import Loader from '@/src/components/Loader/Loader'
import MenuList from '@/src/components/MenuList'
import Separator from '@/src/components/Separator'
import TitleShare from '@/src/components/TitleShare'
import { fetchUseQuery } from '@/src/functions/fetchUseQuery'
import { useTheme } from '@/src/hooks/useTheme'
import { MainStackParamList } from '@/src/types/navigationTypes'
import { IResponseData, LINKS } from '@/src/types/types'
import { RouteProp, useNavigation, useRoute } from '@react-navigation/native'
import { NativeStackNavigationProp } from '@react-navigation/native-stack'
import { FlashList } from '@shopify/flash-list'
import { useQuery } from '@tanstack/react-query'
import React from 'react'
import { RefreshControl, SafeAreaView, View } from 'react-native'

type IDrugPulmtoxSubpattern = {
  subpattern_id: number,
  subpattern_number: string,
  pattern_id: number,
  subpattern_title: string,
  subpattern_text: string,
  drugs: {
    id: string,
    label: string,
    link: string,
    pulmtox_subpattern_cases: string,
  }[]
}

export default function DrugPulmtoxSubpattern() {
  const { colors } = useTheme()
  const route = useRoute<RouteProp<MainStackParamList, 'DrugPulmtoxSubpattern'>>()
  const { param } = route.params;
  const navigation = useNavigation<NativeStackNavigationProp<MainStackParamList>>()

  const { isLoading, isError, data, refetch } = useQuery({
    queryKey: ['drugPulmtoxSubpattern', param],
    queryFn: async () => {
      return fetchUseQuery<IResponseData<IDrugPulmtoxSubpattern>>(
        'get',
        `${LINKS.DRUGPULMTOXSUBPATTERN}/${param}`,
      )
    },
    enabled: !!param,
    gcTime: 2000
  })

  const onRefresh = React.useCallback(() => {
    refetch()
  }, [])


  if (isLoading) return <Loader />

  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: colors.background }}>
      <FlashList
        refreshControl={
          <RefreshControl
            refreshing={isLoading}
            onRefresh={onRefresh}
            colors={[colors.mainBg]}
            progressBackgroundColor={colors.refreshProgressBarBg}
          />
        }
        contentContainerStyle={{ paddingVertical: 15 }}
        ListHeaderComponent={
          <View style={{ paddingHorizontal: 15 }}>
            <TitleShare
              titleText={'Взаимодействие лекарств с дыхательной системой'}
            />
            {data && data.data ? (
              <View style={{ marginTop: 20, rowGap: 5 }}>
                <View style={{
                  backgroundColor: colors.angleRightBlue,
                  alignSelf: 'flex-start',
                  justifyContent: 'center',
                  alignItems: 'center',
                  borderRadius: 20,
                  minWidth: 85
                }}>
                  <CustomTextBold style={{ color: colors.textReverse }}>
                    {data.data[0].subpattern_number}
                  </CustomTextBold>
                </View>
                <CustomTextBold style={{ color: colors.angleRightBlue }}>
                  {data.data[0].subpattern_title}
                </CustomTextBold>
                <CustomTextBold style={{ marginTop: 15 }}>
                  Причинные лекарственные препараты/вещества/вмешательства
                </CustomTextBold>
              </View>
            ) : null}
            {isError ? <ErrorNet /> : null}
          </View>
        }
        data={data?.data[0]?.drugs ?? []}
        renderItem={({ item }) => (
          <MenuList
            title={item.label}
            onPress={() => navigation.navigate('DrugPulmtoxItem', {
              param: `${item.link}:${item.id}`
            })}
            childrenTouch={
              <CustomTextBoldItalic>
                {cases[item.pulmtox_subpattern_cases]}
              </CustomTextBoldItalic>
            }
          />
        )}
        ItemSeparatorComponent={() => <Separator />}
        estimatedItemSize={100}
        ListFooterComponent={data && data.data ? (
          <View style={{ paddingHorizontal: 15, marginVertical: 20 }}>
            <CustomText>
              {data.data[0].subpattern_text}
            </CustomText>
          </View>
        ) : null}
        ListEmptyComponent={() => <CustomText style={{ paddingHorizontal: 15, marginTop: 7 }}>Не найдено</CustomText>}
      />
    </SafeAreaView>
  )
}

export const cases: Record<string, string> = {
  '-': 'сомнительное сообщение',
  '1': '<10 случаев',
  '2': '10–50 случаев',
  '3': '50–100 случаев',
  '4': '100–200 случаев',
  '5': '>200 случаев',
}
