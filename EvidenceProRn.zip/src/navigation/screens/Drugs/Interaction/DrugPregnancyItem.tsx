import Card from '@/src/components/Card'
import CustomBold from '@/src/components/CustomTexts/CustomBold'
import CustomText from '@/src/components/CustomTexts/CustomText'
import CustomTextBold from '@/src/components/CustomTexts/CustomTextBold'
import ErrorNet from '@/src/components/ErrorNet'
import References from '@/src/components/References'
import Separator from '@/src/components/Separator'
import TitleShare from '@/src/components/TitleShare'
import { fetchUseQuery } from '@/src/functions/fetchUseQuery'
import { useTheme } from '@/src/hooks/useTheme'
import { MainStackParamList } from '@/src/types/navigationTypes'
import { IResponseData, LINKS } from '@/src/types/types'
import { RouteProp, useRoute } from '@react-navigation/native'
import { useQuery } from '@tanstack/react-query'
import React from 'react'
import { FlatList, RefreshControl, SafeAreaView, View } from 'react-native'

const findCategoryRisk = (text: string, category: 'fda' | 'tga') => {
  if (text.includes('N')) return riskTexts.fda.N
  if (text.includes('X')) return riskTexts[category].X
  if (text.includes('D')) return riskTexts[category].D
  if (text.includes('C')) return riskTexts[category].C
  if (text.includes('B')) return riskTexts[category].B
  if (text.includes('A')) return riskTexts[category].A
}

type IDrugPregnancy = {
  id: string,
  label: string,
  pregnancy_fda?: string,
  pregnancy_au?: string,
  pregnancy_text?: string,
  pregnancy_refs?: string[]
}

export default function DrugPregnancyItem() {
  const { colors } = useTheme()
  const route = useRoute<RouteProp<MainStackParamList, 'DrugPregnancyItem'>>()
  const { param } = route.params;

  const { isLoading, isError, data, refetch } = useQuery({
    queryKey: ['pregnancyItem', param],
    queryFn: async () => {
      return fetchUseQuery<IResponseData<IDrugPregnancy>>(
        'post',
        LINKS.DRUGPREGNANCY,
        param
      )
    },
    enabled: !!param,
    gcTime: 2000
  })

  const onRefresh = React.useCallback(() => {
    refetch()
  }, [])

  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: colors.background }}>
      <FlatList
        contentContainerStyle={{ padding: 15 }}
        refreshControl={
          <RefreshControl
            refreshing={isLoading}
            onRefresh={onRefresh}
            colors={[colors.mainBg]}
            progressBackgroundColor={colors.refreshProgressBarBg}
          />
        }
        ListHeaderComponent={
          <View style={{ rowGap: 5, marginBottom: 15 }}>
            <TitleShare
              titleText={'Взаимодействие лекарств с беременными'}
            />
            {isError ? <ErrorNet /> : null}
          </View>
        }
        data={data?.data ?? []}
        keyExtractor={(item) => item.id}
        renderItem={({ item }) => {
          return (
            <Card isPadding>
              <View
                style={{ rowGap: 5 }}
              >
                <CustomTextBold style={{
                  textTransform: 'capitalize',
                  marginBottom: 5,
                  paddingHorizontal: 5
                }}>
                  {item.label}
                </CustomTextBold>
                {!item.pregnancy_au && !item.pregnancy_fda && !item.pregnancy_refs && !item.pregnancy_text && (
                  <CustomText style={{ paddingHorizontal: 5 }}>Не найдено данных</CustomText>
                )}
                {item.pregnancy_fda && (
                  <View
                    style={{
                      backgroundColor: item.pregnancy_fda.includes('N') ? (
                        colors.unRisk
                      ) : item.pregnancy_fda.includes('X') ? (
                        colors.vHRisk
                      ) : item.pregnancy_fda.includes('D') ? (
                        colors.hRisk
                      ) : item.pregnancy_fda.includes('C') ? (
                        colors.mRisk
                      ) : item.pregnancy_fda.includes('B') ? (
                        colors.lRisk
                      ) : item.pregnancy_fda.includes('A') ? (
                        colors.vLRisk
                      ) : '',
                      padding: 5,
                      borderRadius: 5,
                      marginHorizontal: 5
                    }}
                  >
                    <CustomTextBold style={{ color: colors.primaryReverse }}>FDA:</CustomTextBold>
                    <CustomTextBold style={{ color: colors.primaryReverse }}>
                      {item.pregnancy_fda}
                    </CustomTextBold>
                  </View>
                )}
                {item.pregnancy_au && (
                  <View
                    style={{
                      backgroundColor: item.pregnancy_au.includes('N') ? (
                        colors.unRisk
                      ) : item.pregnancy_au.includes('X') ? (
                        colors.vHRisk
                      ) : item.pregnancy_au.includes('D') ? (
                        colors.hRisk
                      ) : item.pregnancy_au.includes('C') ? (
                        colors.mRisk
                      ) : item.pregnancy_au.includes('B') ? (
                        colors.lRisk
                      ) : item.pregnancy_au.includes('A') ? (
                        colors.vLRisk
                      ) : '',
                      padding: 5,
                      borderRadius: 5,
                      marginHorizontal: 5
                    }}
                  >
                    <CustomTextBold style={{ color: colors.primaryReverse }}>AUA</CustomTextBold>
                    <CustomTextBold style={{ color: colors.primaryReverse }}>
                      {item.pregnancy_au}
                    </CustomTextBold>
                  </View>
                )}
              </View>
              <View style={{ rowGap: 10, marginTop: 5 }}>
                {item.pregnancy_text ? (
                  <>
                    <Separator />
                    <CustomText style={{ paddingHorizontal: 5 }}>
                      {item.pregnancy_text}
                    </CustomText>
                  </>
                ) : null}
                {item.pregnancy_fda || item.pregnancy_au ? (
                  <Separator />
                ) : null}
                {item.pregnancy_fda ? (
                  <CustomText style={{ paddingHorizontal: 5 }}>
                    <CustomBold>FDA:</CustomBold> {item.pregnancy_fda.length === 1 ? riskTexts.fda[item.pregnancy_fda] : findCategoryRisk(item.pregnancy_fda, 'fda')}
                  </CustomText>
                ) : null}
                {item.pregnancy_au ? (
                  <CustomText style={{ paddingHorizontal: 5 }}>
                    <CustomBold>TGA:</CustomBold> {item.pregnancy_au.length === 1 ? riskTexts.fda[item.pregnancy_au] : findCategoryRisk(item.pregnancy_au, 'tga')}
                  </CustomText>
                ) : null}
                {item.pregnancy_refs && (
                  <>
                    <Separator />
                    <View style={{ paddingHorizontal: 5 }}>
                      <References
                        refs={item.pregnancy_refs}
                        flat
                        isRefOpen
                      />
                    </View>
                  </>
                )}
              </View>
            </Card>
          )
        }}
      />
    </SafeAreaView>
  )
}


const riskTexts: {
  fda: Record<string, string>,
  tga: Record<string, string>,
} = {
  fda: {
    'A': 'Нет риска. Хорошо контролируемые исследования с участием беременных женщин не выявили риска неблагоприятного воздействия на плод в течение первого триместра беременности (также нет доказанных рисков в других триместрах).\nПрименение: Возможно.',
    'B': 'Нет доказанного риска. Исследования на животных не выявили риска неблагоприятного воздействия на плод, и соответствующие исследования на беременных женщинах не проводились.\nПрименение: Возможно.',
    'C': 'Риск не исключен. Исследования на животных показали неблагоприятное воздействие препарата на плод, и адекватных исследований на беременных женщинах не проводилось, но потенциальная польза от использования этого препарата у беременных женщин может оправдать его использование, несмотря на риск.\nИспользуйте, если польза перевешивает риск.',
    'D': 'Риск доказан. Имеются данные о риске неблагоприятного воздействия препарата на плод человека, однако потенциальная польза, связанная с применением препарата у беременных женщин, может оправдать его применение, несмотря на риск.\nПрименение: при угрожающих жизни показаниях или, например, когда другие препараты не помогли.',
    'X': 'Противопоказан. Были выявлены аномалии плода или имеются данные о риске неблагоприятного воздействия этого препарата на плод человека, и поэтому риски этого препарата для плода перевешивают потенциальную пользу для беременной женщины.\nПрименение: Противопоказано.',
    'N': 'Данный препарат не классифицирован FDA.'
  },
  tga: {
    'A': 'Нет риска. Препарат, который использовался большим количеством беременных женщин и не приводил к увеличению частоты врожденных аномалий или других прямых или косвенных побочных эффектов на плод.',
    'B': 'Нет доказанного риска. Препарат, который применялся у ограниченного числа беременных женщин и не показал увеличения частоты врожденных аномалий или других прямых или косвенных неблагоприятных воздействий на плод.\nB1: Исследования на животных не выявили никаких доказательств увеличения случаев повреждения плода.\nB2: Исследования на животных могут быть неадекватными или недостаточными, но имеющиеся данные не указывают на увеличение случаев повреждения плода.\nB3: Исследования на животных показали, что частота повреждений плода увеличивается, но значение для людей неясно.',
    'C': 'Риск не исключен. Лекарственный препарат, которое нанесло вред плоду или новорожденному, не вызвав при этом отклонений, или которое может предположительно оказывать такое воздействие на основании его фармакологических свойств. Эти эффекты могут быть обратимыми.',
    'D': 'Риск доказан. Препараты, которые связаны с увеличением частоты аномалий плода или другого необратимого вреда для человека. Эти препараты также могут оказывать неблагоприятное фармакологическое действие.',
    'X': 'Противопоказан. Лекарственные средства, применение которых сопряжено с очень высоким риском нанесения необратимого вреда плоду и которые ни в коем случае не должны применяться во время беременности или в случае возможной беременности.',
  }
}
