import AngleRight from '@/src/components/AngleRight'
import Card from '@/src/components/Card'
import CustomIconSmall from '@/src/components/CustomIcons/CustomIconSmall'
import CustomBold from '@/src/components/CustomTexts/CustomBold'
import CustomText from '@/src/components/CustomTexts/CustomText'
import CustomTextBold from '@/src/components/CustomTexts/CustomTextBold'
import ErrorNet from '@/src/components/ErrorNet'
import Loader from '@/src/components/Loader/Loader'
import OpenAll from '@/src/components/OpenAll'
import References from '@/src/components/References'
import Separator from '@/src/components/Separator'
import TitleShare from '@/src/components/TitleShare'
import { fetchUseQuery } from '@/src/functions/fetchUseQuery'
import { useTheme } from '@/src/hooks/useTheme'
import { MainStackParamList } from '@/src/types/navigationTypes'
import { IResponseData, LINKS } from '@/src/types/types'
import { faRightLeft } from '@fortawesome/free-solid-svg-icons'
import { RouteProp, useRoute } from '@react-navigation/native'
import { useQuery } from '@tanstack/react-query'
import React, { useEffect, useState } from 'react'
import { FlatList, RefreshControl, SafeAreaView, StyleSheet, TouchableOpacity, View } from 'react-native'

type IDrugDisIntItem = {
   disease: string;
   class: string;
   text: string;
   risk: 'высокий' | 'средний' | 'низкий';
   refs: string[];
   label: string;
}

const riskTexts = {
   'высокий': "Максимальная клиническая значимость. Избегайте этого сочетания. Риск взаимодействия перевешивает пользу.",
   'средний': "Умеренная клиническая значимость. Обычно они избегают этого сочетания. использовать только в особых случаях.",
   'низкий': "Минимальная клиническая значимость. Минимизируйте риск. Оцените риск и рассмотрите возможность назначения другого препарата, постарайтесь избежать риска взаимодействия и/или разработайте план мониторинга.",
}

export default function DrugDisIntItem() {
   const { colors } = useTheme()
   const route = useRoute<RouteProp<MainStackParamList, 'DrugDisIntItem'>>()
   const { param } = route.params;
   const [openStates, setOpenStates] = useState<boolean[]>([]);

   const { isLoading, isError, data, isSuccess, refetch } = useQuery({
      queryKey: ['drugDisIntItem', param],
      queryFn: async () => {
         return fetchUseQuery<IResponseData<IDrugDisIntItem>>(
            'post',
            LINKS.DRUGDISEASE,
            param
         )
      },
      enabled: !!param,
      gcTime: 2000
   })

   useEffect(() => {
      if (data && isSuccess) {
         setOpenStates(Array(data.data.length).fill(false));
      }
   }, [data, isSuccess]);

   const toggleAll = (open: boolean) => {
      setOpenStates(Array(data?.data.length).fill(open));
   };

   const toggleOne = (index: number) => {
      const updated = [...openStates];
      updated[index] = !updated[index];
      setOpenStates(updated);
   };

   const onRefresh = React.useCallback(() => {
      refetch()
   }, [])

   if (isLoading) return <Loader />

   return (
      <SafeAreaView style={{ flex: 1, backgroundColor: colors.background }}>
         {data && data.data && data.data.length > 0 ? (
            <OpenAll
               openStates={openStates}
               toggleAll={toggleAll}
            />
         ) : null}
         <FlatList
            contentContainerStyle={{ padding: 15 }}
            refreshControl={
               <RefreshControl
                  refreshing={isLoading}
                  onRefresh={onRefresh}
                  colors={[colors.mainBg]}
                  progressBackgroundColor={colors.refreshProgressBarBg}
               />
            }
            ListHeaderComponent={
               <View>
                  <TitleShare
                     titleText={'Взаимодействие лекарств с заболеваниями'}
                  />
                  <View style={{ marginVertical: 15 }}>
                     <CustomTextBold style={styles.drugTitle}>
                        {data?.data[0].label} - болезнь взаимодействие
                     </CustomTextBold>
                     <CustomText>Найдено <CustomBold>{data?.data.length}</CustomBold> {data?.data.length === 1 ? `взаимодействие` : `взаимодействий`}</CustomText>
                  </View>
                  {isError ? <ErrorNet /> : null}
               </View>
            }
            data={data?.data ?? []}
            renderItem={({ item, index }) => {
               const isOpen = openStates[index];

               return (
                  <Card>
                     <TouchableOpacity
                        onPress={() => toggleOne(index)}
                        style={{ rowGap: 5 }}
                     >
                        <View
                           style={{
                              backgroundColor: item.risk === 'высокий' ? (
                                 colors.hRisk
                              ) : item.risk === 'средний' ? (
                                 colors.mRisk
                              ) : colors.lRisk,
                              alignSelf: 'flex-start',
                              borderRadius: 10,
                              paddingHorizontal: 3,
                              paddingVertical: 2
                           }}
                        >
                           <CustomTextBold style={{ color: colors.primaryReverse }}>
                              {item.risk}
                           </CustomTextBold>
                        </View>
                        <View
                           style={{
                              flexDirection: 'row',
                              justifyContent: 'space-between'
                           }}
                        >
                           <CustomTextBold style={{
                              color: isOpen ? colors.angleRightBlue : colors.primary, flex: 1
                           }}>
                              {item.disease}
                           </CustomTextBold>
                           <AngleRight
                              isActive={isOpen}
                              color={colors.angleRightBlue}
                           />
                        </View>
                     </TouchableOpacity>
                     {isOpen && (
                        <View style={{ rowGap: 10, marginTop: 5, opacity: isOpen ? 1 : 0 }}>
                           <Separator />
                           <View style={styles.cardClassContainer}>
                              <CustomTextBold>{item.class} ({item.label})</CustomTextBold>
                              <CustomIconSmall
                                 icon={faRightLeft}
                                 color={colors.primary}
                              />
                              <CustomTextBold>{item.disease}</CustomTextBold>
                           </View>
                           <CustomText>
                              {item.text}
                           </CustomText>
                           <Separator />
                           <CustomText>
                              {riskTexts[item.risk]}
                           </CustomText>
                           <Separator />
                           <References
                              refs={item.refs}
                              flat
                              isRefOpen
                           />
                        </View>
                     )}
                  </Card>
               )
            }}
            ItemSeparatorComponent={() => <View style={{ marginVertical: 5 }} />}
         />
      </SafeAreaView>
   )
}

const styles = StyleSheet.create({
   drugTitle: {
      marginBottom: 10,
      textTransform: 'capitalize'
   },
   cardClassContainer: {
      rowGap: 7,
   },
})
