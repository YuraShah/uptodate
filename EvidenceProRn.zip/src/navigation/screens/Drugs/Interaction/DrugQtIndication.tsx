import CustomBold from '@/src/components/CustomTexts/CustomBold'
import CustomText from '@/src/components/CustomTexts/CustomText'
import CustomTextBold from '@/src/components/CustomTexts/CustomTextBold'
import ErrorNet from '@/src/components/ErrorNet'
import Loader from '@/src/components/Loader/Loader'
import MenuList from '@/src/components/MenuList'
import OpenAll from '@/src/components/OpenAll'
import SelectAsyncComponent from '@/src/components/SelectComponent/SelectAsyncComponent'
import SeparatorDash from '@/src/components/SeparatorDash'
import Separator from '@/src/components/Separator'
import TitleShare from '@/src/components/TitleShare'
import { fetchUseQuery } from '@/src/functions/fetchUseQuery'
import { useTheme } from '@/src/hooks/useTheme'
import { IResponseData, LINKS } from '@/src/types/types'
import { useQuery } from '@tanstack/react-query'
import React, { useEffect, useMemo, useState } from 'react'
import { FlatList, RefreshControl, SafeAreaView, useWindowDimensions, View } from 'react-native'

type IDrugQtIndication = {
  id: string,
  indication: string,
  qt: string,
  non_qt: string,
}

export default function DrugQtIndication() {
  const { colors } = useTheme()
  const { width } = useWindowDimensions()
  const [inpValue, setInpValue] = useState<string>('')
  const [openStates, setOpenStates] = useState<boolean[]>([]);

  const toggleOpen = (index: number) => {
    const updated = [...openStates];
    updated[index] = !updated[index];
    setOpenStates(updated);
  };

  const toggleAll = (open: boolean) => {
    setOpenStates(Array(data?.data.length).fill(open));
  };

  const { isLoading, isError, data, refetch, isSuccess } = useQuery({
    queryKey: ['drugQtIndication'],
    queryFn: async () => {
      return fetchUseQuery<IResponseData<IDrugQtIndication>>(
        'post',
        LINKS.DRUGQTINDICATION,
      )
    },
    gcTime: 2000
  })

  const filteredData = useMemo(() => {
    const list = data?.data ?? []
    if (!inpValue.trim()) return list

    return list.filter(item =>
      item.indication.toLowerCase().includes(inpValue.trim().toLowerCase())
    )
  }, [inpValue, data])

  useEffect(() => {
    if (data && isSuccess) {
      setOpenStates(Array(data.data.length).fill(false));
    }
  }, [data, isSuccess]);

  const onRefresh = React.useCallback(() => {
    setInpValue('')
    refetch()
    setOpenStates(new Array(filteredData.length).fill(false));
  }, [])


  if (isLoading) return <Loader />

  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: colors.background }}>
      {data && data.data && data.data.length > 0 ? (
        <OpenAll
          openStates={openStates}
          toggleAll={toggleAll}
        />
      ) : null}
      <FlatList
        contentContainerStyle={{ paddingVertical: 15 }}
        refreshControl={
          <RefreshControl
            refreshing={isLoading}
            onRefresh={onRefresh}
            colors={[colors.mainBg]}
            progressBackgroundColor={colors.refreshProgressBarBg}
          />
        }
        ListHeaderComponent={
          <View style={{ paddingHorizontal: 15 }}>
            <TitleShare
              titleText={'Варианты лечения без препаратов QT'}
            />
            <SelectAsyncComponent
              inpValue={inpValue}
              setInpValue={setInpValue}
              windowWidth={width}
              placeholder={`Напишите показание (≥3 буквы)`}
            />
            {isError ? <ErrorNet /> : null}
          </View>
        }
        data={filteredData}
        renderItem={({ item, index }) => {
          const isOpen = openStates[index]

          return (
            <MenuList
              title={item.indication}
              onPress={() => toggleOpen(index)}
              color={colors.angleRightBlue}
              angleColor={colors.angleRightBlue}
              isActive={isOpen}
              children={isOpen ? (
                <View style={{ rowGap: 10, marginTop: 10 }}>
                  <View>
                    <CustomTextBold>QT-лекарства</CustomTextBold>
                    <CustomText>
                      {item.qt}
                    </CustomText>
                  </View>
                  <SeparatorDash isMarginHorizontal />
                  <View>
                    <CustomTextBold>Не QT-лекарства</CustomTextBold>
                    <CustomText>
                      {item.non_qt}
                    </CustomText>
                  </View>
                </View>
              ) : undefined}
            />
          )
        }}
        ItemSeparatorComponent={() => <Separator />}
        keyExtractor={item => item.id}
        ListEmptyComponent={() => <CustomText style={{ paddingHorizontal: 15 }}>Не найдено совпадений</CustomText>}
      />
    </SafeAreaView>
  )
}
