import Card from '@/src/components/Card'
import CustomText from '@/src/components/CustomTexts/CustomText'
import CustomTextBold from '@/src/components/CustomTexts/CustomTextBold'
import CustomTextSmallBold from '@/src/components/CustomTexts/CustomTextSmallBold'
import ErrorNet from '@/src/components/ErrorNet'
import Loader from '@/src/components/Loader/Loader'
import References from '@/src/components/References'
import SelectAsyncComponent from '@/src/components/SelectComponent/SelectAsyncComponent'
import Separator from '@/src/components/Separator'
import TitleShare from '@/src/components/TitleShare'
import { fetchUseQuery } from '@/src/functions/fetchUseQuery'
import { useTheme } from '@/src/hooks/useTheme'
import { IResponseData, LINKS } from '@/src/types/types'
import { FlashList } from '@shopify/flash-list'
import { useQuery } from '@tanstack/react-query'
import React, { useMemo, useState } from 'react'
import { RefreshControl, SafeAreaView, useWindowDimensions, View } from 'react-native'

type IDrugMethem = {
  id: string,
  label: string,
  methem_text?: string,
  methem_refs?: string[]
}

export default function DrugMethem() {
  const { colors } = useTheme()
  const { width } = useWindowDimensions()
  const [inpValue, setInpValue] = useState<string>('')

  const { isLoading, isError, data, isSuccess, refetch } = useQuery({
    queryKey: ['drugDisl'],
    queryFn: async () => {
      return fetchUseQuery<IResponseData<IDrugMethem>>(
        'post',
        LINKS.DRUGMETHEM,
      )
    },
    gcTime: 2000
  })

  const filteredData = useMemo(() => {
    const list = data?.data ?? []
    if (!inpValue.trim()) return list

    return list.filter(item =>
      item.label.toLowerCase().includes(inpValue.trim().toLowerCase())
    )
  }, [inpValue, data])

  const onRefresh = React.useCallback(() => {
    setInpValue('')
    refetch()
  }, [])


  if (isLoading) return <Loader />

  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: colors.background }}>
      <FlashList
        refreshControl={
          <RefreshControl
            refreshing={isLoading}
            onRefresh={onRefresh}
            colors={[colors.mainBg]}
            progressBackgroundColor={colors.refreshProgressBarBg}
          />
        }
        contentContainerStyle={{ padding: 15 }}
        ListHeaderComponent={
          <View style={{ marginBottom: 10 }}>
            <TitleShare
              titleText={' Лекарства, вызывающие метгемоглобинемию'}
            />
            <SelectAsyncComponent
              inpValue={inpValue}
              setInpValue={setInpValue}
              windowWidth={width}
              placeholder={`Напишите препарат (≥3 буквы)`}
            />
            <View style={{ marginTop: -10 }}>
              <CustomTextSmallBold>MeHb - метгемоглобинемия</CustomTextSmallBold>
            </View>
            {isError ? <ErrorNet /> : null}
          </View>
        }
        data={filteredData}
        renderItem={({ item }) => (
          <Card isPadding>
            <CustomTextBold style={{ textTransform: 'capitalize', paddingHorizontal: 5, paddingBottom: 5 }}>
              {item.label}
            </CustomTextBold>
            {item.methem_text ? (
              <>
                <Separator />
                <CustomText style={{ padding: 5 }}>
                  {item.methem_text}
                </CustomText>
              </>
            ) : null}
            {item.methem_refs ? (
              <>
                <Separator />
                <View style={{ paddingHorizontal: 5 }}>
                  <References
                    refs={item.methem_refs}
                    isRefOpen
                  />
                </View>
              </>
            ) : null}
          </Card>
        )}
        ItemSeparatorComponent={() => <View style={{ marginVertical: 5 }} />}
        estimatedItemSize={80}
        ListEmptyComponent={isSuccess ? <CustomText>Не найдено совпадений</CustomText> : null}
      />
    </SafeAreaView>
  )
}
