import { fetchUseQuery } from '@/src/functions/fetchUseQuery';
import { useTheme } from '@/src/hooks/useTheme';
import { MainStackParamList } from '@/src/types/navigationTypes';
import { IResponseData, LINKS } from '@/src/types/types';
import { RouteProp, useNavigation, useRoute } from '@react-navigation/native';
import { useQuery } from '@tanstack/react-query';
import React from 'react'
import { IDrugNephtoxOtherItem } from './DrugNephtoxDiseaseItem';
import Loader from '@/src/components/Loader/Loader';
import { FlatList, RefreshControl, SafeAreaView, View } from 'react-native';
import TitleShare from '@/src/components/TitleShare';
import CustomText from '@/src/components/CustomTexts/CustomText';
import ErrorNet from '@/src/components/ErrorNet';
import Separator from '@/src/components/Separator';
import MenuList from '@/src/components/MenuList';
import CustomTextBold from '@/src/components/CustomTexts/CustomTextBold';

export default function DrugNephtoxMorphologyItem() {
  const { colors } = useTheme()
  const route = useRoute<RouteProp<MainStackParamList, 'DrugNephtoxMorphologyItem'>>()
  const { param } = route.params;
  const navigation = useNavigation()

  const { isLoading, isError, data, isSuccess, refetch } = useQuery({
    queryKey: ['drugNephtoxMorphologyItem', param],
    queryFn: async () => {
      return fetchUseQuery<IResponseData<IDrugNephtoxOtherItem>>(
        'get',
        `${LINKS.DRUGNEPHTOXMORPHOLOGY}/${param}`,
      )
    },
    enabled: !!param,
    gcTime: 2000
  })

  const onRefresh = React.useCallback(() => {
    refetch()
  }, [])


  if (isLoading) return <Loader />

  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: colors.background }}>
      <FlatList
        contentContainerStyle={{ paddingVertical: 15 }}
        refreshControl={
          <RefreshControl
            refreshing={isLoading}
            onRefresh={onRefresh}
            colors={[colors.mainBg]}
            progressBackgroundColor={colors.refreshProgressBarBg}
          />
        }
        ListHeaderComponent={
          <View style={{ paddingHorizontal: 15 }}>
            <TitleShare
              titleText={'Морфологические болезни'}
            />
            {data && data.data ? (
              <View style={{ marginBottom: 5, marginTop: 20 }}>
                <CustomTextBold>
                  {data.data[0].name}
                </CustomTextBold>
              </View>
            ) : null}
            {isError ? <ErrorNet /> : null}
          </View>
        }
        data={data?.data[0]?.drugs ?? []}
        renderItem={({ item }) => (
          <MenuList
            title={item.label}
            onPress={() => navigation.navigate('Home', {
              screen: "DrugNephtoxItem",
              params: { param: `${item.link}:${item.id}` }
            })}
          />
        )}
        keyExtractor={item => item.id}
        ItemSeparatorComponent={() => <Separator />}
        ListEmptyComponent={isSuccess ? <CustomText style={{ paddingHorizontal: 15 }}>-</CustomText> : null}
      />
    </SafeAreaView>
  )
}
