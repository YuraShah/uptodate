import CustomTextBold from '@/src/components/CustomTexts/CustomTextBold';
import ErrorNet from '@/src/components/ErrorNet';
import Loader from '@/src/components/Loader/Loader';
import MenuList from '@/src/components/MenuList';
import Separator from '@/src/components/Separator';
import TitleShare from '@/src/components/TitleShare';
import { fetchUseQuery } from '@/src/functions/fetchUseQuery';
import { useTheme } from '@/src/hooks/useTheme';
import { MainStackParamList } from '@/src/types/navigationTypes';
import { IResponseData, LINKS } from '@/src/types/types';
import { RouteProp, useNavigation, useRoute } from '@react-navigation/native';
import { useQuery } from '@tanstack/react-query';
import React from 'react'
import { FlatList, View, SafeAreaView, RefreshControl } from 'react-native';


export type IDrugNephtoxOtherItem = {
  name: string,
  drugs: {
    id: string,
    value: string,
    label: string,
    link: string
  }[]
}

export default function DrugNephtoxDiseaseItem() {
  const { colors } = useTheme()
  const route = useRoute<RouteProp<MainStackParamList, 'DrugNephtoxDiseaseItem'>>()
  const { param } = route.params;
  const navigation = useNavigation()

  const { isLoading, isError, data, isSuccess, refetch } = useQuery({
    queryKey: ['drugNephtoxDiseaseItem', param],
    queryFn: async () => {
      return fetchUseQuery<IResponseData<IDrugNephtoxOtherItem>>(
        'get',
        `${LINKS.DRUGNEPHTOXDISEASE}/${param}`,
      )
    },
    enabled: !!param,
    gcTime: 2000
  })

  const onRefresh = React.useCallback(() => {
    refetch()
  }, [])


  if (isLoading) return <Loader />

  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: colors.background }}>
      <FlatList
        contentContainerStyle={{ paddingVertical: 15 }}
        refreshControl={
          <RefreshControl
            refreshing={isLoading}
            onRefresh={onRefresh}
            colors={[colors.mainBg]}
            progressBackgroundColor={colors.refreshProgressBarBg}
          />
        }
        ListHeaderComponent={
          <View style={{ paddingHorizontal: 15 }}>
            <TitleShare
              titleText={'Клинические болезни'}
            />
            {data && data.data ? (
              <View style={{ marginBottom: 5, marginTop: 20 }}>
                <CustomTextBold>
                  {data.data[0].name}
                </CustomTextBold>
              </View>
            ) : null}
            {isError ? <ErrorNet /> : null}
          </View>
        }
        data={data?.data[0]?.drugs ?? []}
        renderItem={({ item }) => (
          <MenuList
            title={item.label}
            onPress={() => navigation.navigate('Home', {
              screen: "DrugNephtoxItem",
              params: { param: `${item.link}:${item.id}` }
            })}
          />
        )}
        keyExtractor={item => item.id}
        ItemSeparatorComponent={() => <Separator />}
      />
    </SafeAreaView>
  )
}
