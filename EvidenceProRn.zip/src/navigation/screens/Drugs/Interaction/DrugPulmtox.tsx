import Menu from '@/src/components/Menu'
import { IMenuList } from '@/src/types/types'
import React from 'react'


export default function DrugPulmtox() {
  return (
    <Menu
      data={pulmtoxList}
      headerTitle='Взаимодействие лекарств с дыхательной системой'
    />
  )
}


const pulmtoxList: IMenuList[] = [
  {
    name: "Лекарства",
    link: "DrugPulmtoxDrug"
  },
  {
    name: "Другие субстанции/вмешательства",
    link: "DrugPulmtoxSubstance"
  },
  {
    name: "Заболевания/состояния",
    link: "DrugPulmtoxPattern"
  }
]
