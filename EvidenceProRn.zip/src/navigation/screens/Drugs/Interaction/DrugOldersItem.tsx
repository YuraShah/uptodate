import Accordion from '@/src/components/Accordion'
import CustomText from '@/src/components/CustomTexts/CustomText'
import CustomTextBold from '@/src/components/CustomTexts/CustomTextBold'
import CustomTextBoldItalic from '@/src/components/CustomTexts/CustomTextBoldItalic'
import CustomTextLargeBold from '@/src/components/CustomTexts/CustomTextLargeBold'
import ErrorNet from '@/src/components/ErrorNet'
import Loader from '@/src/components/Loader/Loader'
import SeparatorDash from '@/src/components/SeparatorDash'
import Separator from '@/src/components/Separator'
import TitleShare from '@/src/components/TitleShare'
import { fetchUseQuery } from '@/src/functions/fetchUseQuery'
import { useTheme } from '@/src/hooks/useTheme'
import { MainStackParamList } from '@/src/types/navigationTypes'
import { IResponseData, LINKS } from '@/src/types/types'
import { RouteProp, useRoute } from '@react-navigation/native'
import { useQuery } from '@tanstack/react-query'
import React from 'react'
import { FlatList, RefreshControl, SafeAreaView, View } from 'react-native'

export type IB1 = {
  indication?: string,
  quality_evidence: string,
  strong_recommendation: string
  recommendation: string,
  avoid: string
}
export type IB2 = {
  quality_evidence: string,
  strong_recommendation: string,
  disease: string,
  recommendation: string,
  avoid: string
}
export type IB3 = {
  quality_evidence: string,
  strong_recommendation: string,
  interaction: string,
  recommendation: string,
  avoid: string
}
export type IB4 = {
  indication?: string,
  quality_evidence: string,
  strong_recommendation: string,
  recommendation: string,
  avoid: string
}
export type IB5 = {
  quality_evidence: string,
  strong_recommendation: string,
  crcl: string,
  recommendation: string,
  avoid: string
}

type IDrugOldersItem = {
  id: string,
  label: string,
  older_beers_1: IB1,
  older_beers_2: IB2,
  older_beers_3: IB3,
  older_beers_4: IB4,
  older_beers_5: IB5,
  older_text: string
}

const BeersItem = ({
  headerTitle,
  children,
  lastItem
}: {
  headerTitle: string,
  children: React.ReactNode,
  lastItem?: boolean
}) => (
  <View style={{
    paddingHorizontal: 15,
    marginBottom: lastItem ? 0 : 10,
  }}>
    <Accordion
      header={
        <CustomTextBold>
          {headerTitle}
        </CustomTextBold>
      }
      content={
        <View style={{ rowGap: 10 }}>
          {children}
        </View>
      }
    />
    {lastItem ? null : (
      <>
        <View style={{ marginVertical: 2 }} />
        <SeparatorDash
          isMarginHorizontal
        />
      </>
    )}
  </View>
)

export default function DrugOldersItem() {
  const { colors } = useTheme()
  const route = useRoute<RouteProp<MainStackParamList, 'DrugOldersItem'>>()
  const { param } = route.params;

  const { isLoading, isError, data, refetch } = useQuery({
    queryKey: ['drugOldersItem', param],
    queryFn: async () => {
      return fetchUseQuery<IResponseData<IDrugOldersItem>>(
        'post',
        LINKS.DRUGOLDERS,
        param
      )
    },
    enabled: !!param,
    gcTime: 2000
  })

  const beersElement = (
    title: string,
    text: string
  ) => {
    return (
      <View>
        <CustomTextBoldItalic>
          {title}
        </CustomTextBoldItalic>
        <CustomText>
          {text}
        </CustomText>
        {title === 'Качество доказательств:' ? (
          <CustomText>
            {oldersQuality.qualityEvidence[text]}
          </CustomText>
        ) : title === 'Сила рекомендаций:' ? (
          <CustomText>
            {oldersQuality.recommendation[text]}
          </CustomText>
        ) : null}
      </View>
    )
  }

  const onRefresh = React.useCallback(() => {
    refetch()
  }, [])

  if (isLoading) return <Loader />

  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: colors.background }}>
      <FlatList
        contentContainerStyle={{ paddingVertical: 15 }}
        refreshControl={
          <RefreshControl
            refreshing={isLoading}
            onRefresh={onRefresh}
            colors={[colors.mainBg]}
            progressBackgroundColor={colors.refreshProgressBarBg}
          />
        }
        ListHeaderComponent={
          <View style={{ paddingHorizontal: 15 }}>
            <TitleShare
              titleText={'Особенности дозирования лекарственных препаратов у пожилых людей (≥65)'}
            />
            {isError ? < ErrorNet /> : null}
          </View>
        }
        data={data?.data ?? []}
        renderItem={({ item }) => (
          <View style={{ marginVertical: 15 }}>
            <CustomTextLargeBold style={{
              paddingHorizontal: 15,
              textTransform: 'capitalize',
              marginBottom: 5
            }}>
              {item.label}
            </CustomTextLargeBold>
            {item.older_text && (
              <>
                <CustomText
                  style={{
                    paddingHorizontal: 15,
                    marginBottom: 15
                  }}
                >
                  {item.older_text}
                </CustomText>
              </>
            )}
            {(item.older_beers_1 || item.older_beers_2 || item.older_beers_3 || item.older_beers_4 || item.older_beers_5) && (
              <>
                <Separator />
                <CustomTextBold
                  style={{
                    paddingHorizontal: 15,
                    marginBottom: 5,
                    marginTop: 15,
                  }}
                >
                  Критерии Бирса
                </CustomTextBold>
              </>
            )}
            {item.older_beers_1 && (
              <BeersItem
                headerTitle='1. Потенциально нежелательные лекарства для пожилых'
                children={
                  <>
                    {item.older_beers_1.indication && (
                      beersElement('Показания:', item?.older_beers_1?.indication)
                    )}
                    {beersElement('Обоснование:', item.older_beers_1.recommendation)}
                    {beersElement('Советы:', item.older_beers_1.avoid)}
                    {beersElement('Качество доказательств:', item.older_beers_1.quality_evidence)}
                    {beersElement('Сила рекомендаций:', item.older_beers_1.strong_recommendation)}
                  </>
                }
              />
            )}
            {item.older_beers_2 && (
              <BeersItem
                headerTitle='2. Лекарства, противопоказанные пожилым с некоторыми заболеваниями'
                children={
                  <>
                    {beersElement('Заболевание или синдром:', item.older_beers_2.disease)}
                    {beersElement('Обоснование:', item.older_beers_2.recommendation)}
                    {beersElement('Советы:', item.older_beers_2.avoid)}
                    {beersElement('Качество доказательств:', item.older_beers_2.quality_evidence)}
                    {beersElement('Сила рекомендаций:', item.older_beers_2.strong_recommendation)}
                  </>
                }
              />
            )}
            {item.older_beers_3 && (
              <BeersItem
                headerTitle='3. Потенциальные клинически значимые лекарственные взаимодействия, которых следует избегать у пожилых'
                children={
                  <>
                    {beersElement('Взаимодействующий препарат:', item.older_beers_3.interaction)}
                    {beersElement('Обоснование:', item.older_beers_3.recommendation)}
                    {beersElement('Советы:', item.older_beers_3.avoid)}
                    {beersElement('Качество доказательств:', item.older_beers_3.quality_evidence)}
                    {beersElement('Сила рекомендаций:', item.older_beers_3.strong_recommendation)}
                  </>
                }
              />
            )}
            {item.older_beers_4 && (
              <BeersItem
                headerTitle='4. Лекарства, побочные эффекты которых могут быть потенциально опасны для пожилых'
                children={
                  <>
                    {item.older_beers_4.indication && (
                      beersElement('Показание:', item.older_beers_4.indication)
                    )}
                    {beersElement('Обоснование:', item.older_beers_4.recommendation)}
                    {beersElement('Советы:', item.older_beers_4.avoid)}
                    {beersElement('Качество доказательств:', item.older_beers_4.quality_evidence)}
                    {beersElement('Сила рекомендаций:', item.older_beers_4.strong_recommendation)}
                  </>
                }
              />
            )}
            {item.older_beers_5 && (
              <BeersItem
                headerTitle='5. Лекарственные препараты, которых следует избегать или уменьшать их дозы у пожилых с различной степенью почечной недостаточности'
                children={
                  <>
                    {beersElement('Клиренс креатинина (CrCl):', item.older_beers_5.crcl)}
                    {beersElement('Обоснование:', item.older_beers_5.recommendation)}
                    {beersElement('Советы:', item.older_beers_5.avoid)}
                    {beersElement('Качество доказательств:', item.older_beers_5.quality_evidence)}
                    {beersElement('Сила рекомендаций:', item.older_beers_5.strong_recommendation)}
                  </>
                }
                lastItem
              />
            )}
          </View>
        )}
        keyExtractor={item => item.id}
      />
    </SafeAreaView>
  )
}


const oldersQuality: {
  qualityEvidence: Record<string, string>, recommendation: Record<string, string>
} = {
  qualityEvidence: {
    'Высокий': "Получен из 1 или более хорошо спланированных и проведенных рандомизированных контролируемых исследований.",
    'Средний': "Получено из рандомизированных контролируемых исследований с важными ограничениями. Кроме того, эта группа включает в себя хорошо спланированные нерандомизированные контролируемые исследования, хорошо спланированный когортный анализ или исследования случай-контроль, а также серии случаев.",
    'Низкий': "Получено из наблюдательных исследований.",
  },
  recommendation: {
    'Сильный': "Вред, нежелательные явления и риски явно перевешивают пользу.",
    'Слабый': "Вред, нежелательные явления и риски могут не перевешивать пользу.",
  }
}
