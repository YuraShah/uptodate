import CustomText from '@/src/components/CustomTexts/CustomText';
import CustomTextBold from '@/src/components/CustomTexts/CustomTextBold';
import ErrorNet from '@/src/components/ErrorNet';
import Loader from '@/src/components/Loader/Loader';
import TitleShare from '@/src/components/TitleShare';
import { fetchUseQuery } from '@/src/functions/fetchUseQuery';
import { useTheme } from '@/src/hooks/useTheme';
import { MainStackParamList } from '@/src/types/navigationTypes';
import { IResponseData, LINKS } from '@/src/types/types';
import { faLink } from '@fortawesome/free-solid-svg-icons';
import { RouteProp, useNavigation, useRoute } from '@react-navigation/native';
import { useQuery } from '@tanstack/react-query';
import React, { useState } from 'react'
import { FlatList, RefreshControl, SafeAreaView, TouchableOpacity, View } from 'react-native';
import { cases } from './DrugPulmtoxSubpattern';
import CustomTextBoldItalic from '@/src/components/CustomTexts/CustomTextBoldItalic';
import Separator from '@/src/components/Separator';
import SeparatorDash from '@/src/components/SeparatorDash';
import Card from '@/src/components/Card';
import AngleRight from '@/src/components/AngleRight';
import CustomTextNoFont from '@/src/components/CustomTexts/CustomTextNoFont';
import { FontAwesomeIcon } from '@fortawesome/react-native-fontawesome';

type IDrugPulmtoxItem = {
  id: string,
  label: string,
  pulmtox_cases: string,
  pulmtox_subpatterns: {
    subpattern_id: number,
    subpattern_number: string,
    pattern_id: number,
    subpattern_title: string,
  }[],
  pulmtox_subpatterns_cases: string[],
  pulmtox_refs: {
    pulmtox_ref_group: {
      pulmtox_ref_title: string,
      pulmtox_ref_link: string,
    }[]
  }[],
}

export default function DrugPulmtoxItem() {
  const { colors } = useTheme()
  const route = useRoute<RouteProp<MainStackParamList, 'DrugPulmtoxItem'>>()
  const { param } = route.params;
  const navigation = useNavigation()
  const [expandedItems, setExpandedItems] = useState<{ [key: number]: boolean }>({});

  const { isLoading, isError, data, isSuccess, refetch } = useQuery({
    queryKey: ['drugPulmtoxItem', param],
    queryFn: async () => {
      return fetchUseQuery<IResponseData<IDrugPulmtoxItem>>(
        'get',
        `${LINKS.DRUGPULMTOX}/${param}`,
      )
    },
    enabled: !!param,
    gcTime: 2000
  })

  const toggleExpand = (id: number) => {
    setExpandedItems(prev => ({
      ...prev,
      [id]: !prev[id],
    }));
  };

  const onRefresh = React.useCallback(() => {
    refetch()
  }, [])


  if (isLoading) return <Loader />

  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: colors.background }}>
      <FlatList
        contentContainerStyle={{ padding: 15 }}
        refreshControl={
          <RefreshControl
            refreshing={isLoading}
            onRefresh={onRefresh}
            colors={[colors.mainBg]}
            progressBackgroundColor={colors.refreshProgressBarBg}
          />
        }
        ListHeaderComponent={
          <View>
            <TitleShare
              titleText={'Взаимодействие лекарств с дыхательной системой'}
            />
            {data && data.data ? (
              <View style={{ marginVertical: 10 }}>
                <CustomTextBold style={{ textTransform: 'capitalize' }}>
                  {data.data[0].label}
                </CustomTextBold>
                <CustomTextBoldItalic>
                  {cases[data.data[0].pulmtox_cases]}
                </CustomTextBoldItalic>
              </View>
            ) : null}
            {isError ? <ErrorNet /> : null}
          </View>
        }
        ListEmptyComponent={isSuccess ? <CustomText>Не найдено</CustomText> : null}
        data={data?.data[0]?.pulmtox_subpatterns ?? []}
        renderItem={({ item, index }) => {
          const currentPattern = patternList[item.pattern_id];
          const currentClassNumber = currentPattern.class_number;
          const currentClassTitle = currentPattern.class_title;

          const prevItem = index > 0 ? data!.data[0].pulmtox_subpatterns[index - 1] : null;
          const prevPatternId = prevItem?.pattern_id;

          const showHeader = item.pattern_id !== prevPatternId;

          return (
            <View>
              {showHeader && (
                <CustomTextBold style={{ marginVertical: 8, color: colors.angleRightBlue }}>
                  {currentClassNumber + ' - ' + currentClassTitle}
                </CustomTextBold>
              )}
              <Card
                isPadding
              >
                <TouchableOpacity
                  onPress={() => navigation.navigate('Home', {
                    screen: 'DrugPulmtoxSubpattern',
                    params: {
                      param: item.subpattern_id.toString()
                    }
                  })}
                  style={{
                    flexDirection: 'row',
                    justifyContent: 'space-between',
                    alignItems: 'center',
                    paddingHorizontal: 5,
                    paddingBottom: 5
                  }}
                >
                  <View style={{ rowGap: 5, flex: 1 }}>
                    <CustomTextBold>
                      {item.subpattern_number}
                    </CustomTextBold>
                    <CustomText>
                      {item.subpattern_title}
                    </CustomText>
                  </View>
                  <AngleRight />
                </TouchableOpacity>
                <Separator />
                <CustomTextBoldItalic style={{ paddingHorizontal: 5, paddingVertical: 2 }}>
                  {cases[data!.data[0].pulmtox_subpatterns_cases[index]]}
                </CustomTextBoldItalic>
                <Separator />
                <TouchableOpacity
                  onPress={() => toggleExpand(item.subpattern_id)}
                  style={{ paddingHorizontal: 5 }}
                >
                  <CustomTextBold style={{ color: colors.othTitle }}>
                    Ссылки
                  </CustomTextBold>
                </TouchableOpacity>
                {expandedItems[item.subpattern_id] && (
                  <FlatList
                    data={data?.data[0]?.pulmtox_refs[index]?.pulmtox_ref_group ?? []}
                    renderItem={({ item: refs, index: refIndex }) => (
                      <View style={{ paddingHorizontal: 5 }}>
                        <TouchableOpacity
                          onPress={() => navigation.navigate('Home', {
                            screen: 'WebView',
                            params: {
                              url: refs.pulmtox_ref_link
                            }
                          })}
                          style={{ paddingVertical: 7 }}
                        >
                          <CustomTextNoFont style={{ fontSize: 15 }}>
                            {refIndex + 1}. {refs.pulmtox_ref_title} <FontAwesomeIcon icon={faLink} size={15} color={colors.primary}/>
                          </CustomTextNoFont>
                        </TouchableOpacity>
                      </View>
                    )}
                    ItemSeparatorComponent={() => <SeparatorDash isMarginHorizontal />
                    }
                  />
                )}
              </Card>
            </View>
          )
        }}
        keyExtractor={item => item.subpattern_id.toString()}
        ItemSeparatorComponent={() => <View style={{ marginVertical: 5 }} />}
      />
    </SafeAreaView>
  )
}


const patternList:
  Record<string, { class_number: string; class_title: string }>
  = {
  1: {
    "class_number": "I",
    "class_title": "Интерстициальное/паренхиматозное заболевание легких"
  },
  2: {
    "class_number": "II",
    "class_title": "Отек легких - Острое повреждение легких - Острый респираторный дистресс-синдром"
  },
  3: {
    "class_number": "III",
    "class_title": "Легочное, альвеолярное кровотечение или кровотечение из дыхательных путей (геморрагия)"
  },
  4: {
    "class_number": "IV",
    "class_title": "Поражения дыхательных путей"
  },
  5: {
    "class_number": "V",
    "class_title": "Поражение плевры и/или перикарда"
  },
  6: {
    "class_number": "VI",
    "class_title": "Легочные васкулопатии"
  },
  7: {
    "class_number": "VII",
    "class_title": "Повреждение средостения"
  },
  8: {
    "class_number": "VIII",
    "class_title": "Поражения центральных, крупных и верхних дыхательных путей (включая носоглотку)"
  },
  9: {
    "class_number": "IX",
    "class_title": "Нервно-мышечные расстройства/Расстройства центральной нервной системы - Нарушение дыхания во сне"
  },
  10: {
    "class_number": "X",
    "class_title": "Системные/отдаленные состояния, синдромы и реакции"
  },
  11: {
    "class_number": "XI",
    "class_title": "Другие"
  },
  12: {
    "class_number": "XII",
    "class_title": "Сердечно-сосудистые повреждения/токсичность"
  },
  13: {
    "class_number": "XIII",
    "class_title": "Опухолевые заболевания"
  },
  14: {
    "class_number": "XIV",
    "class_title": "Гемоглобинопатии – Аномальные состояния гемоглобина (приобретенные)"
  },
  15: {
    "class_number": "XV",
    "class_title": "Патология"
  },
  16: {
    "class_number": "XVI",
    "class_title": "Визуализация"
  },
  17: {
    "class_number": "XVII",
    "class_title": "Инфекции и связанные с ними состояния"
  },
  18: {
    "class_number": "XVIII",
    "class_title": "«Требующие внимания» картины (ТВК)"
  },
  19: {
    "class_number": "XIX",
    "class_title": "Цитологические и биохимические признаки бронхоальвеолярного лаважа, плевральной жидкости или тонкоигольной аспирационной биопсии"
  },
  20: {
    "class_number": "XX",
    "class_title": "Лекарственные и ятрогенные респираторные заболевания у детей",
  },
  21: {
    "class_number": "XXI",
    "class_title": "Данные о повторном назначении"
  },
  22: {
    "class_number": "XXII",
    "class_title": "Лекарственные препараты, соединения и химикаты, хранящиеся дома и вызывающие беспокойство"
  },
  23: {
    "class_number": "XXIII",
    "class_title": "Проблемы при искусственной вентиляции легких"
  },
  24: {
    "class_number": "XXIV",
    "class_title": "Ветеринарная медицина"
  },
  25: {
    "class_number": "XXV",
    "class_title": "Отравление через доверенное лицо"
  },
}
