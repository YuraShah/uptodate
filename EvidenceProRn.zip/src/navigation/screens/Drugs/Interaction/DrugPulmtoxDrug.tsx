import SearchList from '@/src/components/SearchList'
import { fetchUseQuery } from '@/src/functions/fetchUseQuery'
import { IDrugLabel, IResponseData, LINKS } from '@/src/types/types'
import { useQuery } from '@tanstack/react-query'
import React from 'react'

export default function DrugPulmtoxDrug() {
  const { isLoading, isError, data, isSuccess, refetch } = useQuery({
    queryKey: ['drugPulmtoxDrug'],
    queryFn: async () => {
      return fetchUseQuery<IResponseData<IDrugLabel>>(
        'post',
        LINKS.DRUGPULMTOXLIST,
        'лекарство'
      )
    },
    gcTime: 2000
  })

  return (
    <SearchList
      data={data}
      refetch={refetch}
      isLoading={isLoading}
      isError={isError}
      isSuccess={isSuccess}
      screen="DrugPulmtoxItem"
      title='Взаимодействие лекарств с дыхательной системой (лекарства)'
      placeholder='Лекарство... (≥3 буквы)'
    />
  )
}
