import Card from '@/src/components/Card';
import CustomBold from '@/src/components/CustomTexts/CustomBold';
import CustomText from '@/src/components/CustomTexts/CustomText';
import CustomTextBold from '@/src/components/CustomTexts/CustomTextBold';
import CustomTextBoldItalic from '@/src/components/CustomTexts/CustomTextBoldItalic';
import CustomTextLargeBold from '@/src/components/CustomTexts/CustomTextLargeBold';
import ErrorNet from '@/src/components/ErrorNet';
import Loader from '@/src/components/Loader/Loader';
import SeparatorDash from '@/src/components/SeparatorDash';
import Separator from '@/src/components/Separator';
import TitleShare from '@/src/components/TitleShare';
import { fetchUseQuery } from '@/src/functions/fetchUseQuery';
import { useTheme } from '@/src/hooks/useTheme';
import { MainStackParamList } from '@/src/types/navigationTypes';
import { IResponseData, LINKS } from '@/src/types/types';
import { RouteProp, useRoute } from '@react-navigation/native';
import { useQuery } from '@tanstack/react-query';
import React from 'react'
import { FlatList, RefreshControl, SafeAreaView, View } from 'react-native';

type IDrugQt = {
   id: string,
   label: string,
   qt_category: string,
   qt_prolongation?: string,
   qt_tdp?: string,
   qt_ecg?: string,
   qt_lqts?: string,
   qt_contraindication?: string,
}

const ListItem = ({
   title,
   list,
   lastElement = false
}: {
   title: string,
   list: string,
   lastElement?: boolean
}) => (
   <View style={{
      paddingHorizontal: 5,
      marginBottom: lastElement ? 0 : 2
   }}>
      <CustomTextBold>
         {title}
      </CustomTextBold>
      <CustomText style={{
         marginBottom: lastElement ? 0 : 7
      }}>
         {list}
      </CustomText>
      {lastElement ? null : (
         <SeparatorDash
            isMarginHorizontal
         />
      )}
   </View>
)

export default function DrugQtItem() {
   const { colors } = useTheme()
   const route = useRoute<RouteProp<MainStackParamList, 'DrugQtItem'>>()
   const { param } = route.params;


   const { isLoading, isError, data, isSuccess, refetch } = useQuery({
      queryKey: ['drugQtItem'],
      queryFn: async () => {
         return fetchUseQuery<IResponseData<IDrugQt>>(
            'get',
            `${LINKS.DRUGQT}/${param}`,
         )
      },
      enabled: !!param,
      gcTime: 2000
   })

   const onRefresh = React.useCallback(() => {
      refetch()
   }, [])


   if (isLoading) return <Loader />

   return (
      <SafeAreaView style={{ flex: 1, backgroundColor: colors.background }}>
         <FlatList
            refreshControl={
               <RefreshControl
                  refreshing={isLoading}
                  onRefresh={onRefresh}
                  colors={[colors.mainBg]}
                  progressBackgroundColor={colors.refreshProgressBarBg}
               />
            }
            contentContainerStyle={{ padding: 15 }}
            ListHeaderComponent={
               <View style={{ marginBottom: 15 }}>
                  <TitleShare
                     titleText={'Риски лекарственно-индуцированного удлинения интервала QT и желудочковой тахикардии типа «пируэт» (QT препараты)'}
                  />
                  {isError ? <ErrorNet /> : null}
               </View>
            }
            data={data?.data ?? []}
            renderItem={({ item }) => (
               <Card isPadding>
                  <View style={{
                     backgroundColor: item.qt_category === "KR" ? (
                        colors.vHRisk
                     ) : item.qt_category === "PR" ? (
                        colors.hRisk
                     ) : item.qt_category === "CR" ? (
                        colors.mRisk
                     ) : item.qt_category === "SR" ? (
                        colors.lRisk
                     ) : colors.background,
                     alignSelf: 'flex-start',
                     justifyContent: 'center',
                     alignItems: 'center',
                     paddingHorizontal: 15,
                     paddingVertical: 2,
                     borderRadius: 20,
                     marginStart: 5
                  }}>
                     <CustomTextBold style={{
                        color: colors.primaryReverse,
                     }}>
                        {tdpRisks[item.qt_category].category}
                     </CustomTextBold>
                  </View>
                  <Separator />
                  <CustomTextLargeBold style={{
                     textTransform: 'capitalize',
                     paddingHorizontal: 5,
                     paddingVertical: 2
                  }}>
                     {item.label}
                  </CustomTextLargeBold>
                  <Separator />
                  <CustomText style={{
                     paddingHorizontal: 5,
                     paddingVertical: 2
                  }}>
                     {tdpRisks[item.qt_category].text}
                  </CustomText>
                  <Separator />
                  {(item.qt_contraindication || item.qt_ecg || item.qt_lqts || item.qt_prolongation || item.qt_tdp) && (
                     <CustomTextBoldItalic style={{
                        paddingHorizontal: 5,
                     }}>
                        Информация листка-вкладыша препарата
                     </CustomTextBoldItalic>
                  )}
                  {item.qt_prolongation && (
                     <ListItem
                        title='Отмеченное удлинение интервала QT:'
                        list={item.qt_prolongation}
                     />
                  )}
                  {item.qt_tdp && (
                     <ListItem
                        title='Отмеченые случаи TdP:'
                        list={item.qt_tdp}
                     />
                  )}
                  {item.qt_ecg && (
                     <ListItem
                        title='Рекомендации по ЭКГ:'
                        list={item.qt_ecg}
                     />
                  )}
                  {item.qt_lqts && (
                     <ListItem
                        title='Предупреждение относительно использования у людей с врожденным синдромом удлиненного интервала QT:'
                        list={item.qt_lqts}
                     />
                  )}
                  {item.qt_contraindication && (
                     <ListItem
                        title='Противопоказанные сопутствующие препараты:'
                        list={item.qt_contraindication}
                        lastElement
                     />
                  )}
               </Card>
            )}
         />
      </SafeAreaView>
   )
}

const tdpRisks: Record<string, { category: string, text: string }> = {
   "KR": {
      category: "Известный риск TdP",
      text: "Эти препараты удлиняют интервал QT И явно связаны с известным риском развития TdP, даже если принимаются в соответствии с рекомендациями."
   },
   "PR": {
      category: "Возможный риск TdP",
      text: "Эти препараты могут вызывать удлинение интервала QT, НО в настоящее время нет никаких доказательств риска возникновения TdP при приеме в соответствии с рекомендациями."
   },
   "CR": {
      category: "Условный риск TdP",
      text: "Эти препараты связаны с TdP, НО только при определенных обстоятельствах их применения (например, передозировка, у пациентов с такими состояниями, как гипокалиемия, или совместный прием с взаимодействующими препаратами) ИЛИ путем создания определенных условий, которые способствуют или вызывают TdP (например, путем ингибирования метаболизма препарата, удлиняющего интервал QT, или путем вызывания электролитных нарушений, которые вызывают TdP)."
   },
   "SR": {
      category: "Специфический риск TdP",
      text: "Препараты, которых следует избегать при врожденном синдроме удлиненного интервала QT (cLQTS): эти препараты повышают риск развития TdP у пациентов с cLQTS и включают все 3 категории, указанные выше, ПЛЮС дополнительные препараты, которые сами по себе не удлиняют интервал QT, но представляют определенный риск из-за других своих эффектов."
   },
}
