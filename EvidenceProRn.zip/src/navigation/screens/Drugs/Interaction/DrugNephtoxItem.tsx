import CustomLink from '@/src/components/CustomTexts/CustomLink'
import CustomText from '@/src/components/CustomTexts/CustomText'
import CustomTextBold from '@/src/components/CustomTexts/CustomTextBold'
import ErrorNet from '@/src/components/ErrorNet'
import Loader from '@/src/components/Loader/Loader'
import MenuList from '@/src/components/MenuList'
import Separator from '@/src/components/Separator'
import TitleShare from '@/src/components/TitleShare'
import { fetchUseQuery } from '@/src/functions/fetchUseQuery'
import { useTheme } from '@/src/hooks/useTheme'
import { MainStackParamList } from '@/src/types/navigationTypes'
import { IResponseData, LINKS } from '@/src/types/types'
import { RouteProp, useNavigation, useRoute } from '@react-navigation/native'
import { useQuery } from '@tanstack/react-query'
import React from 'react'
import { FlatList, RefreshControl, SafeAreaView, TouchableOpacity, View } from 'react-native'

type IDrugNephtoxItem = {
  id: string,
  label: string,
  link: string,
  nephtox_diseases?: {
    id: string,
    name: string
  }[],
  nephtox_morphologies?: {
    id: string,
    name: string
  }[],
  nephtox_refs?: string
}

export default function DrugNephtoxItem() {
  const { colors } = useTheme()
  const route = useRoute<RouteProp<MainStackParamList, 'DrugNephtoxItem'>>()
  const { param } = route.params;
  const navigation = useNavigation()

  const { isLoading, isError, data, isSuccess, refetch } = useQuery({
    queryKey: ['drugNephtoxItem', param],
    queryFn: async () => {
      return fetchUseQuery<IResponseData<IDrugNephtoxItem>>(
        'get',
        `${LINKS.DRUGNEPHTOX}/${param}`,
      )
    },
    enabled: !!param,
    gcTime: 2000
  })

  const onRefresh = React.useCallback(() => {
    refetch()
  }, [])


  if (isLoading) return <Loader />

  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: colors.background }}>
      <FlatList
        contentContainerStyle={{ paddingVertical: 15 }}
        refreshControl={
          <RefreshControl
            refreshing={isLoading}
            onRefresh={onRefresh}
            colors={[colors.mainBg]}
            progressBackgroundColor={colors.refreshProgressBarBg}
          />
        }
        ListHeaderComponent={
          <View style={{ paddingHorizontal: 15 }}>
            <TitleShare
              titleText={'Взаимодействие лекарств с почками'}
            />
            {data && data.data ? (
              <View style={{ marginTop: 10 }}>
                <CustomTextBold style={{ textTransform: 'capitalize' }}>
                  {data.data[0].label}
                </CustomTextBold>
                <CustomTextBold style={{ marginTop: 10 }}>
                  Клинические болезни
                </CustomTextBold>
              </View>
            ) : null}
            {isError ? <ErrorNet /> : null}
          </View>
        }
        data={data?.data[0]?.nephtox_diseases ?? []}
        renderItem={({ item }) => (
          <MenuList
            title={item.name}
            onPress={() => navigation.navigate('Home', {
              screen: "DrugNephtoxDiseaseItem",
              params: { param: item.id.toString() }
            })}
          />
        )}
        ItemSeparatorComponent={() => <Separator />}
        keyExtractor={item => item.id}
        ListFooterComponent={data && data.data ? (
          <View>
            <View style={{ marginTop: 20 }}>
              <CustomTextBold style={{ paddingHorizontal: 15 }}>
                Морфологические болезни
              </CustomTextBold>
              <FlatList
                data={data?.data[0]?.nephtox_morphologies}
                renderItem={({ item: morphItem }) => (
                  <MenuList
                    title={morphItem.name}
                    onPress={() => navigation.navigate('Home', {
                      screen: "DrugNephtoxMorphologyItem",
                      params: { param: morphItem.id.toString() }
                    })}
                  />
                )}
                keyExtractor={morphItem => morphItem.id}
                ItemSeparatorComponent={() => <Separator />}
                ListEmptyComponent={isSuccess ? <CustomText style={{ paddingHorizontal: 15 }}>-</CustomText> : null}
              />
            </View>
            <View style={{ marginVertical: 15, paddingHorizontal: 15 }}>
              <CustomTextBold>Ссылки</CustomTextBold>
              <TouchableOpacity
                onPress={() => navigation.navigate('Home', {
                  screen: "WebView",
                  params: {
                    url: `https://pubmed.ncbi.nlm.nih.gov/?term=%28%28%22${data?.data[0]?.nephtox_refs ? data?.data[0]?.nephtox_refs : data?.data[0]?.link}%2Fadverse+effects%22%5BMesh%5D+OR+%22${data?.data[0]?.nephtox_refs ? data?.data[0]?.nephtox_refs : data?.data[0]?.link}%2Ftoxicity%22%5BMesh%5D%29%29+AND+%28%28%28nephrotoxicity%29%29+OR+%28%22Kidney+Diseases%2Fchemically+induced%22%5BMesh%5D+OR+%22Kidney+Diseases%2Fpathology%22%5BMesh%5D+OR+%22Kidney+Diseases%2Fphysiopathology%22%5BMesh%5D%29%29`
                  }
                })}
                accessibilityLabel='Press DrugNephWeb Navigation'
                style={{ marginTop: 5 }}
              >
                <CustomText><CustomLink>Посмотреть все ссылки</CustomLink></CustomText>
              </TouchableOpacity>
            </View>
          </View>
        ) : null}
        ListEmptyComponent={isSuccess ? <CustomText style={{ paddingHorizontal: 15 }}>-</CustomText> : null}
      />
    </SafeAreaView>
  )
}
