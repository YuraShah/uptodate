import AngleRight from '@/src/components/AngleRight'
import CustomText from '@/src/components/CustomTexts/CustomText'
import CustomTextBold from '@/src/components/CustomTexts/CustomTextBold'
import ErrorNet from '@/src/components/ErrorNet'
import Loader from '@/src/components/Loader/Loader'
import SeparatorDash from '@/src/components/SeparatorDash'
import Separator from '@/src/components/Separator'
import TitleShare from '@/src/components/TitleShare'
import { fetchUseQuery } from '@/src/functions/fetchUseQuery'
import { useTheme } from '@/src/hooks/useTheme'
import { IResponseData, LINKS } from '@/src/types/types'
import { useNavigation } from '@react-navigation/native'
import { FlashList } from '@shopify/flash-list'
import { useQuery } from '@tanstack/react-query'
import React, { useState } from 'react'
import { FlatList, RefreshControl, SafeAreaView, TouchableOpacity, View } from 'react-native'


type IDrugPulmtoxPattern = {
  pattern_id: number,
  pattern_number: string,
  pattern_title: string,
  subpattern: {
    subpattern_id: number,
    subpattern_number: string,
    subpattern_title: string,
  }[]
}


export default function DrugPulmtoxPattern() {
  const { colors } = useTheme()
  const [openStates, setOpenStates] = useState<boolean[]>([]);
  const navigation = useNavigation();

  const toggleOpen = (index: number) => {
    const updated = [...openStates];
    updated[index] = !updated[index];
    setOpenStates(updated);
  };

  const { isLoading, isError, data, refetch } = useQuery({
    queryKey: ['drugPulmtoxPattern'],
    queryFn: async () => {
      return fetchUseQuery<IResponseData<IDrugPulmtoxPattern>>(
        'post',
        LINKS.DRUGPULMTOXPATTERN,
      )
    },
    gcTime: 2000
  })

  const onRefresh = React.useCallback(() => {
    refetch()
  }, [])


  if (isLoading) return <Loader />

  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: colors.background }}>
      <FlatList
        contentContainerStyle={{ paddingVertical: 15 }}
        refreshControl={
          <RefreshControl
            refreshing={isLoading}
            onRefresh={onRefresh}
            colors={[colors.mainBg]}
            progressBackgroundColor={colors.refreshProgressBarBg}
          />
        }
        ListHeaderComponent={
          <View style={{ paddingHorizontal: 15, marginBottom: 5 }}>
            <TitleShare
              titleText={'Заболевания/состояния'}
            />
            {isError ? <ErrorNet /> : null}
          </View>
        }
        ItemSeparatorComponent={() => <Separator />}
        data={data?.data ?? []}
        renderItem={({ item, index }) => {
          const isOpen = openStates[index];

          return (
            <View style={{ paddingVertical: 15 }}>
              <TouchableOpacity
                onPress={() => toggleOpen(index)}
                style={{
                  paddingHorizontal: 15,
                  rowGap: 7
                }}
              >
                <View style={{
                  backgroundColor: colors.angleRightBlue,
                  alignSelf: 'flex-start',
                  justifyContent: 'center',
                  alignItems: 'center',
                  borderRadius: 20,
                  minWidth: 85
                }}>
                  <CustomTextBold style={{ color: colors.textReverse }}>
                    {item.pattern_number}
                  </CustomTextBold>
                </View>
                <View style={{
                  flexDirection: 'row',
                  justifyContent: 'space-between',
                  alignItems: 'center',
                  gap: 3,
                }}>
                  <CustomTextBold style={{ flex: 1 }}>
                    {item.pattern_title}
                  </CustomTextBold>
                  <AngleRight
                    isActive={isOpen}
                    color={colors.angleRightBlue}
                  />
                </View>
              </TouchableOpacity>
              {isOpen ? (
                <View style={{ minHeight: 50 }}>
                  <FlashList
                    estimatedItemSize={84}
                    data={item.subpattern}
                    renderItem={({ item: subpattern }) => (
                      <TouchableOpacity
                        onPress={() => navigation.navigate('Home',
                          {
                            screen: 'DrugPulmtoxSubpattern',
                            params: {
                              param: subpattern.subpattern_id.toString()
                            }
                          })}
                        style={{
                          paddingHorizontal: 15,
                          paddingVertical: 10
                        }}
                      >
                        <CustomTextBold>
                          {subpattern.subpattern_number}
                        </CustomTextBold>
                        <CustomText>
                          {subpattern.subpattern_title}
                        </CustomText>
                      </TouchableOpacity>
                    )}
                    ItemSeparatorComponent={() => <SeparatorDash />
                    }
                  />
                </View>
              ) : null}
            </View>
          )
        }}
        keyExtractor={item => item.pattern_id.toString()}
      />
    </SafeAreaView>
  )
}
