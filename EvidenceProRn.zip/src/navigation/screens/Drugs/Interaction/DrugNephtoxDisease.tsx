import SearchList from '@/src/components/SearchList'
import { fetchUseQuery } from '@/src/functions/fetchUseQuery'
import { IOtherList, IResponseData, LINKS } from '@/src/types/types'
import { useQuery } from '@tanstack/react-query'
import React from 'react'

export default function DrugNephtoxDisease() {
  const { isLoading, isError, data, isSuccess, refetch } = useQuery({
    queryKey: ['drugNephtoxDisease'],
    queryFn: async () => {
      return fetchUseQuery<IResponseData<IOtherList>>(
        'post',
        LINKS.DRUGNEPHTOXDISEASE,
      )
    },
    gcTime: 2000
  })

  return (
    <SearchList
      data={data}
      refetch={refetch}
      isLoading={isLoading}
      isError={isError}
      isSuccess={isSuccess}
      screen="DrugNephtoxDiseaseItem"
      title='Клинические болезни'
      placeholder='Напишите болезнь (≥3 буквы)'
    />
  )
}
