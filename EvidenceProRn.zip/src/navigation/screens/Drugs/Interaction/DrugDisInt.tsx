import SelectAsyncComponent from '@/src/components/SelectComponent/SelectAsyncComponent'
import TitleShare from '@/src/components/TitleShare'
import { fetchUseQuery } from '@/src/functions/fetchUseQuery'
import { useTheme } from '@/src/hooks/useTheme'
import { IResponseData, LINKS } from '@/src/types/types'
import { useQuery } from '@tanstack/react-query'
import React, { useState } from 'react'
import { SafeAreaView, TouchableOpacity, useWindowDimensions, View } from 'react-native'
import { FlashList } from "@shopify/flash-list";
import MenuList from '@/src/components/MenuList'
import { useNavigation } from '@react-navigation/native'
import Separator from '@/src/components/Separator'
import Loader from '@/src/components/Loader/Loader'
import ErrorNet from '@/src/components/ErrorNet'
import CustomTextBoldItalic from '@/src/components/CustomTexts/CustomTextBoldItalic'
import CustomText from '@/src/components/CustomTexts/CustomText'
import CustomTextSmall from '@/src/components/CustomTexts/CustomTextSmall'

type IDrugDisSearch = {
   id: string,
   value: string,
   label: string,
   link: string,
   disease?: string
}

export default function DrugDisInt() {
   const { colors } = useTheme()
   const { width } = useWindowDimensions()
   const [inpValue, setInpValue] = useState<string>('')
   const [type, setType] = useState<'drug' | 'dis'>('drug')
   const navigation = useNavigation()

   const { isLoading, isError, data, isSuccess } = useQuery({
      queryKey: ['drugDisInt', inpValue],
      queryFn: async () => {
         return fetchUseQuery<IResponseData<IDrugDisSearch>>(
            'post',
            LINKS.DRUGDISEASESEARCH,
            JSON.stringify({ type: type, value: inpValue.toLowerCase() })
         )
      },
      enabled: inpValue.length >= 3,
      gcTime: 2000
   })

   return (
      <SafeAreaView style={{ flex: 1, backgroundColor: colors.background }}>
         <FlashList
            data={data?.data ?? []}
            contentContainerStyle={{ paddingVertical: 15 }}
            ListHeaderComponent={
               <View style={{ paddingHorizontal: 15 }}>
                  <TitleShare
                     titleText={'Взаимодействие лекарств с заболеваниями'}
                  />
                  <View style={{
                     flexDirection: 'row',
                     columnGap: 5,
                     justifyContent: 'space-between',
                     marginTop: 20,
                     width: width >= 780 ? '70%' : '100%'
                  }}>
                     <TouchableOpacity
                        style={{
                           flex: 1,
                           backgroundColor: colors.primaryReverse,
                           borderRadius: 5,
                           alignItems: 'center',
                           justifyContent: 'center',
                           padding: 10,
                        }}
                        accessibilityLabel='Search By Drugs'
                        onPress={() => {
                           setType('drug')
                           setInpValue('')
                        }}
                     >
                        <CustomTextSmall
                           style={{
                              color: type === 'drug' ? colors.mainBg : colors.secondary,
                              textAlign: 'center',
                              lineHeight: 22
                           }}
                        >
                           Поиск по лекарствам
                        </CustomTextSmall>
                     </TouchableOpacity>
                     <TouchableOpacity
                        style={{
                           flex: 1,
                           backgroundColor: colors.primaryReverse,
                           borderRadius: 5,
                           alignItems: 'center',
                           justifyContent: 'center',
                           padding: 10,
                        }}
                        accessibilityLabel='Search By Diseases'
                        onPress={() => {
                           setType('dis')
                           setInpValue('')
                        }}
                     >
                        <CustomTextSmall
                           style={{
                              color: type === 'dis' ? colors.mainBg : colors.secondary,
                              textAlign: 'center',
                              lineHeight: 22
                           }}
                        >
                           Поиск по болезням
                        </CustomTextSmall>
                     </TouchableOpacity>
                  </View>
                  <SelectAsyncComponent
                     inpValue={inpValue}
                     setInpValue={setInpValue}
                     windowWidth={width}
                     placeholder={`Напишите ${type === 'dis' ? 'болезнь' : 'препарат'} (≥3 буквы)`}
                  />
                  {isLoading ? <Loader /> : null}
                  {isError ? <ErrorNet /> : null}
                  {isSuccess && data && data.data && data.data.length === 0 ? <CustomText>Не найдено совпадений</CustomText> : null}
               </View>
            }
            estimatedItemSize={type === 'dis' ? 66 : 38}
            renderItem={({ item }) => (
               <MenuList
                  onPress={() => navigation.navigate('Home', { screen: "DrugDisIntItem", params: { param: `${item.link}:${item.id}` } })}
                  title={item.label}
                  children={item.disease ? (
                     <CustomTextBoldItalic>
                        {item.disease}
                     </CustomTextBoldItalic>
                  ) : undefined}
               />
            )}
            ItemSeparatorComponent={() => <Separator />}
         />
      </SafeAreaView>
   )
}
