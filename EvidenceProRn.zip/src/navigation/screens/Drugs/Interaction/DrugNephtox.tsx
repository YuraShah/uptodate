import Menu from '@/src/components/Menu'
import { IMenuList } from '@/src/types/types'
import React from 'react'

export default function DrugNephtox() {
  return (
    <Menu
      data={nephtoxList}
      headerTitle='Взаимодействие лекарств с почками'
    />
  )
}


const nephtoxList: IMenuList[] = [
  {
    name: "Лекарства",
    link: "DrugNephtoxDrug"
  },
  {
    name: "Клинические болезни",
    link: "DrugNephtoxDisease"
  },
  {
    name: "Морфологические болезни",
    link: "DrugNephtoxMorphology"
  }
]
