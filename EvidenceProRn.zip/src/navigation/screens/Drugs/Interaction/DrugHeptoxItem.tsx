import Accordion from '@/src/components/Accordion';
import Card from '@/src/components/Card';
import CustomIconSmall from '@/src/components/CustomIcons/CustomIconSmall';
import CustomBold from '@/src/components/CustomTexts/CustomBold';
import CustomText from '@/src/components/CustomTexts/CustomText';
import CustomTextBold from '@/src/components/CustomTexts/CustomTextBold';
import ErrorNet from '@/src/components/ErrorNet';
import References from '@/src/components/References';
import Separator from '@/src/components/Separator';
import TitleShare from '@/src/components/TitleShare';
import { fetchUseQuery } from '@/src/functions/fetchUseQuery';
import { useTheme } from '@/src/hooks/useTheme'
import { MainStackParamList } from '@/src/types/navigationTypes';
import { IResponseData, LINKS } from '@/src/types/types';
import { faRightLeft } from '@fortawesome/free-solid-svg-icons';
import { RouteProp, useRoute } from '@react-navigation/native';
import { useQuery } from '@tanstack/react-query';
import React from 'react'
import { FlatList, RefreshControl, SafeAreaView, StyleSheet, View } from 'react-native';

type IDrugHeptoxList = {
  id: string,
  label: string,
  heptox_score?: string,
  heptox_text?: string,
  heptox_note?: string,
  heptox_outcome?: string,
  heptox_refs?: string[]
}

export default function DrugHeptoxItem() {
  const { colors } = useTheme()
  const route = useRoute<RouteProp<MainStackParamList, 'DrugHeptoxItem'>>()
  const { param } = route.params;

  const { isLoading, isError, data, isSuccess, refetch } = useQuery({
    queryKey: ['drugHeptoxItem', param],
    queryFn: async () => {
      return fetchUseQuery<IResponseData<IDrugHeptoxList>>(
        'get',
        `${LINKS.DRUGHEPTOX}/${param}`,
      )
    },
    enabled: !!param,
    gcTime: 2000
  })

  const onRefresh = React.useCallback(() => {
    refetch()
  }, [])

  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: colors.background }}>
      <FlatList
        contentContainerStyle={{ padding: 15 }}
        refreshControl={
          <RefreshControl
            refreshing={isLoading}
            onRefresh={onRefresh}
            colors={[colors.mainBg]}
            progressBackgroundColor={colors.refreshProgressBarBg}
          />
        }
        ListHeaderComponent={
          <View style={{ rowGap: 5, marginBottom: 15 }}>
            <TitleShare
              titleText={'Взаимодействие лекарств с печенью'}
            />
            {isError ? <ErrorNet /> : null}
          </View>
        }
        data={data?.data ?? []}
        keyExtractor={(item) => item.id}
        renderItem={({ item }) => {
          return (
            <Card isPadding>
              <View
                style={{
                  backgroundColor: item.heptox_score?.includes('E') ? (
                    colors.vLRisk
                  ) : item.heptox_score?.length === 1 && item.heptox_score?.includes('D') ? (
                    colors.lRisk
                  ) : item.heptox_score?.includes('C') ? (
                    colors.mRisk
                  ) : item.heptox_score?.includes('B') ? (
                    colors.hRisk
                  ) : item.heptox_score?.includes('A') ? (
                    colors.vHRisk
                  ) : colors.unRisk,
                  alignSelf: 'flex-start',
                  flexDirection: 'row',
                  alignItems: 'center',
                  justifyContent: 'center',
                  paddingHorizontal: 20,
                  borderRadius: 20,
                  marginBottom: 5,
                  marginStart: 5
                }}
              >
                <CustomTextBold style={{ color: colors.primaryReverse }}>
                  {item.heptox_score ?? 'X'}
                </CustomTextBold>
              </View>
              <Separator />
              <View style={{
                flexDirection: 'row',
                flexWrap: 'wrap',
                columnGap: 7,
                alignItems: 'center',
                paddingHorizontal: 5,
                paddingVertical: 2,
              }}>
                <CustomTextBold>
                  {item.label}
                </CustomTextBold>
                <CustomIconSmall
                  icon={faRightLeft}
                  color={colors.primary}
                />
                <CustomTextBold>
                  печень
                </CustomTextBold>
              </View>
              <Separator />
              <View>
                {item.heptox_text && (
                  <>
                    <View style={{
                      paddingHorizontal: 5,
                      paddingVertical: 2,
                    }}>
                      <Accordion
                        header={
                          <CustomTextBold>Гепатотоксичность</CustomTextBold>
                        }
                        content={
                          <CustomText>
                            {item.heptox_text}
                          </CustomText>
                        }
                      />
                    </View>
                    <Separator />
                  </>
                )}
                {item.heptox_outcome && (
                  <>
                    <View style={{
                      paddingHorizontal: 5,
                      paddingVertical: 2,
                    }}>
                      <Accordion
                        header={
                          <CustomTextBold>Введение и исход</CustomTextBold>
                        }
                        content={
                          <CustomText>
                            {item.heptox_outcome}
                          </CustomText>
                        }
                      />
                    </View>
                    <Separator />
                  </>
                )}
                {item.heptox_score && (
                  <>
                    <View style={{
                      padding: 5
                    }}>
                      <CustomText><CustomBold>Оценка вероятности:</CustomBold> {item.heptox_score} ({item.heptox_note && item.heptox_note})</CustomText>
                    </View>
                    <Separator />
                  </>
                )}
                {item.heptox_refs && (
                  <View style={{
                    paddingHorizontal: 5,
                    paddingTop: 7,
                  }}>
                    <References
                      refs={item.heptox_refs}
                      flat
                      isRefOpen
                    />
                  </View>
                )}
              </View>
            </Card>
          )
        }}
      />
    </SafeAreaView>
  )
}

const styles = StyleSheet.create({

})
