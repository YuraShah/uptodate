import CustomText from '@/src/components/CustomTexts/CustomText'
import CustomTextBold from '@/src/components/CustomTexts/CustomTextBold'
import ErrorNet from '@/src/components/ErrorNet'
import Loader from '@/src/components/Loader/Loader'
import SelectAsyncComponent from '@/src/components/SelectComponent/SelectAsyncComponent'
import Separator from '@/src/components/Separator'
import TitleShare from '@/src/components/TitleShare'
import { fetchUseQuery } from '@/src/functions/fetchUseQuery'
import { useTheme } from '@/src/hooks/useTheme'
import { IResponseData, LINKS } from '@/src/types/types'
import { useNavigation } from '@react-navigation/native'
import { FlashList } from '@shopify/flash-list'
import { useQuery } from '@tanstack/react-query'
import React, { useMemo, useState } from 'react'
import { RefreshControl, SafeAreaView, TouchableOpacity, useWindowDimensions, View } from 'react-native'

const risks = {
  'A': 'Хорошо известная причина',
  'B': 'Очень вероятная причина',
  'C': 'Вероятная причина',
  'D': 'Возможная причина (маловероятная причина)',
  'E*': 'Предполагаемая, но недоказанная причина',
  'E': 'Малая возможная причина',
  'X': 'Неизвестно',
}

function getRisk(text: string) {
  if (text.includes('A')) return risks['A'];
  if (text.includes('B')) return risks['B'];
  if (text.includes('C')) return risks['C'];
  if (text.includes('D')) return risks['D'];
  if (text.includes('E*')) return risks['E*'];
  if (text.includes('E')) return risks['E'];
  return risks['X'];
}

type IDrugHeptoxList = {
  id: string,
  value: string,
  label: string,
  link: string,
  heptox_score?: string,
}

export default function DrugHeptox() {
  const { colors } = useTheme()
  const { width } = useWindowDimensions()
  const [inpValue, setInpValue] = useState<string>('')
  const navigation = useNavigation()

  const { isLoading, isError, data, isSuccess, refetch } = useQuery({
    queryKey: ['drugHeptox'],
    queryFn: async () => {
      return fetchUseQuery<IResponseData<IDrugHeptoxList>>(
        'post',
        LINKS.DRUGHEPTOXLIST,
      )
    },
    gcTime: 2000
  })

  const filteredData = useMemo(() => {
    const list = data?.data ?? []
    if (!inpValue.trim()) return list

    return list.filter(item =>
      item.label.toLowerCase().includes(inpValue.trim().toLowerCase())
    )
  }, [inpValue, data])

  const onRefresh = React.useCallback(() => {
    setInpValue('')
    refetch()
  }, [])


  if (isLoading) return <Loader />

  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: colors.background }}>
      <FlashList
        refreshControl={
          <RefreshControl
            refreshing={isLoading}
            onRefresh={onRefresh}
            colors={[colors.mainBg]}
            progressBackgroundColor={colors.refreshProgressBarBg}
          />
        }
        contentContainerStyle={{ padding: 15 }}
        ListHeaderComponent={
          <View>
            <TitleShare
              titleText={'Взаимодействие лекарств с печенью'}
            />
            <SelectAsyncComponent
              inpValue={inpValue}
              setInpValue={setInpValue}
              windowWidth={width}
              placeholder={`Напишите препарат (≥3 буквы)`}
            />
            {isError ? <ErrorNet /> : null}
          </View>
        }
        data={filteredData}
        renderItem={({ item }) => (
          <TouchableOpacity
            onPress={() => navigation.navigate('Home', { screen: 'DrugHeptoxItem', params: { param: `${item.link}:${item.id}` } })}
            style={{
              borderWidth: 1,
              borderColor: colors.borderBottomPrimary,
              borderRadius: 5,
              overflow: 'hidden',
            }}
          >
            <View
              style={{
                backgroundColor: item.heptox_score?.includes('E') ? (
                  colors.vLRisk
                ) : item.heptox_score?.length === 1 && item.heptox_score?.includes('D') ? (
                  colors.lRisk
                ) : item.heptox_score?.includes('C') ? (
                  colors.mRisk
                ) : item.heptox_score?.includes('B') ? (
                  colors.hRisk
                ) : item.heptox_score?.includes('A') ? (
                  colors.vHRisk
                ) : (
                  colors.unRisk
                ),
                alignSelf: 'flex-start',
                flexDirection: 'row',
                alignItems: 'center',
                justifyContent: 'center',
                paddingHorizontal: 20,
                borderRadius: 20,
                marginVertical: 5,
                marginStart: 5
              }}
            >
              <CustomTextBold style={{ color: colors.primaryReverse }}>
                {item.heptox_score ?? 'X'}
              </CustomTextBold>
            </View>
            <Separator />
            <CustomText style={{ textTransform: 'capitalize', paddingVertical: 2, paddingHorizontal: 5 }}>
              {item.label}
            </CustomText>
            <Separator />
            <CustomText style={{ paddingVertical: 2, paddingHorizontal: 5 }}>
              {getRisk(item.heptox_score ?? 'X')}
            </CustomText>
          </TouchableOpacity>
        )}
        ItemSeparatorComponent={() => <View style={{ marginVertical: 5 }} />}
        estimatedItemSize={99}
        ListEmptyComponent={isSuccess ? <CustomText>Не найдено</CustomText> : null}
      />
    </SafeAreaView>
  )
}
