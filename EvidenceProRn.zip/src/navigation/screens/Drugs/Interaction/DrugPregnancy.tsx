import CustomText from '@/src/components/CustomTexts/CustomText'
import ErrorNet from '@/src/components/ErrorNet'
import Loader from '@/src/components/Loader/Loader'
import MenuList from '@/src/components/MenuList'
import SelectAsyncComponent from '@/src/components/SelectComponent/SelectAsyncComponent'
import Separator from '@/src/components/Separator'
import TitleShare from '@/src/components/TitleShare'
import { fetchUseQuery } from '@/src/functions/fetchUseQuery'
import { useDebounce } from '@/src/hooks/useDebounce'
import { useTheme } from '@/src/hooks/useTheme'
import { IDrugLabel, IResponseData, LINKS } from '@/src/types/types'
import { useNavigation } from '@react-navigation/native'
import { FlashList } from '@shopify/flash-list'
import { useQuery } from '@tanstack/react-query'
import React, { useState } from 'react'
import { SafeAreaView, useWindowDimensions, View } from 'react-native'


export default function DrugPregnancy() {
   const { colors } = useTheme()
   const { width } = useWindowDimensions()
   const [inpValue, setInpValue] = useState<string>('')
   const debouncedValue = useDebounce(inpValue, 500)
   const navigation = useNavigation()

   const { isLoading, isError, data, isSuccess } = useQuery({
      queryKey: ['pregnancy', debouncedValue],
      queryFn: async () => {
         return fetchUseQuery<IResponseData<IDrugLabel>>(
            'post',
            LINKS.DRUGPREGNANCYSEARCH,
            JSON.stringify(debouncedValue.toLowerCase())
         )
      },
      enabled: debouncedValue.length >= 3,
      gcTime: 2000
   })

   return (
      <SafeAreaView style={{ flex: 1, backgroundColor: colors.background }}>
         <FlashList
            data={data?.data ?? []}
            contentContainerStyle={{ paddingVertical: 15 }}
            ListHeaderComponent={
               <View style={{ paddingHorizontal: 15 }}>
                  <TitleShare
                     titleText={'Взаимодействие лекарств с беременными'}
                  />
                  <SelectAsyncComponent
                     inpValue={inpValue}
                     setInpValue={setInpValue}
                     windowWidth={width}
                     placeholder={`Напишите препарат (≥3 буквы)`}
                  />
                  {isLoading ? <Loader /> : null}
                  {isError ? <ErrorNet /> : null}
                  {isSuccess && data && data.data.length === 0 ? <CustomText>Не найдено совпадений</CustomText> : null}
               </View>
            }
            estimatedItemSize={38}
            renderItem={({ item }) => (
               <MenuList
                  onPress={() => navigation.navigate('Home', { screen: "DrugPregnancyItem", params: { param: `${item.link}:${item.id}` } })}
                  title={item.label}
               />
            )}
            ItemSeparatorComponent={() => <Separator />}
         />
      </SafeAreaView>
   )
}
