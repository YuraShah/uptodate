import Card from '@/src/components/Card'
import CustomBold from '@/src/components/CustomTexts/CustomBold'
import CustomText from '@/src/components/CustomTexts/CustomText'
import CustomTextBold from '@/src/components/CustomTexts/CustomTextBold'
import ErrorNet from '@/src/components/ErrorNet'
import Loader from '@/src/components/Loader/Loader'
import SelectAsyncComponent from '@/src/components/SelectComponent/SelectAsyncComponent'
import Separator from '@/src/components/Separator'
import TitleShare from '@/src/components/TitleShare'
import { fetchUseQuery } from '@/src/functions/fetchUseQuery'
import { useTheme } from '@/src/hooks/useTheme'
import { IResponseData, LINKS } from '@/src/types/types'
import { FlashList } from '@shopify/flash-list'
import { useQuery } from '@tanstack/react-query'
import React, { useMemo, useState } from 'react'
import { RefreshControl, SafeAreaView, useWindowDimensions, View } from 'react-native'

type IDrugDisl = {
  id: string,
  label: string,
  disl_ic: string
}

export default function DrugDisl() {
  const { colors } = useTheme()
  const { width } = useWindowDimensions()
  const [inpValue, setInpValue] = useState<string>('')

  const { isLoading, isError, data, isSuccess, refetch } = useQuery({
    queryKey: ['drugDisl'],
    queryFn: async () => {
      return fetchUseQuery<IResponseData<IDrugDisl>>(
        'post',
        LINKS.DRUGDISL,
      )
    },
    gcTime: 2000
  })

  const filteredData = useMemo(() => {
    const list = data?.data ?? []
    if (!inpValue.trim()) return list

    return list.filter(item =>
      item.label.toLowerCase().includes(inpValue.trim().toLowerCase())
    )
  }, [inpValue, data])

  const onRefresh = React.useCallback(() => {
    setInpValue('')
    refetch()
  }, [])


  if (isLoading) return <Loader />


  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: colors.background }}>
      <FlashList
        refreshControl={
          <RefreshControl
            refreshing={isLoading}
            onRefresh={onRefresh}
            colors={[colors.mainBg]}
            progressBackgroundColor={colors.refreshProgressBarBg}
          />
        }
        contentContainerStyle={{ padding: 15 }}
        ListHeaderComponent={
          <View>
            <TitleShare
              titleText={'Лекарства, вызывающие лекарственно-индуцированную красную волчанку'}
            />
            <SelectAsyncComponent
              inpValue={inpValue}
              setInpValue={setInpValue}
              windowWidth={width}
              placeholder={`Напишите препарат (≥3 буквы)`}
            />
            {inpValue === '' ? (
              <View style={{ rowGap: 5, marginBottom: 20 }}>
                <CustomText>Список препаратов, вызывающих лекарственную волчанку в <CustomBold>VigiBase</CustomBold>, отсортированный по убыванию <CustomBold>IC025</CustomBold>.</CustomText>
                <CustomText><CustomBold>VigiBase</CustomBold> — это глобальная база данных Всемирной организации здравоохранения (ВОЗ) по индивидуальным отчетам о безопасности лекарственных средств (ICSR), которая содержит ICSR, представленные государствами-членами, участвующими в Международной программе ВОЗ по мониторингу лекарственных средств.</CustomText>
                <CustomText><CustomBold>IC</CustomBold> - информационный компонент. Чем выше IC025, тем чаще сообщается о «нежелательной лекарственной реакции», в частности, тем выше риск лекарственной волчанки и тем препарат является частой причиной.</CustomText>
              </View>
            ) : null}
            {isError ? <ErrorNet /> : null}
          </View>
        }
        data={filteredData}
        renderItem={({ item }) => (
          <Card isPadding>
            <CustomTextBold style={{ paddingHorizontal: 5 }}>
              {item.label}
            </CustomTextBold>
            <Separator />
            <CustomText style={{ paddingHorizontal: 5 }}>
              {item.disl_ic}
            </CustomText>
          </Card>
        )}
        ItemSeparatorComponent={() => <View style={{ marginVertical: 5 }} />}
        estimatedItemSize={48}
        ListEmptyComponent={isSuccess ? <CustomText>Не найдено совпадений</CustomText> : null}
      />
    </SafeAreaView>
  )
}
