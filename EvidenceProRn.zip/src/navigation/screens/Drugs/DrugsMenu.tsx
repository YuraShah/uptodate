import Menu from '@/src/components/Menu'
import { IMenuList } from '@/src/types/types'
import React from 'react'

export default function DrugsMenu() {
  return (
    <Menu data={drugsMenuList} />
  )
}

const drugsMenuList: IMenuList[] = [
  {
    name: "Взаимодействие с заболеваниями",
    link: "DrugDisInt"
  },
  {
    name: "Взаимодействие при беременности",
    link: "DrugPregnancy"
  },
  {
    name: "Взаимодействие с печенью",
    link: "DrugHeptox"
  },
  {
    name: "Взаимодействие с дыхательной системой",
    link: "DrugPulmtox"
  },
  {
    name: "Взаимодействие с почками",
    link: "DrugNephtox"
  },
  {
    name: "Взаимодействие с пожилыми (≥65)",
    link: "DrugOlders"
  },
  {
    name: "Взаимодействие с QT интервалом",
    link: "DrugQt"
  },
  {
    name: "Лекарства, вызывающие метгемоглобинемию",
    link: "DrugMethem"
  },
  {
    name: "Лекарства, вызывающие лекарственно-индуцированную красную волчанку",
    link: "DrugDisl"
  },
  {
    name: "Перекрестная гиперчувствительность",
    link: "MenuCross"
  },
]
