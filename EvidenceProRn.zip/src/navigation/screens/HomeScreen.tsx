import Menu from '@/src/components/Menu'
import { useAppSelector } from '@/src/redux/hooks';
import { MainStackParamList } from '@/src/types/navigationTypes'
import { IMenuList } from '@/src/types/types';
import { faCalculator, faTablets, IconDefinition } from '@fortawesome/free-solid-svg-icons'
import React from 'react'

export default function HomeScreen() {

  return (
    <Menu
      data={homeList}
      headerTitle='Главная страница'
    />
  )
}

const homeList: IMenuList[] =
  [
    {
      name: "Лекарства",
      link: "DrugsMenu",
      icon: faTablets,
      lock: true
    },
    {
      name: "Калькуляторы",
      link: "Calcs",
      icon: faCalculator
    }
  ]
