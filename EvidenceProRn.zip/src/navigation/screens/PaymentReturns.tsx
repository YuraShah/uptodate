import React from 'react'
import { Linking, Platform, SafeAreaView, ScrollView, View } from 'react-native'
import CustomText from '@/src/components/CustomTexts/CustomText'
import CustomTitle from '@/src/components/CustomTexts/CustomTitle'
import CustomBold from '@/src/components/CustomTexts/CustomBold'
import CustomLink from '@/src/components/CustomTexts/CustomLink'
import { useTheme } from '@/src/hooks/useTheme'
import CustomTextBold from '@/src/components/CustomTexts/CustomTextBold'

const PaymentReturns = () => {
   const { colors } = useTheme()

   return (
      <SafeAreaView style={{ flex: 1, backgroundColor: colors.background }}>
         <ScrollView contentContainerStyle={{ padding: 15 }}>
            <View style={{ marginBottom: 70, rowGap: 10 }}>
               <CustomTitle>Условия оплаты и возврата</CustomTitle>
               <CustomText>Оплата доступна исключительно через приложение, в соответствии с политикой {Platform.OS === 'ios' ? 'Apple App Store' : 'Google Play'}.</CustomText>
               {/* <CustomText>В настоящее время, в связи с санкциями, оплата возможна только банковским переводом.</CustomText>
               <CustomText>Для получения реквизитов (номера карты или счёта) свяжитесь с нами через <CustomLink onPress={() => Linking.openURL('https://vk.com/club230049359')}>ВКонтакте</CustomLink>, <CustomLink onPress={() => Linking.openURL('mailto:evidence_ebm@mail.ru')}>Email</CustomLink> или <CustomLink onPress={() => Linking.openURL('https://t.me/evidence_ebm')}>Telegram</CustomLink>.</CustomText> */}
               <View style={{ rowGap: 3 }}>
                  <CustomTextBold>Есть 3 варианта оплаты:</CustomTextBold>
                  <CustomText>Ежемесячная оплата — {Platform.OS === 'ios' ? '1290' : '1199'} руб. в месяц.</CustomText>
                  <CustomText>Оплата за 6 месяцев — {Platform.OS === 'ios' ? '6000' : '5999'} руб.</CustomText>
                  <CustomText>Ежегодная оплата — 11890 руб.</CustomText>
                  <CustomText>Выбирайте удобный для вас вариант и наслаждайтесь всеми преимуществами нашей платформы!</CustomText>
               </View>
               <CustomText>После перевода, пожалуйста, отправьте скриншот подтверждения оплаты и зарегистрированное имя пользователя или электронную почту на указанные выше адреса или в <CustomLink onPress={() => Linking.openURL('https://t.me/evidencepayments_bot')}>Телеграм-бот</CustomLink>.</CustomText>
               <CustomText>Проверка производится ежедневно с 09:00 до 24:00 по московскому времени. После проверки доступ будет открыт.</CustomText>
               <CustomText>Важно отметить, что после совершения платежа возврат средств <CustomBold>невозможен</CustomBold>. Подписки действительны в течение 1 или 6 месяцев и не продлеваются автоматически. По истечении срока действия подписки вам необходимо будет оплатить подписку повторно, если вы захотите продолжить пользоваться платформой.</CustomText>
               <CustomText>
                  Возврат средств осуществляется только согласно правилам {Platform.OS === 'ios' ? 'Apple App Store' : 'Google Play'}.
               </CustomText>
            </View>
         </ScrollView>
      </SafeAreaView>
   )
}

export default PaymentReturns
