import AngleRight from '@/src/components/AngleRight'
import CustomIconSmall from '@/src/components/CustomIcons/CustomIconSmall'
import CustomText from '@/src/components/CustomTexts/CustomText'
import CustomTextBold from '@/src/components/CustomTexts/CustomTextBold'
import ErrorNet from '@/src/components/ErrorNet'
import Loader from '@/src/components/Loader/Loader'
import Separator from '@/src/components/Separator'
import SeparatorDash from '@/src/components/SeparatorDash'
import { fetchUseQuery } from '@/src/functions/fetchUseQuery'
import { useTheme } from '@/src/hooks/useTheme'
import { deleteUserFavorites, getUserCalcs } from '@/src/redux/features/user/userAPI'
import { useAppDispatch } from '@/src/redux/hooks'
import { MainStackParamList } from '@/src/types/navigationTypes'
import { IResponseData, LINKS } from '@/src/types/types'
import { faX } from '@fortawesome/free-solid-svg-icons'
import { useNavigation } from '@react-navigation/native'
import { useQuery } from '@tanstack/react-query'
import React from 'react'
import { FlatList, RefreshControl, SafeAreaView, TouchableOpacity, View } from 'react-native'

type IFavorites = {
   title: string,
   group: {
      favorites_id: string
      title: string,
      link: string
   }[]
}

export default function Favorites() {
   const { colors } = useTheme()
   const dispatch = useAppDispatch()
   const navigation = useNavigation()

   const { isLoading, isError, data, refetch, isSuccess } = useQuery({
      queryKey: ['favorites'],
      queryFn: async () => {
         return fetchUseQuery<IResponseData<IFavorites>>(
            'post',
            LINKS.USERFAVORITES,
         )
      },
      gcTime: 2000
   })


   const deleteFavorite = (favId: string) => {
      dispatch(deleteUserFavorites(favId))
         .unwrap()
         .then(() => refetch())
   }

   React.useEffect(() => {
      dispatch(getUserCalcs())
   }, [])

   const onRefresh = React.useCallback(() => {
      refetch()
   }, [])


   if (isLoading) return <Loader />

   return (
      <SafeAreaView style={{ flex: 1, backgroundColor: colors.background }}>
         <FlatList
            contentContainerStyle={{ paddingVertical: 15 }}
            refreshControl={
               <RefreshControl
                  refreshing={isLoading}
                  onRefresh={onRefresh}
                  colors={[colors.mainBg]}
                  progressBackgroundColor={colors.refreshProgressBarBg}
               />
            }
            ListHeaderComponent={isError ? <ErrorNet /> : null}
            data={data?.data ?? []}
            renderItem={({ item }) => (
               <View style={{ paddingHorizontal: 15 }}>
                  <CustomTextBold>
                     {categories[item.title].title}
                  </CustomTextBold>
                  <FlatList
                     data={item.group}
                     renderItem={({ item: group }) => (
                        <View style={{
                           flexDirection: 'row',
                           justifyContent: 'space-between',
                           columnGap: 7
                        }}>
                           <TouchableOpacity
                              onPress={() => {
                                 const category = categories[item.title];
                                 navigation.navigate("Home", {
                                    screen: category.link as any,
                                    params: {
                                       param: group.link
                                    }
                                 })
                              }}
                              style={{
                                 flexDirection: 'row',
                                 justifyContent: 'space-between',
                                 alignItems: 'center',
                                 paddingVertical: 10,
                                 flex: 1,
                                 columnGap: 3
                              }}
                           >
                              <CustomText style={{ flex: 1 }}>
                                 {group.title}
                              </CustomText>
                              <AngleRight />
                           </TouchableOpacity>
                           <TouchableOpacity
                              onPress={() => deleteFavorite(group.favorites_id)}
                              style={{
                                 width: 30,
                                 alignItems: 'center',
                                 justifyContent: 'center',
                                 paddingTop: 4
                              }}
                           >
                              <CustomIconSmall
                                 icon={faX}
                                 color={colors.angleRightPrimary}
                              />
                           </TouchableOpacity>

                        </View>
                     )}
                     keyExtractor={group => group.favorites_id}
                     ItemSeparatorComponent={() => <SeparatorDash isMarginHorizontal />}
                  />
               </View>
            )}
            ItemSeparatorComponent={() => <Separator />}
            ListEmptyComponent={isSuccess ? <CustomText style={{ paddingHorizontal: 15 }}>Нет добавленных</CustomText> : null}
         />
      </SafeAreaView>
   )
}

const categories: Record<string, { title: string, link: keyof MainStackParamList }> = {
   "calc": {
      title: "Калькуляторы",
      link: "CalcsItem",
   },
}
