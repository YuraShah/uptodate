import React, { useEffect, useState } from 'react'
import { useForm } from 'react-hook-form'
import { useAppDispatch, useAppSelector } from '@/src/redux/hooks';
import { Alert, SafeAreaView, ScrollView, StyleSheet, View, useWindowDimensions } from 'react-native';
import { IResponseMessage, LINKS } from '@/src/types/types';
import * as yup from "yup";
import { yupResolver } from "@hookform/resolvers/yup";
import { signOut } from '@/src/redux/features/auth/authAPI';
import FormPassword from '@/src/components/Form/FormPassword';
import ButtonLoad from '@/src/components/ButtonLoad';
import Error from '@/src/components/ErrorNet';
import CustomTitle from '@/src/components/CustomTexts/CustomTitle';
import { useMutation } from '@tanstack/react-query';
import { useTheme } from '@/src/hooks/useTheme';
import { fetchUseQuery } from '@/src/functions/fetchUseQuery';
import { Toast } from 'toastify-react-native';
import { useNavigation } from '@react-navigation/native';
import CustomTextBold from '@/src/components/CustomTexts/CustomTextBold';
import ToastModal from '@/src/components/ToastModal';

const schema = yup.object().shape({
   old_password: yup
      .string()
      .required("Поле обязательно для заполнения")
      .matches(
         /^(?=.*[0-9])(?=.*[a-zа-яА-Я])(?=.*[A-Zа-яА-Я]).{8,32}$/,
         "Поле обязательно для заполнения"
      ),
   new_password: yup
      .string()
      .required("Поле обязательно для заполнения")
      .matches(
         /^(?=.*[0-9])(?=.*[a-zа-яА-Я])(?=.*[A-Zа-яА-Я]).{8,32}$/,
         "Пароль должен состоять не менее чем из 8 символов, начинаться с буквы, содержать не менее 1 цифры, 1 строчной буквы и 1 заглавной буквы"
      ),
   new_password_confirm: yup
      .string()
      .required("Поле обязательно для заполнения")
      .oneOf([yup.ref("new_password")], "Это поле должно совпадать с паролем"),
});

type IUserChangePass = {
   old_password: string,
   new_password: string,
   new_password_confirm: string
}
type IUserChangePassReq = {
   email: string,
   oldpass: string,
   newpass: string,
}

const UserChangePassword = () => {
   const { user } = useAppSelector((state) => state.authStore)
   const { control, handleSubmit, formState: { errors } } = useForm<IUserChangePass>({ resolver: yupResolver(schema) })
   const [isOldPasswordShow, setIsOldPasswordShow] = useState<boolean>(false);
   const [isNewPasswordShow, setIsNewPasswordShow] = useState<boolean>(false);
   const [isNewPasswordConfirmShow, setIsNewPasswordConfirmShow] = useState<boolean>(false);
   const dispatch = useAppDispatch()
   const windowWidth = useWindowDimensions().width;
   const { deviceToken } = useAppSelector(state => state.notificationsStore)
   const { colors } = useTheme()
   const navigation = useNavigation()
   const [toastText, setToastText] = useState<string>()

   const { mutate, isPending, isError, data } = useMutation({
      mutationFn: async (obj: string) => {
         return fetchUseQuery<IResponseMessage>(
            'post', LINKS.CHANGEUSERPASSWORD, obj
         )
      },
   })

   const save = (data: IUserChangePass) => {
      if (!user) return

      if (data.old_password === data.new_password) {
         // Toast.error("Новый пароль не должен быть повторением старого пароля", "top")
         setToastText("Новый пароль не должен быть повторением старого пароля")
      } else {
         const reqObj: IUserChangePassReq = {
            email: user.email,
            oldpass: data.old_password,
            newpass: data.new_password
         }
         mutate(JSON.stringify(reqObj))
      }
   }

   const serverResponses = () => {
      if (!user || !data || !data.message) return

      if (data.message.length > 0 && data.message[0] === "wrong password") {
         // Toast.error("Старый пароль неверный", "top")
         setToastText("Старый пароль неверный")
      } else if (data.message.length > 0 && data.message[0] === "success") {

         dispatch(signOut(JSON.stringify({ uid: user?.id!, device_token: deviceToken })))
            .then(() => {
               navigation.navigate('Home', { screen: 'SignIn' })
            })

         Alert.alert('', 'Вы изменили свой пароль. Пожалуйста, войдите снова.', [
            { text: 'ОК', style: 'default', },
         ]);
      } else if (data.message.length > 0 && data.message[0] === "limit") {
         // Toast.error("Превышен лимит смены пароля в 1 день. Попробуйте завтра", "top")
         setToastText("Превышен лимит смены пароля в 1 день. Попробуйте завтра")
      }
   }

   useEffect(() => {
      serverResponses()
   }, [data])

   useEffect(() => {
      if (toastText) {
         const timeout = setTimeout(() => {
            setToastText(undefined);
         }, 2000);

         return () => clearTimeout(timeout);
      }
   }, [toastText]);


   return (
      <SafeAreaView style={{ flex: 1, backgroundColor: colors.background }}>
         <ToastModal
            text={toastText!}
            opacity={toastText ? 1 : 0}
         />
         <ScrollView
            style={styles.container}
         >
            <CustomTitle>Смена пароля</CustomTitle>
            {data && data.message && data.message.length > 0 && data.message[0] === "success" ? (
               <CustomTextBold style={[styles.attentionText, { color: colors.formAttention }]}>
                  Пароль успешно изменен.
               </CustomTextBold>
            ) : (
               <>
                  {isError && <Error />}
                  <View style={[styles.form, windowWidth >= 780 && { width: '70%' }]}>
                     <FormPassword<IUserChangePass>
                        control={control}
                        labelTitle={'Напишите текущий пароль'}
                        inputId={'old_password'}
                        errorMessage={errors.old_password?.message}
                        required
                        showBoolean={isOldPasswordShow}
                        showFunction={setIsOldPasswordShow}
                        fontBold
                     />
                     <FormPassword<IUserChangePass>
                        control={control}
                        labelTitle={'Напишите новый пароль'}
                        inputId={'new_password'}
                        errorMessage={errors.new_password?.message}
                        required
                        showBoolean={isNewPasswordShow}
                        showFunction={setIsNewPasswordShow}
                        fontBold
                     />
                     <FormPassword<IUserChangePass>
                        control={control}
                        labelTitle={'Потвердите новый пароль'}
                        inputId={'new_password_confirm'}
                        errorMessage={errors.new_password_confirm?.message}
                        required
                        showBoolean={isNewPasswordConfirmShow}
                        showFunction={setIsNewPasswordConfirmShow}
                        fontBold
                     />
                     <ButtonLoad
                        title={'Изменить'}
                        status={isPending}
                        marginTop={10}
                        onPress={handleSubmit(save)}
                     />
                  </View>
               </>
            )}
         </ScrollView>
      </SafeAreaView>
   )
}

const styles = StyleSheet.create({
   container: {
      padding: 15,
   },
   attentionText: {
      marginTop: 15
   },
   form: {
      marginTop: 10,
      marginBottom: 280,
      padding: 5,
      rowGap: 15
   },
})

export default UserChangePassword
