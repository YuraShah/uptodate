import React, { useState } from 'react';
import { useForm } from 'react-hook-form';
import { useAppDispatch, useAppSelector } from '@/src/redux/hooks';
import { Platform, RefreshControl, SafeAreaView, ScrollView, StyleSheet, TouchableOpacity, View, useWindowDimensions } from 'react-native';
import { yupResolver } from "@hookform/resolvers/yup";
import * as yup from "yup";
import { clearRegisterMessage, clearSignMessage } from '@/src/redux/features/auth/authSlice';
import ButtonLoad from '@/src/components/ButtonLoad';
import FormInput from '@/src/components/Form/FormInput';
import FormPassword from '@/src/components/Form/FormPassword';
import { signIn } from '@/src/redux/features/auth/authAPI';
import CustomText from '@/src/components/CustomTexts/CustomText';
import CustomTitle from '@/src/components/CustomTexts/CustomTitle';
import CustomLink from '@/src/components/CustomTexts/CustomLink';
import { useTheme } from '@/src/hooks/useTheme';
import { useNavigation } from '@react-navigation/native';
import { NativeStackNavigationProp } from '@react-navigation/native-stack';
import { MainStackParamList } from '@/src/types/navigationTypes';
import { Toast } from 'toastify-react-native';
import { clearCheckVerifyResendData, clearForgetPasswordData } from '@/src/redux/features/verifyRecovery/verifySlice';
import ErrorNet from '@/src/components/ErrorNet';
import CustomTextBold from '@/src/components/CustomTexts/CustomTextBold';
import * as Device from 'expo-device';
import Constants from 'expo-constants';
import * as SecureStore from 'expo-secure-store';
import CustomBold from '@/src/components/CustomTexts/CustomBold';
import CustomTextSmall from '@/src/components/CustomTexts/CustomTextSmall';


const schema = yup.object().shape({
  email: yup
    .string()
    .required("Поле обязательно для заполнения")
    .email("Неверный адрес электронной почты"),
  password: yup
    .string()
    .required("Поле обязательно для заполнения")
    .matches(
      /^(?=.*[0-9])(?=.*[a-zа-я])(?=.*[A-ZА-Я]).{8,32}$/,
      "Неправильный пароль"
    ),
});

type SignInForm = {
  email: string,
  password: string,
}

const getUniqueId = async () => {
  let id = await SecureStore.getItemAsync('uniqueDeviceId');
  return id;
}


const SignIn = () => {
  const { control, handleSubmit, formState: { errors }, reset } = useForm<SignInForm>({ resolver: yupResolver(schema) })
  const { user, error, status, signMessage } = useAppSelector((state) => state.authStore)
  const dispatch = useAppDispatch();
  const [isShowPassword, setIsShowPassword] = useState<boolean>(false);
  const windowWidth = useWindowDimensions().width;
  const [refreshing, setRefreshing] = React.useState(false);
  const { deviceToken } = useAppSelector(state => state.notificationsStore)
  const { colors } = useTheme()
  const navigation = useNavigation<NativeStackNavigationProp<MainStackParamList>>()

  const save = async (data: SignInForm) => {
    const signInData = {
      email: data.email.trim(),
      password: data.password,
      device_token: deviceToken,
      remember_me: true,
      device: Device.manufacturer ?? '0',
      version: Constants?.expoConfig?.version ?? '0',
      uniqId: await getUniqueId() ?? '',
      platform: Platform.OS
    }

    dispatch(signIn(JSON.stringify(signInData)))
      .unwrap()
      .then((user) => {
        if (!user.data) return
        Toast.success(`Добро пожаловать, ${user.data.user.username}`)
        dispatch(clearSignMessage())
        navigation.replace('HomeScreen')
      })
  }

  const navigateToForgetPassword = () => {
    dispatch(clearForgetPasswordData())
    navigation.navigate('ForgotPassword')
  }

  const navigateToVerifyResend = () => {
    navigation.navigate('VerifyResend')
    dispatch(clearCheckVerifyResendData())
  }

  const navigateToRegister = () => {
    navigation.navigate('Register')
    dispatch(clearRegisterMessage())
  }

  const onRefresh = React.useCallback(() => {
    setRefreshing(true);
    dispatch(clearSignMessage())
    reset()
    setIsShowPassword(false)
    setTimeout(() => {
      setRefreshing(false);
    }, 300);
  }, []);


  return (
    !user && (
      <SafeAreaView style={{ flex: 1, backgroundColor: colors.background }}>
        <ScrollView
          style={styles.container}
          refreshControl={
            <RefreshControl
              refreshing={refreshing}
              onRefresh={onRefresh}
              colors={[colors.mainBg]}
              progressBackgroundColor={colors.refreshProgressBarBg}
            />
          }
        >
          <CustomTitle>Вход в аккаунт</CustomTitle>
          {error !== '' ? (
            <ErrorNet />
          ) : status === 'succeeded' && signMessage.length > 0 && signMessage[0] === 'Verify email code' && (
            <CustomTextBold style={[styles.attentionText, { color: colors.formAttention }]}>Для входа в аккаунт необходимо подтвердить код на электронной почте. Если его нет в основной папке, следует также проверить папку «Спам». (<CustomLink onPress={() => navigateToVerifyResend()}>отправить еще раз</CustomLink>)</CustomTextBold>
          )}
          {status === 'succeeded' && signMessage.length > 0 && (
            <CustomTextBold style={[styles.attentionText, { color: colors.formAttention }]}>
              {signMessage[0] === 'Blocked' ? (
                "Аккаунт заблокирован"
              ) : signMessage[0] === 'Not found' ? (
                "Пользователь не найден"
              ) : signMessage[0] === 'The user is already signed in with another device' ? (
                "Пользователь уже вошел в систему на другом устройстве"
              ) : signMessage[0] === 'The device is already attached to another user' ? (
                "Устройство уже связан к другому пользователю"
              ) : ''
              }
            </CustomTextBold>
          )}
          <CustomTextSmall style={{ marginVertical: 10 }}><CustomBold>Внимание։</CustomBold> устройство привязывается к аккаунту. Для входа с другого устройства необходимо сначала выйти из аккаунта на текущем устройстве.</CustomTextSmall>
          <View
            style={[styles.form, windowWidth >= 780 && { width: '70%' }]}
          >
            <FormInput<SignInForm>
              control={control}
              labelTitle={'Электронная почта'}
              inputId={'email'}
              inputPlaceholder={''}
              errorMessage={errors.email?.message}
              required
              autoCapitalize={true}
              fontBold={true}
            />
            <FormPassword<SignInForm>
              control={control}
              labelTitle={'Пароль'}
              inputId={'password'}
              errorMessage={errors.password?.message}
              required
              showBoolean={isShowPassword}
              showFunction={setIsShowPassword}
              fontBold={true}
            />
            <View>
              <TouchableOpacity
                onPress={() => navigateToForgetPassword()}
                accessibilityLabel='Press Navigate'
                style={{ marginVertical: 15 }}
              >
                <CustomText><CustomLink>Забыл пароль</CustomLink></CustomText>
              </TouchableOpacity>
            </View>
            <View>
              <TouchableOpacity
                onPress={() => navigateToRegister()}
                accessibilityLabel='Press Navigate'
                style={{ minHeight: 48, marginBottom: 15 }}
              >
                <CustomText><CustomLink>Регистрация</CustomLink></CustomText>
              </TouchableOpacity>
            </View>
            <ButtonLoad
              title={'Вход'}
              status={status}
              onPress={handleSubmit(save)}
            />
          </View>
        </ScrollView>
      </SafeAreaView>
    )
  )
}

const styles = StyleSheet.create({
  container: {
    padding: 15,
  },
  attentionText: {
    marginTop: 10
  },
  form: {
    marginTop: 10,
    marginBottom: 280,
    padding: 5,
    rowGap: 10
  },
})

export default SignIn
