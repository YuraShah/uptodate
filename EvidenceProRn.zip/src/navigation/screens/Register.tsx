import React, { useEffect, useState } from 'react'
import * as yup from "yup";
import { yupResolver } from "@hookform/resolvers/yup";
import { useForm } from 'react-hook-form';
import { useAppDispatch, useAppSelector } from '@/src/redux/hooks';
import { useTheme } from '@/src/hooks/useTheme';
import { useNavigation } from '@react-navigation/native';
import { RefreshControl, SafeAreaView, ScrollView, StyleSheet, TextInput, useWindowDimensions, View } from 'react-native';
import { clearRegisterMessage } from '@/src/redux/features/auth/authSlice';
import { Toast } from 'toastify-react-native';
import CustomTitle from '@/src/components/CustomTexts/CustomTitle';
import CustomText from '@/src/components/CustomTexts/CustomText';
import FormInput from '@/src/components/Form/FormInput';
import FormPassword from '@/src/components/Form/FormPassword';
import CustomLink from '@/src/components/CustomTexts/CustomLink';
import Checkbox from 'expo-checkbox';
import ButtonLoad from '@/src/components/ButtonLoad';
import { registerUser } from '@/src/redux/features/auth/authAPI';
import CustomTextBold from '@/src/components/CustomTexts/CustomTextBold';
import CustomTextSmall from '@/src/components/CustomTexts/CustomTextSmall';
import CustomBold from '@/src/components/CustomTexts/CustomBold';

const schema = yup.object().shape({
   email: yup
      .string()
      .required("Поле обязательно для заполнения")
      .email("Неверный адрес электронной почты"),
   username: yup
      .string()
      .required("Поле обязательно для заполнения")
      .min(5, "Имя пользователя должно быть не менее 5 символов")
      .max(30, "Имя пользователя должно содержать не более 30 символов"),
   firstname: yup
      .string()
      .required("Поле обязательно для заполнения")
      .matches(/^[a-zA-Zа-яА-Я]+$/, "Имя должно состоять только из букв (английский, русский)")
      .min(2, "Имя должно состоять не менее чем из 2 символов")
      .max(30, "Имя должно содержать не более 30 символов"),
   surname: yup
      .string()
      .required("Поле обязательно для заполнения")
      .matches(/^[a-zA-Zа-яА-Я]+$/, "Фамилия должна состоять только из букв (английский, русский)")
      .min(4, "Фамилия должна быть длиной не менее 4 символов")
      .max(50, "Фамилия должна содержать не более 50 символов"),
   password: yup
      .string()
      .required("Поле обязательно для заполнения")
      .matches(
         /^(?=.*[0-9])(?=.*[a-zа-яА-Я])(?=.*[A-Zа-яА-Я]).{8,32}$/,
         "Пароль должен состоять не менее чем из 8 символов, начинаться с буквы, содержать не менее 1 цифры, 1 строчной буквы и 1 заглавной буквы"
      ),
   password_confirmation: yup
      .string()
      .required("Поле обязательно для заполнения")
      .oneOf([yup.ref("password")], "Это поле должно совпадать с паролем"),
});

type RegisterForm = {
   email: string,
   username: string,
   firstname: string,
   surname: string,
   password: string,
   password_confirmation: string,
}


export default function Register() {
   const { control, handleSubmit, formState: { errors }, reset } = useForm<RegisterForm>({ resolver: yupResolver(schema) })
   const dispatch = useAppDispatch();
   const [isShowPassword, setIsShowPassword] = useState<boolean>(false);
   const [isShowPasswordConfirm, setIsShowPasswordConfirm] = useState<boolean>(false);
   const [refreshing, setRefreshing] = React.useState(false);
   const { colors } = useTheme()
   const { user, registerStatus, registerMessage } = useAppSelector((state) => state.authStore)
   const windowWidth = useWindowDimensions().width;
   const [isChecked, setChecked] = useState(false);
   const [checkedError, setCheckedError] = useState('')
   const [honeypot, setHoneyPot] = useState('')
   const navigation = useNavigation()


   const save = (data: RegisterForm) => {
      if (!isChecked) {
         Toast.info("Все поля обязательны для заполнения")
         setCheckedError('Поле обязательно для заполнения')
         return
      }

      if (honeypot.trim()) {
         Toast.info("Ошибка")
         return
      }
      setCheckedError('')

      const registerData = {
         email: data.email,
         username: data.username,
         password: data.password,
         firstname: data.firstname,
         surname: data.surname,
      }

      dispatch(registerUser(JSON.stringify(registerData)))
         .unwrap()
         .then(() => {
         })
         .catch((err) => {
            Toast.error(err.message, 'top');
         });
   }

   useEffect(() => {
      if (registerMessage[0] === "Success") {
         Toast.success("Вы успешно зарегистрировались", 'top')
      }
   }, [registerMessage])


   const onRefresh = React.useCallback(() => {
      setRefreshing(true);
      dispatch(clearRegisterMessage())
      reset()
      setIsShowPassword(false)
      setIsShowPasswordConfirm(false)
      setChecked(false)
      setCheckedError('')
      setTimeout(() => {
         setRefreshing(false);
      }, 300);
   }, []);


   return (
      !user && (
         <SafeAreaView style={{ flex: 1, backgroundColor: colors.background }}>
            <ScrollView
               style={styles.container}
               refreshControl={
                  <RefreshControl
                     refreshing={refreshing}
                     onRefresh={onRefresh}
                     colors={[colors.mainBg]}
                     progressBackgroundColor={colors.refreshProgressBarBg}
                  />
               }
            >
               <CustomTitle>Вход в аккаунт</CustomTitle>
               {registerMessage?.length > 0 && registerMessage[0] === "Success" ? (
                  <CustomTextBold style={[styles.attentionText, { color: colors.formAttention }]}>Вы успешно зарегистрировались. Код подтверждения был отправлен на ваш адрес электронной почты (если его нет в вашей основной папке, вам также следует проверить папку «Спам»).</CustomTextBold>
               ) : (
                  <>
                     <CustomTextSmall style={{ marginVertical: 10 }}><CustomBold>Внимание։</CustomBold> пробный полный доступ предоставляется на 2 дня. После окончания пробного периода требуется оформить подписку.</CustomTextSmall>
                     <View
                        style={[styles.form, windowWidth >= 780 && { width: '70%' }]}
                     >
                        <FormInput<RegisterForm>
                           control={control}
                           labelTitle={'Электронная почта'}
                           inputId={'email'}
                           inputPlaceholder={''}
                           errorMessage={errors.email?.message}
                           required
                           autoCapitalize={true}
                           fontBold={true}
                        />
                        <FormInput<RegisterForm>
                           control={control}
                           labelTitle={'Имя пользователя'}
                           inputId={'username'}
                           inputPlaceholder={''}
                           errorMessage={errors.username?.message}
                           required
                           autoCapitalize={true}
                           fontBold={true}
                        />
                        <FormInput<RegisterForm>
                           control={control}
                           labelTitle={'Имя'}
                           inputId={'firstname'}
                           inputPlaceholder={''}
                           errorMessage={errors.firstname?.message}
                           required
                           autoCapitalize={true}
                           fontBold={true}
                        />
                        <FormInput<RegisterForm>
                           control={control}
                           labelTitle={'Фамилия'}
                           inputId={'surname'}
                           inputPlaceholder={''}
                           errorMessage={errors.surname?.message}
                           required
                           autoCapitalize={true}
                           fontBold={true}
                        />
                        <FormPassword<RegisterForm>
                           control={control}
                           labelTitle={'Пароль'}
                           inputId={'password'}
                           errorMessage={errors.password?.message}
                           required
                           showBoolean={isShowPassword}
                           showFunction={setIsShowPassword}
                           fontBold={true}
                        />
                        <FormPassword<RegisterForm>
                           control={control}
                           labelTitle={'Повторите пароль'}
                           inputId={'password_confirmation'}
                           errorMessage={errors.password_confirmation?.message}
                           required
                           showBoolean={isShowPasswordConfirm}
                           showFunction={setIsShowPasswordConfirm}
                           fontBold={true}
                        />
                        <TextInput
                           value={honeypot}
                           onChangeText={setHoneyPot}
                           placeholder=''
                           accessible={false}
                           style={{ height: 0, opacity: 0, position: 'absolute', left: -9999 }}
                        />
                        <View style={{ marginBottom: 15 }}>
                           {checkedError !== '' && (
                              <CustomText style={[styles.errorText, { color: colors.formError }]}>
                                 {checkedError}
                              </CustomText>
                           )}
                           <View style={styles.checkboxContainer}>
                              <Checkbox
                                 color={colors.checkboxColor}
                                 value={isChecked}
                                 onValueChange={setChecked}
                              />
                              <CustomText>
                                 Я принимаю <CustomLink onPress={() => navigation.navigate("Settings", { screen: "Privacy" })}>условия использования</CustomLink> и <CustomLink onPress={() => navigation.navigate("Settings", { screen: "Privacy" })}>политику конфиденциальности</CustomLink> Evidence
                              </CustomText>
                           </View>
                        </View>
                        <ButtonLoad
                           title={'Регистрация'}
                           status={registerStatus}
                           onPress={handleSubmit(save)}
                        />
                     </View>
                  </>
               )}
            </ScrollView>
         </SafeAreaView>
      )
   )
}

const styles = StyleSheet.create({
   container: {
      padding: 15,
   },
   attentionText: {
      marginTop: 10
   },
   form: {
      marginTop: 10,
      marginBottom: 280,
      padding: 5,
      rowGap: 10
   },
   errorText: {
      marginBottom: 7,
   },
   checkboxContainer: {
      flexDirection: 'row',
      alignItems: 'center',
      columnGap: 12,
   }
})
