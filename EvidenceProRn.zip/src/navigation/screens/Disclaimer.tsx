import CustomText from '@/src/components/CustomTexts/CustomText'
import CustomTitle from '@/src/components/CustomTexts/CustomTitle'
import { useTheme } from '@/src/hooks/useTheme'
import React from 'react'
import { SafeAreaView, ScrollView, View } from 'react-native'

export default function Disclaimer() {
   const { colors } = useTheme()

   return (
      <SafeAreaView style={{ flex: 1, backgroundColor: colors.background }}>
         <ScrollView>
            <View style={{ padding: 15, rowGap: 10, marginBottom: 70 }}>
               <CustomTitle>Отказ от отвественности</CustomTitle>
               <CustomText>
                  Данная платформа предоставляет информацию исключительно в ознакомительных целях. Её нельзя использовать в качестве основы для самостоятельной диагностики и лечения, и он не может заменить консультацию врача. Пользователь несет ответственность за любые принятые решения и действия, совершенные на основании информации, предоставленной в приложении. Перед принятием решения о лечении, а также перед началом или изменением лечения всегда следует консультироваться с квалифицированным врачом.
               </CustomText>
            </View>
         </ScrollView>
      </SafeAreaView>
   )
}
