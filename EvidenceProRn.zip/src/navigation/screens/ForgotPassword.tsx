import React from 'react';
import { useForm } from 'react-hook-form';
import { IResponseMessage, LINKS } from '@/src/types/types';
import { RefreshControl, SafeAreaView, ScrollView, StyleSheet, View, useWindowDimensions } from 'react-native';
import * as yup from "yup";
import { yupResolver } from "@hookform/resolvers/yup";
import FormInput from '@/src/components/Form/FormInput';
import ButtonLoad from '@/src/components/ButtonLoad';
import CustomText from '@/src/components/CustomTexts/CustomText';
import CustomTitle from '@/src/components/CustomTexts/CustomTitle';
import { useMutation } from '@tanstack/react-query';
import { fetchUseQuery } from '@/src/functions/fetchUseQuery';
import { useTheme } from '@/src/hooks/useTheme';
import CustomTextBold from '@/src/components/CustomTexts/CustomTextBold';


const schema = yup.object().shape({
   forgetPassword: yup
      .string()
      .required("Поле обязательно для заполнения")
      .email("Неверный адрес электронной почты"),
});

export type ForgetPasswordForm = {
   forgetPassword: string;
}

const ForgotPassword = () => {
   const { control, handleSubmit, formState: { errors }, setValue } = useForm<ForgetPasswordForm>({ resolver: yupResolver(schema) })
   const windowWidth = useWindowDimensions().width;
   const [refreshing, setRefreshing] = React.useState(false);
   const { colors } = useTheme()

   const { mutate, isPending, isError, data, reset } = useMutation({
      mutationFn: async (formData: string) => {
         return fetchUseQuery<IResponseMessage>(
            'post', LINKS.FORGOTPASSWORD, formData
         );
      }
   })

   const save = (data: ForgetPasswordForm): void => {
      mutate(JSON.stringify(data.forgetPassword))
   }

   const onRefresh = React.useCallback(() => {
      setRefreshing(true);
      setValue('forgetPassword', '')
      reset()
      setTimeout(() => {
         setRefreshing(false);
      }, 300);
   }, []);


   return (
      <SafeAreaView style={{ flex: 1, backgroundColor: colors.background }}>
         <ScrollView
            style={styles.container}
            refreshControl={
               <RefreshControl
                  refreshing={refreshing}
                  onRefresh={onRefresh}
                  colors={[colors.mainBg]}
                  progressBackgroundColor={colors.refreshProgressBarBg}
               />
            }
         >
            <CustomTitle>Восстановления пароля</CustomTitle>
            {data && data.message.length > 0 && data.message[0] === 'Invalid email' && (
               <CustomText style={[styles.attentionText, { color: colors.formAttention }]}>
                  Адрес электронной почты указан неверно
               </CustomText>
            )}
            {isError ? (
               <CustomText style={[styles.attentionText, { color: colors.formAttention }]}>
                  Проблема с подключением. Попробуйте обновить страницу
               </CustomText>
            ) : data && data.message?.length > 0 && data.message[0] === 'A password recovery code has been sent to the email address' ? (
               <CustomTextBold style={[styles.attentionText, { color: colors.formAttention }]}>Код восстановления пароля отправлен на ваш адрес электронной почты. Если его нет в вашей основной папке, вам также следует проверить папку «Спам».</CustomTextBold>
            ) : data && data.message?.length > 0 && data.message[0] === 'The recovery code has already been sent' ? (
               <CustomTextBold style={[styles.attentionText, { color: colors.formAttention }]}>Код восстановления уже отправлен на ваш адрес электронной почты. Вы можете его активировать. Если его нет в вашей основной папке, вам также следует проверить папку «Спам».</CustomTextBold>
            ) : data && data.message?.length > 0 && data.message[0] === 'The recovery code had expired' ? (
               <CustomTextBold style={[styles.attentionText, { color: colors.formAttention }]}>Срок действия кода восстановления истек. Новый был отправлен. Если его нет в вашей основной папке, вам также следует проверить папку «Спам».</CustomTextBold>
            ) : data && data.message?.length > 0 && data.message[0] === 'Exhausted' ? (
               <CustomTextBold style={[styles.attentionText, { color: colors.formAttention }]}>Превышен лимит смены пароля в 1 день. Попробуйте завтра.</CustomTextBold>
            ) : (
               <View style={[styles.form, windowWidth >= 780 && { width: '70%' }]}>
                  <FormInput<ForgetPasswordForm>
                     control={control}
                     labelTitle={'Напишите адрес электронной почты'}
                     inputId={'forgetPassword'}
                     inputPlaceholder={''}
                     errorMessage={errors.forgetPassword?.message}
                     required
                     autoCapitalize={true}
                     fontBold={true}
                  />
                  <ButtonLoad
                     title={'Восстановить'}
                     status={isPending}
                     onPress={handleSubmit(save)}
                     marginTop={5}
                  />
               </View>
            )}
         </ScrollView>
      </SafeAreaView>
   )
}

const styles = StyleSheet.create({
   container: {
      padding: 15,
   },
   attentionText: {
      marginTop: 10,
   },
   form: {
      marginTop: 10,
      marginBottom: 40,
      padding: 5,
      rowGap: 10,
   },
})

export default ForgotPassword
