import React, { useEffect } from 'react'
import { BackHandler } from 'react-native'
import { useFocusEffect, useNavigation } from '@react-navigation/native';
import CustomTextNoFont from '@/src/components/CustomTexts/CustomTextNoFont';
import { SafeAreaView } from 'react-native-safe-area-context';
import { NativeStackNavigationProp } from '@react-navigation/native-stack';
import { MainStackParamList } from '@/src/types/navigationTypes';
import CustomStatusBar from '@/src/components/CustomStatusBar';
import { useTheme } from '@/src/hooks/useTheme';


const BlockDevice = () => {
   const navigation = useNavigation<NativeStackNavigationProp<MainStackParamList>>();

   useEffect(() => {
      const backAction = () => {
         return true;
      };

      const backHandler = BackHandler.addEventListener(
         'hardwareBackPress',
         backAction
      );

      return () => backHandler.remove();
   }, []);

   useFocusEffect(
      React.useCallback(() => {
         navigation.getParent()?.setOptions({
            swipeEnabled: false,
         });

         return () => {
            navigation.getParent()?.setOptions({
               swipeEnabled: true,
            });
         };
      }, [navigation])
   );


   return (
      <>
         <CustomStatusBar />
         <SafeAreaView style={{ flex: 1, backgroundColor: '#f2f2f2' }}>
            <CustomTextNoFont style={{ margin: 20, fontSize: 17, color: 'black' }}>
               Устройство заблокировано.
            </CustomTextNoFont>
         </SafeAreaView>
      </>
   )
}

export default BlockDevice
