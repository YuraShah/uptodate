import React from 'react';
import { Linking, SafeAreaView, ScrollView, View } from 'react-native';
import CustomText from '@/src/components/CustomTexts/CustomText';
import CustomTitle from '@/src/components/CustomTexts/CustomTitle';
import CustomTextBold from '@/src/components/CustomTexts/CustomTextBold';
import CustomLink from '@/src/components/CustomTexts/CustomLink';
import { useNavigation } from '@react-navigation/native';
import { useTheme } from '@/src/hooks/useTheme';

const About = () => {
   const navigation = useNavigation()
   const { colors } = useTheme()

   return (
      <SafeAreaView style={{ flex: 1, backgroundColor: colors.background }}>
         <ScrollView contentContainerStyle={{ padding: 15 }}>
            <View style={{ rowGap: 10 }}>
               <CustomTitle>О нас</CustomTitle>
               <CustomText><CustomTextBold>Evidence</CustomTextBold> - большая медицинская информационная платформа, призванная помочь пациентам и врачам, а также повысить качество лечения. Платформа содержит актуальную информацию о лекарственных препаратах, их взаимодействии с органами и системами организма, а также включает большую базу медицинских калькуляторов. Все источники информации приведены в нижней части страницы.</CustomText>
               <CustomText>Переосмыслите медицинскую информацию. <CustomTextBold>Evidence</CustomTextBold> Переосмыслите медицинскую информацию.</CustomText>
               <CustomText>Если у вас есть вопросы или предложения, напишите в <CustomLink onPress={() => Linking.openURL('https://t.me/evidence_ebm')}>телеграм</CustomLink> или на <CustomLink onPress={() => Linking.openURL('mailto:evidence_ebm@mail.ru')}>электронную почту</CustomLink>:</CustomText>
               <CustomTextBold style={{ marginTop: 20 }}>
                  Отказ от ответственности
               </CustomTextBold>
               <CustomText>Вся информация на платформе основана на научных статьях и исследованиях, регулярно обновляется, чтобы быть актуальной и точной, и предназначена исключительно для образовательных целей. Он не призван заменить самолечение или медицинские консультации, а скорее сделать их более эффективными. Любые изменения в лечении следует вносить только после консультации с врачом. При использовании полной или частичной информации с платформы ссылка на <CustomTextBold>Evidence</CustomTextBold> обязательна.</CustomText>
               <CustomText>Мы рекомендуем всегда консультироваться с врачом перед началом приема новых лекарств, лечения или изменения образа жизни. <CustomTextBold>Evidence</CustomTextBold> не несет ответственности за какие-либо советы, курс лечения, диагностику или любую другую информацию или услуги, включая медицинские услуги.</CustomText>
            </View>
         </ScrollView>
      </SafeAreaView>
   )
}

export default About
