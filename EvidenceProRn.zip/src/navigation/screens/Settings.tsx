import Separator from '@/src/components/Separator';
import { useTheme } from '@/src/hooks/useTheme';
import { signOut } from '@/src/redux/features/auth/authAPI';
import { useAppDispatch, useAppSelector } from '@/src/redux/hooks';
import { SettingsParamList } from '@/src/types/navigationTypes';
import { useFocusEffect, useNavigation } from '@react-navigation/native';
import React, { useCallback } from 'react'
import { Linking, Platform, RefreshControl, SafeAreaView, ScrollView, StyleSheet, Switch, TouchableOpacity, View } from 'react-native';
import { Toast } from 'toastify-react-native';
import { faAddressCard, faBell, faCreditCard, faEnvelope, faFile, faFont, faKey, faMedal, faMoon, faPalette, faRightFromBracket, faScaleBalanced, faShieldHalved, faSun, faUser, faUserMinus } from '@fortawesome/free-solid-svg-icons';
import { faTelegram, faVk } from '@fortawesome/free-brands-svg-icons';
import CustomIcon from '@/src/components/CustomIcons/CustomIcon';
import CustomTextLargeBold from '@/src/components/CustomTexts/CustomTextLargeBold';
import CustomText from '@/src/components/CustomTexts/CustomText';
import CustomTextBold from '@/src/components/CustomTexts/CustomTextBold';
import { getPaymentExpire, getPaymentStatus } from '@/src/redux/features/payment/paymentAPI';
import CustomLink from '@/src/components/CustomTexts/CustomLink';
import { setLarge, setMedium, setSmall } from '@/src/redux/features/fontSize/fontSizeSlice';
import * as SecureStore from 'expo-secure-store';
import Constants from 'expo-constants';
import { registerForPushNotifications } from '@/src/redux/features/notifications/notificationsAPI';
import { changeUserNotification, getUserNotification } from '@/src/redux/features/deviceParams/deviceParamsAPI';
import { userNotificationNumberChange } from '@/src/redux/features/deviceParams/deviceParamsSlice';
import { FontAwesomeIcon } from '@fortawesome/react-native-fontawesome';
import { toggleTheme } from '@/src/redux/features/theme/themeSlice';
import MenuList from '@/src/components/MenuList';
import AngleRight from '@/src/components/AngleRight';
import { saveInSecureStore } from '@/src/functions/functions';

export default function Settings() {
   const { deviceToken } = useAppSelector(state => state.notificationsStore)
   const { user } = useAppSelector(state => state.authStore)
   const dispatch = useAppDispatch()
   const { colors } = useTheme()
   const navigation = useNavigation()
   const [refreshing, setRefreshing] = React.useState(false);
   const { userNotificationNumber } = useAppSelector(state => state.deviceStore);
   const { paymentData, paymentExpire, paymentStatus } = useAppSelector(state => state.paymentStore);
   const { textSize } = useAppSelector(state => state.fontSizeStore);
   const { isDarkMode } = useAppSelector(state => state.themeStore)


   useFocusEffect(
      useCallback(() => {
         if (!user) return;

         const request = {
            uid: user.id,
            platform: Platform.OS
         }

         dispatch(getPaymentExpire(JSON.stringify(request)))
      }, [user])
   );

   const fontSizeBtn = (fz: string) => {
      if (fz === '14') {
         dispatch(setSmall())
      } else if (fz === '16') {
         dispatch(setMedium())
      } else if (fz === '18') {
         dispatch(setLarge())
      }

      const saveFontSize = async () => {
         try {
            await SecureStore.setItemAsync('fontSize', fz);
         } catch (error) {
         }
      };
      saveFontSize();
   }

   const handleTheme = async () => {
      try {
         await SecureStore.setItemAsync('theme', !isDarkMode ? 'dark' : 'light');
         dispatch(toggleTheme())
      } catch (error) {
      }
   }

   const handleLogout = () => {
      if (!user) return;

      dispatch(signOut(JSON.stringify({ uid: user.id, device_token: deviceToken })))
         .unwrap()
         .then(() => {
            Toast.success("Вы вышли из аккаунта", "top")
            navigation.navigate("Home", { screen: "SignIn" })
         })
         .catch((error) => {
            Toast.error(error.message ?? "Ошибка", "top")
         });
   };

   const notificationNumberChange = () => {
      if (!user) return

      if (userNotificationNumber[0] === 0) {

         if (deviceToken && deviceToken.startsWith("id-")) {
            dispatch(registerForPushNotifications())
               .unwrap()
               .then(() => {
                  dispatch(changeUserNotification(JSON.stringify({ uid: user!.id, notify_number: 1 })))
                     .then((r) => {
                        if (r?.meta?.requestStatus === 'fulfilled') {
                           dispatch(userNotificationNumberChange(1))
                           saveInSecureStore('1', 'notifyNumber');
                        }
                     })
               })
               .catch(() => {
                  Toast.info('Проблема с настройками. Включите уведомления из телефона', 'top');
               })
         } else {
            dispatch(changeUserNotification(JSON.stringify({ uid: user!.id, notify_number: 1 })))
               .then((r) => {
                  if (r?.meta?.requestStatus === 'fulfilled') {
                     dispatch(userNotificationNumberChange(1))
                     saveInSecureStore('1', 'notifyNumber');
                  }
               })
         }

      } else {
         dispatch(changeUserNotification(JSON.stringify({ uid: user!.id, notify_number: 0 })))
            .then((r) => {
               if (r?.meta?.requestStatus === 'fulfilled') {
                  dispatch(userNotificationNumberChange(0))
                  saveInSecureStore('0', 'notifyNumber');
               }
            })
      }
   }

   const FontBtn = ({
      fontSize,
      accLabel,
      label
   }: {
      fontSize: number,
      accLabel: string,
      label: string
   }) => {
      return (
         <TouchableOpacity
            onPress={() => fontSizeBtn(fontSize.toString())}
            style={[
               styles.fontTouch,
               textSize === fontSize && {
                  borderWidth: 2,
                  borderColor: isDarkMode ? colors.primary : colors.mainBg
               }
            ]}
            accessibilityLabel={`Press ${accLabel}`}
         >
            <CustomText
               style={[
                  {
                     color: textSize === fontSize && isDarkMode ? colors.primary : textSize === fontSize ? colors.mainBg : colors.secondary,
                     textAlign: 'center'
                  },
               ]}>
               {label}
            </CustomText>
         </TouchableOpacity>
      )
   }

   const onRefresh = React.useCallback(() => {
      if (!user) return;

      setRefreshing(true);
      dispatch(getUserNotification(JSON.stringify(user.id)))
      dispatch(getPaymentStatus(JSON.stringify(user.id)))
      dispatch(getPaymentExpire(JSON.stringify(user.id)))
      setTimeout(() => {
         setRefreshing(false);
      }, 300);
   }, []);


   return (
      <SafeAreaView style={{ flex: 1, backgroundColor: colors.background }}>
         <ScrollView
            style={styles.container}
            contentContainerStyle={{ flexGrow: 1 }}
            refreshControl={user ? (
               <RefreshControl
                  refreshing={refreshing}
                  onRefresh={onRefresh}
                  colors={[colors.mainBg]}
                  progressBackgroundColor={colors.refreshProgressBarBg}
               />
            ) : undefined}
         >
            <View style={{ flex: 1 }}>
               {user ? (
                  <View
                     style={styles.content}
                  >
                     <CustomTextLargeBold style={styles.title}>
                        Аккаунт
                     </CustomTextLargeBold>
                     <View
                        style={styles.contentNoTouch}
                     >
                        <View style={styles.contentView}>
                           <View style={styles.contentIcon}>
                              <CustomIcon
                                 icon={faUser}
                                 color={colors.primary}
                              />
                           </View>
                           <CustomText style={styles.contentText}>
                              Имя пользователя
                           </CustomText>
                        </View>
                        <CustomTextBold style={styles.contentOthText}>
                           {user?.username}
                        </CustomTextBold>
                     </View>
                     <Separator />
                     <View
                        style={styles.contentNoTouch}
                     >
                        <TouchableOpacity
                           style={styles.contentView}
                           onPress={() => navigation.navigate("Settings", { screen: 'ChangeEmail' })}
                        >
                           <View style={styles.contentIcon}>
                              <CustomIcon
                                 icon={faEnvelope}
                                 color={colors.primary}
                              />
                           </View>
                           <CustomText style={styles.contentText}>
                              Электронная почта
                           </CustomText>
                           <AngleRight />
                        </TouchableOpacity>
                        <CustomTextBold style={styles.contentOthText}>
                           {user?.email}
                        </CustomTextBold>
                     </View>
                     <Separator />
                     <MenuList
                        icon={faKey}
                        onPress={() => navigation.navigate("Settings", { screen: 'ChangePassword' })}
                        title='Изменить пароль'
                        color={colors.primary}
                     />
                     <Separator />
                     <View
                        style={styles.contentNoTouch}
                     >
                        <View style={styles.contentView}>
                           <View style={styles.contentIcon}>
                              <CustomIcon
                                 icon={faMedal}
                                 color={colors.primary}
                              />
                           </View>
                           <CustomText style={styles.contentText}>
                              Подписка
                           </CustomText>
                        </View>
                        <CustomTextBold style={[styles.contentOthText]}>
                           {paymentData.length > 0 && paymentData[0] === 1 ? (
                              <>Активна {paymentExpire.length > 0 && `(до ${paymentExpire[0]})`}</>
                           ) : (
                              <CustomLink onPress={() => navigation.navigate("Home", { screen: "Payment" })}>Не активна → Активировать</CustomLink>
                           )}
                        </CustomTextBold>
                     </View>
                     <Separator />
                     <View
                        style={styles.contentNoTouch}
                     >
                        <View style={styles.contentView}>
                           <View style={styles.contentIcon}>
                              <CustomIcon
                                 icon={faFont}
                                 color={colors.primary}
                              />
                           </View>
                           <CustomText style={styles.contentText}>
                              Размер шрифта
                           </CustomText>
                        </View>
                        <View style={styles.fontTouchContainer}>
                           <FontBtn
                              fontSize={14}
                              accLabel='S'
                              label='Маленький'
                           />
                           <FontBtn
                              fontSize={16}
                              accLabel='M'
                              label='Средний'
                           />
                           <FontBtn
                              fontSize={18}
                              accLabel='L'
                              label='Большой'
                           />
                        </View>
                     </View>
                     <Separator />
                     <View
                        style={styles.contentNoTouch}
                     >
                        <View style={styles.contentView}>
                           <View style={styles.contentIcon}>
                              <CustomIcon
                                 icon={faBell}
                                 color={colors.primary}
                              />
                           </View>
                           <CustomText style={styles.contentText}>
                              Уведомления
                           </CustomText>
                           <View>
                              <Switch
                                 trackColor={{ false: colors.borderBottomPrimary, true: isDarkMode ? colors.primaryOpac : colors.mainBgOpac }}
                                 thumbColor={isDarkMode ? colors.primary : colors.mainBg}
                                 value={userNotificationNumber.length > 0 && userNotificationNumber[0] === 1 ? true : false}
                                 onValueChange={notificationNumberChange}
                                 style={Platform.OS === 'ios' ? { transform: [{ scaleX: 0.8 }, { scaleY: 0.8 }] } : null}
                              />
                           </View>
                        </View>
                     </View>
                     <Separator />
                     <TouchableOpacity
                        style={styles.contentTouch}
                        onPress={() => handleTheme()}
                     >
                        <View style={styles.contentView}>
                           <View style={styles.contentIcon}>
                              <CustomIcon
                                 icon={faPalette}
                                 color={colors.primary}
                              />
                           </View>
                           <CustomText style={styles.contentText}>
                              Изменить тему
                           </CustomText>
                        </View>
                        <View style={styles.contentAngleBox}>
                           <CustomIcon
                              icon={!isDarkMode ? faSun : faMoon}
                              color={colors.primary}
                           />
                        </View>
                     </TouchableOpacity>
                     <Separator />
                     <MenuList
                        icon={faRightFromBracket}
                        onPress={() => handleLogout()}
                        title='Выйти из аккаунта'
                        color={colors.primary}
                     />
                     <Separator />
                     <MenuList
                        icon={faUserMinus}
                        onPress={() => navigation.navigate("Settings", { screen: 'DeleteAcc' })}
                        title='Удалить аккаунт'
                        color={colors.primary}
                     />
                  </View>
               ) : null}
               {settingList.map(({ title, children }) => {
                  return (
                     <View
                        key={title}
                     >
                        <CustomTextLargeBold style={styles.title}>
                           {title}
                        </CustomTextLargeBold>
                        {children.map(({ subtitle, iconName, link }, index) => (
                           <React.Fragment key={subtitle}>
                              <MenuList
                                 icon={iconName}
                                 onPress={() => navigation.navigate("Settings", { screen: link as keyof SettingsParamList })}
                                 title={subtitle}
                                 color={colors.primary}
                              />
                              {children.length - 1 !== index ? (
                                 <Separator />
                              ) : null}
                           </React.Fragment>
                        ))}
                        {!user ? (
                           <>
                              <Separator />
                              <MenuList
                                 icon={faUser}
                                 onPress={() => navigation.navigate('Home', { screen: 'SignIn' })}
                                 title='Вход в аккаунт'
                                 color={colors.primary}
                              />
                           </>
                        ) : null}
                     </View>
                  )
               })}
            </View>
            <View>
               <Separator />
               <View style={styles.socContainer}>
                  {socList.map(({ icon, link, access }) => (
                     <TouchableOpacity
                        style={[styles.socTouch, { backgroundColor: colors.mainBg }]}
                        onPress={() => Linking.openURL(link)}
                        accessibilityLabel={`Press ${access}`}
                        key={access}
                     >
                        <FontAwesomeIcon
                           icon={icon}
                           color={colors.primaryReverse}
                           size={25}
                        />
                     </TouchableOpacity>
                  ))}
               </View>
               <View style={{ marginBottom: user ? 25 : 5 }}>
                  <CustomTextBold
                     style={{
                        textAlign: 'center',
                     }}
                  >
                     Evidence {Constants?.expoConfig?.version}
                  </CustomTextBold>
               </View>
            </View>
         </ScrollView>
      </SafeAreaView>
   )
}

const styles = StyleSheet.create({
   container: {
      paddingTop: 15,
      paddingBottom: 5,
   },
   content: {
      marginBottom: 40
   },
   title: {
      paddingHorizontal: 15,
      marginBottom: 7
   },
   contentTouch: {
      paddingHorizontal: 15,
      paddingVertical: 10,
      flexDirection: 'row',
      justifyContent: 'space-between',
      alignItems: 'center',
      gap: 3,
   },
   contentView: {
      flexDirection: 'row',
      columnGap: 15,
      flex: 1
   },
   contentIcon: {
      paddingTop: 6,
   },
   contentAngleBox: {
      paddingTop: 5,
      width: 20,
   },
   contentText: {
      flex: 1
   },
   contentNoTouch: {
      paddingHorizontal: 15,
      paddingVertical: 10,
      rowGap: 2
   },
   contentOthText: {
      paddingLeft: 35,
   },
   fontTouchContainer: {
      marginTop: 5
   },
   fontTouch: {
      paddingVertical: 5
   },
   socContainer: {
      gap: 5,
      flexDirection: 'row',
      marginBottom: 10,
      justifyContent: 'center',
      paddingTop: 15,
   },
   socTouch: {
      width: 50,
      height: 50,
      flexDirection: 'row',
      alignItems: 'center',
      justifyContent: 'center',
      borderRadius: 4
   }
})

const settingList = [
   {
      title: "Правила и условия",
      children: [
         {
            subtitle: "О нас",
            link: "About",
            iconName: faAddressCard
         },
         {
            subtitle: "Условия использования, ответственность и конфиденциальность",
            link: "Privacy",
            iconName: faShieldHalved
         },
         {
            subtitle: "Условия оплаты и возврата",
            link: "PaymentReturns",
            iconName: faCreditCard
         },
         {
            subtitle: "Отказ от ответственности",
            link: "Disclaimer",
            iconName: faFile
         },
      ]
   },

]

const socList = [
   {
      icon: faEnvelope,
      link: 'mailto:evidence_ebm@mail.ru',
      access: 'Mail'
   },
   {
      icon: faTelegram,
      link: 'https://t.me/evidence_ebm',
      access: 'Telegram'
   },
   {
      icon: faVk,
      link: 'https://vk.com/club230049359',
      access: 'Vk'
   }
]
