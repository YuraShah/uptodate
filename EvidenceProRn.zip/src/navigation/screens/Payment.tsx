import React, { } from 'react'
import { Platform, SafeAreaView, ScrollView, TouchableOpacity, View } from 'react-native'
import { useTheme } from '@/src/hooks/useTheme'
import CustomTextBold from '@/src/components/CustomTexts/CustomTextBold'
import { useAppDispatch, useAppSelector } from '@/src/redux/hooks'
import CustomTitle from '@/src/components/CustomTexts/CustomTitle'

const payments = Platform.select({
   "android": [
      {
         title: 'Месяц / 1199 ₽',
         id: 1,
         sku: 'com.evidence.subscription.monthly'
      },
      {
         title: '6 месяцев / 5999 ₽',
         id: 2,
         sku: 'com.evidence.subscription.6months'
      },
      {
         title: 'Год / 11890 ₽',
         id: 3,
         sku: 'com.evidence.subscription.yearly'
      }
   ],
   "ios": [
      {
         title: 'Месяц / 1290 ₽',
         id: 1,
         sku: 'com.evidence.subscription.ios.monthly'
      },
      {
         title: '6 месяцев / 6000 ₽',
         id: 2,
         sku: 'com.evidence.subscription.ios.6months'
      },
      {
         title: 'Год / 11890 ₽',
         id: 3,
         sku: 'com.evidence.subscription.ios.yearly'
      }
   ]
})

export default function Payment() {
   const { colors } = useTheme()
   const dispatch = useAppDispatch()
   const { user } = useAppSelector(state => state.authStore)
   const { paymentData } = useAppSelector(state => state.paymentStore)

   return (
      <SafeAreaView style={{ flex: 1, backgroundColor: colors.background }}>
         <ScrollView
            contentContainerStyle={{ padding: 15, flexGrow: 1 }}
         >
            <CustomTitle>Оплата подписки (Pay subscription)</CustomTitle>
            {paymentData.length > 0 && paymentData[0] === 1 ? (
               <CustomTextBold style={{ marginVertical: 15 }}>У вас уже есть подписка.</CustomTextBold>
            ) : (
               <View style={{ marginVertical: 20, flex: 1 }}>
                  <View style={{ rowGap: 10, marginBottom: 10, flexGrow: 1 }}>
                     {payments!.map((product) => (
                        <TouchableOpacity
                           key={product.id}
                           style={{
                              backgroundColor: colors.mainBg,
                              paddingVertical: 15,
                              paddingHorizontal: 10,
                              borderRadius: 5,
                              justifyContent: 'center',
                              alignItems: 'center'
                           }}
                        // onPress={ }
                        >
                           <CustomTextBold style={{ color: colors.mainBgText }}>
                              {product.title}
                           </CustomTextBold>
                        </TouchableOpacity>
                     ))}
                  </View>
                  <TouchableOpacity
                     // onPress={}
                     style={{
                        backgroundColor: colors.mainBg,
                        paddingVertical: 15,
                        paddingHorizontal: 10,
                        borderRadius: 5,
                        justifyContent: 'center',
                        alignItems: 'center',
                     }}
                  >
                     <CustomTextBold style={{ color: colors.mainBgText }}>
                        Восстановить подписку (Restore subscription)
                     </CustomTextBold>
                  </TouchableOpacity>
               </View>
            )}
         </ScrollView>
      </SafeAreaView >
   )
}
