import React from 'react'
import { Alert, StyleSheet, TouchableOpacity, View } from 'react-native';
import { useAppDispatch, useAppSelector } from '@/src/redux/hooks';
import { signOut } from '@/src/redux/features/auth/authAPI';
import Error from '@/src/components/ErrorNet';
import { useTheme } from '@/src/hooks/useTheme';
import { useNavigation } from '@react-navigation/native';
import { deleteUserAcc } from '@/src/redux/features/user/userAPI';
import CustomTextBold from '@/src/components/CustomTexts/CustomTextBold';


const UserDeleteAcc = () => {
  const { user } = useAppSelector(state => state.authStore)
  const dispatch = useAppDispatch();
  const { deleteAccError } = useAppSelector((state) => state.userStore)
  const { deviceToken } = useAppSelector(state => state.notificationsStore)
  const { colors } = useTheme()
  const navigation = useNavigation()

  const deleteAccount = () => {
    if (!user) return;

    dispatch(deleteUserAcc(JSON.stringify(user.id)))
      .then((rej) => {
        if (rej.meta.requestStatus !== 'rejected') {
          dispatch(signOut(JSON.stringify({ uid: user?.id!, device_token: deviceToken })))
            .then(() => navigation.navigate('Home', { screen: 'SignIn' }))

          Alert.alert('', 'Вы удалили аккаунт.', [
            { text: 'ОК', style: 'default', },
          ]);
        }
      })
  }

  return (
    <View style={{
      flex: 1,
      backgroundColor: colors.background,
      alignItems: 'center',
      justifyContent: 'center'
    }}>
      <CustomTextBold>
        Вы хотите удалить аккаунт?
      </CustomTextBold>
      {deleteAccError && (
        <Error />
      )}
      <View style={styles.btnsContainer}>
        <TouchableOpacity
          style={[styles.btn, { backgroundColor: colors.updateCloseBg, }]}
          onPress={() => navigation.goBack()}
          accessibilityLabel='Press No'
        >
          <CustomTextBold style={{ color: colors.black }}>
            Нет
          </CustomTextBold>
        </TouchableOpacity>
        <TouchableOpacity
          style={[styles.btn, { backgroundColor: colors.updateOpenBg }]}
          onPress={() => deleteAccount()}
          accessibilityLabel='Press Yes'
        >
          <CustomTextBold style={{ color: colors.black }}>
            Да
          </CustomTextBold>
        </TouchableOpacity>
      </View>
    </View>
  )
}

const styles = StyleSheet.create({
  container: {
    marginBottom: 40,
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  btnsContainer: {
    marginVertical: 15,
    flexDirection: 'row',
    gap: 20,
  },
  btn: {
    width: 100,
    height: 50,
    borderRadius: 4,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center'
  },
})

export default UserDeleteAcc
