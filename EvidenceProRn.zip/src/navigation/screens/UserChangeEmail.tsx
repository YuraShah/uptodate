import React, { useEffect, useState } from 'react'
import { useForm } from 'react-hook-form'
import { useAppDispatch, useAppSelector } from '@/src/redux/hooks';
import { IResponseMessage, LINKS } from '@/src/types/types';
import { Alert, SafeAreaView, ScrollView, StyleSheet, View, useWindowDimensions } from 'react-native';
import * as yup from "yup";
import { yupResolver } from "@hookform/resolvers/yup";
import { signOut } from '@/src/redux/features/auth/authAPI';
import FormPassword from '@/src/components/Form/FormPassword';
import FormInput from '@/src/components/Form/FormInput';
import ButtonLoad from '@/src/components/ButtonLoad';
import Error from '@/src/components/ErrorNet';
import CustomTitle from '@/src/components/CustomTexts/CustomTitle';
import { useMutation } from '@tanstack/react-query';
import { useTheme } from '@/src/hooks/useTheme';
import { fetchUseQuery } from '@/src/functions/fetchUseQuery';
import { Toast } from 'toastify-react-native';
import { useNavigation } from '@react-navigation/native';
import CustomTextBold from '@/src/components/CustomTexts/CustomTextBold';
import ToastModal from '@/src/components/ToastModal';


const schema = yup.object().shape({
   password: yup
      .string()
      .required("Поле обязательно для заполнения")
      .matches(
         /^(?=.*[0-9])(?=.*[a-zа-яА-Я])(?=.*[A-Zа-яА-Я]).{8,32}$/,
         "Неверный пароль"
      ),
   email: yup
      .string()
      .required("Поле обязательно для заполнения")
      .email("Неверный адрес электронной почты"),
   email_confirmation: yup
      .string()
      .required("Поле обязательно для заполнения")
      .oneOf([yup.ref("email")], "Это поле должно совпадать с электронной почтой"),
})

type IUserChangeEmailForm = {
   password: string,
   email: string,
   email_confirmation: string
}
type IUserChangeEmailReq = {
   oldemail: string,
   pass: string,
   email: string,
}


const UserChangeEmail = () => {
   const { user } = useAppSelector((state) => state.authStore)
   const { control, handleSubmit, formState: { errors } } = useForm<IUserChangeEmailForm>({ resolver: yupResolver(schema) })
   const [isShowPassword, setIsShowPassword] = useState<boolean>(false);
   const dispatch = useAppDispatch()
   const windowWidth = useWindowDimensions().width;
   const { deviceToken } = useAppSelector(state => state.notificationsStore)
   const { colors } = useTheme()
   const navigation = useNavigation()
   const [toastText, setToastText] = useState<string>()

   const { mutate, isPending, isError, data } = useMutation({
      mutationFn: async (obj: string) => {
         return fetchUseQuery<IResponseMessage>(
            'post', LINKS.CHANGEUSEREMAIL, obj
         )
      },
   })

   const save = (data: IUserChangeEmailForm) => {
      if (!user) return

      if (user.email === data.email) {
         setToastText("Адрес электронной почты не изменился")
         // Toast.error("Адрес электронной почты не изменился", "top")
      } else {
         const reqObj: IUserChangeEmailReq = {
            oldemail: user.email,
            pass: data.password,
            email: data.email
         }
         mutate(JSON.stringify(reqObj))
      }
   }

   const serverResponses = () => {
      if (!data || !data.message) return

      if (data.message.length > 0 && data.message[0] === "wrong password") {
         // Toast.error("Пароль неверный", "top")
         setToastText("Пароль неверный")
      } else if (data.message.length > 0 && data.message[0] === "success") {
         dispatch(signOut(JSON.stringify({ uid: user?.id!, device_token: deviceToken })))
            .then(() => {
               navigation.navigate('Home', { screen: 'SignIn' })
            })

         Alert.alert('', 'Вы изменили адрес электронной почты. Код активации был отправлен на ваш адрес электронной почты.', [
            { text: 'ОК', style: 'default', },
         ]);
      } else if (data.message.length > 0 && data.message[0] === "limit") {
         // Toast.error("Достигнут лимит изменения адресов электронной почты в день. Попробуйте завтра.", "top")
         setToastText("Достигнут лимит изменения адресов электронной почты в день. Попробуйте завтра.")
      } else if (data.message.length > 0 && data.message[0] === "already") {
         // Toast.error("Пользователь с таким адресом электронной почты уже зарегистрирован.", "top")
         setToastText("Пользователь с таким адресом электронной почты уже зарегистрирован.")
      } else if (data.message.length > 0 && data.message[0] === "email_limit") {
         // Toast.error("Электронную почту можно изменить 1 раз. Свяжитесь с помощью email, telegram или vk.", "top")
         setToastText("Электронную почту можно изменить 1 раз. Свяжитесь с помощью email, telegram или vk.")
      }
   }

   useEffect(() => {
      serverResponses()
   }, [data])

   useEffect(() => {
      if (toastText) {
         const timeout = setTimeout(() => {
            setToastText(undefined);
         }, 2000);

         return () => clearTimeout(timeout);
      }
   }, [toastText]);

   return (
      <SafeAreaView style={{ flex: 1, backgroundColor: colors.background }}>
         <ToastModal
            text={toastText!}
            opacity={toastText ? 1 : 0}
         />
         <ScrollView
            style={styles.container}
         >
            <CustomTitle>Изменение адреса электронной почты</CustomTitle>
            {data && data.message && data.message.length > 0 && data.message[0] === "success" ? (
               <CustomTextBold style={[styles.attentionText, { color: colors.formAttention }]}>
                  Адрес электронной почты успешно изменен. Код активации был отправлен на ваш адрес электронной почты.
               </CustomTextBold>
            ) : (
               <>
                  {isError && <Error />}
                  <View style={[styles.form, windowWidth >= 780 && { width: '70%' }]}>
                     <FormPassword<IUserChangeEmailForm>
                        control={control}
                        labelTitle={'Напишите пароль'}
                        inputId={'password'}
                        errorMessage={errors.password?.message}
                        required
                        requiredText={'(обязателен для изменения адреса электронной почты)'}
                        showBoolean={isShowPassword}
                        showFunction={setIsShowPassword}
                        fontBold
                     />
                     <FormInput<IUserChangeEmailForm>
                        control={control}
                        labelTitle={'Введите новый адрес электронной почты'}
                        inputId={'email'}
                        inputPlaceholder={''}
                        errorMessage={errors.email?.message}
                        required
                        autoCapitalize={true}
                        fontBold
                     />
                     <FormInput<IUserChangeEmailForm>
                        control={control}
                        labelTitle={'Подтвердите новый адрес электронной почты'}
                        inputId={'email_confirmation'}
                        inputPlaceholder={''}
                        errorMessage={errors.email_confirmation?.message}
                        required
                        autoCapitalize={true}
                        fontBold
                     />
                     <ButtonLoad
                        title={'Изменить'}
                        status={isPending}
                        marginTop={10}
                        onPress={handleSubmit(save)}
                     />
                  </View>
               </>
            )}
         </ScrollView>
      </SafeAreaView>
   )
}

const styles = StyleSheet.create({
   container: {
      padding: 15,
   },
   attentionText: {
      marginTop: 15
   },
   form: {
      marginTop: 10,
      marginBottom: 280,
      padding: 5,
      rowGap: 15
   },
})

export default UserChangeEmail
