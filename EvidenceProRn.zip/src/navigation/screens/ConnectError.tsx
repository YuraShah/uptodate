import React, { useEffect, useRef } from 'react'
import { BackHandler, NativeEventSubscription, ScrollView, TouchableOpacity, View } from 'react-native'
import * as Updates from 'expo-updates';
import { useFocusEffect, useNavigation } from '@react-navigation/native';
import CustomTextNoFont from '@/src/components/CustomTexts/CustomTextNoFont';
import { useTheme } from '@/src/hooks/useTheme';
import { SafeAreaView } from 'react-native-safe-area-context';
import CustomStatusBar from '@/src/components/CustomStatusBar';

const ConnectError = () => {
   const navigation = useNavigation()
   const { colors } = useTheme()
   const backHandlerRef = useRef<NativeEventSubscription | null>(null);

   useEffect(() => {
      backHandlerRef.current = BackHandler.addEventListener(
         'hardwareBackPress',
         () => true
      );

      return () => {
         backHandlerRef.current?.remove();
      };
   }, []);

   useFocusEffect(
      React.useCallback(() => {
         navigation.getParent()?.setOptions({
            swipeEnabled: false,
         });

         return () => {
            navigation.getParent()?.setOptions({
               swipeEnabled: true,
            });
         };
      }, [navigation])
   );


   return (
      <>
         <CustomStatusBar />
         <SafeAreaView style={{ flex: 1, backgroundColor: colors.background }}>
            <ScrollView
               style={{ padding: 15 }}
            >
               <CustomTextNoFont
                  style={{ fontSize: 18 }}
               >
                  Проблема с подключением. Для работы приложения требуется постоянное подключение к Интернету.
               </CustomTextNoFont>
               <View
                  style={{
                     marginVertical: 40
                  }}
               >
                  <TouchableOpacity
                     onPress={() => Updates.reloadAsync()}
                     style={{
                        backgroundColor: colors.mainBg,
                        borderRadius: 4,
                        marginVertical: 3,
                        alignItems: 'center',
                        minHeight: 60,
                        justifyContent: 'center'
                     }}
                  >
                     <CustomTextNoFont
                        style={{
                           fontSize: 18,
                           color: colors.mainBgText
                        }}
                     >
                        Открыть приложение снова
                     </CustomTextNoFont>
                  </TouchableOpacity>
                  <TouchableOpacity
                     onPress={() => {
                        backHandlerRef.current?.remove();
                        navigation.goBack()
                     }}
                     style={{
                        backgroundColor: colors.mainBg,
                        borderRadius: 4,
                        marginVertical: 3,
                        alignItems: 'center',
                        minHeight: 60,
                        justifyContent: 'center'
                     }}
                  >
                     <CustomTextNoFont
                        style={{
                           fontSize: 18,
                           color: colors.mainBgText
                        }}
                     >
                        Вернуться в приложение
                     </CustomTextNoFont>
                  </TouchableOpacity>
               </View>
            </ScrollView>
         </SafeAreaView>
      </>
   )
}

export default ConnectError
