import React, { useEffect, useMemo, useState } from 'react'
import calculators from '@/src/constants/calcs/data/calcs.json'
import { RefreshControl, SafeAreaView, SectionList, TouchableOpacity, StyleSheet, View, Platform } from 'react-native'
import { useAppDispatch, useAppSelector } from '@/src/redux/hooks'
import { useWindowDimensions } from 'react-native';
import { useConnectNet } from '@/src/hooks/useConnectNet';
import TitleShare from '@/src/components/TitleShare';
import CustomText from '@/src/components/CustomTexts/CustomText';
import CustomTextBold from '@/src/components/CustomTexts/CustomTextBold';
import { excludeIosParams } from '@/src/navigation/excludeIosRoutes';
import { useTheme } from '@/src/hooks/useTheme';
import { useNavigation } from '@react-navigation/native';
import { NativeStackNavigationProp } from '@react-navigation/native-stack';
import { MainStackParamList } from '@/src/types/navigationTypes';
import { getUserCalcs } from '@/src/redux/features/user/userAPI';
import SelectAsyncComponent from '@/src/components/SelectComponent/SelectAsyncComponent';
import AngleRight from '@/src/components/AngleRight';
import OpenAll from '@/src/components/OpenAll';
import { Toast } from 'toastify-react-native';
import { FontAwesomeIcon } from '@fortawesome/react-native-fontawesome';
import { faLock } from '@fortawesome/free-solid-svg-icons';


interface ICalcData {
   calcId: string,
   calcTitle: string
   calcText: string,
   calcLink: string,
   calcType: string[],
}
interface ICalc {
   title: string,
   data: ICalcData[]
}

const Calcs = () => {
   const [inpValue, setInpValue] = useState<string>('')
   const [openStates, setOpenStates] = useState<boolean[]>([]);
   const [refreshing, setRefreshing] = React.useState(false);
   const { width } = useWindowDimensions();
   const dispatch = useAppDispatch()
   const { colors } = useTheme()
   const navigation = useNavigation<NativeStackNavigationProp<MainStackParamList>>()
   useConnectNet();
   const { user } = useAppSelector(state => state.authStore)
   const { paymentData } = useAppSelector(state => state.paymentStore)

   useEffect(() => {
      if (!user || paymentData.length === 0 || paymentData[0] !== 1) return

      dispatch(getUserCalcs())
   }, [user, paymentData])

   const filteredData = useMemo(() => {
      const list = calculators ?? [];

      if (!inpValue.trim()) return list;

      const search = inpValue.trim().toLowerCase();

      return list
         .map(section => {
            const filteredItems = section.data.filter(item =>
               Platform.OS !== 'ios'
                  ? item.calcTitle.toLowerCase().includes(search)
                  : item.calcTitle.toLowerCase().includes(search) &&
                  !excludeIosParams.includes(item.calcLink)
            );

            return {
               ...section,
               data: filteredItems
            };
         })
         .filter(section => section.data.length > 0);
   }, [inpValue]);

   const toggleAll = (open: boolean) => {
      setOpenStates(Array(filteredData.length).fill(open));
   };

   const toggleOne = (index: number) => {
      setOpenStates(prev => {
         const updated = [...prev];
         updated[index] = !updated[index];
         return updated;
      });
   };

   useEffect(() => {
      setOpenStates(Array(filteredData.length).fill(true));
   }, [filteredData]);

   const onRefresh = React.useCallback(() => {
      setRefreshing(true);
      setInpValue('')
      setOpenStates(Array(filteredData.length).fill(true));
      setTimeout(() => {
         setRefreshing(false);
      }, 300);
   }, []);


   return (
      <SafeAreaView style={{ flex: 1, backgroundColor: colors.background }}>
         {filteredData.length > 0 ? (
            <OpenAll
               openStates={openStates}
               toggleAll={toggleAll}
            />
         ) : null}
         <SectionList
            refreshControl={
               <RefreshControl
                  refreshing={refreshing}
                  onRefresh={onRefresh}
                  colors={[colors.mainBg]}
                  progressBackgroundColor={colors.refreshProgressBarBg}
               />
            }
            contentContainerStyle={{ paddingVertical: 15 }}
            ListHeaderComponent={
               <View style={{ paddingHorizontal: 15 }}>
                  <TitleShare
                     titleText={'Медицинские калькуляторы'}
                  />
                  <SelectAsyncComponent
                     inpValue={inpValue}
                     setInpValue={setInpValue}
                     windowWidth={width}
                     placeholder={`... (≥3 буквы)`}
                  />
               </View>
            }
            sections={filteredData}
            keyExtractor={(item) => item.calcId}
            renderItem={({ item, section, index }) => {
               const sectionIndex = filteredData.findIndex(s => s.title === section.title);
               const isOpen = openStates[sectionIndex];

               if ((Platform.OS === 'ios' && excludeIosParams.includes(item.calcLink)) || isOpen) {
                  return null;
               } else {
                  return (
                     <>
                        <TouchableOpacity
                           onPress={() => {
                              if ((!user || paymentData.length === 0 || paymentData[0] !== 1)
                                 && item.calcId !== 'EV-CALC-03' && item.calcId !== 'EV-CALC-04') {
                                 Toast.info("Нужна подписка для доступа")
                              } else {
                                 navigation.navigate('CalcsItem', {
                                    param: item.calcLink
                                 })
                              }
                           }}
                           accessibilityLabel={`Press ${item.calcTitle}`}
                           style={{
                              paddingHorizontal: 15,
                              flexDirection: 'row',
                              alignItems: 'center',
                              position: 'relative'
                           }}
                        >
                           {(!user || paymentData.length === 0 || paymentData[0] !== 1)
                              && item.calcId !== 'EV-CALC-03' && item.calcId !== 'EV-CALC-04' ? (
                              <View
                                 style={{
                                    position: 'absolute',
                                    top: '50%',
                                    left: '50%',
                                 }}
                              >
                                 <FontAwesomeIcon
                                    icon={faLock}
                                    size={30}
                                    color={colors.lockCenter}
                                 />
                              </View>
                           ) : null}
                           <View style={{ flex: 1 }}>
                              <CustomTextBold>
                                 {item.calcTitle}
                              </CustomTextBold>
                              <CustomText style={styles.calcText}>
                                 {item.calcText}
                              </CustomText>
                           </View>
                           <AngleRight />
                        </TouchableOpacity>
                        <View
                           style={{
                              height: section.data.length - 1 === index ? 0 : 1,
                              backgroundColor: colors.borderBottomPrimary,
                              marginTop: 7,
                              marginBottom: section.data.length - 1 === index ? 15 : 7,
                           }}
                        />
                     </>
                  )
               }
            }}
            renderSectionHeader={({ section }) => {
               const sectionIndex = filteredData.findIndex(s => s.title === section.title);
               const isOpen = openStates[sectionIndex];
               const isLast = sectionIndex === filteredData.length - 1

               return (
                  <>
                     <TouchableOpacity
                        onPress={() => toggleOne(sectionIndex)}
                        style={[
                           styles.headerTouch,
                           { ...width >= 650 && { paddingRight: 17 } },
                           {
                              paddingHorizontal: 15,
                              backgroundColor: colors.background
                           }
                        ]}
                     >
                        <CustomTextBold style={[styles.headerTitle, { color: colors.calcHeader }]}>
                           {section.title}
                        </CustomTextBold>
                        <AngleRight
                           isActive={!isOpen}
                           color={colors.calcHeader}
                        />
                     </TouchableOpacity>
                     {isLast ? null : isOpen && (
                        <View style={{ height: 1, backgroundColor: colors.borderBottomPrimary }} />
                     )}
                  </>
               )
            }}
            ListEmptyComponent={<CustomText style={{ paddingHorizontal: 15 }}>Не найдено совпадений</CustomText>}
            ListFooterComponent={<View style={{ marginBottom: 50 }} />}
         />
      </SafeAreaView>
   )
}

const styles = StyleSheet.create({
   calcText: {
      marginVertical: 5,
   },
   headerTouch: {
      flexDirection: 'row',
      justifyContent: 'space-between',
      paddingVertical: 10,
      backgroundColor: 'red'
   },
   headerTitle: {
      flex: 1
   },
})

export default Calcs
