import { MainStackParamList } from '@/src/types/navigationTypes'
import { useRoute, RouteProp, useNavigation } from '@react-navigation/native'
import { NativeStackNavigationProp } from '@react-navigation/native-stack'
import React from 'react'
import { Platform, View } from 'react-native'
import ABCD2 from '@/src/components/Calcs/Item/ABCD2'
import AcetamTox from '@/src/components/Calcs/Item/AcetamTox'
import Ada from '@/src/components/Calcs/Item/ADA'
import Apgar from '@/src/components/Calcs/Item/Apgar'
import AsthmaPI from '@/src/components/Calcs/Item/AsthmaPI'
import BenzConvert from '@/src/components/Calcs/Item/BenzConvert'
import BenzQuestionnaire from '@/src/components/Calcs/Item/BenzQuestionnaire'
import BodyMassIndex from '@/src/components/Calcs/Item/BodyMassIndex'
import BodySurfaceArea from '@/src/components/Calcs/Item/BodySurfaceArea'
import CaHypoalb from '@/src/components/Calcs/Item/CaHypoalb'
import CambridgeDiab from '@/src/components/Calcs/Item/CambridgeDiab'
import Centor from '@/src/components/Calcs/Item/Centor'
import CHADSVASC2 from '@/src/components/Calcs/Item/CHADSVASC2'
import ChildPugh from '@/src/components/Calcs/Item/ChildPugh'
import Ciwa from '@/src/components/Calcs/Item/Ciwa'
import CKDEPI from '@/src/components/Calcs/Item/CKDEPI'
import ClinicalFrailtyScale from '@/src/components/Calcs/Item/ClinicalFrailtyScale'
import Cmai from '@/src/components/Calcs/Item/Cmai'
import CockcroftGault from '@/src/components/Calcs/Item/CockcroftGault'
import COWS from '@/src/components/Calcs/Item/COWS'
import CRUSADE from '@/src/components/Calcs/Item/CRUSADE'
import DentTAMax from '@/src/components/Calcs/Item/DentTAMax'
import Drip from '@/src/components/Calcs/Item/DRIP'
import Epworth from '@/src/components/Calcs/Item/Epworth'
import FraminghamScore from '@/src/components/Calcs/Item/FraminghamScore'
import Garfield from '@/src/components/Calcs/Item/Garfield'
import GCSConverter from '@/src/components/Calcs/Item/GCSConverter'
import GcsConverterMineral from '@/src/components/Calcs/Item/GcsConverterMineral'
import GRACE from '@/src/components/Calcs/Item/GRACE'
import H2FPEF from '@/src/components/Calcs/Item/H2FPEF'
import Hasbled from '@/src/components/Calcs/Item/Hasbled'
import HEART from '@/src/components/Calcs/Item/HEART'
import HEMORR2HAGES from '@/src/components/Calcs/Item/HEMORR2HAGES'
import IdealAdjustedWeight from '@/src/components/Calcs/Item/IdealAdjustedWeight'
import IntraVenousSpeed from '@/src/components/Calcs/Item/IntraVenousSpeed'
import Karnofsky from '@/src/components/Calcs/Item/Karnofsky'
import MAI from '@/src/components/Calcs/Item/MAI'
import MDRD from '@/src/components/Calcs/Item/MDRD'
import MeldNa from '@/src/components/Calcs/Item/MeldNa'
import MeldOriginal from '@/src/components/Calcs/Item/MeldOriginal'
import MeldThree from '@/src/components/Calcs/Item/MeldThree'
import NACDose from '@/src/components/Calcs/Item/NACDose'
import NicotineDependence from '@/src/components/Calcs/Item/NicotineDependence'
import OST from '@/src/components/Calcs/Item/OST'
import PercentageGramSolution from '@/src/components/Calcs/Item/PercentageGramSolution'
import PRECISEDAPT from '@/src/components/Calcs/Item/PRECISEDAPT'
import QTc from '@/src/components/Calcs/Item/QTc'
import QtRiskIcu from '@/src/components/Calcs/Item/QtRiskIcu'
import QtRiskNonIcu from '@/src/components/Calcs/Item/QtRiskNonIcu'
import REACH from '@/src/components/Calcs/Item/REACH'
import Sams from '@/src/components/Calcs/Item/Sams'
import SCORE2 from '@/src/components/Calcs/Item/SCORE2'
import Score2Diab from '@/src/components/Calcs/Item/Score2Diab'
import SerumOsmolality from '@/src/components/Calcs/Item/SerumOsmolality'
import SmokingIndex from '@/src/components/Calcs/Item/SmokingIndex'
import StatinDoses from '@/src/components/Calcs/Item/StatinDoses'
import Sunscreen from '@/src/components/Calcs/Item/sunscreen/Sunscreen'
import Wtoh from '@/src/components/Calcs/Item/Wtoh'
import { excludeIosParams } from '@/src/navigation/excludeIosRoutes'
import SunscreenFace from '@/src/components/Calcs/Item/sunscreen/SunscreenFace'
import SunscreenBody from '@/src/components/Calcs/Item/sunscreen/SunscreenBody'
import { Toast } from 'toastify-react-native';
import CopdAssessment from '@/src/components/Calcs/Item/CopdAssessment'
import Mmrc from '@/src/components/Calcs/Item/Mmrc'

const screens: Record<string, React.ComponentType> = {
   'gcsconverter': GCSConverter,
   'volumespeed': IntraVenousSpeed,
   'pgsolution': PercentageGramSolution,
   'smokingindex': SmokingIndex,
   'nicotinetest': NicotineDependence,
   'g-mai': MAI,
   'epworth-sleepiness-scale': Epworth,
   'abcd2': ABCD2,
   'heart': HEART,
   'reach': REACH,
   'crusade': CRUSADE,
   'centor': Centor,
   'cows': COWS,
   'hemorr2hages': HEMORR2HAGES,
   'bmi': BodyMassIndex,
   'ideal-adjusted-weight': IdealAdjustedWeight,
   'body-surface-area': BodySurfaceArea,
   'cha2ds2vasc': CHADSVASC2,
   'precisedapt': PRECISEDAPT,
   'h2fpef': H2FPEF,
   'qt-risk-icu': QtRiskIcu,
   'qt-risk-non-icu': QtRiskNonIcu,
   'egfr-cockcroft': CockcroftGault,
   'egfr-mdrd': MDRD,
   'egfr-ckd-epi': CKDEPI,
   'ca-correction-hypoalbum': CaHypoalb,
   'dent-ta-max': DentTAMax,
   'sunscreen': Sunscreen,
   'sunscreen/face': SunscreenFace,
   'sunscreen/body': SunscreenBody,
   'score2': SCORE2,
   'score2-diabetes': Score2Diab,
   'framinghamscore': FraminghamScore,
   'grace': GRACE,
   'acetaminophen-toxicity-assessment': AcetamTox,
   'acetaminophen-overdose-nac-dosing': NACDose,
   'serum-osmolality': SerumOsmolality,
   'ada-risk': Ada,
   'apgar-score': Apgar,
   'asthma-predictive-index': AsthmaPI,
   'cambridge-diabetes-risk': CambridgeDiab,
   'drip': Drip,
   'has-bled': Hasbled,
   'karnofsky-scale': Karnofsky,
   'ost': OST,
   'sams': Sams,
   'statins-lipids': StatinDoses,
   'qtc': QTc,
   'whtr': Wtoh,
   'clinical-frailty-scale': ClinicalFrailtyScale,
   'benzodiazepine-questionnaire': BenzQuestionnaire,
   'ciwa-b': Ciwa,
   'cohen-mansfield-agitation-inventory': Cmai,
   'garfield': Garfield,
   'csconverter-mineral': GcsConverterMineral,
   'child-pugh-score': ChildPugh,
   'meld-score-original': MeldOriginal,
   'meld-score-na': MeldNa,
   'meld-score-3': MeldThree,
   'benzodiazepine-conversion': BenzConvert,
   'copd-assessment': CopdAssessment,
   'mmrc': Mmrc
}

const CalcsItem = () => {
   const route = useRoute<RouteProp<MainStackParamList, 'CalcsItem'>>()
   const { param } = route.params
   const navigation = useNavigation<NativeStackNavigationProp<MainStackParamList>>()

   if (
      !screens[param] ||
      (Platform.OS === 'ios' && excludeIosParams.includes(param))
   ) {
      navigation.replace('Calcs');
      Toast.error("Неверная ссылка", "top")
      return null;
   }


   const SelectedScreen = screens[param];

   return (
      <View key={param} style={{ flex: 1 }}>
         <SelectedScreen />
      </View>
   )
}

export default CalcsItem
