import React from 'react'
import { useForm } from 'react-hook-form'
import { IResponseMessage, LINKS } from '@/src/types/types'
import { ScrollView, StyleSheet, View, useWindowDimensions, SafeAreaView } from 'react-native'
import * as yup from "yup";
import { yupResolver } from "@hookform/resolvers/yup";
import FormInput from '@/src/components/Form/FormInput'
import ButtonLoad from '@/src/components/ButtonLoad'
import Error from '@/src/components/ErrorNet'
import CustomTitle from '@/src/components/CustomTexts/CustomTitle'
import { useMutation } from '@tanstack/react-query'
import { fetchUseQuery } from '@/src/functions/fetchUseQuery'
import { useTheme } from '@/src/hooks/useTheme';
import CustomTextBold from '@/src/components/CustomTexts/CustomTextBold';


const schema = yup.object().shape({
   email: yup
      .string()
      .required("Поле обязательно для заполнения")
      .email("Неверный адрес электронной почты"),
});

type VerifyResendForm = {
   email: string
}


const VerifyResend = () => {
   const { control, handleSubmit, formState: { errors } } = useForm<VerifyResendForm>({ resolver: yupResolver(schema) })
   const windowWidth = useWindowDimensions().width;
   const { colors } = useTheme()

   const { mutate, isPending, isError, data } = useMutation({
      mutationFn: async (formData: string) => {
         return fetchUseQuery<IResponseMessage>(
            'post', LINKS.VERIFYRESEND, formData
         )
      },
   })

   const save = (data: VerifyResendForm): void => {
      mutate(JSON.stringify(data.email))
   }


   return (
      <SafeAreaView style={{ flex: 1, backgroundColor: colors.background }}>
         <ScrollView style={styles.container}>
            <CustomTitle>Отправить код подтверждения еще раз</CustomTitle>
            {data && data.message?.length > 0 && data.message[0] === "Sent" ? (
               <CustomTextBold style={[styles.attentionText, { color: colors.formAttention }]}>Код активации был отправлен на ваш адрес электронной почты. Если его нет в вашей основной папке, проверьте также папку «Спам».</CustomTextBold>
            ) : (
               <>
                  {isError ? (
                     <Error />
                  ) : data && data.message?.length > 0 && data.message[0] === "Activate limit" ? (
                     <CustomTextBold style={[styles.attentionText, { color: colors.formAttention }]}>Достигнут лимит отправки кодов активации на адрес электронной почты. Попробуйте завтра.</CustomTextBold>
                  ) : data && data.message?.length > 0 && data.message[0] === "Invalid email" && (
                     <CustomTextBold style={[styles.attentionText, { color: colors.formAttention }]}>Неверный адрес электронной почты</CustomTextBold>
                  )}
                  <View style={[styles.form, windowWidth >= 780 && { width: '70%' }]}>
                     <FormInput<VerifyResendForm>
                        control={control}
                        labelTitle={'Напишите адрес электронной почты'}
                        inputId={'email'}
                        inputPlaceholder={''}
                        errorMessage={errors.email?.message}
                        required
                        autoCapitalize={true}
                        fontBold={true}
                     />
                     <ButtonLoad
                        title={'Отправить'}
                        status={isPending}
                        onPress={handleSubmit(save)}
                        marginTop={5}
                     />
                  </View>
               </>
            )}
         </ScrollView>
      </SafeAreaView>
   )
}

const styles = StyleSheet.create({
   container: {
      padding: 15,
   },
   attentionText: {
      marginTop: 10
   },
   form: {
      marginTop: 10,
      marginBottom: 40,
      padding: 5,
      rowGap: 10
   },
})

export default VerifyResend
