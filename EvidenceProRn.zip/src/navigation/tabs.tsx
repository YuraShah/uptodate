import React, { useState, useEffect } from 'react'
import { BottomTabBarProps, createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { PlatformPressable } from '@react-navigation/elements';
import { getFocusedRouteNameFromRoute, useLinkBuilder, useNavigation } from '@react-navigation/native';
import { useTheme } from '@/src/hooks/useTheme';
import * as Notifications from 'expo-notifications';
import * as SecureStore from 'expo-secure-store';
import * as Device from 'expo-device';
import * as SplashScreen from 'expo-splash-screen';
import * as ScreenCapture from 'expo-screen-capture';
import { usePreventScreenCapture } from 'expo-screen-capture';
import { Platform, View } from 'react-native';
import CustomIcon from '@/src/components/CustomIcons/CustomIcon';
import CustomTextNoFont from '@/src/components/CustomTexts/CustomTextNoFont';
import { faGear, faHome, faStar } from '@fortawesome/free-solid-svg-icons';
import { StackMain } from '@/src/navigation/stack';
import { getSecureDeviceId, registerForPushNotifications } from '@/src/redux/features/notifications/notificationsAPI';
import { useAppDispatch, useAppSelector } from '@/src/redux/hooks';
import { addAndGetScreenshotsQuantity, changeUserNotification, getDeviceBlockNum, getUserNotification } from '@/src/redux/features/deviceParams/deviceParamsAPI';
import { setLarge, setMedium, setSmall } from '@/src/redux/features/fontSize/fontSizeSlice';
import { IResponseData, IResponseMessage } from '@/src/types/types';
import { useConnectNet } from '@/src/hooks/useConnectNet';
import { authStorage } from '@/src/redux/authStorage';
import { getUser, signOut } from '@/src/redux/features/auth/authAPI';
import { checkSignDevice } from '@/src/redux/features/verifyRecovery/verifyAPI';
import { userNotificationNumberChange } from '@/src/redux/features/deviceParams/deviceParamsSlice';
import { Toast } from 'toastify-react-native';
import { findMatchingScreen } from '@/src/navigation/findMatchingScreen';
import BlockDevice from '@/src/navigation/screens/BlockDevice';
import ManyRequests from '@/src/navigation/screens/ManyRequests';
import ConnectError from '@/src/navigation/screens/ConnectError';
import { StackSettings } from '@/src/navigation/stackSettings';
import { toggleTheme } from '@/src/redux/features/theme/themeSlice';
import { StackFavorites } from '@/src/navigation/stackFavorites';
import { IRoot } from '@/src/navigation/index';
import { getFromSecureStore } from '@/src/functions/functions';


Notifications.setNotificationHandler({
   handleNotification: async () => ({
      shouldShowAlert: true,
      shouldPlaySound: true,
      shouldSetBadge: false,
   }),
});

const getUniqueId = async () => {
   let id = await SecureStore.getItemAsync('uniqueDeviceId');
   if (!id) {
      id = `id-${Math.random().toString(36).slice(2, 11)}-${Device.brand}`;
      await SecureStore.setItemAsync('uniqueDeviceId', id);
   }
};

const getFontSize = async () => {
   try {
      return await SecureStore.getItemAsync('fontSize');
   } catch (error) {
      return null;
   }
};

const hasPermissions = async () => {
   const { status } = await ScreenCapture.requestPermissionsAsync();
   return status === 'granted';
};


function MyTabBar(props: BottomTabBarProps) {
   const { state, descriptors, navigation } = props;
   const { buildHref } = useLinkBuilder();
   const { colors } = useTheme()
   const currentRoute = state.routes[state.index];
   const focusedRouteName = getFocusedRouteNameFromRoute(currentRoute) ?? currentRoute.name;
   const { isDarkMode } = useAppSelector(state => state.themeStore)

   const hiddenRoutes = ['BlockDevice', 'ManyRequests', 'ConnectError', 'WebView'];

   if (hiddenRoutes.includes(state.routes[state.index].name) ||
      hiddenRoutes.includes(focusedRouteName)
   ) {
      return null;
   }

   return (
      <View style={{ flexDirection: 'row' }}>
         {state.routes.map((route, index) => {
            if (hiddenRoutes.includes(route.name)) return null;

            const { options } = descriptors[route.key];
            const label = route.name === 'Home' ? 'Главная' : route.name === 'Favorites' ? 'Избранное' : 'Настройки';
            const iconName = route.name === 'Home' ? faHome : route.name === 'Favorites' ? faStar : faGear;

            const isFocused = state.index === index;

            const onPress = () => {
               const event = navigation.emit({
                  type: 'tabPress',
                  target: route.key,
                  canPreventDefault: true,
               });

               if (!isFocused && !event.defaultPrevented) {
                  navigation.navigate(route.name, route.params);
               }
            };

            const onLongPress = () => {
               navigation.emit({
                  type: 'tabLongPress',
                  target: route.key,
               });
            };

            return (
               <PlatformPressable
                  href={buildHref(route.name, route.params)}
                  accessibilityState={isFocused ? { selected: true } : {}}
                  accessibilityLabel={options.tabBarAccessibilityLabel}
                  testID={options.tabBarButtonTestID}
                  onPress={onPress}
                  onLongPress={onLongPress}
                  pressOpacity={0.8}
                  pressColor="rgba(0,0,0,0.05)"
                  style={{ flex: 1, backgroundColor: colors.background }}
                  key={index}
               >
                  <View style={{
                     alignItems: 'center',
                     borderTopColor: colors.borderBottomPrimary,
                     borderTopWidth: 1,
                     paddingTop: 5
                  }}>
                     <CustomIcon
                        icon={iconName}
                        size={20}
                        color={isFocused && isDarkMode ? colors.primary : isFocused ? colors.mainBg : colors.secondary}
                     />
                     <CustomTextNoFont style={{
                        color: isFocused && isDarkMode ? colors.primary : isFocused ? colors.mainBg : colors.secondary,
                        fontSize: 14
                     }}>
                        {label}
                     </CustomTextNoFont>
                  </View>
               </PlatformPressable>
            );
         })}
      </View>
   );
}

const Tab = createBottomTabNavigator();

export function MyTabs({
   initialUrl,
   isNavContainerReady
}: IRoot) {
   const dispatch = useAppDispatch();
   const { deviceToken, isPushReady } = useAppSelector(state => state.notificationsStore)
   const { user } = useAppSelector(state => state.authStore)
   const navigation = useNavigation();
   const [isReadyToNavigate, setIsReadyToNavigate] = useState(false);
   const [isUserLoading, setIsUserLoading] = useState(true);
   useConnectNet();
   usePreventScreenCapture();
   const lastNotificationResponse = Notifications.useLastNotificationResponse();
   const { isDarkMode } = useAppSelector(state => state.themeStore)
   const { paymentData } = useAppSelector(state => state.paymentStore)

   useEffect(() => {
      getUniqueId();

      dispatch(registerForPushNotifications())
         .unwrap()
         .catch(() => {
            dispatch(getSecureDeviceId())
         })
   }, [])

   const getUserFunction = async () => {
      const authToken = await authStorage.getAccessToken()

      if (authToken) {
         await dispatch(getUser(JSON.stringify({ deviceToken: deviceToken, platform: Platform.OS })))
      } else if (!authToken && user) {
         await dispatch(signOut(JSON.stringify({ uid: user.id, device_token: deviceToken })))
      }

      setIsUserLoading(false)
   }

   useEffect(() => {
      if (isPushReady && isNavContainerReady) {
         getUserFunction()
      }
   }, [deviceToken, isPushReady, isNavContainerReady])

   useEffect(() => {
      if (!isUserLoading) {
         setIsReadyToNavigate(true);
         SplashScreen.hideAsync();
      }
   }, [isUserLoading]);

   const navigationDeepLink = async (url: string, isReadyNavigate: boolean) => {
      await new Promise(resolve => setTimeout(resolve, 1500));

      if (isReadyNavigate && url) {
         const matchingScreen = findMatchingScreen(url);

         if (!matchingScreen) {
            Toast.error("Неверная ссылка", "top")
            return
         }

         if (typeof matchingScreen === 'string') {
            navigation.navigate('Home', { screen: 'WebView', params: { url: matchingScreen } });
            return;
         }

         if (Object.keys(matchingScreen.params).length > 0) {
            navigation.navigate(matchingScreen.screen as any, matchingScreen.params as any);
         } else {
            navigation.navigate(matchingScreen.screen as any);
         }
      }
   }

   useEffect(() => {
      if (initialUrl) {
         navigationDeepLink(initialUrl, isReadyToNavigate)
      }
   }, [isReadyToNavigate, initialUrl]);


   useEffect(() => {
      const navigationPush = () => {
         if (
            isReadyToNavigate &&
            lastNotificationResponse &&
            lastNotificationResponse.actionIdentifier === Notifications.DEFAULT_ACTION_IDENTIFIER &&
            lastNotificationResponse?.notification?.request?.content?.data
         ) {
            const checkObj = Object.keys(lastNotificationResponse?.notification?.request?.content?.data);
            if (checkObj.length > 0) {
               const onLink = lastNotificationResponse?.notification?.request?.content?.data

               if (onLink && typeof onLink === 'object' && user) {
                  if (onLink.link) {
                     const link = onLink.link as string;
                     if (link) {
                        navigation.navigate('Home', { screen: 'WebView', params: { url: link } });
                     }
                  } else if (onLink.expoLink) {
                     const expoLink = onLink.expoLink as string;
                     navigationDeepLink(expoLink, isReadyToNavigate)
                  } else {
                     // console.error('onLink does not contain a valid link property:', onLink);
                  }
               }
            }
         }
      }

      navigationPush()

   }, [lastNotificationResponse, isReadyToNavigate]);

   const getDeviceBlock = () => {
      dispatch(getDeviceBlockNum(JSON.stringify(deviceToken)))
         .then((response) => {
            if (response?.meta?.requestStatus === 'fulfilled') {
               const payload = response.payload as IResponseData<number>;

               if (
                  payload &&
                  Array.isArray(payload.data) &&
                  payload.data[0] === 1
               ) {
                  navigation.navigate('BlockDevice');
               }
            }
         })
   }

   const checkSignUserAndDevice = () => {
      if (user && user.id) {
         dispatch(checkSignDevice(JSON.stringify({ uid: user.id, device_token: deviceToken })))
            .then((r) => {
               const payload = r.payload as IResponseMessage;

               if (r.type === "sign/devicecheck/rejected" || (payload.message && payload.message[0] === 'error')) {
                  dispatch(signOut(JSON.stringify({ uid: user?.id!, device_token: deviceToken })))
               }
            })
      }
   }

   const checkNotificationNumber = () => {
      dispatch(getUserNotification(JSON.stringify(user!.id)))
         .then(async (r) => {
            if (r?.meta?.requestStatus === 'fulfilled') {
               const payload = r.payload as { status: boolean, data: number[] };
               const notifyNumber = await getFromSecureStore('notifyNumber');

               if (
                  (deviceToken && deviceToken.startsWith("id-") && payload.data[0] !== 0) ||
                  (deviceToken && !deviceToken.startsWith("id-") && payload.data[0] === 0 && notifyNumber && +notifyNumber !== payload.data[0])
               ) {
                  dispatch(changeUserNotification(JSON.stringify({ uid: user!.id, notify_number: 0 })))
                  dispatch(userNotificationNumberChange(0))
               } else if (deviceToken && !deviceToken.startsWith("id-")) {
                  if (
                     (!notifyNumber && payload.data[0] !== 1) ||
                     (payload.data[0] === 1 && notifyNumber && +notifyNumber !== payload.data[0])
                  ) {
                     dispatch(changeUserNotification(JSON.stringify({ uid: user!.id, notify_number: 1 })))
                     dispatch(userNotificationNumberChange(1))
                  }
               }
            }
         })
   }

   useEffect(() => {
      if (isPushReady && user) {
         getDeviceBlock()
         checkSignUserAndDevice()
         checkNotificationNumber()
      }
   }, [deviceToken, isPushReady, user])


   const fontSizeDispatcher = (fz: string) => {
      if (fz === '16') {
         dispatch(setMedium())
      } else if (fz === '18') {
         dispatch(setLarge())
      } else if (fz === '14') {
         dispatch(setSmall())
      }
   }

   const fetchFontSize = async () => {
      if (user) {
         const fontSize = await getFontSize();
         fontSizeDispatcher(fontSize || '16');
      } else {
         dispatch(setMedium());
      }
   };

   const getTheme = async () => {
      try {
         const theme = await SecureStore.getItemAsync('theme');
         if (!user) {
            if (isDarkMode) {
               dispatch(toggleTheme());
            }
            return;
         }

         if (!theme) {
            await SecureStore.setItemAsync('theme', 'light');
         } else {
            const shouldBeDark = theme === 'dark';
            if (shouldBeDark !== isDarkMode) {
               dispatch(toggleTheme());
            }
         }
      } catch (error) {
         return null;
      }
   }

   useEffect(() => {
      fetchFontSize();
      getTheme()
   }, [user]);


   useEffect(() => {
      if (Platform.OS === 'android') return;

      let subscription: any;

      const addListenerAsync = async () => {
         if (!user) return;

         if (await hasPermissions()) {
            subscription = ScreenCapture.addScreenshotListener(() => {
               dispatch(addAndGetScreenshotsQuantity(JSON.stringify(user.id)))
                  .then((response) => {
                     if (response?.meta?.requestStatus === 'fulfilled') {
                        const payload = response.payload as IResponseMessage;

                        if (payload && Array.isArray(payload.message)) {
                           const message = payload.message;

                           if (message[0] === 'limit') {
                              Toast.warn("Слишком много скриншотов за короткое время", "top")
                           } else if (message[0] === 'blocked') {
                              navigation.navigate('BlockDevice');
                           }
                        }
                     } else if (response?.meta?.requestStatus === 'rejected') {
                        dispatch(signOut(JSON.stringify({ uid: user?.id!, device_token: deviceToken })))
                     }
                  })
            });
         }
      };
      addListenerAsync();

      return () => {
         subscription?.remove();
      };
   }, [user]);

   return (
      <Tab.Navigator
         initialRouteName='Home'
         tabBar={(props) => <MyTabBar {...props} />}
      >
         <Tab.Screen
            name="Home"
            component={StackMain}
            options={{ headerShown: false }}
         />
         {user && paymentData.length > 0 && paymentData[0] === 1 ? (
            <Tab.Screen
               name="Favorites"
               component={StackFavorites}
               options={{ headerShown: false }}
            />
         ) : null}
         <Tab.Screen
            name="Settings"
            component={StackSettings}
            options={{ headerShown: false }}
         />
         <Tab.Screen
            name="BlockDevice"
            component={BlockDevice}
            options={{ headerShown: false }}
         />
         <Tab.Screen
            name="ManyRequests"
            component={ManyRequests}
            options={{ headerShown: false }}
         />
         <Tab.Screen
            name="ConnectError"
            component={ConnectError}
            options={{ headerShown: false }}
         />
      </Tab.Navigator>
   );
}