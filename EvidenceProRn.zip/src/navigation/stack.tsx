import { createNativeStackNavigator } from "@react-navigation/native-stack";
import SignIn from "@/src/navigation/screens/SignIn";
import { useEffect, useState } from "react";
import { Image, Platform, View } from "react-native";
import * as ScreenOrientation from 'expo-screen-orientation';
import { useTheme } from "@/src/hooks/useTheme";
import CustomTextBold from "@/src/components/CustomTexts/CustomTextBold";
import WebViewScreen from "@/src/navigation/screens/WebViewScreen";
import { useAppSelector } from "@/src/redux/hooks";
import HomeScreen from "@/src/navigation/screens/HomeScreen";
import { mainStacksList } from "@/src/navigation/stacksList";
import { MainStackParamList } from "@/src/types/navigationTypes";


const Stack = createNativeStackNavigator();

export const headerBackButtonDisplayMode = 'minimal'

export const StackMain = () => {
   const [orientation, setOrientation] = useState<number>();
   const { colors } = useTheme()
   const { user } = useAppSelector(state => state.authStore)
   const { paymentData } = useAppSelector(state => state.paymentStore)

   useEffect(() => {
      if (Platform.OS === 'ios') {
         ScreenOrientation.getOrientationAsync().then((data) => setOrientation(data));

         const onChangeOrientation = ({ orientationInfo }: ScreenOrientation.OrientationChangeEvent) => {
            setOrientation(orientationInfo.orientation);
         };

         const subscription = ScreenOrientation.addOrientationChangeListener(onChangeOrientation);

         return () => {
            ScreenOrientation.removeOrientationChangeListener(subscription);
         };
      }
   }, []);


   const StackScreen = (
      name: keyof MainStackParamList,
      component: () => React.JSX.Element | null | false,
      headerTitle: string
   ) => {
      return (
         <Stack.Screen
            name={name}
            component={component}
            options={{
               headerStyle: { backgroundColor: colors.mainBg },
               headerTintColor: colors.headerTintColor,
               headerTitle: headerTitle,
               headerBackButtonDisplayMode: headerBackButtonDisplayMode,
            }}
            key={name}
         />
      )
   }

   const HeaderTitle = () => (
      <View style={{
         flexDirection: 'row',
         alignItems: 'center',
         gap: 10,
         paddingVertical: 7,
         justifyContent: 'center'
      }}>
         <Image
            style={{
               width: Platform.OS === 'ios' && (orientation === 3 || orientation === 4) ? 22 : Platform.OS === 'ios' ? 35 : 50,
               height: Platform.OS === 'ios' && (orientation === 3 || orientation === 4) ? 22 : Platform.OS === 'ios' ? 35 : 50,
               resizeMode: 'contain'
            }}
            source={require('@/assets/images/logo120.png')}
         />
         <CustomTextBold
            style={{
               color: colors.mainBgText,
               fontSize: 18
            }}
         >
            Evidence
         </CustomTextBold>
      </View>
   )


   return (
      <Stack.Navigator
         initialRouteName={"HomeScreen"}
         screenOptions={{
            animation: 'slide_from_right',
         }}
      >
         <Stack.Screen
            name="HomeScreen"
            component={HomeScreen}
            options={{
               headerTitle: () => <HeaderTitle />,
               headerStyle: { backgroundColor: colors.mainBg },
               headerBackButtonDisplayMode: headerBackButtonDisplayMode,
            }}
         />
         {mainStacksList.map(({ name, component, headerTitle, auth, exc }) => {
            if (auth === 1 && !user) return null;
            if (auth === 0 && user && !exc) return null;

            return StackScreen(name as keyof MainStackParamList, component, headerTitle);
         })}
         <Stack.Screen
            name="WebView"
            component={WebViewScreen}
            options={{
               headerStyle: { backgroundColor: colors.mainBg },
               headerTintColor: colors.headerTintColor,
               headerTitle: "Evidence",
               headerBackButtonDisplayMode: headerBackButtonDisplayMode,
            }}
         />
      </Stack.Navigator>
   )
}