import React, { useEffect, useState } from 'react'
import { IResponseData, LINKS } from '@/src/types/types'
import { Platform, View } from 'react-native'
import { useQuery } from '@tanstack/react-query'
import { fetchUseQuery } from '@/src/functions/fetchUseQuery'
import { MyTabs } from '@/src/navigation/tabs'
import AppClose from '@/src/components/AppClose'
import AppUpdate from '@/src/components/AppUpdate'
import Constants from 'expo-constants';
import { useSafeAreaInsets } from 'react-native-safe-area-context'
import * as ScreenOrientation from 'expo-screen-orientation';
import { useTheme } from '@/src/hooks/useTheme'

export type TypeIsAppClose = {
   is_close_version: string,
   is_close_version_update: number,
   is_close: number,
   is_close_link: string,
}

export type IRoot = {
   initialUrl?: string,
   isNavContainerReady: boolean
}

export default function Root({
   initialUrl,
   isNavContainerReady
}: IRoot) {
   const insets = useSafeAreaInsets();
   const [orientation, setOrientation] = React.useState<number>()
   const [isAppCloseVersion, setIsAppCloseVersion] = useState(false)
   const { colors } = useTheme()

   const { data, isSuccess } = useQuery({
      queryKey: ['app-close'],
      queryFn: async () => {
         return fetchUseQuery<IResponseData<TypeIsAppClose>>(
            'post',
            LINKS.ISAPPCLOSE,
            Platform.OS
         )
      },
   })

   useEffect(() => {
      if (isSuccess &&
         data && data.data && data.data.length > 0 &&
         data.data[0].is_close !== 1 &&
         data.data[0].is_close_version !== Constants?.expoConfig?.version &&
         data.data[0]?.is_close_version_update !== 1) {
         setIsAppCloseVersion(true)
      }
   }, [data, isSuccess])

   useEffect(() => {
      if (Platform.OS !== 'android') return;

      const updateOrientation = async () => {
         const scrOrientation = await ScreenOrientation.getOrientationAsync();
         setOrientation(scrOrientation)
      }
      updateOrientation();

      const subscription = ScreenOrientation.addOrientationChangeListener(updateOrientation);
      return () => {
         ScreenOrientation.removeOrientationChangeListener(subscription);
      };
   }, [])


   return (
      <View style={{
         flex: 1,
         backgroundColor: colors.mainBg,
         paddingBottom: Platform.OS === 'android' && orientation === ScreenOrientation.Orientation.PORTRAIT_UP ? insets.bottom : 0,
         paddingLeft: Platform.OS === 'android' && orientation === ScreenOrientation.Orientation.LANDSCAPE_LEFT || orientation === ScreenOrientation.Orientation.LANDSCAPE_RIGHT ? insets.left : 0,
         paddingRight: Platform.OS === 'android' && orientation === ScreenOrientation.Orientation.LANDSCAPE_LEFT || orientation === ScreenOrientation.Orientation.LANDSCAPE_RIGHT ? insets.right : 0,
      }}>
         {data && data.data && data.data.length > 0 &&
            (data.data[0].is_close === 1 ||
               (data.data[0].is_close_version !== Constants?.expoConfig?.version &&
                  data.data[0].is_close_version_update === 1)
            ) ? (
            <AppClose
               isAppCloseLink={data.data[0].is_close_link}
            />
         ) : (
            <>
               <MyTabs
                  initialUrl={initialUrl}
                  isNavContainerReady={isNavContainerReady}
               />
               {isAppCloseVersion && data && data.data && data.data.length > 0 && (
                  <AppUpdate
                     setIsAppCloseVersion={setIsAppCloseVersion}
                     isAppCloseLink={data.data[0].is_close_link}
                  />
               )}
            </>
         )}
      </View>
   )
}
