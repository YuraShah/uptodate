import { deepLinkScreens } from "@/src/navigation/deepLinkScreens";
import { excludeIosParams, excludeIosScreens } from "@/src/navigation/excludeIosRoutes";
import { Platform } from "react-native";

export function findMatchingScreen(path: string) {
   for (const [screen, pattern] of Object.entries(deepLinkScreens)) {
      const regexPattern = pattern.replace(/:\w+/g, '([^/]+)');
      const regex = new RegExp(`^${regexPattern}$`);
      const match = path.match(regex);

      if (match) {
         const paramNames = (pattern.match(/:\w+/g) || []).map((param) => param.substring(1));
         const paramValues = match.slice(1);
         const params = Object.fromEntries(paramNames.map((name, index) => [name, paramValues[index]]));

         if (Platform.OS === 'ios') {
            const hasExcludedParam = Object.values(params).some(param =>
               excludeIosParams.includes(param)
            );

            if (excludeIosScreens.includes(screen) || hasExcludedParam) {
               // return `https://evidence.am/${path}`;
               return null;
            }
         }

         return { screen, params };
      }
   }
   return null;
}