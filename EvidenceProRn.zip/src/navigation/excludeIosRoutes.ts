export const excludeIosScreens = [
   "Drug"
]

export const excludeIosParams = [
   'gcsconverter',
   'cha2ds2vasc',
   'dent-ta-max',
   'acetaminophen-toxicity-assessment',
   'csconverter-mineral',
   'benzodiazepine-conversion',
]