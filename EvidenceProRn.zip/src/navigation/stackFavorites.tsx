import { createNativeStackNavigator } from "@react-navigation/native-stack";
import { useTheme } from "@/src/hooks/useTheme";
import { FavoritesParamList } from "@/src/types/navigationTypes";
import Favorites from "@/src/navigation/screens/Favorites";
import { headerBackButtonDisplayMode } from "@/src/navigation/stack";

const Stack = createNativeStackNavigator();

const stacksFavorites = [
   {
      name: "FavoritesHome",
      component: Favorites,
      headerTitle: "Избранное"
   },
]

export const StackFavorites = () => {
   const { colors } = useTheme()

   const StackScreen = (
      name: keyof FavoritesParamList,
      component: () => React.JSX.Element | null | false,
      headerTitle: string
   ) => (
      <Stack.Screen
         name={name}
         component={component}
         options={{
            headerStyle: { backgroundColor: colors.mainBg },
            headerTintColor: colors.headerTintColor,
            headerTitle: headerTitle,
            headerBackButtonDisplayMode: headerBackButtonDisplayMode
         }}
         key={name}
      />
   )

   return (
      <Stack.Navigator
         initialRouteName="FavoritesHome"
         screenOptions={{
            animation: 'slide_from_right',
         }}
      >
         {stacksFavorites.map(({ name, component, headerTitle }) => {
            return StackScreen(name as keyof FavoritesParamList, component, headerTitle);
         })}
      </Stack.Navigator>
   )
}