import { createNativeStackNavigator } from "@react-navigation/native-stack";
import { useTheme } from "@/src/hooks/useTheme";
import Settings from "@/src/navigation/screens/Settings";
import About from "@/src/navigation/screens/About";
import Privacy from "@/src/navigation/screens/Privacy";
import PaymentReturns from "@/src/navigation/screens/PaymentReturns";
import UserChangeEmail from "@/src/navigation/screens/UserChangeEmail";
import UserChangePassword from "@/src/navigation/screens/UserChangePassword";
import UserDeleteAcc from "@/src/navigation/screens/UserDeleteAcc";
import { useAppSelector } from "@/src/redux/hooks";
import { SettingsParamList } from "@/src/types/navigationTypes";
import Disclaimer from "@/src/navigation/screens/Disclaimer";
import { headerBackButtonDisplayMode } from "@/src/navigation/stack";

const Stack = createNativeStackNavigator();

const stacksSetting = [
   {
      name: "SettingHome",
      component: Settings,
      headerTitle: "Настройки"
   },
   {
      name: "About",
      component: About,
      headerTitle: "О нас"
   },
   {
      name: "Privacy",
      component: Privacy,
      headerTitle: "Условия использования, ответственность и конфиденциальность"
   },
   {
      name: "PaymentReturns",
      component: PaymentReturns,
      headerTitle: "Условия оплаты и возврата"
   },
   {
      name: "Disclaimer",
      component: Disclaimer,
      headerTitle: "Отказ от ответсвенности"
   }
]

const stacksSettingModal = [
   {
      name: "ChangeEmail",
      component: UserChangeEmail,
      headerTitle: "Измененение адреса электронной почты"
   },
   {
      name: "ChangePassword",
      component: UserChangePassword,
      headerTitle: "Изменение пароля"
   },
   {
      name: "DeleteAcc",
      component: UserDeleteAcc,
      headerTitle: "Удаление аккаунта"
   },
]

export const StackSettings = () => {
   const { colors } = useTheme()
   const { user } = useAppSelector(state => state.authStore)

   const StackScreen = (
      name: keyof SettingsParamList,
      component: () => React.JSX.Element | null | false,
      headerTitle: string
   ) => (
      <Stack.Screen
         name={name}
         component={component}
         options={{
            headerStyle: { backgroundColor: colors.mainBg },
            headerTintColor: colors.headerTintColor,
            headerTitle: headerTitle,
            headerBackButtonDisplayMode: headerBackButtonDisplayMode
         }}
         key={name}
      />
   )

   return (
      <Stack.Navigator
         initialRouteName="SettingHome"
         screenOptions={{
            animation: 'slide_from_right',
         }}
      >
         <Stack.Group>
            {stacksSetting.map(({ name, component, headerTitle }) => {
               return StackScreen(name as keyof SettingsParamList, component, headerTitle);
            })}
         </Stack.Group>
         {user ? (
            <Stack.Group screenOptions={{ presentation: 'modal', animation: 'slide_from_bottom' }}>
               {stacksSettingModal.map(({ name, component, headerTitle }) => {
                  return StackScreen(name as keyof SettingsParamList, component, headerTitle);
               })}
            </Stack.Group>
         ) : null}
      </Stack.Navigator>
   )
}