import { MainStackParamList, SettingsParamList } from "@/src/types/navigationTypes"
import Register from "@/src/navigation/screens/Register"
import ForgotPassword from "@/src/navigation/screens/ForgotPassword"
import VerifyResend from "@/src/navigation/screens/VerifyResend"
import DrugsMenu from "@/src/navigation/screens/Drugs/DrugsMenu"
import Calcs from "@/src/navigation/screens/Calcs/Calcs"
import DrugDisInt from "@/src/navigation/screens/Drugs/Interaction/DrugDisInt"
import DrugDisIntItem from "@/src/navigation/screens/Drugs/Interaction/DrugDisIntItem"
import DrugHeptox from "@/src/navigation/screens/Drugs/Interaction/DrugHeptox"
import DrugHeptoxItem from "@/src/navigation/screens/Drugs/Interaction/DrugHeptoxItem"
import DrugNephtox from "@/src/navigation/screens/Drugs/Interaction/DrugNephtox"
import DrugNephtoxDisease from "@/src/navigation/screens/Drugs/Interaction/DrugNephtoxDisease"
import DrugNephtoxItem from "@/src/navigation/screens/Drugs/Interaction/DrugNephtoxItem"
import DrugNephtoxMorphology from "@/src/navigation/screens/Drugs/Interaction/DrugNephtoxMorphology"
import DrugOlders from "@/src/navigation/screens/Drugs/Interaction/DrugOlders"
import DrugOldersItem from "@/src/navigation/screens/Drugs/Interaction/DrugOldersItem"
import DrugPregnancy from "@/src/navigation/screens/Drugs/Interaction/DrugPregnancy"
import DrugPregnancyItem from "@/src/navigation/screens/Drugs/Interaction/DrugPregnancyItem"
import DrugPulmtox from "@/src/navigation/screens/Drugs/Interaction/DrugPulmtox"
import DrugPulmtoxDrug from "@/src/navigation/screens/Drugs/Interaction/DrugPulmtoxDrug"
import DrugPulmtoxItem from "@/src/navigation/screens/Drugs/Interaction/DrugPulmtoxItem"
import DrugPulmtoxPattern from "@/src/navigation/screens/Drugs/Interaction/DrugPulmtoxPattern"
import DrugPulmtoxSubpattern from "@/src/navigation/screens/Drugs/Interaction/DrugPulmtoxSubpattern"
import DrugPulmtoxSubstance from "@/src/navigation/screens/Drugs/Interaction/DrugPulmtoxSubstance"
import DrugQt from "@/src/navigation/screens/Drugs/Interaction/DrugQt"
import DrugQtFactor from "@/src/navigation/screens/Drugs/Interaction/DrugQtFactor"
import DrugQtIndication from "@/src/navigation/screens/Drugs/Interaction/DrugQtIndication"
import DrugNephtoxDrug from "@/src/navigation/screens/Drugs/Interaction/DrugNephtoxDrug"
import DrugNephtoxDiseaseItem from "@/src/navigation/screens/Drugs/Interaction/DrugNephtoxDiseaseItem"
import DrugNephtoxMorphologyItem from "@/src/navigation/screens/Drugs/Interaction/DrugNephtoxMorphologyItem"
import DrugQtDrugs from "@/src/navigation/screens/Drugs/Interaction/DrugQtDrugs"
import DrugQtItem from "@/src/navigation/screens/Drugs/Interaction/DrugQtItem"
import CalcsItem from "@/src/navigation/screens/Calcs/CalcsItem"
import DrugDisl from "@/src/navigation/screens/Drugs/Interaction/DrugDisl"
import DrugMethem from "@/src/navigation/screens/Drugs/Interaction/DrugMethem"
import MenuCross from "@/src/navigation/screens/Drugs/CrossReactivity/MenuCross"
import CrossItem from "@/src/navigation/screens/Drugs/CrossReactivity/CrossItem"
import SignIn from "@/src/navigation/screens/SignIn"
import Payment from "./screens/Payment"

export type IStacks = {
   name: keyof MainStackParamList | keyof SettingsParamList,
   component: () => React.JSX.Element | null | false,
   headerTitle: string,
   auth?: 0 | 1,
   exc?: boolean
}

export const mainStacksList: IStacks[] = [
   {
      name: "SignIn",
      component: SignIn,
      headerTitle: "Вход в аккаунт",
      auth: 0
   },
   {
      name: "Register",
      component: Register,
      headerTitle: "Регистрация",
      auth: 0
   },
   {
      name: "ForgotPassword",
      component: ForgotPassword,
      headerTitle: "Восстановления пароля",
      auth: 0
   },
   {
      name: "VerifyResend",
      component: VerifyResend,
      headerTitle: "Отправка кода потверждения",
      auth: 0
   },
   {
      name: "Payment",
      component: Payment,
      headerTitle: "Оплата подписки",
      auth: 1
   },
   {
      name: "DrugsMenu",
      component: DrugsMenu,
      headerTitle: "Лекарства",
      auth: 1
   },
   {
      name: "DrugDisInt",
      component: DrugDisInt,
      headerTitle: "Лекарство - болезнь взаимодействие",
      auth: 1
   },
   {
      name: "DrugDisIntItem",
      component: DrugDisIntItem,
      headerTitle: "Лекарство - болезнь взаимодействие",
      auth: 1
   },
   {
      name: "DrugPregnancy",
      component: DrugPregnancy,
      headerTitle: "Лекарство - беременная взаимодействие",
      auth: 1
   },
   {
      name: "DrugPregnancyItem",
      component: DrugPregnancyItem,
      headerTitle: "Лекарство - беременная взаимодействие",
      auth: 1
   },
   {
      name: "DrugHeptox",
      component: DrugHeptox,
      headerTitle: "Лекарство - печень взаимодействие",
      auth: 1
   },
   {
      name: "DrugHeptoxItem",
      component: DrugHeptoxItem,
      headerTitle: "Лекарство - печень взаимодействие",
      auth: 1
   },
   {
      name: "DrugPulmtox",
      component: DrugPulmtox,
      headerTitle: "Лекарство - дыхательная система взаимодействие",
      auth: 1
   },
   {
      name: "DrugPulmtoxDrug",
      component: DrugPulmtoxDrug,
      headerTitle: "Лекарство - дыхательная система взаимодействие",
      auth: 1
   },
   {
      name: "DrugPulmtoxSubstance",
      component: DrugPulmtoxSubstance,
      headerTitle: "Лекарство - дыхательная система взаимодействие",
      auth: 1
   },
   {
      name: "DrugPulmtoxItem",
      component: DrugPulmtoxItem,
      headerTitle: "Лекарство - дыхательная система взаимодействие",
      auth: 1
   },
   {
      name: "DrugPulmtoxSubpattern",
      component: DrugPulmtoxSubpattern,
      headerTitle: "Лекарство - дыхательная система взаимодействие",
      auth: 1
   },
   {
      name: "DrugPulmtoxPattern",
      component: DrugPulmtoxPattern,
      headerTitle: "Лекарство - дыхательная система взаимодействие",
      auth: 1
   },
   {
      name: "DrugNephtox",
      component: DrugNephtox,
      headerTitle: "Лекарство - почки взаимодействие",
      auth: 1
   },
   {
      name: "DrugNephtoxDrug",
      component: DrugNephtoxDrug,
      headerTitle: "Лекарство - почки взаимодействие",
      auth: 1
   },
   {
      name: "DrugNephtoxItem",
      component: DrugNephtoxItem,
      headerTitle: "Лекарство - почки взаимодействие",
      auth: 1
   },
   {
      name: "DrugNephtoxDisease",
      component: DrugNephtoxDisease,
      headerTitle: "Лекарство - почки взаимодействие",
      auth: 1
   },
   {
      name: "DrugNephtoxDiseaseItem",
      component: DrugNephtoxDiseaseItem,
      headerTitle: "Лекарство - почки взаимодействие",
      auth: 1
   },
   {
      name: "DrugNephtoxMorphology",
      component: DrugNephtoxMorphology,
      headerTitle: "Лекарство - почки взаимодействие",
      auth: 1
   },
   {
      name: "DrugNephtoxMorphologyItem",
      component: DrugNephtoxMorphologyItem,
      headerTitle: "Лекарство - почки взаимодействие",
      auth: 1
   },
   {
      name: "DrugOlders",
      component: DrugOlders,
      headerTitle: "Лекарство - ≥65 лет взаимодействие",
      auth: 1
   },
   {
      name: "DrugOldersItem",
      component: DrugOldersItem,
      headerTitle: "Лекарство - ≥65 лет взаимодействие",
      auth: 1
   },
   {
      name: "DrugQt",
      component: DrugQt,
      headerTitle: "Лекарство - QT взаимодействие",
      auth: 1
   },
   {
      name: "DrugQtDrugs",
      component: DrugQtDrugs,
      headerTitle: "Лекарство - QT взаимодействие",
      auth: 1
   },
   {
      name: "DrugQtItem",
      component: DrugQtItem,
      headerTitle: "Лекарство - QT взаимодействие",
      auth: 1
   },
   {
      name: "DrugQtFactor",
      component: DrugQtFactor,
      headerTitle: "Лекарство - QT взаимодействие",
      auth: 1
   },
   {
      name: "DrugQtIndication",
      component: DrugQtIndication,
      headerTitle: "Лекарство - QT взаимодействие",
      auth: 1
   },
   {
      name: "DrugMethem",
      component: DrugMethem,
      headerTitle: "Лекарство - метгемоглобинемия взаимодействие",
      auth: 1
   },
   {
      name: "DrugDisl",
      component: DrugDisl,
      headerTitle: "Лекарство - системная волчанка взаимодействие",
      auth: 1
   },
   {
      name: "MenuCross",
      component: MenuCross,
      headerTitle: "Перекрестная гиперчувствительность",
      auth: 1
   },
   {
      name: "CrossItem",
      component: CrossItem,
      headerTitle: "Перекрестная гиперчувствительность",
      auth: 1
   },
   {
      name: "Calcs",
      component: Calcs,
      headerTitle: "Калькуляторы",
      auth: 0,
      exc: true
   },
   {
      name: "CalcsItem",
      component: CalcsItem,
      headerTitle: "Калькуляторы",
      auth: 0,
      exc: true
   }
]