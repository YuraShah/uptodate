import { createNavigationContainerRef } from "@react-navigation/native";
import { MainStackParamList } from "@/src/types/navigationTypes";

export const navigationRef = createNavigationContainerRef<MainStackParamList>();

export function navigate(
   name: keyof MainStackParamList | any,
   params?: MainStackParamList[keyof MainStackParamList]
) {
   if (navigationRef.isReady()) {
      if(params) {
         navigationRef.navigate(name, params)
      } else {
         navigationRef.navigate(name)
      }
      
   }
}