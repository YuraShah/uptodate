import React from 'react'
import { setLogoutCallback } from '@/src/redux/features/auth/logoutAction';
import { store } from '@/src/redux/store';
import { resetAuth } from '@/src/redux/features/auth/authSlice';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { Provider } from 'react-redux';
import { ClickOutsideProvider } from 'react-native-click-outside';
import Toast from '@/src/components/Toast';
import { SafeAreaProvider } from 'react-native-safe-area-context';
import { NavigationContainer } from '@react-navigation/native';
import Root from '@/src/navigation';
import { navigationRef } from '@/src/navigation/rootNavigation'
import * as SplashScreen from 'expo-splash-screen';
import * as Linking from 'expo-linking';
import { Platform } from 'react-native';
import { SystemBars } from "react-native-edge-to-edge";


SplashScreen.preventAutoHideAsync();
SplashScreen.setOptions({
  fade: true,
});

setLogoutCallback(() => {
  store.dispatch(resetAuth());
});

const queryClient = new QueryClient()

export default function App() {
  const [initialUrl, setInitialUrl] = React.useState<string>();
  const [isNavContainerReady, setIsNavContainerReady] = React.useState<boolean>(false)

  const fetchInitialUrl = async () => {
    const url = await Linking.getInitialURL();

    if (!url || (!url.startsWith('evidenceru://') && !url.startsWith('https://ru.evidence.am'))) return;

    const { scheme, hostname, path } = Linking.parse(url);

    if (scheme === 'evidenceru') {
      setInitialUrl(`${hostname}/${path}`);
    } else {
      setInitialUrl(path ?? undefined);
    }
  };

  React.useEffect(() => {
    const handleUrlChange = (event: any) => {
      const url = event.url;

      if (!url || (!url.startsWith('evidenceru://') && !url.startsWith('https://ru.evidence.am'))) return;

      const { scheme, hostname, path } = Linking.parse(url);

      if (scheme === 'evidenceru') {
        setInitialUrl(`${hostname}/${path}`);
      } else {
        setInitialUrl(path ?? undefined);
      }
    };

    const listener = Linking.addEventListener('url', handleUrlChange);

    return () => {
      listener.remove();
    };
  }, []);

  React.useEffect(() => {
    fetchInitialUrl();
  }, [])

  return (
    <Provider store={store}>
      <QueryClientProvider client={queryClient}>
        <ClickOutsideProvider>
          <Toast />
          <SystemBars
            style={{
              statusBar: "light",
              navigationBar: Platform.OS === 'ios' ? undefined : "light"
            }}
          />
          <SafeAreaProvider>
            <NavigationContainer
              ref={navigationRef}
              onReady={() => setIsNavContainerReady(true)}
            >
              <Root
                initialUrl={initialUrl}
                isNavContainerReady={isNavContainerReady}
              />
            </NavigationContainer>
          </SafeAreaProvider>
        </ClickOutsideProvider>
      </QueryClientProvider>
    </Provider >
  );
}
